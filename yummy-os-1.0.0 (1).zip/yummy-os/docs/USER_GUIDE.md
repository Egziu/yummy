# Quick guides

## Cashier (shop)
1. Open `/pos` on the counter device → tap your name → enter your PIN.
2. First login of the day: count the opening float → **Open shift**.
3. Tap products (or scan the barcode / type and press Enter). Tap a line for − / + / % / Remove.
4. **Charge (F9)** → choose the payment. Cash: tap a quick amount, give the change shown. telebirr / CBE Birr / bank: type the transaction reference from the customer's SMS.
5. **New sale.** Print the receipt if the customer wants it.
6. The pill at the top shows **Online** or **Offline · N pending**. Offline is fine — keep selling. Never clear the browser data.
7. End of day: **Close shift** → count the drawer → if it differs, your manager enters their PIN.

Refunds: **Refund** → pick the receipt (or type its number) → quantities, reason → your manager approves with their own PIN.

## Café staff
Choose **Dine-in + Table** or **Takeaway**. Drinks with options open a modifier panel. **Send to kitchen** sends new items to the barista / kitchen / dessert screens. Orders stay on the table until paid — even after a refresh.

## Barista / kitchen screen
Tickets appear by station. Tap **Start → Ready → Served**. Tickets older than 8 minutes get a red outline.

## Shop / café manager (back office `/office`)
Request stock (**Transfers → New request**), receive deliveries (**Receive**: enter good and damaged quantities), see your branch dashboard, investigate discrepancies.

## Warehouse
**Transfers**: approve (stock is reserved first-expiry-first), dispatch (driver), see in-transit. **Warehouse map**: click a rack to see lots; *Edit layout* to drag racks. **Inventory**: expiry watch → request disposal; approve adjustments (someone else must have requested them).

## Production
**Smart planner** suggests batches from recent sales and stock. **Production orders**: approve → release (ingredients issued) → complete (good units, scrap, QC). Recipes: an author creates a version in admin; a different person approves it.

## Finance
**Accounting**: P&L by branch, trial balance, journals, lock a period after month-end review. **Procurement**: invoices held by the three-way match need a manager release; the person who recorded an invoice cannot pay it.

## Management
**Executive dashboard** (all outlets, live or provisional), **Control tower** (network, flow, workflows), **Quality & recall** (trace a lot, hold it), **Terminals & sync** (enrol/revoke devices, review rejected operations), **Audit trail**.
