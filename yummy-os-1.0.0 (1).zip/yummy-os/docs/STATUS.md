# Release status — what is done, what is not

Release 1.0.0 is a **working foundation**: the transactional core (ledger, stock, production, distribution,
procurement, POS with offline sync, accounting, security, backups) is implemented, integrated and tested. Several
modules from the master prompt are **not built yet**. Nothing here is "production-approved": per Part 40, that
decision belongs to Yummy's business, finance, security and technical owners after user acceptance testing.

Legend: ✅ implemented & tested · 🟡 partial (what exists is real; listed gaps remain) · ⬜ not started

| Part | Area | Status | Notes / gaps |
|---|---|---|---|
| 2 | Organisation (HQ, production, warehouse, 3 shops, 2 cafés, unlimited branches) | ✅ | Branches/locations are configuration. |
| 3 | Architecture | 🟡 | Django/DRF/PostgreSQL/React-TS/PWA done. **No Redis/Celery** (not needed yet; long exports run synchronously, row-limited). Real-time = 5-second polling, not WebSockets. OpenAPI schema is generated but incomplete for function views. |
| 4 | Premium UX | 🟡 | POS, KDS, back office with light/dark, keyboard shortcuts (F2, F9), barcode wedge, Amharic labels. Missing: command palette, saved filters, onboarding tours, Tigrinya translations, full WCAG audit. |
| 5 | Identity & access | 🟡 | 15 starter roles, custom roles, branch-scoped RBAC server-side, SoD on PO, invoice/payment, transfers, adjustments, recipes, refunds; lockout; device enrolment & revocation. Missing: MFA, step-up auth, session list / forced logout UI. |
| 6 | Product master | 🟡 | Kinds, SKU/barcode, local names, units, VAT, shelf life, reorder points, allergens, effective-dated prices, modifiers. Variants are modelled as separate SKUs; no product images, unit conversions or effective-dated cost/tax history. |
| 7 | Recipes & costing | ✅ | Versioned, nested/phantom, cycle detection, waste %, scaling, cost simulation, actual batch costing with labour-hour overhead. Gaps: substitution rules, equipment capacity, posted variance accounts. |
| 8 | Production | 🟡 | Order lifecycle, FEFO issue, all-or-nothing release, yield/scrap, lots with expiry, QC hold, smart planner. Missing: workstation tablet screens, downtime, multi-stage tracking. |
| 9 | Inventory & warehouse | 🟡 | Ledger, lots, FEFO, reservations, in-transit, quarantine/holds, adjustments with approval, discrepancies, valuation. Missing: stock-count module (cycle/blind counts), automatic purchase replenishment, unit conversions. |
| 10 | Live warehouse map | ✅ | Real locations, states, capacity bars, pick heatmap, drag-and-drop editor, activity feed, stale-data badge. Expiry/value heatmap variants not added. |
| 11 | Control tower | 🟡 | Network map with live transfers, supply-chain stages, workflow progress. Missing: configurable workflow engine (stages/approvals are coded, thresholds are settings). |
| 12 | Procurement | 🟡 | PO, approval, receipt with lots/rejections, 3-way match with tolerances, held invoices, duplicate protection, payments. Missing: RFQ/quotations, budgets, credit notes, supplier returns, PO creation form in the UI (API exists; admin can be used). |
| 13 | Transfers & distribution | ✅ | Full custody chain with partial approval, damage, shortage, cancel. Missing: route/vehicle planning. |
| 14 | Retail POS | 🟡 | Offline sales, cash/telebirr/CBE Birr/bank/card (reference capture), split tender, discounts with approval, hold/resume, refunds with approval, cash in/out, shift close with over/short. **No live payment-provider integration** (references are typed in); no gift cards/customer credit/exchanges; no cash-drawer kick or ESC/POS printer driver (browser printing used). |
| 15 | Café | 🟡 | Tables & takeaway tabs, modifiers, kitchen tickets, KDS by station, recipe consumption. Missing: table transfer/merge, split bills, reservations. KDS needs network to the server. |
| 16 | Customers & loyalty | ⬜ | Only customer name/TIN on sales. |
| 17 | Accounting | 🟡 | GL, posting rules, cost centres, periods & locking, reversal, trial balance, P&L by branch, journals. Missing: balance sheet & cash-flow statements, AR/AP ageing reports, bank reconciliation, overhead allocation rules, budgets, Ethiopian e-invoicing/fiscal device integration. |
| 18 | HR & payroll | ⬜ | |
| 19 | Expenses & budgeting | ⬜ | |
| 20 | Food safety & traceability | 🟡 | Lot holds, expiry blocking, disposal workflow, forward recall trace. Missing: HACCP checklists, temperature logs, corrective actions. |
| 21 | Fixed assets & maintenance | ⬜ | |
| 22 | Reporting & export | 🟡 | CSV exports (sales, stock, trial balance) with permission checks, audit and formula-injection protection; printable receipts. Missing: PDF/XLSX, report builder, scheduled reports. |
| 23 | Executive dashboard | ✅ | KPIs with definitions, live/provisional labelling, trend, ranking, best sellers, heatmap, expiry, approvals, fact-based briefing. |
| 24 | Forecasting & AI | 🟡 | Transparent statistical planner. Missing: forecast accuracy tracking, anomaly detection, AI assistant. |
| 25 | Notifications & tasks | ⬜ | Dashboard briefing and badges only. |
| 26 | Customisation | 🟡 | Settings table, price lists, roles, map layout, Django admin. No custom fields. |
| 27 | Data import | ⬜ | Use admin or scripts for now. |
| 28 | Security | 🟡 | See VERIFICATION.md. Missing: MFA, dependency/secret/SAST scanning in CI, SBOM, independent penetration test. |
| 29 | Offline continuity | ✅ | Verified in a real browser including cold reload while offline. |
| 30 | Backup & recovery | ✅ | WAL archiving, base + logical backups, encryption option, PITR script, executed drill. Off-site copy target must be configured by you. |
| 31 | Performance | 🟡 | Sync p95 153 ms at 5 concurrent terminals (3 workers, dev VM). No large-volume load test yet. |
| 33 | Scenarios A–J | ✅ | A–I automated tests; J executed as `pitr_drill.sh`. |
| 34 | Invariants | ✅ | DB constraints + triggers + `verify_integrity`. |
| 36 | Deployment | 🟡 | Dockerfile, Compose, nginx, CI written. **The Docker build was NOT RUN in this environment** (no container registry access) — run `docker compose build` before go-live. |
| 40 | Acceptance gates | ⬜ | UAT with cashiers, bakers, warehouse, accountants and executives has not happened. |

## Suggested next phases
1. **Pilot readiness:** stock-count module, PO/supplier forms in UI, ESC/POS printing + cash drawer, telebirr/CBE Birr API (when credentials exist), MFA for managers, UAT at one shop + one café.
2. **Finance:** balance sheet, cash flow, AR/AP ageing, bank reconciliation, expenses & budgets, e-invoicing per current Ethiopian rules.
3. **People:** HR, attendance, payroll (legally reviewed rules).
4. **Growth:** loyalty, notifications, report builder, PDF/XLSX, HACCP logs, assets & maintenance, forecasting accuracy, assistant.
