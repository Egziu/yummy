# Architecture

## Shape

```
 Counter devices (PWA)                     Server (one database of record)
 ┌──────────────────────┐   HTTPS/JSON   ┌───────────────────────────────────────────┐
 │ POS  ─ IndexedDB      │──────────────▶│ nginx (TLS, headers) → gunicorn → Django   │
 │  outbox · sales · tabs│◀──────────────│  apps: iam · catalog · inventory · pos ·   │
 │  catalogue · PINs     │  bootstrap    │  production · transfers · procurement ·    │
 │ Service worker (shell)│               │  accounting · reports · core (audit, seq)  │
 └──────────────────────┘               │              │                            │
 KDS screen ── polls /api/kds            │        PostgreSQL 16  ── WAL archive ──▶ backups
 Back office ── /office (online)         └───────────────────────────────────────────┘
```

A **modular monolith**: each domain is a Django app with its own models and a `services.py` holding all business
rules. Views are thin; they authenticate, check permissions and call services. Nothing writes stock or ledger rows
except the services, and the database enforces what must never happen even if code is wrong.

## Decisions (ADR summary)

| # | Decision | Why |
|---|---|---|
| 1 | Django 5.2 LTS + DRF, PostgreSQL 16, React 19/TypeScript PWA | Mature, supported to 2028, transactional integrity, one codebase for POS/KDS/back office. |
| 2 | Modular monolith, no microservices | Five outlets do not need distributed systems; boundaries are clean enough to split later. |
| 3 | **Offline-first POS as a PWA with IndexedDB** (not a native app) | Runs on any Android tablet / Windows PC browser, installs from the URL, updates itself. Limitation: browser storage can be cleared by the user or OS — mitigated by syncing every few seconds when online, the server-side receipt counter and the sync monitor showing devices with queued work. |
| 4 | Client-generated UUIDs for every operation + server idempotency ledger (`SyncOperation`) | Retries after lost responses never duplicate a sale, refund, shift or cash movement. |
| 5 | Strict in-order upload; RETRY stops the batch | A sale can never arrive before its shift; a refund never before its sale. |
| 6 | Physical events are never rejected for stock | Bread already handed over must be recorded. Oversell books negative stock **and** a `StockDiscrepancy` for investigation. Price differences are flagged, not rejected. Only malformed / unauthorised operations are REJECTED, and they are kept for manager review. |
| 7 | Shared integer pricing algorithm (cents · milli-units · basis points), tested against `spec/pricing_cases.json` on both sides | Offline receipts equal the server's books to the cent. |
| 8 | Immutable ledgers enforced by PostgreSQL triggers | `StockMovement`, `JournalEntry/Line`, `AuditLog` reject UPDATE/DELETE. Corrections are reversing entries. |
| 9 | Deferred constraint trigger: every journal must balance at COMMIT | A coding error cannot leave the books out of balance. |
| 10 | Hash-chained audit log | Tampering by a database superuser is detectable (`verify_integrity`). |
| 11 | Inventory valuation = enterprise moving-average cost; picking = FEFO | Simple, auditable, and independent: the operational picking order does not change valuation. |
| 12 | Production at **actual batch cost** (materials issued + labour + overhead by labour hours); standard cost for variance only | Never mixes standard and actual valuation (spec 7.3). |
| 13 | Device enrolment with one-time codes; per-cashier PIN verifiers delivered to enrolled devices | No shared passwords; every sale is attributable to a person; works offline. Limitation: a stolen, enrolled device holds PIN verifiers (PBKDF2, 120k iterations) — revoke it in *Terminals & sync*. |
| 14 | Read-only projections for maps and dashboards | The warehouse map and control tower never change stock; they render committed state every 5 s and show a stale-data badge if the server is unreachable. |

## Sync protocol

`POST /api/pos/sync` with `X-Terminal-Token` and `{ops: [{op_id, kind, created_at, payload}], pending_count}`.

| kind | effect on server |
|---|---|
| `shift_open` | creates the shift (UUID from the device) |
| `sale` | validates cashier rights at the branch, recomputes every line with the canonical algorithm, checks payments = total, flags price/tax differences, consumes stock FEFO (recipes exploded for menu items, modifiers consume ingredients), posts revenue/VAT/payment and COGS journals |
| `refund` | requires a different approver with `pos.refund_approve`, prevents excess refunds (row lock + DB check), restocks or not, posts returns |
| `cash_move` | cash drop / float top-up with journal |
| `kitchen_ticket` | ticket for the KDS station |
| `shift_close` | expected cash computed on the server from synced data; over/short posted |

Responses per op: `APPLIED` (drop from outbox), `REJECTED` (keep for review), `RETRY` (keep; later ops wait).
`GET /api/pos/bootstrap` delivers catalogue, branch prices (effective-dated, branch lists override the default),
modifiers, cashier PIN verifiers, settings and the last receipt number for the terminal.

## Posting rules (default chart, configurable in `AccountMapping`)

| Event | Debit | Credit |
|---|---|---|
| Goods receipt | Inventory (raw / finished) | Goods received not invoiced |
| Matched supplier invoice | GRNI, VAT input, purchase price variance | Accounts payable |
| Supplier payment | Accounts payable | Bank / cash |
| Release to production | Work in progress | Inventory |
| Production output | Finished goods (actual cost) | WIP, applied labour, applied overhead |
| Transfer dispatch / receipt | In transit → destination inventory | Source inventory → in transit (damage → waste, shortage → shrinkage) |
| POS sale | Cash / mobile money / bank / card; COGS | Revenue (ex VAT), VAT output; Inventory |
| Refund | Sales returns, VAT output (restock: Inventory) | Payment account (restock: COGS) |
| Adjustment / disposal | Waste or shrinkage (or inventory if found) | Inventory |
| Shift over/short | Cash or cash over/short | the other |

## Data model highlights

`Branch` (unlimited; HQ, production, warehouse, shop, café) → `Location` tree with map geometry → `StockBalance`
(projection, unique per product/location/lot) ← `StockMovement` (ledger). `Lot` carries expiry, hold flag and the
production order that made it, giving forward/backward traceability. `Recipe`/`RecipeLine` (versioned, phantom
lines), `ProductionOrder`/`ProductionIssue`, `TransferOrder`/`TransferLine`/`TransferAllocation`, `PurchaseOrder` →
`GoodsReceipt` → `SupplierInvoice` → `SupplierPayment`, `Shift`/`Sale`/`SaleLine`/`Payment`/`Refund`/`KitchenTicket`/
`SyncOperation`, `Account`/`AccountMapping`/`FiscalPeriod`/`JournalEntry`/`JournalLine`, `Role`/`RoleAssignment`
(branch-scoped), `Terminal`, `ApiToken`, `AuditLog`, `Setting`.
