# Operations guide

## 1. Infrastructure

Minimum for five outlets: one Linux VM (4 vCPU, 8 GB RAM, 100 GB SSD) in a reliable data centre or cloud region,
plus an **off-site copy of backups** (second provider or a NAS at head office). Each outlet needs a browser device
(Android tablet 10" or Windows PC with Chrome/Edge), an 80 mm receipt printer and a cash drawer; internet can be
intermittent — the POS is designed for it.

## 2. First deployment

```bash
git clone <repo> yummy-os && cd yummy-os/deploy
cp .env.example .env && nano .env      # long random YUMMY_SECRET_KEY, DB_PASSWORD, hosts, BACKUP_PASSPHRASE
mkdir certs && cp /path/fullchain.pem /path/privkey.pem certs/
docker compose up -d --build
docker compose exec app python manage.py migrate
docker compose exec app python manage.py init_org
docker compose exec app python manage.py createsuperuser
docker compose exec app python manage.py verify_integrity
curl -k https://localhost/api/health
```

Never run `seed_demo` on production (it refuses unless DEBUG or an explicit flag is set).

### Configure the organisation (in `/admin/`)
1. Branches (HQ, PROD, WH, SHOP1–3, CAFE1–2) and stock **Locations** (at least one `is_sellable` location per outlet; warehouse zones/racks with map coordinates).
2. Units, categories, VAT rate (**confirm the current rate with your tax advisor**), products, recipes (author → approve by a second person), price lists (default + café menu lists), modifiers.
3. Users, PINs (POS staff) and **role assignments scoped to branches**.
4. Terminals: create, then issue one-time enrolment codes from *Back office → Terminals & sync* and enrol each device at `/pos`.
5. Opening stock: post receipts or adjustments (approved) so the ledger starts from documented quantities.

## 3. Releases

```bash
git pull && cd deploy
docker compose build app
docker compose run --rm app python manage.py migrate --plan     # review
docker compose up -d app && docker compose exec app python manage.py migrate
docker compose exec app python manage.py verify_integrity
```
POS devices pick up the new client automatically (service worker revalidates `sw.js` on each load). Queued offline
operations are compatible across releases; never remove an operation kind without a migration path.

**Rollback:** `docker compose up -d app` with the previous image tag. If a migration must be reverted, restore
from backup into a separate database first and compare — do not hand-edit ledger tables (they are append-only by design).

## 4. Backups and disaster recovery

| Layer | Mechanism | Frequency |
|---|---|---|
| Continuous | PostgreSQL WAL archiving to `/wal-archive` (`archive_timeout = 300` s) | every ≤ 5 min |
| Physical | `pg_basebackup` (compressed tar), optionally GPG-encrypted | nightly 01:30 + on container start |
| Logical | `pg_dump -Fc`, verified with `pg_restore --list` | nightly |
| Off-site | copy `/backups` and `/wal-archive` volumes to a second location (rclone/rsync job — **you must configure the target**) | hourly recommended |

Targets: **RPO ≤ 15 min** (WAL) and **RTO ≤ 2 h**. Measured in the drill on this release: **RPO 0, RTO 2 s** for the
demo database (3,309 sales) — production timings must be re-measured on the real server.

### Point-in-time restore (e.g. someone deleted data at 14:07)
1. Stop the app: `docker compose stop app`.
2. Restore into an **empty** directory/volume — never over the live one:
   `scripts/restore-pitr.sh /backups/base/<STAMP> "2026-10-10 14:05:00+03" /var/lib/postgresql/restore`
3. Start a PostgreSQL container on that directory, wait for `recovery stopping` in the log.
4. Point a temporary app instance at it and run `python manage.py verify_integrity`.
5. Business owner and finance sign off → switch `DATABASE_URL` / volume → start the app.
6. Record the incident (time, data window, who approved) in the audit log via the admin.

Rehearse quarterly: `sudo deploy/scripts/pitr_drill.sh <latest logical dump>` runs the full cycle on a throw-away
cluster and prints the measured RPO/RTO.

## 5. Monitoring

* `GET /api/health` — liveness and database reachability (container healthcheck uses it).
* *Terminals & sync* page — devices offline > 2 min, queued operations per device, rejected operations.
* Dashboard badge **Provisional** — some terminals have not synced recently; figures may be incomplete.
* Cron `python manage.py verify_integrity` hourly; alert on non-zero exit.
* Backup history: `/backups/backup-history.log` (alert on `FAILED` or no entry for 26 h).
* Logs: structured JSON on stdout (`docker compose logs app`), nginx access logs.

## 6. Runbooks

| Symptom | Action |
|---|---|
| Outlet offline for hours | Sales continue locally. Check the sync pill count is growing, not erroring. When connectivity returns the queue drains automatically. Do **not** clear the browser data. |
| Device lost/stolen | *Terminals & sync → Revoke*. Unsynced sales on that device are lost; reconcile the shift cash manually. Reset PINs of staff who used it. |
| "Needs review" operations | *Terminals & sync → Rejected operations*: read the reason (e.g. totals mismatch, unknown cashier), fix master data or re-enter, then *Resolve* with a note. |
| Negative stock / discrepancy | *Inventory → Discrepancies*: investigate (late transfer receipt? unrecorded production?), correct with an approved adjustment, resolve with a note. |
| Period end | Review trial balance, then *Accounting → Lock period*. Late postings into a locked period are refused. |
| Recall | *Quality & recall*: trace the lot, put affected lots on hold (blocks consumption everywhere), notify outlets, dispose via approved adjustments. |
