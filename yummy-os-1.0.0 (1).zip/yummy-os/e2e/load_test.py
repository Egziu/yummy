"""
Concurrency/latency smoke test for the POS sync endpoint against a running, seeded server.
Five terminals (one per outlet) upload sales concurrently, one sale per request, as a busy lunch hour would.

  python e2e/load_test.py --base http://127.0.0.1:8000 --sales 60
"""
import argparse
import json
import statistics
import threading
import time
import urllib.request
import uuid
from datetime import datetime, timezone

PW = "Yummy@2026demo"


def call(base, path, data=None, headers=None):
    req = urllib.request.Request(base + path, data=json.dumps(data).encode() if data is not None else None,
                                 headers={"Content-Type": "application/json", **(headers or {})},
                                 method="POST" if data is not None else "GET")
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default="http://127.0.0.1:8000")
    ap.add_argument("--sales", type=int, default=60, help="sales per terminal")
    a = ap.parse_args()
    admin = call(a.base, "/api/auth/login", {"username": "admin", "password": PW})["token"]
    outlets = ["SHOP1", "SHOP2", "SHOP3", "CAFE1", "CAFE2"]
    lat, errors, lock = [], [], threading.Lock()

    def worker(outlet):
        code = f"{outlet}-LOAD"
        enr = call(a.base, "/api/terminals", {"code": code, "name": "load", "branch": outlet, "kind": "RETAIL"},
                   {"Authorization": f"Bearer {admin}"})["enrollment_code"]
        tok = call(a.base, "/api/terminals/enroll", {"terminal_code": code, "enrollment_code": enr})["device_token"]
        h = {"X-Terminal-Token": tok}
        boot = call(a.base, "/api/pos/bootstrap", headers=h)
        cashier = next(c for c in boot["cashiers"] if "pos.sell" in c["permissions"])
        bread = next(p for p in boot["products"] if p["sku"] == "FG-BREAD-S")
        sid = str(uuid.uuid4())
        now = datetime.now(timezone.utc).isoformat()
        call(a.base, "/api/pos/sync", {"ops": [{"op_id": str(uuid.uuid4()), "kind": "shift_open", "created_at": now,
                                                 "payload": {"shift_id": sid, "cashier_id": cashier["id"], "opening_float": "0", "opened_at": now}}]}, h)
        for i in range(a.sales):
            now = datetime.now(timezone.utc).isoformat()
            op = {"op_id": str(uuid.uuid4()), "kind": "sale", "created_at": now, "payload": {
                "id": str(uuid.uuid4()), "number": f"{code}-{i:06d}", "shift_id": sid, "cashier_id": cashier["id"],
                "created_at": now, "tax_inclusive": True,
                "lines": [{"line_no": 1, "product_id": bread["id"], "qty": "2", "unit_price": bread["price"], "discount": "0",
                           "tax_rate": bread["tax_rate"]}],
                "payments": [{"method": "CASH", "amount": f"{2 * float(bread['price']):.2f}"}]}}
            t0 = time.perf_counter()
            try:
                r = call(a.base, "/api/pos/sync", {"ops": [op]}, h)["results"][0]
                if r["status"] != "APPLIED":
                    raise RuntimeError(r)
            except Exception as e:  # noqa: BLE001
                with lock:
                    errors.append(str(e))
            with lock:
                lat.append((time.perf_counter() - t0) * 1000)

    t = time.perf_counter()
    threads = [threading.Thread(target=worker, args=(o,)) for o in outlets]
    [th.start() for th in threads]
    [th.join() for th in threads]
    wall = time.perf_counter() - t
    lat.sort()
    print(f"sales synced : {len(lat) - len(errors)} / {len(lat)} ({len(errors)} errors)")
    print(f"throughput   : {len(lat) / wall:.1f} sales/s with {len(outlets)} concurrent terminals")
    print(f"latency ms   : p50 {statistics.median(lat):.0f} · p95 {lat[int(len(lat) * .95) - 1]:.0f} · max {lat[-1]:.0f}")


if __name__ == "__main__":
    main()
