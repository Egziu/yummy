"""
Browser end-to-end test of the offline-first POS and the back office, against a running server
seeded with `manage.py seed_demo`.

  python e2e/run_e2e.py --base http://127.0.0.1:8000 --out e2e/screenshots

What it proves (each step asserts, then screenshots):
  1. A terminal enrols with a one-time code and caches the catalogue.
  2. A cashier signs in with a PIN and sells online.
  3. The network is cut: sales continue, receipts print, the queue grows.
  4. While still offline the browser is RELOADED: the app shell comes from the service worker,
     the cashier signs in again (PIN checked on-device) and sells again.
  5. The network returns: the queue drains in order and the server has every sale exactly once.
  6. The back office shows the new sales on the dashboard, control tower, warehouse map and sync monitor.
"""
import argparse
import json
import os
import sys
import time
import urllib.request
from pathlib import Path

from playwright.sync_api import expect, sync_playwright

DEMO_PASSWORD = "Yummy@2026demo"


def api(base, path, data=None, token=None):
    req = urllib.request.Request(base + path, data=json.dumps(data).encode() if data is not None else None,
                                 headers={"Content-Type": "application/json",
                                          **({"Authorization": f"Bearer {token}"} if token else {})},
                                 method="POST" if data is not None else "GET")
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default="http://127.0.0.1:8000")
    ap.add_argument("--out", default=str(Path(__file__).parent / "screenshots"))
    ap.add_argument("--terminal", default="SHOP1-T1")
    ap.add_argument("--pin", default="1010")
    args = ap.parse_args()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    base = args.base
    step = {"n": 0}

    def shot(page, name):
        step["n"] += 1
        page.wait_for_timeout(350)  # let modal fade-in finish
        page.screenshot(path=str(out / f"{step['n']:02d}-{name}.png"), full_page=False)
        print(f"  ✓ {name}")

    admin = api(base, "/api/auth/login", {"username": "admin", "password": DEMO_PASSWORD})["token"]
    code = api(base, "/api/terminals", {"code": args.terminal, "name": "Shop 1 counter", "branch": args.terminal.split("-")[0],
                                         "kind": "RETAIL"}, admin)["enrollment_code"]
    before = api(base, "/api/reports/dashboard?branch=SHOP1", token=admin)["kpis"]["today"]

    with sync_playwright() as p:
        browser = p.chromium.launch()
        ctx = browser.new_context(viewport={"width": 1366, "height": 860}, base_url=base)
        page = ctx.new_page()
        page.on("pageerror", lambda e: print("PAGE ERROR:", e))

        print("1. enrol terminal")
        page.goto("/pos")
        page.get_by_label("Terminal code").fill(args.terminal)
        page.get_by_label("8-digit enrolment code").fill(code)
        shot(page, "pos-enrol")
        page.get_by_role("button", name="Enrol terminal").click()
        expect(page.get_by_text("Who is selling?")).to_be_visible(timeout=15000)
        shot(page, "pos-cashier-select")

        def sign_in():
            page.get_by_role("button", name="Cashier Shop1").click()
            for d in args.pin:
                page.locator(".keypad button", has_text=d).first.click()
            page.wait_for_timeout(1500)

        print("2. sign in and sell online")
        sign_in()
        if page.get_by_role("heading", name="Open shift").is_visible():
            page.get_by_role("button", name="Open shift").last.click()
        expect(page.locator(".grid .ptile").first).to_be_visible(timeout=10000)
        page.locator(".ptile", has_text="White bread - small").click()
        page.locator(".ptile", has_text="White bread - small").click()
        page.locator(".ptile", has_text="Butter croissant").click()
        shot(page, "pos-cart-online")

        def pay_cash():
            page.get_by_role("button", name="Charge").click()
            page.locator(".quick-cash button").first.click()
            page.get_by_role("button", name="Complete sale").click()
            expect(page.locator(".receipt")).to_be_visible(timeout=10000)

        pay_cash()
        shot(page, "pos-receipt-online")
        page.get_by_role("button", name="New sale").click()
        page.wait_for_timeout(2500)

        print("3. network cut - keep selling")
        ctx.set_offline(True)
        page.evaluate("window.dispatchEvent(new Event('offline'))")
        for item in ("Traditional Dabo", "Chocolate muffin", "White bread - large"):
            page.locator(".ptile", has_text=item).click()
            pay_cash()
            page.get_by_role("button", name="New sale").click()
        expect(page.locator(".syncpill")).to_contain_text("Offline", timeout=20000)
        expect(page.locator(".syncpill")).to_contain_text("pending")
        shot(page, "pos-offline-queue")

        print("4. reload while offline (service worker shell + on-device PIN)")
        page.reload()
        expect(page.get_by_text("Who is selling?")).to_be_visible(timeout=15000)
        sign_in()
        expect(page.locator(".grid .ptile").first).to_be_visible(timeout=10000)
        page.locator(".ptile", has_text="Cookies").click()
        page.locator(".cline").first.click()
        page.get_by_role("button", name="Charge").click()
        page.get_by_role("button", name="telebirr").click()
        page.get_by_label("Transaction reference").fill("TB7731902")
        page.get_by_role("button", name="Complete sale").click()
        expect(page.locator(".receipt")).to_be_visible()
        expect(page.get_by_text("saved offline")).to_be_visible()
        shot(page, "pos-offline-receipt-after-reload")
        page.get_by_role("button", name="New sale").click()
        page.locator(".syncpill").click()
        shot(page, "pos-sync-centre-offline")
        page.keyboard.press("Escape")

        print("5. network back - queue drains in order")
        ctx.set_offline(False)
        page.evaluate("window.dispatchEvent(new Event('online'))")
        expect(page.locator(".syncpill")).to_contain_text("Online", timeout=30000)
        expect(page.locator(".syncpill")).not_to_contain_text("pending", timeout=30000)
        shot(page, "pos-synced")

        after = api(base, "/api/reports/dashboard?branch=SHOP1", token=admin)["kpis"]["today"]
        added = after["transactions"] - before["transactions"]
        assert added == 5, f"expected exactly 5 new sales on the server, got {added}"
        print(f"  ✓ server received exactly {added} sales (no loss, no duplicates)")

        print("6. back office")
        office = ctx.new_page()
        office.goto("/office")
        office.get_by_label("Username").fill("ceo")
        office.get_by_label("Password").fill(DEMO_PASSWORD)
        office.get_by_role("button", name="Sign in").click()
        expect(office.get_by_text("Daily briefing")).to_be_visible(timeout=15000)
        office.wait_for_timeout(800)
        shot(office, "office-dashboard")
        office.goto("/office/tower")
        expect(office.get_by_text("Enterprise network")).to_be_visible()
        office.wait_for_timeout(800)
        shot(office, "office-control-tower")
        office.close()
        wh = ctx.new_page()
        wh.goto("/office")
        wh.get_by_label("Username").fill("whmgr")
        wh.get_by_label("Password").fill(DEMO_PASSWORD)
        wh.get_by_role("button", name="Sign in").click()
        wh.wait_for_timeout(1200)
        wh.goto("/office/warehouse")
        expect(wh.get_by_text("Smart store map")).to_be_visible(timeout=15000)
        wh.locator("svg g", has_text="A1").first.click()
        wh.wait_for_timeout(500)
        shot(wh, "office-warehouse-map")
        wh.goto("/office/transfers")
        wh.wait_for_timeout(1200)
        shot(wh, "office-transfers")
        wh.close()
        adm = ctx.new_page()
        adm.goto("/office")
        adm.get_by_label("Username").fill("admin")
        adm.get_by_label("Password").fill(DEMO_PASSWORD)
        adm.get_by_role("button", name="Sign in").click()
        adm.wait_for_timeout(1200)
        for path, name in (("sync", "office-sync-monitor"), ("production", "office-production"),
                           ("accounting", "office-accounting"), ("inventory", "office-inventory")):
            adm.goto(f"/office/{path}")
            adm.wait_for_timeout(1500)
            shot(adm, name)
        adm.goto("/office/production")
        adm.get_by_role("button", name="Smart planner").click()
        adm.wait_for_timeout(1500)
        shot(adm, "office-smart-planner")

        print("7. café: modifiers, table tab, send to kitchen, KDS bump, pay")
        cafe = browser.new_context(viewport={"width": 1366, "height": 860}, base_url=base)
        cp = cafe.new_page()
        ccode = api(base, "/api/terminals", {"code": "CAFE1-T1", "name": "Café counter", "branch": "CAFE1", "kind": "CAFE"}, admin)["enrollment_code"]
        cp.goto("/pos")
        cp.get_by_label("Terminal code").fill("CAFE1-T1")
        cp.get_by_label("8-digit enrolment code").fill(ccode)
        cp.get_by_role("button", name="Enrol terminal").click()
        cp.get_by_role("button", name="Cashier Cafe1").click()
        for d in "4040":
            cp.locator(".keypad button", has_text=d).first.click()
        cp.wait_for_timeout(1200)
        if cp.get_by_role("heading", name="Open shift").is_visible():
            cp.get_by_role("button", name="Open shift").last.click()
        cp.get_by_role("button", name="Table T1").click()
        cp.get_by_role("button", name="T4", exact=True).click()
        cp.locator(".ptile", has_text="Cappuccino").click()
        cp.get_by_role("button", name="Extra shot").click()
        cp.get_by_role("button", name="Add", exact=True).click()
        cp.locator(".ptile", has_text="Macchiato").click()
        cp.get_by_role("button", name="Plain").click()
        cp.locator(".ptile", has_text="Chocolate cake slice").click()
        shot(cp, "cafe-tab-T4")
        cp.get_by_role("button", name="Send to kitchen").click()
        cp.wait_for_timeout(2500)
        kds = browser.new_context(viewport={"width": 1280, "height": 720}, base_url=base).new_page()
        kcode = api(base, "/api/terminals", {"code": "CAFE1-KDS", "name": "Barista screen", "branch": "CAFE1", "kind": "KDS"}, admin)["enrollment_code"]
        kds.goto("/pos")
        kds.get_by_label("Terminal code").fill("CAFE1-KDS")
        kds.get_by_label("8-digit enrolment code").fill(kcode)
        kds.get_by_role("button", name="Enrol terminal").click()
        expect(kds.locator(".ticket", has_text="T4").first).to_be_visible(timeout=15000)
        kds.locator(".ticket", has_text="Cappuccino").get_by_role("button", name="Start").click()
        kds.wait_for_timeout(600)
        shot(kds, "kds-barista-screen")
        cp.get_by_role("button", name="Charge").click()
        cp.locator(".quick-cash button").first.click()
        cp.get_by_role("button", name="Complete sale").click()
        expect(cp.locator(".receipt")).to_contain_text("Table")
        shot(cp, "cafe-receipt")
        cp.get_by_role("button", name="New sale").click()
        expect(cp.locator(".syncpill")).not_to_contain_text("pending", timeout=30000)

        print("8. refund with supervisor approval (different person)")
        cp.get_by_role("button", name="Refund").click()
        cp.locator(".modal table.data tbody tr").first.click()
        cp.locator(".modal input[type=number]").first.fill("1")
        cp.get_by_placeholder("e.g. stale, wrong item").fill("Customer changed mind")
        cp.get_by_role("button", name="Supervisor approval").click()
        for d in "4444":
            cp.locator(".modal .keypad button", has_text=d).last.click()
        expect(cp.get_by_text("Refund recorded")).to_be_visible(timeout=10000)
        shot(cp, "cafe-refund-approved")
        expect(cp.locator(".syncpill")).not_to_contain_text("pending", timeout=30000)
        browser.close()
    print("E2E PASSED")


if __name__ == "__main__":
    os.environ.setdefault("PLAYWRIGHT_BROWSERS_PATH", "/opt/pw-browsers")
    sys.exit(main())
