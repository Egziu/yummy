import json
from datetime import date
from decimal import Decimal
from pathlib import Path

import pytest

from apps.core.ethiopian import format_ethiopian, from_ethiopian, to_ethiopian
from apps.core.money import div_half_up, price_line, q2

CASES = json.loads((Path(__file__).resolve().parents[2] / "spec" / "pricing_cases.json").read_text())["cases"]


@pytest.mark.parametrize("case", CASES, ids=[c["name"] for c in CASES])
def test_pricing_cases_match_shared_spec(case):
    got = price_line(Decimal(case["unit_price"]), Decimal(case["qty"]), Decimal(case["discount"]),
                     Decimal(case["tax_rate"]), case["tax_inclusive"])
    assert got == case["expect"]


def test_line_invariants():
    for c in CASES:
        r = c["expect"]
        assert r["gross"] - r["discount"] == (r["total"] if c["tax_inclusive"] else r["base"])
        assert r["base"] + r["tax"] == r["total"]


def test_rejects_floats_and_bad_lines():
    with pytest.raises(TypeError):
        q2(1.1)
    with pytest.raises(ValueError):
        price_line(Decimal("10"), Decimal("1"), Decimal("11"), Decimal("0.15"), True)
    with pytest.raises(ValueError):
        price_line(Decimal("10"), Decimal("0"), Decimal("0"), Decimal("0.15"), True)


def test_half_up_division_symmetry():
    assert div_half_up(5, 2) == 3
    assert div_half_up(-5, 2) == -3
    assert div_half_up(4, 3) == 1


@pytest.mark.parametrize("greg,eth", [
    (date(2026, 9, 11), (2019, 1, 1)),    # Enkutatash 2019 E.C.
    (date(2027, 9, 12), (2020, 1, 1)),    # New year after a Gregorian leap year shifts to Sep 12
    (date(2026, 1, 7), (2018, 4, 29)),    # Genna (Ethiopian Christmas)
    (date(2027, 9, 11), (2019, 13, 6)),   # Pagume 6 in the Ethiopian leap year 2019
    (date(2026, 10, 9), (2019, 1, 29)),
])
def test_ethiopian_calendar(greg, eth):
    assert to_ethiopian(greg) == eth
    assert from_ethiopian(*eth) == greg


def test_ethiopian_round_trip_ten_years():
    d = date(2020, 1, 1)
    while d < date(2030, 1, 1):
        assert from_ethiopian(*to_ethiopian(d)) == d
        d = date.fromordinal(d.toordinal() + 1)
    assert format_ethiopian(date(2026, 9, 11)) == "Meskerem 1, 2019 E.C."
    with pytest.raises(ValueError):
        from_ethiopian(2018, 13, 6)  # 2018 is not a leap year
