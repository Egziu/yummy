"""Scenario I (unauthorised access), tamper resistance, authentication, and API end-to-end."""
import threading
import uuid
from decimal import Decimal as D

import pytest
from django.core.management import call_command
from django.db import DatabaseError, connection, transaction
from django.utils import timezone
from rest_framework.test import APIClient

from apps.accounting.models import FiscalPeriod, JournalEntry, JournalLine
from apps.accounting.services import Draft, account_for, post
from apps.core import audit
from apps.core.audit import verify_chain
from apps.core.exceptions import BusinessRuleError
from apps.core.models import AuditLog
from apps.iam.models import ApiToken
from apps.inventory.models import StockMovement
from apps.reports.views import _csv_safe

from .conftest import open_shift, sale_payload, stock


def client_for(user):
    c = APIClient()
    c.credentials(HTTP_AUTHORIZATION="Bearer " + ApiToken.issue(user))
    return c


def terminal_client(term):
    raw = term.new_enrollment_code()
    token = APIClient().post("/api/terminals/enroll", {"terminal_code": term.code, "enrollment_code": raw},
                             format="json").json()["device_token"]
    c = APIClient()
    c.credentials(HTTP_X_TERMINAL_TOKEN=token)
    return c, token


def test_scenario_i_cashier_is_denied_server_side(org):
    c = client_for(org.u["cashier1"])
    assert c.get("/api/accounting/trial-balance").status_code == 403
    assert c.get("/api/reports/export/trial-balance.csv").status_code == 403
    assert c.get("/api/sync/conflicts").status_code == 403
    assert c.get("/api/audit").status_code == 403
    from apps.procurement.models import Supplier
    from apps.procurement import services as proc

    po = proc.create_po(org.u["buyer"], Supplier.objects.create(code="S", name="S"), org.loc["WH-A"],
                        [{"product": org.p["flour"], "qty": 1, "unit_cost": 1}])
    assert c.post(f"/api/procurement/orders/{po.pk}/approve").status_code == 403
    # dashboard is scoped: cashier has no reporting rights
    assert c.get("/api/reports/dashboard").status_code == 403
    # unauthenticated requests are refused
    assert APIClient().get("/api/inventory/balances").status_code in (401, 403)


def test_branch_manager_only_sees_own_branch(org):
    stock(org.p["bread"], org.loc["SHOP1"], 5, 6, "S1")
    stock(org.p["bread"], org.loc["SHOP2"], 7, 6, "S2")
    rows = client_for(org.u["mgr1"]).get("/api/inventory/balances").json()
    assert {r["branch"] for r in rows} == {"SHOP1"}
    dash = client_for(org.u["mgr1"]).get("/api/reports/dashboard").json()
    assert {b["code"] for b in dash["branches"]} == {"SHOP1"}


def test_append_only_ledgers_reject_update_and_delete(org):
    stock(org.p["flour"], org.loc["WH-A"], 5, 80)
    post(Draft().dr("cash", 10).cr("revenue", 10), memo="t", source_type="T", source_id="1", idempotency_key="t1")
    audit.record("test.event")
    for stmt in ("UPDATE inventory_stockmovement SET qty = 999",
                 "DELETE FROM inventory_stockmovement",
                 "UPDATE accounting_journalline SET debit = debit + 1",
                 "DELETE FROM accounting_journalentry",
                 "UPDATE core_auditlog SET action = 'tampered'",
                 "DELETE FROM core_auditlog"):
        with pytest.raises(DatabaseError, match="append-only"):
            with transaction.atomic(), connection.cursor() as cur:
                cur.execute(stmt)
    with pytest.raises(DatabaseError):
        with transaction.atomic():
            StockMovement.objects.update(note="x")


def test_unbalanced_journal_rejected_by_database(org):
    entry = JournalEntry.objects.create(number="JE-X", date=timezone.localdate(), memo="bad", source_type="T",
                                        source_id="x", idempotency_key="bad")
    with pytest.raises(DatabaseError, match="unbalanced"):
        with transaction.atomic():
            JournalLine.objects.bulk_create([
                JournalLine(entry=entry, account=account_for("cash"), debit=D("100")),
                JournalLine(entry=entry, account=account_for("revenue"), credit=D("90")),
            ])
    with pytest.raises(BusinessRuleError):  # and the application refuses before reaching the database
        post(Draft().dr("cash", 1).cr("revenue", 2), memo="x", source_type="T", source_id="2", idempotency_key="t2")


def test_locked_period_blocks_posting(org):
    today = timezone.localdate()
    FiscalPeriod.objects.create(year=today.year, month=today.month, status="LOCKED")
    with pytest.raises(BusinessRuleError) as e:
        post(Draft().dr("cash", 1).cr("revenue", 1), memo="x", source_type="T", source_id="3", idempotency_key="t3")
    assert e.value.code == "period_locked"


def test_audit_chain_detects_tampering(org):
    for i in range(3):
        audit.record("test.event", data={"i": i})
    assert verify_chain()[0]
    with connection.cursor() as c:  # an attacker with DB superuser disables the trigger and edits a row
        c.execute("ALTER TABLE core_auditlog DISABLE TRIGGER core_auditlog_append_only")
        c.execute("UPDATE core_auditlog SET data = '{\"i\": 99}' WHERE id = (SELECT MIN(id) FROM core_auditlog)")
        c.execute("ALTER TABLE core_auditlog ENABLE TRIGGER core_auditlog_append_only")
    ok, _, bad = verify_chain()
    assert not ok and bad == AuditLog.objects.order_by("id").first().id


def test_login_lockout_and_token_expiry(org, settings):
    c = APIClient()
    for _ in range(settings.YUMMY_MAX_FAILED_LOGINS):
        assert c.post("/api/auth/login", {"username": "ceo", "password": "wrong"}, format="json").status_code == 401
    r = c.post("/api/auth/login", {"username": "ceo", "password": "Test-pass-2026!"}, format="json")
    assert r.status_code == 423  # locked even with the right password
    org.u["accountant"].refresh_from_db()
    ok = c.post("/api/auth/login", {"username": "accountant", "password": "Test-pass-2026!"}, format="json")
    assert ok.status_code == 200 and "accounting.view" in ok.json()["user"]["permissions"]
    token = ok.json()["token"]
    assert ApiToken.objects.filter(key_hash=__import__("hashlib").sha256(token.encode()).hexdigest()).exists()
    ApiToken.objects.update(expires_at=timezone.now())
    c.credentials(HTTP_AUTHORIZATION="Bearer " + token)
    assert c.get("/api/auth/me").status_code == 401


def test_terminal_enrollment_single_use_and_revocation(org):
    term = org.t["SHOP1"]
    code = term.new_enrollment_code()
    first = APIClient().post("/api/terminals/enroll", {"terminal_code": term.code, "enrollment_code": code}, format="json")
    second = APIClient().post("/api/terminals/enroll", {"terminal_code": term.code, "enrollment_code": code}, format="json")
    assert first.status_code == 200 and second.status_code == 400
    c = APIClient()
    c.credentials(HTTP_X_TERMINAL_TOKEN=first.json()["device_token"])
    assert c.get("/api/pos/bootstrap").status_code == 200
    admin = __import__("apps.iam.models", fromlist=["User"]).User.objects.create(username="root", is_superuser=True)
    assert client_for(admin).post(f"/api/terminals/{term.code}/revoke").status_code == 200
    assert c.get("/api/pos/bootstrap").status_code in (401, 403)
    # user tokens cannot call device endpoints and device tokens cannot call back-office endpoints
    assert client_for(org.u["mgr1"]).get("/api/pos/bootstrap").status_code == 403


def test_pos_end_to_end_over_http(org):
    stock(org.p["bread"], org.loc["SHOP1"], 20, 6, "B1")
    stock(org.p["bread"], org.loc["SHOP1"], 5, 6, "B2")
    c, _ = terminal_client(org.t["SHOP1"])
    boot = c.get("/api/pos/bootstrap").json()
    skus = {p["sku"]: p for p in boot["products"]}
    assert set(skus) == {"BREAD", "CAKE", "CAPPUCCINO"}  # everything priced on the active lists
    assert skus["BREAD"]["stock"] == 25  # all lots at the counter are summed
    cashier = next(x for x in boot["cashiers"] if x["name"] == "cashier1")
    assert "pin_hash" in cashier and "1010" not in str(boot)
    import hashlib

    derived = hashlib.pbkdf2_hmac("sha256", b"1010", bytes.fromhex(cashier["pin_salt"]), cashier["pin_iterations"]).hex()
    assert derived == cashier["pin_hash"]  # the offline verifier works without the server
    sid = str(uuid.uuid4())
    ops = [{"op_id": str(uuid.uuid4()), "kind": "shift_open", "created_at": timezone.now().isoformat(),
            "payload": {"shift_id": sid, "cashier_id": cashier["id"], "opening_float": "100",
                        "opened_at": timezone.now().isoformat()}},
           {"op_id": str(uuid.uuid4()), "kind": "sale", "created_at": timezone.now().isoformat(),
            "payload": sale_payload(org.t["SHOP1"], sid, org.u["cashier1"], [(org.p["bread"], 3, "15.00", "0", [])])}]
    r = c.post("/api/pos/sync", {"ops": ops, "pending_count": 2}, format="json").json()
    assert [x["status"] for x in r["results"]] == ["APPLIED", "APPLIED"]
    num = ops[1]["payload"]["number"]
    looked = c.get(f"/api/pos/sales/{num}").json()
    assert looked["total"] == "45.00" and looked["lines"][0]["qty"] == "3.000"
    dash = client_for(org.u["ceo"]).get("/api/reports/dashboard").json()
    assert dash["kpis"]["today"]["sales"] == "45.00" and dash["ledger_balanced"] is True


def test_csv_exports_neutralise_formula_injection(org):
    assert _csv_safe("=HYPERLINK(\"http://evil\")") == "'=HYPERLINK(\"http://evil\")"
    assert _csv_safe("@SUM(A1)") == "'@SUM(A1)"
    assert _csv_safe("-12.50") == "-12.50"  # genuine negative numbers stay numeric
    r = client_for(org.u["ceo"]).get("/api/reports/export/sales.csv")
    assert r.status_code == 200 and r["Content-Type"].startswith("text/csv")
    assert AuditLog.objects.filter(action="report.exported").exists()


@pytest.mark.django_db(transaction=True)
def test_concurrent_approvals_cannot_oversell_reserved_stock(django_db_blocker):
    """Two managers approve competing transfers for the last 100 loaves at the same moment."""
    call_command("init_org", verbosity=0)
    from apps.catalog.models import Category, Product, Unit
    from apps.core.models import Branch
    from apps.iam.models import User
    from apps.inventory.models import Location, StockBalance
    from apps.transfers import services as xfer

    wh = Branch.objects.create(code="WH", name="WH", kind="WAREHOUSE")
    s1 = Branch.objects.create(code="S1", name="S1", kind="SHOP")
    src = Location.objects.create(code="SRC", name="src", branch=wh)
    d1 = Location.objects.create(code="D1", name="d1", branch=s1, kind="SALES", is_sellable=True)
    d2 = Location.objects.create(code="D2", name="d2", branch=s1, kind="SALES")
    p = Product.objects.create(sku="B", name="B", kind="FINISHED", unit=Unit.objects.create(code="pcs", name="pcs"),
                               category=Category.objects.create(name="c"), track_lots=False)
    stock(p, src, 100, 5)
    req = User.objects.create(username="req", is_superuser=True)
    apprs = [User.objects.create(username=f"a{i}", is_superuser=True) for i in range(2)]
    t1 = xfer.request_transfer(req, src, d1, [{"product": p, "qty": D("100")}])
    t2 = xfer.request_transfer(req, src, d2, [{"product": p, "qty": D("100")}])
    barrier, results = threading.Barrier(2), {}

    def approve(i, t):
        from django.db import connection as conn

        try:
            barrier.wait()
            xfer.approve_transfer(apprs[i], t.pk)
            results[i] = "ok"
        except Exception as e:  # noqa: BLE001
            results[i] = type(e).__name__
        finally:
            conn.close()

    threads = [threading.Thread(target=approve, args=(i, t)) for i, t in enumerate((t1, t2))]
    [th.start() for th in threads]
    [th.join() for th in threads]
    reserved = StockBalance.objects.get(product=p, location=src).qty_reserved
    assert sorted(results.values()) == ["BusinessRuleError", "ok"]  # exactly one approval wins
    assert reserved == D("100")
