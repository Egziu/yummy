"""Scenarios A (procurement), B (production), C (distribution) and H (expiry) from the specification."""
from datetime import timedelta
from decimal import Decimal as D

import pytest
from django.db.models import Sum
from django.utils import timezone

from apps.accounting.models import JournalEntry, JournalLine
from apps.accounting.services import account_for, trial_balance
from apps.core.exceptions import BusinessRuleError, InsufficientStock, PermissionDeniedError
from apps.inventory import services as inv
from apps.inventory import workflows
from apps.inventory.models import Location, Lot, StockBalance, StockDiscrepancy, StockMovement
from apps.procurement import services as proc
from apps.procurement.models import PurchaseOrder, SupplierInvoice
from apps.production import services as prod
from apps.production.models import ProductionOrder, Recipe, RecipeLine
from apps.transfers import services as xfer
from apps.transfers.models import TransferOrder

from .conftest import stock


def on_hand(product, location):
    return StockBalance.objects.filter(product=product, location=location).aggregate(s=Sum("qty_on_hand"))["s"] or 0


def gl(key, branch=None):
    qs = JournalLine.objects.filter(account=account_for(key))
    if branch:
        qs = qs.filter(branch=branch)
    r = qs.aggregate(d=Sum("debit"), c=Sum("credit"))
    return (r["d"] or 0) - (r["c"] or 0)


# --------------------------------------------------------------- Scenario A
def test_scenario_a_procurement_flow(org):
    from apps.procurement.models import Supplier

    sup = Supplier.objects.create(code="MILL", name="Mill")
    po = proc.create_po(org.u["buyer"], sup, org.loc["WH-A"],
                        [{"product": org.p["flour"], "qty": D("100"), "unit_cost": D("82")}])
    with pytest.raises(BusinessRuleError) as e:  # cannot receive before approval
        proc.receive_goods(org.u["clerk"], po.pk, [{"order_line": po.lines.first().pk, "qty_accepted": D("100")}])
    proc.approve_po(org.u["procmgr"], po.pk)
    line = po.lines.first()
    proc.receive_goods(org.u["clerk"], po.pk, [{"order_line": line.pk, "qty_accepted": D("98"), "qty_rejected": D("2"),
                                                "lot_code": "MILL-1", "expiry_date": timezone.localdate() + timedelta(days=90)}])
    po.refresh_from_db()
    assert po.status == PurchaseOrder.Status.PARTIAL
    assert on_hand(org.p["flour"], org.loc["WH-A"]) == D("98")
    assert inv.avg_cost(org.p["flour"]) == D("82")
    assert gl("inventory_raw") == D("8036.00") and gl("grni") == D("-8036.00")

    invoice = proc.record_invoice(org.u["accountant"], po.pk, "INV-1", timezone.localdate(),
                                  [{"order_line": line.pk, "qty": D("98"), "unit_cost": D("82")}], tax=D("1205.40"))
    assert invoice.status == SupplierInvoice.Status.POSTED
    assert gl("grni") == 0 and gl("payable") == D("-9241.40") and gl("vat_input") == D("1205.40")

    with pytest.raises(PermissionDeniedError):  # accountants record invoices but cannot release money
        proc.pay_invoice(org.u["accountant"], invoice.pk, D("100"))
    with pytest.raises(BusinessRuleError) as e:
        proc.pay_invoice(org.u["finance"], invoice.pk, D("99999"))
    assert e.value.code == "overpayment"
    proc.pay_invoice(org.u["finance"], invoice.pk, D("9241.40"), reference="CBE-1")
    invoice.refresh_from_db()
    assert invoice.status == SupplierInvoice.Status.PAID and gl("payable") == 0
    assert trial_balance()["balanced"]


def test_invoice_recorder_cannot_pay_it(org):
    from apps.procurement.models import Supplier

    sup = Supplier.objects.create(code="X", name="X")
    po = proc.create_po(org.u["buyer"], sup, org.loc["WH-A"], [{"product": org.p["sugar"], "qty": 10, "unit_cost": 100}])
    proc.approve_po(org.u["procmgr"], po.pk)
    l = po.lines.first()
    proc.receive_goods(org.u["clerk"], po.pk, [{"order_line": l.pk, "qty_accepted": D("10"), "lot_code": "S1"}])
    inv_doc = proc.record_invoice(org.u["finance"], po.pk, "X-1", timezone.localdate(),
                                  [{"order_line": l.pk, "qty": D("10"), "unit_cost": D("100")}])
    with pytest.raises(BusinessRuleError) as e:
        proc.pay_invoice(org.u["finance"], inv_doc.pk, D("100"))
    assert e.value.code == "sod_violation"


def test_po_segregation_of_duties_and_permissions(org):
    from apps.procurement.models import Supplier

    sup = Supplier.objects.create(code="S", name="S")
    with pytest.raises(PermissionDeniedError):  # a cashier cannot raise purchase orders
        proc.create_po(org.u["cashier1"], sup, org.loc["WH-A"], [{"product": org.p["flour"], "qty": 1, "unit_cost": 1}])
    po = proc.create_po(org.u["procmgr"], sup, org.loc["WH-A"], [{"product": org.p["flour"], "qty": 1, "unit_cost": 1}])
    with pytest.raises(BusinessRuleError) as e:
        proc.approve_po(org.u["procmgr"], po.pk)
    assert e.value.code == "sod_violation"


def test_three_way_match_holds_price_and_quantity_exceptions(org):
    from apps.procurement.models import Supplier

    sup = Supplier.objects.create(code="D", name="Dairy")
    po = proc.create_po(org.u["buyer"], sup, org.loc["WH-A"], [{"product": org.p["milk"], "qty": 50, "unit_cost": 70}])
    proc.approve_po(org.u["procmgr"], po.pk)
    l = po.lines.first()
    proc.receive_goods(org.u["clerk"], po.pk, [{"order_line": l.pk, "qty_accepted": D("40"), "lot_code": "M1"}])
    held = proc.record_invoice(org.u["accountant"], po.pk, "D-77", timezone.localdate(),
                               [{"order_line": l.pk, "qty": D("50"), "unit_cost": D("80")}])
    assert held.status == SupplierInvoice.Status.HELD
    assert {x["issue"] for x in held.match_exceptions} == {"quantity_exceeds_receipt", "price_above_po"}
    assert gl("payable") == 0  # nothing posted to payables
    with pytest.raises(BusinessRuleError) as e:
        proc.pay_invoice(org.u["finance"], held.pk, D("10"))
    assert e.value.code == "invoice_held"
    with pytest.raises(BusinessRuleError) as e:  # the same supplier invoice can never be entered twice
        proc.record_invoice(org.u["accountant"], po.pk, "D-77", timezone.localdate(),
                            [{"order_line": l.pk, "qty": D("1"), "unit_cost": D("70")}])
    assert e.value.code == "duplicate_invoice"
    proc.release_held_invoice(org.u["procmgr"], held.pk, "Supplier price increase agreed")
    assert gl("ppv") == D("500.00")  # 50 x (80 - 70)
    assert trial_balance()["balanced"]


# --------------------------------------------------------------- Scenario B
def test_nested_recipe_explosion_and_cycle_detection(org):
    req, labor = prod.explode(prod.active_recipe(org.p["bread"]), D("2"))
    by = {p.sku: q for p, q in req.items()}
    # 2 batches x 5 kg dough; dough recipe (10 kg) = 6 flour + 3 milk  -> 6 flour, 3 milk
    assert by == {"FLOUR": D("6"), "MILK": D("3")}
    assert labor == D("120") + D("30")  # 2 x 60 + (10/10) x 30
    r = Recipe.objects.create(product=org.p["flour"], output_qty=1, status="APPROVED")
    RecipeLine.objects.create(recipe=r, ingredient=org.p["bread"], qty=1, explode=True)
    with pytest.raises(BusinessRuleError) as e:
        prod.explode(r)
    assert e.value.code == "recipe_cycle"


def test_scenario_b_production_fefo_costing_and_journals(org):
    today = timezone.localdate()
    stock(org.p["flour"], org.loc["PROD"], 10, 80, "FL-OLD", today + timedelta(days=5))
    stock(org.p["flour"], org.loc["PROD"], 50, 90, "FL-NEW", today + timedelta(days=60))
    stock(org.p["flour"], org.loc["PROD"], 20, 80, "FL-EXPIRED", today - timedelta(days=1))
    stock(org.p["milk"], org.loc["PROD"], 40, 70, "MK-1", today + timedelta(days=4))
    o = prod.create_order(org.u["prodmgr"], org.p["bread"], D("400"), today, org.loc["PROD"], org.loc["WH-C"])
    with pytest.raises(BusinessRuleError):
        prod.release_order(org.u["baker"], o.pk)  # not approved yet
    prod.approve_order(org.u["prodmgr"], o.pk)
    avg_flour = inv.avg_cost(org.p["flour"])
    prod.release_order(org.u["baker"], o.pk)
    o.refresh_from_db()
    issues = {(i.lot.code, i.qty) for i in o.issues.select_related("lot")}
    # 400 loaves = 4 batches -> 20 kg dough = 12 kg flour + 6 l milk; FEFO takes the old lot first, never the expired one
    assert issues == {("FL-OLD", D("10.000")), ("FL-NEW", D("2.000")), ("MK-1", D("6.000"))}
    assert o.material_cost == (D("12") * avg_flour + D("6") * D("70")).quantize(D("0.01"))
    assert gl("wip") == o.material_cost

    prod.complete_order(org.u["baker"], o.pk, D("390"), D("10"))
    o.refresh_from_db()
    labor_hours = (D("4") * 60 + D("2") * 30) / 60  # 5 hours
    assert o.labor_cost == labor_hours * D("85") and o.overhead_cost == labor_hours * D("40")
    assert o.unit_cost == ((o.material_cost + o.labor_cost + o.overhead_cost) / D("390")).quantize(D("0.0001"))
    assert on_hand(org.p["bread"], org.loc["WH-C"]) == D("390")
    lot = Lot.objects.get(product=org.p["bread"], code=o.number)
    assert lot.expiry_date == today + timedelta(days=2) and lot.production_order_id == o.pk
    assert gl("wip") == 0 and gl("inventory_fg") == o.material_cost + o.labor_cost + o.overhead_cost
    assert trial_balance()["balanced"]
    with pytest.raises(BusinessRuleError):
        prod.complete_order(org.u["baker"], o.pk, D("1"))  # cannot complete twice


def test_release_is_all_or_nothing_on_shortage(org):
    stock(org.p["flour"], org.loc["PROD"], 100, 80, "F1")
    stock(org.p["milk"], org.loc["PROD"], 1, 70, "M1")  # not enough milk
    o = prod.create_order(org.u["prodmgr"], org.p["bread"], D("400"), timezone.localdate(), org.loc["PROD"],
                          org.loc["WH-C"])
    prod.approve_order(org.u["prodmgr"], o.pk)
    with pytest.raises(InsufficientStock):
        prod.release_order(org.u["baker"], o.pk)
    assert on_hand(org.p["flour"], org.loc["PROD"]) == D("100")  # flour untouched (rolled back)
    assert JournalEntry.objects.filter(source_type="MO").count() == 0


def test_qc_failure_goes_to_quarantine_and_is_not_sellable(org):
    stock(org.p["flour"], org.loc["PROD"], 100, 80, "F1")
    stock(org.p["milk"], org.loc["PROD"], 100, 70, "M1")
    o = prod.create_order(org.u["prodmgr"], org.p["bread"], D("100"), timezone.localdate(), org.loc["PROD"],
                          org.loc["WH-C"])
    prod.approve_order(org.u["prodmgr"], o.pk)
    prod.release_order(org.u["baker"], o.pk)
    prod.complete_order(org.u["baker"], o.pk, D("100"), qc_passed=False)
    assert on_hand(org.p["bread"], org.loc["PROD-QC"]) == D("100")
    allocs, short = inv.allocate_fefo(org.p["bread"], org.loc["PROD-QC"], D("1"))
    assert allocs == [] and short == D("1")  # held lot is never allocated


# --------------------------------------------------------------- Scenario C
def _fg(org, qty=200):
    today = timezone.localdate()
    stock(org.p["bread"], org.loc["WH-C"], qty // 2, 5, "B-OLD", today + timedelta(days=1))
    stock(org.p["bread"], org.loc["WH-C"], qty - qty // 2, 5, "B-NEW", today + timedelta(days=2))


def test_scenario_c_transfer_lifecycle_with_damage_and_shortage(org):
    _fg(org)
    t = xfer.request_transfer(org.u["mgr1"], org.loc["WH-C"], org.loc["SHOP1"],
                              [{"product": org.p["bread"], "qty": D("150")}])
    with pytest.raises(PermissionDeniedError):  # a shop manager cannot approve warehouse stock leaving
        xfer.approve_transfer(org.u["mgr1"], t.pk)
    xfer.approve_transfer(org.u["whmgr"], t.pk)
    bal = StockBalance.objects.filter(product=org.p["bread"], location=org.loc["WH-C"])
    assert sum(b.qty_reserved for b in bal) == D("150")
    xfer.dispatch_transfer(org.u["clerk"], t.pk, driver="Yohannes")
    transit = inv.in_transit_location(org.b["SHOP1"])
    assert on_hand(org.p["bread"], transit) == D("150") and on_hand(org.p["bread"], org.loc["WH-C"]) == D("50")
    assert sum(b.qty_reserved for b in bal.all()) == 0
    line = t.lines.get()
    xfer.receive_transfer(org.u["mgr1"], t.pk, [{"line": line.pk, "qty_received": D("140"), "qty_damaged": D("6")}])
    t.refresh_from_db()
    assert t.status == TransferOrder.Status.RECONCILED
    assert on_hand(org.p["bread"], org.loc["SHOP1"]) == D("140")
    assert on_hand(org.p["bread"], transit) == 0
    assert StockDiscrepancy.objects.filter(reason="TRANSIT_SHORTAGE", qty=D("-4")).exists()
    assert gl("in_transit") == 0 and gl("waste") == D("30.00") and gl("shrinkage") == D("20.00")
    # receiving twice must never duplicate stock
    with pytest.raises(BusinessRuleError) as e:
        xfer.receive_transfer(org.u["mgr1"], t.pk)
    assert e.value.code == "already_received"
    assert on_hand(org.p["bread"], org.loc["SHOP1"]) == D("140")
    assert trial_balance()["balanced"]


def test_transfer_partial_approval_and_cancel_releases_reservation(org):
    _fg(org, 60)
    t = xfer.request_transfer(org.u["mgr1"], org.loc["WH-C"], org.loc["SHOP1"],
                              [{"product": org.p["bread"], "qty": D("100")}])
    xfer.approve_transfer(org.u["whmgr"], t.pk)
    assert t.lines.get().qty_approved == D("60")
    xfer.cancel_transfer(org.u["whmgr"], t.pk, "Driver unavailable")
    assert all(b.qty_reserved == 0 for b in StockBalance.objects.filter(location=org.loc["WH-C"]))


def test_requester_cannot_approve_own_transfer(org):
    from apps.iam.models import User

    boss = User.objects.create(username="boss", is_superuser=True)  # holds every permission, still bound by SoD
    _fg(org)
    t = xfer.request_transfer(boss, org.loc["WH-C"], org.loc["WH-A"], [{"product": org.p["bread"], "qty": D("1")}])
    with pytest.raises(BusinessRuleError) as e:
        xfer.approve_transfer(boss, t.pk)
    assert e.value.code == "sod_violation"


# --------------------------------------------------------------- Scenario H
def test_scenario_h_expired_stock_blocked_then_disposed_with_approval(org):
    today = timezone.localdate()
    stock(org.p["milk"], org.loc["WH-A"], 10, 70, "OLD", today - timedelta(days=1))
    rows = workflows.expiring_lots()
    assert rows and rows[0]["expired"] and rows[0]["lot"] == "OLD"
    with pytest.raises(InsufficientStock):
        inv.consume(org.p["milk"], org.loc["WH-A"], D("1"), StockMovement.Kind.SALE, "T", "1")
    lot = Lot.objects.get(code="OLD")
    adj = workflows.request_adjustment(org.u["clerk"], org.loc["WH-A"], "EXPIRY",
                                       [{"product": org.p["milk"], "lot": lot, "qty_change": D("-10")}])
    with pytest.raises((BusinessRuleError, PermissionDeniedError)):
        workflows.approve_adjustment(org.u["clerk"], adj.pk)  # requester lacks approval right / SoD
    workflows.approve_adjustment(org.u["whmgr"], adj.pk)
    assert on_hand(org.p["milk"], org.loc["WH-A"]) == 0
    assert gl("waste") == D("700.00")
    assert gl("inventory_raw") == D("-700.00")  # test opening stock carries no opening journal
    assert StockMovement.objects.filter(doc_type="ADJ", kind="WASTE").count() == 1


def test_recall_trace_follows_ingredient_lot_into_finished_goods(org):
    from rest_framework.test import APIClient

    from apps.iam.models import ApiToken

    stock(org.p["flour"], org.loc["PROD"], 100, 80, "SUSPECT")
    stock(org.p["milk"], org.loc["PROD"], 100, 70, "M1")
    o = prod.create_order(org.u["prodmgr"], org.p["bread"], D("100"), timezone.localdate(), org.loc["PROD"],
                          org.loc["WH-C"])
    prod.approve_order(org.u["prodmgr"], o.pk)
    prod.release_order(org.u["baker"], o.pk)
    prod.complete_order(org.u["baker"], o.pk, D("100"))
    t = xfer.request_transfer(org.u["mgr1"], org.loc["WH-C"], org.loc["SHOP1"], [{"product": org.p["bread"], "qty": 30}])
    xfer.approve_transfer(org.u["whmgr"], t.pk)
    xfer.dispatch_transfer(org.u["clerk"], t.pk)
    xfer.receive_transfer(org.u["mgr1"], t.pk)
    c = APIClient()
    c.credentials(HTTP_AUTHORIZATION="Bearer " + ApiToken.issue(org.u["qa"]))
    lot = Lot.objects.get(code="SUSPECT")
    r = c.get(f"/api/reports/recall?lot_id={lot.pk}").json()
    assert [b["order"] for b in r["batches"]] == [o.number]
    bread_lot = next(a for a in r["affected_lots"] if a["lot"] == o.number)
    where = {x["location"]: D(str(x["qty"])) for x in bread_lot["on_hand"]}
    assert where == {"WH-C": D("70"), "SHOP1-FLOOR": D("30")}
