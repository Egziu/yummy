"""Scenarios D (retail sale), E (café order), F (refund), G (network outage / offline sync)."""
import uuid
from decimal import Decimal as D

from django.db.models import Sum
from django.utils import timezone

from apps.accounting.models import JournalEntry
from apps.accounting.services import trial_balance
from apps.inventory.models import StockBalance, StockDiscrepancy, StockMovement
from apps.pos.models import KitchenTicket, Refund, Sale, Shift, SyncOperation
from apps.pos.sync import apply_batch

from .conftest import op, open_shift, sale_payload, stock
from .test_supply_chain import gl, on_hand


def test_scenario_d_retail_sale_effects(org):
    stock(org.p["bread"], org.loc["SHOP1"], 50, D("6"), "B1")
    t, cashier = org.t["SHOP1"], org.u["cashier1"]
    sid = open_shift(t, cashier)
    payload = sale_payload(t, sid, cashier, [(org.p["bread"], 5, "15.00", "0", [])])
    [r] = apply_batch(t, [op("sale", payload)])
    assert r["status"] == "APPLIED" and r["total"] == "75.00" and r["flags"] == []
    sale = Sale.objects.get(pk=payload["id"])
    assert sale.tax_total == D("9.78") and sale.cost_total == D("30.00")
    assert on_hand(org.p["bread"], org.loc["SHOP1"]) == D("45")
    assert gl("cash") == D("75.00") and gl("revenue") == D("-65.22") and gl("vat_output") == D("-9.78")
    assert gl("cogs") == D("30.00") and gl("inventory_fg") == D("-30.00")
    je = JournalEntry.objects.get(source_type="SALE")
    assert je.branch == org.b["SHOP1"] and trial_balance()["balanced"]


def test_replaying_the_same_operation_is_idempotent(org):
    stock(org.p["bread"], org.loc["SHOP1"], 50, D("6"), "B1")
    t, cashier = org.t["SHOP1"], org.u["cashier1"]
    sid = open_shift(t, cashier)
    sale_op = op("sale", sale_payload(t, sid, cashier, [(org.p["bread"], 2, "15.00", "0", [])]))
    first = apply_batch(t, [sale_op])
    again = apply_batch(t, [sale_op, sale_op])  # e.g. response lost, terminal retries twice
    assert first[0]["status"] == again[0]["status"] == again[1]["status"] == "APPLIED"
    assert Sale.objects.count() == 1 and JournalEntry.objects.filter(source_type="SALE").count() == 1
    assert on_hand(org.p["bread"], org.loc["SHOP1"]) == D("48")
    # a different op carrying the same sale id is also absorbed (no double sale)
    dup = op("sale", sale_op["payload"])
    assert apply_batch(t, [dup])[0].get("duplicate") is True and Sale.objects.count() == 1


def test_scenario_e_cafe_order_consumes_recipe_and_modifiers(org):
    stock(org.p["beans"], org.loc["CAFE1"], 2, D("900"), "CF1")
    stock(org.p["milk"], org.loc["CAFE1"], 10, D("70"), "MK1")
    stock(org.p["cake"], org.loc["CAFE1"], 2, D("400"), "CK1")
    t, cashier = org.t["CAFE1"], org.u["cafecash"]
    sid = open_shift(t, cashier)
    tk = op("kitchen_ticket", {"id": str(uuid.uuid4()), "station": "BARISTA", "order_ref": "T4",
                               "items": [{"name": "Cappuccino", "qty": 2, "modifiers": ["Extra shot"]}],
                               "created_at": timezone.now().isoformat()})
    sale = sale_payload(t, sid, cashier, [(org.p["cappuccino"], 2, "85.00", "0", [org.shot]),
                                          (org.p["cake"], 1, "1200.00", "0", [])],
                        method="TELEBIRR", order_type="DINE_IN", table_label="T4")
    res = apply_batch(t, [tk, op("sale", sale)])
    assert [r["status"] for r in res] == ["APPLIED", "APPLIED"] and res[1]["flags"] == []
    assert KitchenTicket.objects.get().station == "BARISTA"
    # 2 cappuccinos = 2 x (9 g + 9 g extra shot) beans, 2 x 150 ml milk
    assert on_hand(org.p["beans"], org.loc["CAFE1"]) == D("1.964")
    assert on_hand(org.p["milk"], org.loc["CAFE1"]) == D("9.700")
    assert on_hand(org.p["cake"], org.loc["CAFE1"]) == D("1")
    s = Sale.objects.get(pk=sale["id"])
    assert s.cost_total == (D("0.036") * 900 + D("0.3") * 70 + 400).quantize(D("0.01"))
    assert gl("mobile_money") == s.total and trial_balance()["balanced"]


def test_price_difference_is_flagged_not_rejected(org):
    stock(org.p["bread"], org.loc["SHOP1"], 5, D("6"), "B1")
    t, cashier = org.t["SHOP1"], org.u["cashier1"]
    sid = open_shift(t, cashier)
    [r] = apply_batch(t, [op("sale", sale_payload(t, sid, cashier, [(org.p["bread"], 1, "14.00", "0", [])]))])
    assert r["status"] == "APPLIED" and r["flags"][0]["code"] == "price_differs"


def test_tampered_totals_are_rejected_and_kept_for_review(org):
    t, cashier = org.t["SHOP1"], org.u["cashier1"]
    sid = open_shift(t, cashier)
    p = sale_payload(t, sid, cashier, [(org.p["bread"], 2, "15.00", "0", [])])
    p["lines"][0]["total"] = "20.00"
    [r] = apply_batch(t, [op("sale", p)])
    assert r["status"] == "REJECTED" and r["error"] == "totals_mismatch"
    assert SyncOperation.objects.get(status="REJECTED").payload["number"] == p["number"]
    assert Sale.objects.count() == 0
    p2 = sale_payload(t, sid, cashier, [(org.p["bread"], 2, "15.00", "0", [])])
    p2["payments"][0]["amount"] = "10.00"
    assert apply_batch(t, [op("sale", p2)])[0]["error"] == "payment_mismatch"


def test_large_discount_requires_supervisor(org):
    stock(org.p["cake"], org.loc["SHOP1"], 5, D("400"), "C1")
    t, cashier = org.t["SHOP1"], org.u["cashier1"]
    sid = open_shift(t, cashier)
    p = sale_payload(t, sid, cashier, [(org.p["cake"], 1, "1200.00", "300.00", [])])
    [r] = apply_batch(t, [op("sale", p)])
    assert r["status"] == "REJECTED" and r["error"] in ("unknown_user", "forbidden")
    p2 = sale_payload(t, sid, cashier, [(org.p["cake"], 1, "1200.00", "300.00", [])],
                      discount_approver_id=org.u["mgr1"].pk)
    [r2] = apply_batch(t, [op("sale", p2)])
    assert r2["status"] == "APPLIED"
    assert Sale.objects.get(pk=p2["id"]).discount_approved_by == org.u["mgr1"]


def test_scenario_f_refund_rules(org):
    stock(org.p["bread"], org.loc["SHOP1"], 50, D("6"), "B1")
    t, cashier, mgr = org.t["SHOP1"], org.u["cashier1"], org.u["mgr1"]
    sid = open_shift(t, cashier)
    sale = sale_payload(t, sid, cashier, [(org.p["bread"], 3, "15.00", "0", [])])
    apply_batch(t, [op("sale", sale)])

    def refund(qty, approver, restock=True):
        return op("refund", {"id": str(uuid.uuid4()), "number": f"R-{uuid.uuid4().hex[:6]}", "sale_id": sale["id"],
                             "shift_id": sid, "cashier_id": cashier.pk, "approver_id": approver.pk,
                             "created_at": timezone.now().isoformat(), "reason": "Customer returned",
                             "method": "CASH", "restock": restock, "lines": [{"line_no": 1, "qty": str(qty)}]})

    assert apply_batch(t, [refund(1, cashier)])[0]["error"] in ("forbidden", "sod_violation")
    r1 = apply_batch(t, [refund(1, mgr)])[0]
    assert r1["status"] == "APPLIED" and r1["amount"] == "15.00"
    assert on_hand(org.p["bread"], org.loc["SHOP1"]) == D("48")  # 50 - 3 + 1 restocked
    r2 = apply_batch(t, [refund(5, mgr)])[0]
    assert r2["status"] == "REJECTED" and r2["error"] == "excess_refund"
    r3 = apply_batch(t, [refund(2, mgr, restock=False)])[0]
    assert r3["amount"] == "30.00"
    s = Sale.objects.get(pk=sale["id"])
    assert s.refunded_total == s.total == D("45.00")
    assert apply_batch(t, [refund(1, mgr)])[0]["error"] == "excess_refund"
    assert Refund.objects.count() == 2 and trial_balance()["balanced"]
    assert gl("sales_returns") == (D("45.00") - D("5.87")).quantize(D("0.01"))


def test_scenario_g_offline_burst_oversell_ordering_and_retry(org):
    """
    Shop 2 is offline: it records a shift, 4 sales (selling more bread than the system thinks it has) and a
    shift close. On reconnect the queue is uploaded; the first upload attempt is cut off half-way and retried.
    """
    stock(org.p["bread"], org.loc["SHOP2"], 10, D("6"), "B1")
    t, cashier = org.t["SHOP2"], org.u["cashier2"]
    sid = str(uuid.uuid4())
    queue = [op("shift_open", {"shift_id": sid, "cashier_id": cashier.pk, "opening_float": "300.00",
                               "opened_at": timezone.now().isoformat()})]
    sales = [sale_payload(t, sid, cashier, [(org.p["bread"], 4, "15.00", "0", [])], was_offline=True) for _ in range(4)]
    queue += [op("sale", s) for s in sales]
    queue.append(op("shift_close", {"shift_id": sid, "counted_cash": "530.00", "closed_at": timezone.now().isoformat(),
                                    "closed_by_id": cashier.pk, "approver_id": org.u["mgr2"].pk}))
    # out of order delivery: sales before their shift -> RETRY, and everything after waits (strict ordering)
    res = apply_batch(t, queue[1:3])
    assert [r["status"] for r in res] == ["RETRY", "RETRY"]
    assert Sale.objects.count() == 0
    # partial upload then full retry of the whole queue
    apply_batch(t, queue[:3])
    res = apply_batch(t, queue)
    assert all(r["status"] == "APPLIED" for r in res), res
    assert Sale.objects.filter(was_offline=True).count() == 4
    assert on_hand(org.p["bread"], org.loc["SHOP2"]) == D("-6")  # sold 16 with 10 on record
    disc = StockDiscrepancy.objects.filter(location=org.loc["SHOP2"], reason="NEGATIVE_STOCK")
    assert disc.aggregate(s=Sum("qty"))["s"] == D("-6")
    shift = Shift.objects.get(pk=sid)
    assert shift.expected_cash == D("540.00") and shift.over_short == D("-10.00")
    assert shift.approved_by == org.u["mgr2"]
    assert gl("cash_over_short") == D("10.00") and trial_balance()["balanced"]
    # nothing lost, nothing duplicated
    assert SyncOperation.objects.filter(terminal=t, status="APPLIED").count() == len(queue)
    assert JournalEntry.objects.filter(source_type="SALE").count() == 4


def test_terminal_cannot_act_for_another_branch_or_shift(org):
    t1, t2 = org.t["SHOP1"], org.t["SHOP2"]
    sid = open_shift(t1, org.u["cashier1"])
    # SHOP2 terminal tries to use a SHOP1 cashier
    bad = op("shift_open", {"shift_id": str(uuid.uuid4()), "cashier_id": org.u["cashier1"].pk, "opening_float": "0",
                            "opened_at": timezone.now().isoformat()})
    assert apply_batch(t2, [bad])[0]["error"] == "forbidden"
    # ... or post into SHOP1's shift
    p = sale_payload(t2, sid, org.u["cashier2"], [(org.p["bread"], 1, "15.00", "0", [])])
    assert apply_batch(t2, [op("sale", p)])[0]["error"] == "forbidden"
    # op ids are bound to the terminal that created them
    o = op("sale", sale_payload(t1, sid, org.u["cashier1"], [(org.p["bread"], 1, "15.00", "0", [])]))
    apply_batch(t1, [o])
    assert apply_batch(t2, [o])[0]["status"] == "REJECTED"


def test_sync_records_stock_movements_with_receipt_reference(org):
    stock(org.p["bread"], org.loc["SHOP1"], 5, D("6"), "B1")
    t = org.t["SHOP1"]
    sid = open_shift(t, org.u["cashier1"])
    p = sale_payload(t, sid, org.u["cashier1"], [(org.p["bread"], 2, "15.00", "0", [])])
    apply_batch(t, [op("sale", p)])
    m = StockMovement.objects.get(kind="SALE")
    assert m.doc_id == p["number"] and m.lot.code == "B1" and m.qty == D("-2")
    assert StockBalance.objects.get(location=org.loc["SHOP1"]).qty_on_hand == D("3")
