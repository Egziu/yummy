"""
Yummy OS settings.

All environment-specific values come from environment variables so the same
image runs in development, staging and production. Production refuses to start
with insecure defaults (see the DEBUG/SECRET_KEY checks below).
"""
import os
from pathlib import Path
from urllib.parse import urlparse, unquote

BASE_DIR = Path(__file__).resolve().parent.parent


def env(name, default=None):
    return os.environ.get(name, default)


def env_bool(name, default=False):
    v = os.environ.get(name)
    if v is None:
        return default
    return v.strip().lower() in {"1", "true", "yes", "on"}


DEBUG = env_bool("YUMMY_DEBUG", False)
SECRET_KEY = env("YUMMY_SECRET_KEY", "dev-insecure-key-change-me" if DEBUG else None)
if not SECRET_KEY:
    raise RuntimeError("YUMMY_SECRET_KEY must be set when YUMMY_DEBUG is off.")
if not DEBUG and SECRET_KEY.startswith("dev-insecure"):
    raise RuntimeError("Refusing to run production with the development secret key.")

ALLOWED_HOSTS = [h.strip() for h in env("YUMMY_ALLOWED_HOSTS", "localhost,127.0.0.1").split(",") if h.strip()]
CSRF_TRUSTED_ORIGINS = [o.strip() for o in env("YUMMY_CSRF_ORIGINS", "").split(",") if o.strip()]

INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "rest_framework",
    "drf_spectacular",
    "apps.core",
    "apps.iam",
    "apps.catalog",
    "apps.inventory",
    "apps.accounting",
    "apps.procurement",
    "apps.production",
    "apps.transfers",
    "apps.pos",
    "apps.reports",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "whitenoise.middleware.WhiteNoiseMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "yummy.urls"
TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ]
        },
    }
]
WSGI_APPLICATION = "yummy.wsgi.application"


def _db_from_url(url):
    u = urlparse(url)
    return {
        "ENGINE": "django.db.backends.postgresql",
        "NAME": u.path.lstrip("/"),
        "USER": unquote(u.username or ""),
        "PASSWORD": unquote(u.password or ""),
        "HOST": u.hostname or "localhost",
        "PORT": str(u.port or 5432),
        "CONN_MAX_AGE": int(env("YUMMY_DB_CONN_MAX_AGE", "60")),
        "OPTIONS": {"connect_timeout": 5},
    }


DATABASES = {"default": _db_from_url(env("DATABASE_URL", "postgres://yummy:yummy@localhost:5432/yummy"))}
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"
AUTH_USER_MODEL = "iam.User"

PASSWORD_HASHERS = [
    "django.contrib.auth.hashers.Argon2PasswordHasher",
    "django.contrib.auth.hashers.PBKDF2PasswordHasher",
]
AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator", "OPTIONS": {"min_length": 10}},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

LANGUAGE_CODE = "en"
LANGUAGES = [("en", "English"), ("am", "Amharic"), ("ti", "Tigrinya")]
TIME_ZONE = "Africa/Addis_Ababa"
USE_I18N = True
USE_TZ = True

STATIC_URL = "static/"
STATIC_ROOT = BASE_DIR / "staticfiles"
FRONTEND_DIST = Path(env("YUMMY_FRONTEND_DIST", str(BASE_DIR.parent / "frontend" / "dist")))

REST_FRAMEWORK = {
    "DEFAULT_AUTHENTICATION_CLASSES": [
        "apps.iam.auth.UserTokenAuthentication",
        "apps.iam.auth.TerminalAuthentication",
    ],
    "DEFAULT_PERMISSION_CLASSES": ["rest_framework.permissions.IsAuthenticated"],
    "DEFAULT_SCHEMA_CLASS": "drf_spectacular.openapi.AutoSchema",
    "EXCEPTION_HANDLER": "apps.core.exceptions.api_exception_handler",
    "DEFAULT_THROTTLE_RATES": {"login": env("YUMMY_LOGIN_RATE", "20/min"), "enroll": "10/min"},
    "COERCE_DECIMAL_TO_STRING": True,
    "DEFAULT_RENDERER_CLASSES": ["apps.core.renderers.ExactJSONRenderer"],
    "UNAUTHENTICATED_USER": None,
}
SPECTACULAR_SETTINGS = {"TITLE": "Yummy OS API", "VERSION": "1.0.0"}

# Back-office token lifetime (hours). POS terminals use long-lived device tokens.
YUMMY_TOKEN_TTL_HOURS = int(env("YUMMY_TOKEN_TTL_HOURS", "12"))
YUMMY_MAX_FAILED_LOGINS = int(env("YUMMY_MAX_FAILED_LOGINS", "5"))
YUMMY_LOCKOUT_MINUTES = int(env("YUMMY_LOCKOUT_MINUTES", "15"))
# PBKDF2-SHA256 iterations for offline POS PIN verifiers (the POS reads this from bootstrap).
YUMMY_PIN_ITERATIONS = int(env("YUMMY_PIN_ITERATIONS", "120000"))

SECURE_CONTENT_TYPE_NOSNIFF = True
SECURE_REFERRER_POLICY = "same-origin"
X_FRAME_OPTIONS = "DENY"
SESSION_COOKIE_HTTPONLY = True
if not DEBUG:
    SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")
    SECURE_SSL_REDIRECT = env_bool("YUMMY_SSL_REDIRECT", True)
    SESSION_COOKIE_SECURE = True
    CSRF_COOKIE_SECURE = True
    SECURE_HSTS_SECONDS = int(env("YUMMY_HSTS_SECONDS", "31536000"))
    SECURE_HSTS_INCLUDE_SUBDOMAINS = True

LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "json": {"format": '{"ts":"%(asctime)s","level":"%(levelname)s","logger":"%(name)s","msg":"%(message)s"}'}
    },
    "handlers": {"console": {"class": "logging.StreamHandler", "formatter": "json"}},
    "root": {"handlers": ["console"], "level": env("YUMMY_LOG_LEVEL", "INFO")},
}

# Serve the built frontend (PWA) from the site root so the service worker controls "/".
WHITENOISE_ROOT = FRONTEND_DIST if FRONTEND_DIST.exists() else None
