"""
Posting engine. Every business event calls `post()` with lines expressed as
mapping keys (configurable in AccountMapping) or explicit account codes.
"""
from collections import defaultdict
from dataclasses import dataclass, field
from decimal import Decimal

from django.db import transaction
from django.utils import timezone

from apps.core.exceptions import BusinessRuleError
from apps.core.models import DocumentSequence
from apps.core.money import ZERO, q2

from .models import Account, AccountMapping, FiscalPeriod, JournalEntry, JournalLine

# Default chart of accounts and posting rules (configurable after install).
DEFAULT_ACCOUNTS = [
    ("1010", "Cash on hand - POS drawers", "ASSET"),
    ("1020", "Bank - current account", "ASSET"),
    ("1030", "Mobile money clearing (telebirr / CBE Birr)", "ASSET"),
    ("1040", "Card settlement clearing", "ASSET"),
    ("1100", "Accounts receivable", "ASSET"),
    ("1210", "Inventory - raw materials & packaging", "ASSET"),
    ("1220", "Inventory - finished goods", "ASSET"),
    ("1230", "Inventory - in transit", "ASSET"),
    ("1240", "Work in progress", "ASSET"),
    ("1310", "VAT receivable (input)", "ASSET"),
    ("2010", "Accounts payable", "LIABILITY"),
    ("2020", "Goods received not invoiced", "LIABILITY"),
    ("2110", "VAT payable (output)", "LIABILITY"),
    ("3010", "Owner's equity", "EQUITY"),
    ("3020", "Opening balance equity", "EQUITY"),
    ("4010", "Sales revenue", "REVENUE"),
    ("4020", "Sales discounts", "REVENUE"),
    ("4030", "Sales returns", "REVENUE"),
    ("5010", "Cost of goods sold", "EXPENSE"),
    ("5020", "Waste, spoilage & expiry", "EXPENSE"),
    ("5030", "Inventory shrinkage & count differences", "EXPENSE"),
    ("5040", "Purchase price variance", "EXPENSE"),
    ("5050", "Production variance", "EXPENSE"),
    ("5110", "Applied direct labour (contra)", "EXPENSE"),
    ("5120", "Applied manufacturing overhead (contra)", "EXPENSE"),
    ("6010", "Cash over / short", "EXPENSE"),
]
DEFAULT_MAPPINGS = {
    "cash": "1010", "bank": "1020", "mobile_money": "1030", "card": "1040", "receivable": "1100",
    "inventory_raw": "1210", "inventory_fg": "1220", "in_transit": "1230", "wip": "1240",
    "vat_input": "1310", "payable": "2010", "grni": "2020", "vat_output": "2110",
    "opening_equity": "3020", "revenue": "4010", "sales_discount": "4020", "sales_returns": "4030",
    "cogs": "5010", "waste": "5020", "shrinkage": "5030", "ppv": "5040", "production_variance": "5050",
    "applied_labor": "5110", "applied_overhead": "5120", "cash_over_short": "6010",
}

PAYMENT_METHOD_ACCOUNT = {
    "CASH": "cash", "BANK_TRANSFER": "bank", "TELEBIRR": "mobile_money", "CBE_BIRR": "mobile_money",
    "CARD": "card", "CREDIT": "receivable",
}


def install_chart():
    for code, name, typ in DEFAULT_ACCOUNTS:
        Account.objects.get_or_create(code=code, defaults={"name": name, "type": typ})
    for key, code in DEFAULT_MAPPINGS.items():
        AccountMapping.objects.get_or_create(key=key, defaults={"account": Account.objects.get(code=code)})


def account_for(key_or_code) -> Account:
    m = AccountMapping.objects.select_related("account").filter(key=key_or_code).first()
    if m:
        return m.account
    return Account.objects.get(code=key_or_code)


@dataclass
class Draft:
    """Accumulates journal lines, merging same account/branch pairs."""

    lines: dict = field(default_factory=lambda: defaultdict(lambda: [ZERO, ZERO]))

    def dr(self, key, amount, branch=None):
        amount = q2(amount)
        if amount < 0:
            return self.cr(key, -amount, branch)
        if amount:
            self.lines[(key, branch.pk if branch else None)][0] += amount
        return self

    def cr(self, key, amount, branch=None):
        amount = q2(amount)
        if amount < 0:
            return self.dr(key, -amount, branch)
        if amount:
            self.lines[(key, branch.pk if branch else None)][1] += amount
        return self

    def totals(self):
        d = sum((v[0] for v in self.lines.values()), ZERO)
        c = sum((v[1] for v in self.lines.values()), ZERO)
        return d, c


def ensure_period_open(date):
    p, _ = FiscalPeriod.objects.get_or_create(year=date.year, month=date.month)
    if p.status == FiscalPeriod.Status.LOCKED:
        raise BusinessRuleError(f"Accounting period {date:%Y-%m} is locked.", code="period_locked")


@transaction.atomic
def post(draft: Draft, *, memo, source_type, source_id, idempotency_key, date=None, branch=None, user=None):
    """Post a balanced journal once. Re-posting with the same idempotency key returns the existing entry."""
    existing = JournalEntry.objects.filter(idempotency_key=idempotency_key).first()
    if existing:
        return existing
    d, c = draft.totals()
    if d != c:
        raise BusinessRuleError(f"Journal does not balance (Dr {d} / Cr {c}).", code="unbalanced")
    if d == 0:
        return None
    date = date or timezone.localdate()
    ensure_period_open(date)
    entry = JournalEntry.objects.create(
        number=DocumentSequence.next("JE", "JE"),
        date=date, memo=memo[:255], source_type=source_type, source_id=str(source_id),
        idempotency_key=idempotency_key, branch=branch,
        posted_by=user if getattr(user, "pk", None) else None,
    )
    rows = []
    for (key, branch_id), (dr, cr) in draft.lines.items():
        acct = account_for(key)
        net = dr - cr  # net per account/branch keeps lines single-sided
        if net == 0:
            continue
        rows.append(JournalLine(entry=entry, account=acct, branch_id=branch_id,
                                debit=net if net > 0 else ZERO, credit=-net if net < 0 else ZERO))
    JournalLine.objects.bulk_create(rows)
    return entry


@transaction.atomic
def reverse(entry: JournalEntry, *, memo=None, user=None, date=None):
    if hasattr(entry, "reversed_by"):
        raise BusinessRuleError("Entry already reversed.", code="already_reversed")
    date = date or timezone.localdate()
    ensure_period_open(date)
    rev = JournalEntry.objects.create(
        number=DocumentSequence.next("JE", "JE"), date=date, memo=memo or f"Reversal of {entry.number}",
        source_type=entry.source_type, source_id=entry.source_id,
        idempotency_key=f"reversal:{entry.idempotency_key}", branch=entry.branch, reversal_of=entry,
        posted_by=user if getattr(user, "pk", None) else None,
    )
    JournalLine.objects.bulk_create([
        JournalLine(entry=rev, account_id=l.account_id, branch_id=l.branch_id, debit=l.credit, credit=l.debit)
        for l in entry.lines.all()
    ])
    return rev


def trial_balance(date_to=None, branch=None):
    from django.db.models import Sum

    qs = JournalLine.objects.all()
    if date_to:
        qs = qs.filter(entry__date__lte=date_to)
    if branch:
        qs = qs.filter(branch=branch)
    rows = (qs.values("account__code", "account__name", "account__type")
            .annotate(dr=Sum("debit"), cr=Sum("credit")).order_by("account__code"))
    out = []
    td = tc = Decimal("0")
    for r in rows:
        net = (r["dr"] or 0) - (r["cr"] or 0)
        debit = net if net > 0 else Decimal("0")
        credit = -net if net < 0 else Decimal("0")
        td += debit
        tc += credit
        out.append({"code": r["account__code"], "name": r["account__name"], "type": r["account__type"],
                    "debit": q2(debit), "credit": q2(credit)})
    return {"rows": out, "total_debit": q2(td), "total_credit": q2(tc), "balanced": td == tc}


def profit_and_loss(date_from, date_to, branch=None):
    from django.db.models import Sum

    qs = JournalLine.objects.filter(entry__date__gte=date_from, entry__date__lte=date_to,
                                    account__type__in=["REVENUE", "EXPENSE"])
    if branch:
        qs = qs.filter(branch=branch)
    rows = qs.values("account__code", "account__name", "account__type").annotate(
        dr=Sum("debit"), cr=Sum("credit")).order_by("account__code")
    revenue = expense = Decimal("0")
    lines = []
    for r in rows:
        if r["account__type"] == "REVENUE":
            amt = (r["cr"] or 0) - (r["dr"] or 0)
            revenue += amt
        else:
            amt = (r["dr"] or 0) - (r["cr"] or 0)
            expense += amt
        lines.append({"code": r["account__code"], "name": r["account__name"], "type": r["account__type"],
                      "amount": q2(amt)})
    return {"lines": lines, "revenue": q2(revenue), "expenses": q2(expense), "net_profit": q2(revenue - expense)}
