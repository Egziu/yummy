from django.contrib import admin

from .models import Account, AccountMapping, FiscalPeriod

admin.site.register(Account)
admin.site.register(AccountMapping)
admin.site.register(FiscalPeriod)
