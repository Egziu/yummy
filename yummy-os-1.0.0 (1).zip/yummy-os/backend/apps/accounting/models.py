from django.conf import settings
from django.db import models
from django.db.models import Q

from apps.core.models import Branch


class Account(models.Model):
    class Type(models.TextChoices):
        ASSET = "ASSET", "Asset"
        LIABILITY = "LIABILITY", "Liability"
        EQUITY = "EQUITY", "Equity"
        REVENUE = "REVENUE", "Revenue"
        EXPENSE = "EXPENSE", "Expense"

    code = models.CharField(max_length=12, unique=True)
    name = models.CharField(max_length=120)
    type = models.CharField(max_length=10, choices=Type.choices)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["code"]

    def __str__(self):
        return f"{self.code} {self.name}"

    @property
    def debit_normal(self):
        return self.type in (self.Type.ASSET, self.Type.EXPENSE)


class AccountMapping(models.Model):
    """Posting-rule configuration: business event keys -> GL accounts."""

    key = models.CharField(max_length=40, unique=True)
    account = models.ForeignKey(Account, on_delete=models.PROTECT)
    description = models.CharField(max_length=160, blank=True)

    def __str__(self):
        return f"{self.key} -> {self.account.code}"


class FiscalPeriod(models.Model):
    class Status(models.TextChoices):
        OPEN = "OPEN", "Open"
        LOCKED = "LOCKED", "Locked"

    year = models.PositiveSmallIntegerField()
    month = models.PositiveSmallIntegerField()
    status = models.CharField(max_length=8, choices=Status.choices, default=Status.OPEN)
    locked_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.PROTECT)
    locked_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        unique_together = [("year", "month")]
        ordering = ["year", "month"]

    def __str__(self):
        return f"{self.year}-{self.month:02d} ({self.status})"


class JournalEntry(models.Model):
    """
    Posted journals are immutable (DB trigger). Corrections are made with a
    reversing entry. A deferred constraint trigger guarantees every entry
    balances at commit time.
    """

    number = models.CharField(max_length=30, unique=True)
    date = models.DateField(db_index=True)
    memo = models.CharField(max_length=255)
    source_type = models.CharField(max_length=40, db_index=True)
    source_id = models.CharField(max_length=60, db_index=True)
    idempotency_key = models.CharField(max_length=120, unique=True)
    branch = models.ForeignKey(Branch, null=True, blank=True, on_delete=models.PROTECT)
    posted_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.PROTECT)
    posted_at = models.DateTimeField(auto_now_add=True)
    reversal_of = models.OneToOneField("self", null=True, blank=True, on_delete=models.PROTECT,
                                       related_name="reversed_by")

    class Meta:
        ordering = ["-date", "-id"]
        verbose_name_plural = "journal entries"

    def __str__(self):
        return f"{self.number} {self.memo}"


class JournalLine(models.Model):
    entry = models.ForeignKey(JournalEntry, on_delete=models.PROTECT, related_name="lines")
    account = models.ForeignKey(Account, on_delete=models.PROTECT)
    branch = models.ForeignKey(Branch, null=True, blank=True, on_delete=models.PROTECT,
                               help_text="Cost centre dimension")
    debit = models.DecimalField(max_digits=16, decimal_places=2, default=0)
    credit = models.DecimalField(max_digits=16, decimal_places=2, default=0)
    description = models.CharField(max_length=160, blank=True)

    class Meta:
        indexes = [models.Index(fields=["account", "branch"])]
        constraints = [
            models.CheckConstraint(condition=Q(debit__gte=0) & Q(credit__gte=0), name="jl_nonneg"),
            models.CheckConstraint(
                condition=(Q(debit__gt=0) & Q(credit=0)) | (Q(credit__gt=0) & Q(debit=0)),
                name="jl_one_side",
            ),
        ]
