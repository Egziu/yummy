import hashlib
import json
from datetime import timedelta

from django.db.models import Q, Sum
from django.utils import timezone
from rest_framework.decorators import api_view
from rest_framework.response import Response

from apps.catalog.models import Category, Product
from apps.catalog.services import branch_price_table
from apps.core.ethiopian import format_ethiopian
from apps.core.exceptions import BusinessRuleError
from apps.core.models import Setting
from apps.iam.models import RoleAssignment, Terminal, User
from apps.iam.permissions import permissions_of, require, require_terminal
from apps.inventory.models import StockBalance
from apps.inventory.services import sellable_location

from .models import KitchenTicket, Sale
from .sync import apply_batch

POS_PERMS = ["pos.sell", "pos.refund", "pos.refund_approve", "pos.discount_override", "pos.shift_approve",
             "kds.operate"]


@api_view(["GET"])
def bootstrap(request):
    """Everything a terminal needs to run offline. Cached by the POS in IndexedDB."""
    term = require_terminal(request)
    branch = term.branch
    prices = branch_price_table(branch)
    products = (Product.objects.filter(is_active=True, is_sellable=True, pk__in=prices.keys())
                .select_related("category", "tax_rate", "unit").prefetch_related("modifiers"))
    try:
        loc = sellable_location(branch)
        stock_tot = {pid: float(q) for pid, q in StockBalance.objects.filter(location=loc).values("product_id")
                     .annotate(q=Sum("qty_on_hand")).values_list("product_id", "q")}
    except BusinessRuleError:
        stock_tot = {}
    user_ids = (RoleAssignment.objects.filter(Q(branch=branch) | Q(branch__isnull=True))
                .filter(role__permissions__has_any_keys=POS_PERMS).values_list("user_id", flat=True))
    cashiers = []
    for u in User.objects.filter(Q(pk__in=user_ids) | Q(is_superuser=True), is_active=True).exclude(pin_hash=""):
        perms = sorted(permissions_of(u, branch) & set(POS_PERMS))
        if perms:
            cashiers.append({"id": u.pk, "name": u.label, "pin_salt": u.pin_salt, "pin_hash": u.pin_hash,
                             "pin_iterations": u.pin_iterations, "permissions": perms})
    payload = {
        "terminal": {"code": term.code, "name": term.name, "kind": term.kind},
        "branch": {"code": branch.code, "name": branch.name, "kind": branch.kind, "address": branch.address,
                   "phone": branch.phone, "tin": branch.tin},
        "settings": {
            "max_discount_pct": str(Setting.get("pos.max_discount_pct_without_approval")),
            "currency": "ETB",
        },
        "categories": [{"id": c.id, "name": c.name, "color": c.color, "sort": c.sort_order}
                       for c in Category.objects.filter(products__in=products).distinct()],
        "products": [
            {
                "id": p.pk, "sku": p.sku, "barcode": p.barcode or "", "name": p.name, "name_local": p.name_local,
                "category_id": p.category_id, "unit": p.unit.code, "kind": p.kind,
                "price": str(prices[p.pk][0]), "tax_inclusive": prices[p.pk][1],
                "tax_rate": str(p.tax_rate.rate if p.tax_rate else 0), "station": p.station,
                "color": p.color or p.category.color, "allergens": p.allergens,
                "stock": stock_tot.get(p.pk), "is_stocked": p.is_stocked,
                "modifiers": [{"id": m.pk, "name": m.name, "group": m.group, "price_delta": str(m.price_delta)}
                              for m in p.modifiers.all() if m.is_active],
            }
            for p in products
        ],
        "cashiers": cashiers,
        "payment_methods": ["CASH", "TELEBIRR", "CBE_BIRR", "BANK_TRANSFER", "CARD"],
    }
    version = hashlib.sha256(json.dumps(payload, sort_keys=True, default=str).encode()).hexdigest()[:16]
    payload["catalog_version"] = version
    last = (Sale.objects.filter(terminal=term, number__startswith=f"{term.code}-").order_by("-created_at")
            .values_list("number", flat=True)[:200])
    seqs = [int(n.rsplit("-", 1)[1]) for n in last if n.rsplit("-", 1)[1].isdigit()]
    payload["last_receipt_seq"] = max(seqs) if seqs else 0
    payload["server_time"] = timezone.now().isoformat()
    payload["ethiopian_date"] = format_ethiopian(timezone.localdate())
    return Response(payload)


@api_view(["POST"])
def sync(request):
    term = require_terminal(request)
    ops = request.data.get("ops") or []
    if not isinstance(ops, list):
        return Response({"error": "invalid", "detail": "ops must be a list"}, status=400)
    results = apply_batch(term, ops, request.data.get("pending_count"))
    return Response({"results": results, "server_time": timezone.now().isoformat()})


@api_view(["GET"])
def lookup_sale(request, number):
    """Online lookup of a sale (any terminal of the same branch) for refunds."""
    term = require_terminal(request)
    sale = Sale.objects.filter(number=number, branch=term.branch).prefetch_related("lines__product", "payments").first()
    if sale is None:
        return Response({"error": "not_found", "detail": "No sale with that number at this branch."}, status=404)
    return Response({
        "id": str(sale.id), "number": sale.number, "created_at": sale.created_at, "total": str(sale.total),
        "refunded_total": str(sale.refunded_total), "shift_id": str(sale.shift_id),
        "lines": [{"line_no": l.line_no, "product_id": l.product_id, "name": l.product.name, "qty": str(l.qty),
                   "qty_refunded": str(l.qty_refunded), "total": str(l.total), "tax": str(l.tax),
                   "is_stocked": l.product.is_stocked}
                  for l in sale.lines.all()],
        "payments": [{"method": p.method, "amount": str(p.amount)} for p in sale.payments.all()],
    })


def _kds_branch(request):
    if isinstance(request.auth, Terminal):
        return request.auth.branch
    branch_code = request.query_params.get("branch") or request.data.get("branch")
    from apps.core.models import Branch

    branch = Branch.objects.get(code=branch_code)
    require(request.user, "kds.operate", branch)
    return branch


@api_view(["GET"])
def kds_tickets(request):
    branch = _kds_branch(request)
    station = request.query_params.get("station")
    since = timezone.now() - timedelta(hours=12)
    qs = KitchenTicket.objects.filter(branch=branch, created_at__gte=since).exclude(status__in=["SERVED", "VOID"])
    if station:
        qs = qs.filter(station=station)
    return Response([{"id": str(t.id), "station": t.station, "order_ref": t.order_ref, "order_type": t.order_type,
                      "items": t.items, "status": t.status, "created_at": t.created_at} for t in qs[:200]])


@api_view(["POST"])
def kds_update(request, ticket_id):
    branch = _kds_branch(request)
    status = request.data.get("status")
    if status not in KitchenTicket.Status.values:
        return Response({"error": "invalid", "detail": "Unknown status"}, status=400)
    t = KitchenTicket.objects.get(pk=ticket_id, branch=branch)
    t.status = status
    if status == "READY":
        t.ready_at = timezone.now()
    t.save(update_fields=["status", "ready_at", "updated_at"])
    return Response({"ok": True, "status": t.status})


@api_view(["POST"])
def heartbeat(request):
    term = require_terminal(request)
    pending = request.data.get("pending_count")
    upd = {"last_seen_at": timezone.now(), "app_version": str(request.data.get("app_version", ""))[:30]}
    if pending is not None:
        upd["reported_pending"] = max(0, int(pending))
    Terminal.objects.filter(pk=term.pk).update(**upd)
    return Response({"server_time": timezone.now().isoformat()})

