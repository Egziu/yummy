"""
Offline-first POS synchronisation.

Terminals record every action locally (IndexedDB) as an operation with a
client-generated UUID, then upload them in order. The server applies each
operation exactly once (SyncOperation is the idempotency ledger) inside its own
savepoint and answers per operation:

  APPLIED   - recorded; the client may drop it from the outbox
  REJECTED  - permanently invalid; recorded for manager review (never silently lost)
  RETRY     - transient (dependency not yet synced / server error); client retries

Physical events that already happened (a customer paid and left with bread)
are never rejected because of stock: they are booked, and any oversell raises
a StockDiscrepancy. Price differences against the current price list are
flagged, not rejected - the customer paid the price on the receipt.
"""
import logging
import uuid
from collections import defaultdict
from datetime import datetime
from decimal import Decimal, InvalidOperation

from django.db import transaction
from django.utils import timezone
from django.utils.dateparse import parse_datetime

from apps.accounting.services import PAYMENT_METHOD_ACCOUNT, Draft, post
from apps.catalog.models import Modifier, Product
from apps.catalog.services import resolve_price
from apps.core import audit
from apps.core.exceptions import BusinessRuleError
from apps.core.models import Setting
from apps.core.money import ZERO, div_half_up, from_cents, price_line, q2, q3, to_cents, to_milli
from apps.iam.models import Terminal, User
from apps.iam.permissions import has_perm
from apps.inventory import services as inv
from apps.inventory.models import StockMovement
from apps.production.services import active_recipe, explode

from .models import CashMovement, KitchenTicket, Payment, Refund, Sale, SaleLine, Shift, SyncOperation

log = logging.getLogger("yummy.sync")
MAX_BATCH = 200


class Reject(Exception):
    def __init__(self, code, detail):
        super().__init__(detail)
        self.code, self.detail = code, detail


class Retry(Exception):
    pass


def _dt(value, field):
    if isinstance(value, datetime):
        return value
    dt = parse_datetime(str(value or ""))
    if dt is None:
        raise Reject("invalid_payload", f"'{field}' is not a valid timestamp")
    if timezone.is_naive(dt):
        dt = timezone.make_aware(dt)
    return dt


def _dec(value, field):
    try:
        d = Decimal(str(value))
    except (InvalidOperation, TypeError):
        raise Reject("invalid_payload", f"'{field}' is not a number")
    if not d.is_finite():
        raise Reject("invalid_payload", f"'{field}' is not a number")
    return d


def _uuid(value, field):
    try:
        return uuid.UUID(str(value))
    except (ValueError, TypeError):
        raise Reject("invalid_payload", f"'{field}' is not a UUID")


def _user(user_id, terminal, perm, role="cashier"):
    user = User.objects.filter(pk=user_id, is_active=True).first()
    if user is None:
        raise Reject("unknown_user", f"Unknown or inactive {role}")
    if not has_perm(user, perm, terminal.branch):
        raise Reject("forbidden", f"{user.label} lacks '{perm}' at {terminal.branch.code}")
    return user


def _shift(shift_id, terminal, lock=False):
    qs = Shift.objects.select_for_update() if lock else Shift.objects
    shift = qs.filter(pk=_uuid(shift_id, "shift_id")).first()
    if shift is None:
        raise Retry("shift not yet synced")
    if shift.terminal_id != terminal.pk:
        raise Reject("forbidden", "Shift belongs to another terminal")
    return shift


# ---------------------------------------------------------------- handlers

def op_shift_open(terminal, p):
    cashier = _user(p.get("cashier_id"), terminal, "pos.sell")
    sid = _uuid(p.get("shift_id"), "shift_id")
    if Shift.objects.filter(pk=sid).exists():
        return {"shift_id": str(sid)}
    float_amt = q2(_dec(p.get("opening_float", "0"), "opening_float"))
    if float_amt < 0:
        raise Reject("invalid_payload", "Opening float cannot be negative")
    Shift.objects.create(id=sid, terminal=terminal, branch=terminal.branch, cashier=cashier,
                         opened_at=_dt(p.get("opened_at"), "opened_at"), opening_float=float_amt)
    audit.record("pos.shift_opened", actor=cashier, object_type="pos.Shift", object_id=sid, branch=terminal.branch,
                 terminal=terminal, data={"float": str(float_amt)})
    return {"shift_id": str(sid)}


def op_cash_move(terminal, p):
    shift = _shift(p.get("shift_id"), terminal)
    user = _user(p.get("user_id"), terminal, "pos.sell")
    kind = p.get("kind")
    if kind not in ("IN", "OUT"):
        raise Reject("invalid_payload", "kind must be IN or OUT")
    amount = q2(_dec(p.get("amount"), "amount"))
    if amount <= 0:
        raise Reject("invalid_payload", "amount must be positive")
    cm = CashMovement.objects.create(id=_uuid(p.get("id"), "id"), shift=shift, kind=kind, amount=amount,
                                     reason=str(p.get("reason", ""))[:120], at=_dt(p.get("at"), "at"), user=user)
    br = terminal.branch
    d = Draft().dr("bank", amount, br).cr("cash", amount, br) if kind == "OUT" else Draft().dr("cash", amount, br).cr("bank", amount, br)
    post(d, memo=f"Cash {kind.lower()} {terminal.code}: {cm.reason}", source_type="CASH", source_id=cm.id,
         idempotency_key=f"cash:{cm.id}", date=timezone.localdate(cm.at), branch=br, user=user)
    return {"id": str(cm.id)}


def _consume_for_line(product, qty, location, sale, user, flags, modifiers):
    """Stock effect of selling `qty` of product. Returns {inventory_account_key: cost}."""
    costs = defaultdict(lambda: ZERO)

    def take(p, q):
        _, c = inv.consume(p, location, q3(q), StockMovement.Kind.SALE, "SALE", sale.number, actor=user,
                           allow_negative=True, discrepancy_source=f"SALE:{sale.number}")
        costs[p.inventory_account_key] += c

    if product.is_stocked:
        take(product, qty)
    elif product.kind == Product.Kind.MENU:
        recipe = active_recipe(product)
        if recipe is None:
            flags.append({"code": "no_recipe", "product": product.sku})
        else:
            req, _ = explode(recipe, qty / recipe.output_qty)
            for ing, iq in req.items():
                if ing.is_stocked:
                    take(ing, iq)
    for m in modifiers:
        if m.ingredient_id and m.ingredient_qty > 0:
            take(m.ingredient, m.ingredient_qty * qty)
    return costs


def op_sale(terminal, p):
    sale_id = _uuid(p.get("id"), "id")
    existing = Sale.objects.filter(pk=sale_id).first()
    if existing:
        return {"sale_id": str(existing.id), "number": existing.number, "duplicate": True}
    branch = terminal.branch
    shift = _shift(p.get("shift_id"), terminal)
    cashier = _user(p.get("cashier_id"), terminal, "pos.sell")
    created_at = _dt(p.get("created_at"), "created_at")
    if shift.status == Shift.Status.CLOSED and shift.closed_at and created_at > shift.closed_at:
        raise Reject("shift_closed", "Sale is dated after its shift was closed")
    number = str(p.get("number", ""))[:40]
    if not number or Sale.objects.filter(number=number).exists():
        raise Reject("duplicate_number", f"Receipt number '{number}' already used by another sale")
    tax_inclusive = bool(p.get("tax_inclusive", True))
    lines = p.get("lines") or []
    payments = p.get("payments") or []
    if not lines:
        raise Reject("invalid_payload", "Sale has no lines")
    if not payments:
        raise Reject("invalid_payload", "Sale has no payments")

    flags = []
    max_disc = Decimal(str(Setting.get("pos.max_discount_pct_without_approval")))
    approver = None
    priced, gross_c, disc_c, tax_c, total_c = [], 0, 0, 0, 0
    for i, l in enumerate(lines, start=1):
        product = Product.objects.filter(pk=l.get("product_id")).select_related("tax_rate").first()
        if product is None:
            raise Reject("unknown_product", f"Line {i}: unknown product")
        if not product.is_sellable or not product.is_active:
            flags.append({"code": "product_not_sellable", "product": product.sku})
        qty = _dec(l.get("qty"), "qty")
        unit_price = _dec(l.get("unit_price"), "unit_price")
        discount = _dec(l.get("discount", "0"), "discount")
        rate = _dec(l.get("tax_rate", "0"), "tax_rate")
        try:
            calc = price_line(unit_price, qty, discount, rate, tax_inclusive)
        except ValueError as e:
            raise Reject("invalid_line", f"Line {i}: {e}")
        if l.get("total") is not None and to_cents(_dec(l["total"], "total")) != calc["total"]:
            raise Reject("totals_mismatch", f"Line {i}: terminal total {l['total']} != server {from_cents(calc['total'])}")
        mod_ids = [m.get("id") for m in (l.get("modifiers") or [])]
        mods = list(Modifier.objects.filter(pk__in=mod_ids).select_related("ingredient"))
        # price check (flag only)
        list_price, _ = resolve_price(product, branch, created_at)
        expected = (list_price or ZERO) + sum((m.price_delta for m in mods), ZERO)
        if list_price is None:
            flags.append({"code": "no_list_price", "product": product.sku})
        elif q2(expected) != q2(unit_price):
            flags.append({"code": "price_differs", "product": product.sku, "charged": str(q2(unit_price)),
                          "list": str(q2(expected))})
        if product.tax_rate and q2(rate * 100) != q2(product.tax_rate.rate * 100):
            flags.append({"code": "tax_rate_differs", "product": product.sku, "charged": str(rate)})
        if calc["discount"] and calc["gross"] and calc["discount"] * 100 > calc["gross"] * max_disc:
            if approver is None:
                approver = _user(p.get("discount_approver_id"), terminal, "pos.discount_override", "approver")
        priced.append((i, product, qty, unit_price, rate, calc, mods, l))
        gross_c += calc["gross"]
        disc_c += calc["discount"]
        tax_c += calc["tax"]
        total_c += calc["total"]

    pay_total_c = 0
    for pmt in payments:
        if pmt.get("method") not in Payment.Method.values:
            raise Reject("invalid_payment", f"Unknown payment method {pmt.get('method')}")
        amt_c = to_cents(_dec(pmt.get("amount"), "amount"))
        if amt_c <= 0:
            raise Reject("invalid_payment", "Payment amounts must be positive")
        if pmt.get("method") != "CASH" and pmt.get("method") != "CREDIT" and not str(pmt.get("reference", "")).strip():
            flags.append({"code": "missing_payment_reference", "method": pmt.get("method")})
        pay_total_c += amt_c
    if pay_total_c != total_c:
        raise Reject("payment_mismatch", f"Payments {from_cents(pay_total_c)} do not equal total {from_cents(total_c)}")
    claimed = p.get("totals", {}).get("total")
    if claimed is not None and to_cents(_dec(claimed, "totals.total")) != total_c:
        raise Reject("totals_mismatch", f"Terminal total {claimed} != server {from_cents(total_c)}")

    sale = Sale.objects.create(
        id=sale_id, number=number, branch=branch, terminal=terminal, shift=shift, cashier=cashier,
        order_type=p.get("order_type") if p.get("order_type") in Sale.OrderType.values else Sale.OrderType.RETAIL,
        table_label=str(p.get("table_label", ""))[:20], customer_name=str(p.get("customer_name", ""))[:80],
        customer_tin=str(p.get("customer_tin", ""))[:40], created_at=created_at,
        was_offline=bool(p.get("was_offline")), tax_inclusive=tax_inclusive, gross=from_cents(gross_c),
        discount_total=from_cents(disc_c), tax_total=from_cents(tax_c), total=from_cents(total_c), flags=flags,
        discount_approved_by=approver,
    )
    location = inv.sellable_location(branch)
    draft = Draft()
    cost_total = ZERO
    revenue_c = 0
    for i, product, qty, unit_price, rate, calc, mods, l in priced:
        costs = _consume_for_line(product, qty, location, sale, cashier, flags, mods)
        cost = sum(costs.values(), ZERO)
        SaleLine.objects.create(
            sale=sale, line_no=i, product=product, qty=q3(qty), unit_price=q2(unit_price),
            gross=from_cents(calc["gross"]), discount=from_cents(calc["discount"]), tax_rate=rate,
            tax=from_cents(calc["tax"]), base=from_cents(calc["base"]), total=from_cents(calc["total"]),
            cost=q2(cost), modifiers=[{"id": m.pk, "name": m.name, "price_delta": str(m.price_delta)} for m in mods],
            note=str(l.get("note", ""))[:160],
        )
        cost_total += cost
        revenue_c += calc["base"]
        for acct, c in costs.items():
            draft.dr("cogs", c, branch).cr(acct, c, branch)
    for pmt in payments:
        amt = from_cents(to_cents(_dec(pmt["amount"], "amount")))
        tendered = pmt.get("tendered")
        Payment.objects.create(sale=sale, method=pmt["method"], amount=amt,
                               tendered=q2(_dec(tendered, "tendered")) if tendered not in (None, "") else None,
                               reference=str(pmt.get("reference", ""))[:80])
        draft.dr(PAYMENT_METHOD_ACCOUNT[pmt["method"]], amt, branch)
    draft.cr("revenue", from_cents(revenue_c), branch).cr("vat_output", from_cents(tax_c), branch)
    sale.cost_total = q2(cost_total)
    sale.flags = flags
    sale.save(update_fields=["cost_total", "flags"])
    post(draft, memo=f"POS sale {sale.number}", source_type="SALE", source_id=sale.number,
         idempotency_key=f"sale:{sale.id}", date=timezone.localdate(created_at), branch=branch, user=cashier)
    if flags:
        audit.record("pos.sale_flagged", actor=cashier, obj=sale, branch=branch, terminal=terminal,
                     data={"flags": flags})
    return {"sale_id": str(sale.id), "number": sale.number, "total": str(sale.total), "flags": flags}


def refund_amounts(line: SaleLine, qty: Decimal):
    """Proportional refund for `qty` of a line; the final unit refunds the exact remainder (no rounding drift)."""
    total_c, tax_c = to_cents(line.total), to_cents(line.tax)
    lq, prior, now = to_milli(line.qty), to_milli(line.qty_refunded), to_milli(qty)

    def share(c, m):
        return div_half_up(c * m, lq)

    if prior + now == lq:
        return total_c - share(total_c, prior), tax_c - share(tax_c, prior)
    return share(total_c, prior + now) - share(total_c, prior), share(tax_c, prior + now) - share(tax_c, prior)


def op_refund(terminal, p):
    rid = _uuid(p.get("id"), "id")
    if Refund.objects.filter(pk=rid).exists():
        return {"refund_id": str(rid), "duplicate": True}
    branch = terminal.branch
    shift = _shift(p.get("shift_id"), terminal)
    cashier = _user(p.get("cashier_id"), terminal, "pos.refund")
    approver = _user(p.get("approver_id"), terminal, "pos.refund_approve", "approver")
    if approver.pk == cashier.pk:
        raise Reject("sod_violation", "Refund must be approved by a different person")
    sale = Sale.objects.select_for_update().filter(pk=_uuid(p.get("sale_id"), "sale_id")).first()
    if sale is None:
        raise Retry("original sale not yet synced")
    if sale.branch_id != branch.pk:
        raise Reject("forbidden", "Refunds must be processed at the branch of sale")
    reason = str(p.get("reason", "")).strip()[:160]
    if not reason:
        raise Reject("invalid_payload", "A refund reason is required")
    method = p.get("method", "CASH")
    if method not in Payment.Method.values:
        raise Reject("invalid_payment", "Unknown refund method")
    restock = bool(p.get("restock"))
    amount_c = tax_c = 0
    detail = []
    draft = Draft()
    location = inv.sellable_location(branch)
    for spec in p.get("lines") or []:
        line = SaleLine.objects.select_for_update().select_related("product").filter(
            sale=sale, line_no=int(spec.get("line_no", 0))).first()
        if line is None:
            raise Reject("invalid_line", f"Sale has no line {spec.get('line_no')}")
        qty = q3(_dec(spec.get("qty"), "qty"))
        if qty <= 0 or line.qty_refunded + qty > line.qty:
            raise Reject("excess_refund", f"Line {line.line_no}: cannot refund {qty}; "
                                          f"{line.qty - line.qty_refunded} remaining")
        a_c, t_c = refund_amounts(line, qty)
        cost = q2(line.cost * qty / line.qty)
        line.qty_refunded += qty
        line.save(update_fields=["qty_refunded"])
        amount_c += a_c
        tax_c += t_c
        detail.append({"line_no": line.line_no, "sku": line.product.sku, "qty": str(qty), "amount": str(from_cents(a_c))})
        if restock and line.product.is_stocked and cost > 0:
            inv._apply(line.product, location, qty, StockMovement.Kind.SALE_RETURN, "REFUND", p.get("number", rid),
                       unit_cost=cost / qty, actor=cashier, note=reason)
            draft.dr(line.product.inventory_account_key, cost, branch).cr("cogs", cost, branch)
    if not detail:
        raise Reject("invalid_payload", "Refund has no lines")
    amount, tax = from_cents(amount_c), from_cents(tax_c)
    claimed = p.get("amount")
    flags = []
    if claimed is not None and q2(_dec(claimed, "amount")) != amount:
        flags.append({"code": "refund_amount_differs", "terminal": str(claimed), "server": str(amount)})
    number = str(p.get("number") or f"R-{rid.hex[:10]}")[:40]
    Refund.objects.create(id=rid, number=number, sale=sale, shift=shift, created_at=_dt(p.get("created_at"), "created_at"),
                          cashier=cashier, approved_by=approver, reason=reason, method=method, amount=amount, tax=tax,
                          restock=restock, lines=detail)
    Sale.objects.filter(pk=sale.pk).update(refunded_total=sale.refunded_total + amount)
    draft.dr("sales_returns", amount - tax, branch).dr("vat_output", tax, branch).cr(
        PAYMENT_METHOD_ACCOUNT[method], amount, branch)
    post(draft, memo=f"Refund {number} of {sale.number}", source_type="REFUND", source_id=number,
         idempotency_key=f"refund:{rid}", branch=branch, user=cashier)
    audit.record("pos.refund", actor=cashier, object_type="pos.Refund", object_id=rid, branch=branch, terminal=terminal,
                 data={"sale": sale.number, "amount": str(amount), "approver": approver.pk, "reason": reason,
                       "flags": flags})
    return {"refund_id": str(rid), "amount": str(amount), "flags": flags}


def op_kitchen_ticket(terminal, p):
    tid = _uuid(p.get("id"), "id")
    if KitchenTicket.objects.filter(pk=tid).exists():
        return {"ticket_id": str(tid)}
    station = p.get("station", "KITCHEN")
    if station not in ("BARISTA", "KITCHEN", "DESSERT"):
        raise Reject("invalid_payload", "Unknown station")
    items = [{"name": str(i.get("name", ""))[:80], "qty": str(i.get("qty", "1")),
              "modifiers": [str(m)[:40] for m in (i.get("modifiers") or [])][:10], "note": str(i.get("note", ""))[:120]}
             for i in (p.get("items") or [])][:50]
    if not items:
        raise Reject("invalid_payload", "Ticket has no items")
    KitchenTicket.objects.create(id=tid, branch=terminal.branch, terminal=terminal, station=station,
                                 order_ref=str(p.get("order_ref", ""))[:40], order_type=str(p.get("order_type", "DINE_IN"))[:10],
                                 items=items, created_at=_dt(p.get("created_at"), "created_at"))
    return {"ticket_id": str(tid)}


def expected_cash(shift):
    from django.db.models import Sum

    sales_cash = Payment.objects.filter(sale__shift=shift, method="CASH").aggregate(s=Sum("amount"))["s"] or ZERO
    refunds_cash = Refund.objects.filter(shift=shift, method="CASH").aggregate(s=Sum("amount"))["s"] or ZERO
    cin = shift.cash_movements.filter(kind="IN").aggregate(s=Sum("amount"))["s"] or ZERO
    cout = shift.cash_movements.filter(kind="OUT").aggregate(s=Sum("amount"))["s"] or ZERO
    return q2(shift.opening_float + sales_cash - refunds_cash + cin - cout)


def op_shift_close(terminal, p):
    shift = _shift(p.get("shift_id"), terminal, lock=True)
    if shift.status == Shift.Status.CLOSED:
        return {"shift_id": str(shift.id), "expected_cash": str(shift.expected_cash), "over_short": str(shift.over_short)}
    closer = _user(p.get("closed_by_id") or shift.cashier_id, terminal, "pos.sell")
    counted = q2(_dec(p.get("counted_cash"), "counted_cash"))
    if counted < 0:
        raise Reject("invalid_payload", "Counted cash cannot be negative")
    expected = expected_cash(shift)
    diff = counted - expected
    approver = None
    if diff and p.get("approver_id"):
        approver = _user(p.get("approver_id"), terminal, "pos.shift_approve", "approver")
    shift.status, shift.closed_at = Shift.Status.CLOSED, _dt(p.get("closed_at"), "closed_at")
    shift.counted_cash, shift.expected_cash, shift.over_short = counted, expected, diff
    shift.closed_by, shift.approved_by = closer, approver
    shift.save()
    if diff:
        br = terminal.branch
        d = Draft().dr("cash", diff, br).cr("cash_over_short", diff, br)
        post(d, memo=f"Cash over/short shift {str(shift.id)[:8]} {terminal.code}", source_type="SHIFT",
             source_id=shift.id, idempotency_key=f"shift:{shift.id}", date=timezone.localdate(shift.closed_at),
             branch=br, user=closer)
    audit.record("pos.shift_closed", actor=closer, object_type="pos.Shift", object_id=shift.id, branch=terminal.branch,
                 terminal=terminal, data={"expected": str(expected), "counted": str(counted), "diff": str(diff),
                                          "approved_by": approver.pk if approver else None})
    return {"shift_id": str(shift.id), "expected_cash": str(expected), "over_short": str(diff)}


HANDLERS = {
    "shift_open": op_shift_open,
    "cash_move": op_cash_move,
    "sale": op_sale,
    "refund": op_refund,
    "kitchen_ticket": op_kitchen_ticket,
    "shift_close": op_shift_close,
}


def apply_operation(terminal: Terminal, op: dict) -> dict:
    try:
        op_id = _uuid(op.get("op_id"), "op_id")
    except Reject as r:
        return {"op_id": op.get("op_id"), "status": "REJECTED", "error": r.code, "detail": r.detail}
    done = SyncOperation.objects.filter(pk=op_id).first()
    if done:
        if done.terminal_id != terminal.pk:
            return {"op_id": str(op_id), "status": "REJECTED", "error": "forbidden", "detail": "Operation id conflict"}
        return {"op_id": str(op_id), "status": done.status, **done.result}
    kind = op.get("kind")
    handler = HANDLERS.get(kind)
    payload = op.get("payload") or {}
    try:
        client_at = _dt(op.get("created_at") or timezone.now(), "created_at")
        if handler is None:
            raise Reject("unknown_kind", f"Unknown operation '{kind}'")
        with transaction.atomic():
            result = handler(terminal, payload)
            SyncOperation.objects.create(op_id=op_id, terminal=terminal, kind=kind, status="APPLIED", result=result,
                                         payload=payload, client_created_at=client_at)
        return {"op_id": str(op_id), "status": "APPLIED", **result}
    except Retry as r:
        return {"op_id": str(op_id), "status": "RETRY", "detail": str(r)}
    except (Reject, BusinessRuleError) as r:
        code = getattr(r, "code", "business_rule")
        detail = getattr(r, "detail", None) or getattr(r, "message", str(r))
        with transaction.atomic():
            SyncOperation.objects.create(
                op_id=op_id, terminal=terminal, kind=str(kind)[:20], status="REJECTED",
                result={"error": code, "detail": detail}, payload=payload,
                client_created_at=timezone.now(),
            )
            audit.record("pos.sync_rejected", object_type="pos.SyncOperation", object_id=op_id, branch=terminal.branch,
                         terminal=terminal, data={"kind": kind, "error": code, "detail": detail})
        return {"op_id": str(op_id), "status": "REJECTED", "error": code, "detail": detail}
    except Exception:  # transient: keep in the client outbox and retry later
        log.exception("sync op %s failed", op_id)
        return {"op_id": str(op_id), "status": "RETRY", "detail": "server_error"}


def apply_batch(terminal, ops, pending_count=None):
    if len(ops) > MAX_BATCH:
        raise BusinessRuleError(f"At most {MAX_BATCH} operations per request.")
    results = []
    blocked = False
    for op in ops:
        if blocked:
            # keep strict ordering: once an op must retry, later ops wait for it
            results.append({"op_id": op.get("op_id"), "status": "RETRY", "detail": "waiting_for_earlier_operation"})
            continue
        r = apply_operation(terminal, op)
        results.append(r)
        if r["status"] == "RETRY":
            blocked = True
    now = timezone.now()
    upd = {"last_seen_at": now}
    if ops:
        upd["last_sync_at"] = now
    if pending_count is not None:
        upd["reported_pending"] = max(0, int(pending_count) - sum(1 for r in results if r["status"] != "RETRY"))
    Terminal.objects.filter(pk=terminal.pk).update(**upd)
    return results
