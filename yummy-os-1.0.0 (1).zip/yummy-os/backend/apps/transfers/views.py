from django.db.models import Q
from django.shortcuts import get_object_or_404
from rest_framework.decorators import api_view
from rest_framework.response import Response

from apps.catalog.models import Product
from apps.core.api import dec, user_ref
from apps.inventory.models import Location
from apps.iam.permissions import branches_for, require_user

from . import services
from .models import TransferOrder


def _json(t):
    return {
        "id": t.pk, "number": t.number, "status": t.status, "status_label": t.get_status_display(),
        "source": t.source.code, "source_branch": t.source.branch.code,
        "destination": t.destination.code, "destination_branch": t.destination.branch.code,
        "note": t.note, "needed_by": t.needed_by, "driver": t.driver, "vehicle": t.vehicle,
        "requested_by": user_ref(t.requested_by), "requested_at": t.requested_at,
        "approved_by": user_ref(t.approved_by), "approved_at": t.approved_at,
        "dispatched_by": user_ref(t.dispatched_by), "dispatched_at": t.dispatched_at,
        "received_by": user_ref(t.received_by), "received_at": t.received_at,
        "lines": [{"id": l.pk, "sku": l.product.sku, "name": l.product.name, "unit": l.product.unit.code,
                   "requested": l.qty_requested, "approved": l.qty_approved, "dispatched": l.qty_dispatched,
                   "received": l.qty_received, "damaged": l.qty_damaged, "note": l.discrepancy_note,
                   "lots": [{"lot": a.lot.code if a.lot else None, "expiry": a.lot.expiry_date if a.lot else None,
                             "qty": a.qty} for a in l.allocations.all()]}
                  for l in t.lines.all()],
    }


def _qs():
    return (TransferOrder.objects.select_related("source__branch", "destination__branch", "requested_by",
                                                  "approved_by", "dispatched_by", "received_by")
            .prefetch_related("lines__product__unit", "lines__allocations__lot"))


@api_view(["GET", "POST"])
def transfers(request):
    user = require_user(request)
    if request.method == "GET":
        allowed = set(branches_for(user, "transfer.request").values_list("pk", flat=True)) | set(
            branches_for(user, "transfer.approve").values_list("pk", flat=True)) | set(
            branches_for(user, "transfer.dispatch").values_list("pk", flat=True)) | set(
            branches_for(user, "transfer.receive").values_list("pk", flat=True))
        qs = _qs().filter(Q(source__branch__in=allowed) | Q(destination__branch__in=allowed))
        if s := request.query_params.get("status"):
            qs = qs.filter(status__in=s.split(","))
        return Response([_json(t) for t in qs[:200]])
    src = get_object_or_404(Location, code=request.data.get("source"))
    dst = get_object_or_404(Location, code=request.data.get("destination"))
    lines = [{"product": get_object_or_404(Product, sku=l.get("sku")), "qty": dec(l, "qty", positive=True)}
             for l in request.data.get("lines") or []]
    t = services.request_transfer(user, src, dst, lines, note=str(request.data.get("note", ""))[:255])
    return Response(_json(_qs().get(pk=t.pk)), status=201)


@api_view(["GET"])
def transfer_detail(request, tid):
    require_user(request)
    return Response(_json(get_object_or_404(_qs(), pk=tid)))


@api_view(["POST"])
def transfer_action(request, tid, action):
    user = require_user(request)
    if action == "approve":
        services.approve_transfer(user, tid)
    elif action == "dispatch":
        services.dispatch_transfer(user, tid, str(request.data.get("driver", ""))[:80],
                                   str(request.data.get("vehicle", ""))[:40])
    elif action == "receive":
        services.receive_transfer(user, tid, request.data.get("lines"))
    elif action == "cancel":
        services.cancel_transfer(user, tid, str(request.data.get("reason", ""))[:200])
    else:
        return Response({"error": "not_found"}, status=404)
    return Response(_json(_qs().get(pk=tid)))
