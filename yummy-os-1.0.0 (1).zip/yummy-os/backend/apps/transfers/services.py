"""
Inter-branch transfers with custody tracking:
request -> approve (FEFO lots reserved) -> dispatch (stock moves to IN-TRANSIT)
-> receive (to destination; damage to waste; shortage to shrinkage + discrepancy).
"""
from django.db import transaction
from django.utils import timezone

from apps.accounting.services import Draft, post
from apps.core import audit
from apps.core.exceptions import BusinessRuleError
from apps.core.models import DocumentSequence
from apps.core.money import ZERO, q2, q3
from apps.inventory import services as inv
from apps.inventory.models import StockDiscrepancy, StockMovement
from apps.iam.permissions import require

from .models import TransferAllocation, TransferLine, TransferOrder

S = TransferOrder.Status


@transaction.atomic
def request_transfer(user, source, destination, lines, note="", needed_by=None):
    require(user, "transfer.request", destination.branch)
    if source.pk == destination.pk:
        raise BusinessRuleError("Source and destination must differ.")
    if not lines:
        raise BusinessRuleError("A transfer needs at least one line.")
    t = TransferOrder.objects.create(number=DocumentSequence.next("TR", "TR"), source=source, destination=destination,
                                     note=note, needed_by=needed_by, requested_by=user)
    for l in lines:
        if q3(l["qty"]) <= 0:
            raise BusinessRuleError("Requested quantities must be positive.")
        TransferLine.objects.create(order=t, product=l["product"], qty_requested=q3(l["qty"]))
    audit.record("transfer.requested", actor=user, obj=t, branch=destination.branch,
                 data={"from": source.code, "to": destination.code, "lines": len(lines)})
    return t


def _lock(order_id):
    return TransferOrder.objects.select_for_update().select_related("source__branch", "destination__branch").get(
        pk=order_id)


@transaction.atomic
def approve_transfer(user, order_id):
    t = _lock(order_id)
    require(user, "transfer.approve", t.source.branch)
    if t.status != S.SUBMITTED:
        raise BusinessRuleError(f"{t.number} is not awaiting approval (status {t.status}).")
    if t.requested_by_id == user.pk:
        raise BusinessRuleError("You cannot approve your own transfer request.", code="sod_violation")
    any_qty = False
    for line in t.lines.select_related("product"):
        allocs, short = inv.allocate_fefo(line.product, t.source, line.qty_requested)
        for a in allocs:
            inv.reserve(a.balance_id, a.qty)
            TransferAllocation.objects.create(line=line, lot=a.lot, qty=a.qty)
        line.qty_approved = q3(line.qty_requested - short)
        line.discrepancy_note = f"Short at approval: {short}" if short else ""
        line.save(update_fields=["qty_approved", "discrepancy_note"])
        any_qty = any_qty or line.qty_approved > 0
    if not any_qty:
        raise BusinessRuleError("Nothing is available to transfer at the source.", code="insufficient_stock")
    t.status, t.approved_by, t.approved_at = S.APPROVED, user, timezone.now()
    t.save()
    audit.record("transfer.approved", actor=user, obj=t, branch=t.source.branch)
    return t


@transaction.atomic
def cancel_transfer(user, order_id, reason=""):
    t = _lock(order_id)
    require(user, "transfer.approve", t.source.branch)
    if t.status not in (S.SUBMITTED, S.APPROVED):
        raise BusinessRuleError("Dispatched transfers cannot be cancelled; receive and return them instead.")
    for line in t.lines.all():
        for a in line.allocations.all():
            inv.release(line.product, t.source, a.lot, a.qty)
    t.status = S.CANCELLED
    t.save(update_fields=["status"])
    audit.record("transfer.cancelled", actor=user, obj=t, data={"reason": reason})
    return t


@transaction.atomic
def dispatch_transfer(user, order_id, driver="", vehicle=""):
    t = _lock(order_id)
    require(user, "transfer.dispatch", t.source.branch)
    if t.status != S.APPROVED:
        raise BusinessRuleError(f"{t.number} must be approved before dispatch (status {t.status}).")
    transit = inv.in_transit_location(t.destination.branch)
    draft, src_branch = Draft(), t.source.branch
    for line in t.lines.select_related("product"):
        total = ZERO
        for a in line.allocations.all():
            cost = inv.avg_cost(line.product)
            inv.move_between(line.product, t.source, transit, a.qty, lot=a.lot, kind_out=StockMovement.Kind.TRANSFER_OUT,
                             kind_in=StockMovement.Kind.TRANSFER_IN, doc_type="TR", doc_id=t.number, actor=user,
                             release_reserved=a.qty, unit_cost=cost, note="dispatch")
            a.unit_cost = cost
            a.save(update_fields=["unit_cost"])
            total += a.qty
            value = q2(a.qty * cost)
            draft.dr("in_transit", value, src_branch).cr(line.product.inventory_account_key, value, src_branch)
        line.qty_dispatched = total
        line.save(update_fields=["qty_dispatched"])
    t.status, t.dispatched_by, t.dispatched_at = S.DISPATCHED, user, timezone.now()
    t.driver, t.vehicle = driver, vehicle
    t.save()
    post(draft, memo=f"Transfer {t.number} dispatched {t.source.code} -> {t.destination.code}", source_type="TR",
         source_id=t.number, idempotency_key=f"tr-dispatch:{t.number}", branch=src_branch, user=user)
    audit.record("transfer.dispatched", actor=user, obj=t, branch=src_branch, data={"driver": driver})
    return t


@transaction.atomic
def receive_transfer(user, order_id, lines=None):
    """
    lines: [{"line": id, "qty_received": D, "qty_damaged": D, "note": str}]; omitted lines are received in full.
    The row lock + status check make a second receipt impossible (no duplicated stock).
    """
    t = _lock(order_id)
    dest_branch = t.destination.branch
    require(user, "transfer.receive", dest_branch)
    if t.status != S.DISPATCHED:
        raise BusinessRuleError(f"{t.number} is not in transit (status {t.status}).", code="already_received"
                                if t.status in (S.RECEIVED, S.RECONCILED) else "business_rule")
    specs = {int(l["line"]): l for l in (lines or [])}
    transit = inv.in_transit_location(dest_branch)
    waste = inv.waste_location(dest_branch)
    draft, differences = Draft(), False
    for line in t.lines.select_related("product"):
        spec = specs.get(line.pk, {})
        received = q3(spec.get("qty_received", line.qty_dispatched))
        damaged = q3(spec.get("qty_damaged", 0))
        if received < 0 or damaged < 0 or received + damaged > line.qty_dispatched:
            raise BusinessRuleError(f"Received + damaged exceeds dispatched for {line.product.name}.")
        short = line.qty_dispatched - received - damaged
        buckets = [(received, t.destination, StockMovement.Kind.TRANSFER_IN, line.product.inventory_account_key),
                   (damaged, waste, StockMovement.Kind.WASTE, "waste"),
                   (short, waste, StockMovement.Kind.WASTE, "shrinkage")]
        allocs = list(line.allocations.all())
        ai, left_in_alloc = 0, (allocs[0].qty if allocs else ZERO)
        for qty, dest, kind, acct in buckets:
            remaining = qty
            while remaining > 0 and ai < len(allocs):
                take = min(remaining, left_in_alloc)
                a = allocs[ai]
                inv.move_between(line.product, transit, dest, take, lot=a.lot, kind_out=StockMovement.Kind.TRANSFER_OUT,
                                 kind_in=kind, doc_type="TR", doc_id=t.number, actor=user, unit_cost=a.unit_cost,
                                 note="receive" if acct != "shrinkage" else "transit shortage")
                value = q2(take * a.unit_cost)
                draft.dr(acct, value, dest_branch).cr("in_transit", value, t.source.branch)
                remaining -= take
                left_in_alloc -= take
                if left_in_alloc == 0:
                    ai += 1
                    left_in_alloc = allocs[ai].qty if ai < len(allocs) else ZERO
        if short > 0:
            StockDiscrepancy.objects.create(product=line.product, location=t.destination, qty=-short,
                                            reason="TRANSIT_SHORTAGE", source=f"TR:{t.number}")
        if short or damaged:
            differences = True
        line.qty_received, line.qty_damaged = received, damaged
        line.discrepancy_note = (spec.get("note") or "")[:200]
        line.save(update_fields=["qty_received", "qty_damaged", "discrepancy_note"])
    t.status = S.RECONCILED if differences else S.RECEIVED
    t.received_by, t.received_at = user, timezone.now()
    t.save()
    post(draft, memo=f"Transfer {t.number} received at {t.destination.code}", source_type="TR", source_id=t.number,
         idempotency_key=f"tr-receive:{t.number}", branch=dest_branch, user=user)
    audit.record("transfer.received", actor=user, obj=t, branch=dest_branch, data={"differences": differences})
    return t
