from django.conf import settings
from django.db import models
from django.db.models import Q

from apps.catalog.models import Product
from apps.inventory.models import Location, Lot


class TransferOrder(models.Model):
    class Status(models.TextChoices):
        SUBMITTED = "SUBMITTED", "Requested"
        APPROVED = "APPROVED", "Approved (stock reserved)"
        DISPATCHED = "DISPATCHED", "In transit"
        RECEIVED = "RECEIVED", "Received"
        RECONCILED = "RECONCILED", "Received with differences"
        CANCELLED = "CANCELLED", "Cancelled"

    number = models.CharField(max_length=30, unique=True)
    source = models.ForeignKey(Location, on_delete=models.PROTECT, related_name="+")
    destination = models.ForeignKey(Location, on_delete=models.PROTECT, related_name="+")
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.SUBMITTED)
    note = models.CharField(max_length=255, blank=True)
    needed_by = models.DateField(null=True, blank=True)
    requested_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="+")
    requested_at = models.DateTimeField(auto_now_add=True)
    approved_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.PROTECT,
                                    related_name="+")
    approved_at = models.DateTimeField(null=True, blank=True)
    dispatched_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.PROTECT,
                                      related_name="+")
    dispatched_at = models.DateTimeField(null=True, blank=True)
    driver = models.CharField(max_length=80, blank=True)
    vehicle = models.CharField(max_length=40, blank=True)
    received_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.PROTECT,
                                    related_name="+")
    received_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-id"]
        constraints = [models.CheckConstraint(condition=~Q(source=models.F("destination")), name="xfer_distinct_locations")]

    def __str__(self):
        return self.number


class TransferLine(models.Model):
    order = models.ForeignKey(TransferOrder, on_delete=models.CASCADE, related_name="lines")
    product = models.ForeignKey(Product, on_delete=models.PROTECT)
    qty_requested = models.DecimalField(max_digits=14, decimal_places=3)
    qty_approved = models.DecimalField(max_digits=14, decimal_places=3, default=0)
    qty_dispatched = models.DecimalField(max_digits=14, decimal_places=3, default=0)
    qty_received = models.DecimalField(max_digits=14, decimal_places=3, default=0)
    qty_damaged = models.DecimalField(max_digits=14, decimal_places=3, default=0)
    discrepancy_note = models.CharField(max_length=200, blank=True)

    class Meta:
        constraints = [
            models.CheckConstraint(condition=Q(qty_requested__gt=0), name="xl_requested_positive"),
            models.CheckConstraint(
                condition=Q(qty_received__gte=0) & Q(qty_damaged__gte=0)
                & Q(qty_received__lte=models.F("qty_dispatched") - models.F("qty_damaged")),
                name="xl_receipt_within_dispatch"),
        ]


class TransferAllocation(models.Model):
    """Lot-level plan created at approval (reserved) and executed at dispatch."""

    line = models.ForeignKey(TransferLine, on_delete=models.CASCADE, related_name="allocations")
    lot = models.ForeignKey(Lot, null=True, blank=True, on_delete=models.PROTECT)
    qty = models.DecimalField(max_digits=14, decimal_places=3)
    unit_cost = models.DecimalField(max_digits=14, decimal_places=4, default=0)
