from django.db.models import Q
from django.shortcuts import get_object_or_404
from rest_framework.decorators import api_view
from rest_framework.response import Response

from apps.catalog.models import Product
from apps.core.api import dec, user_ref
from apps.core.models import Branch
from apps.core.money import q2
from apps.iam.permissions import branches_for, require, require_user

from . import services as inv
from . import workflows
from .models import Location, Lot, StockAdjustment, StockBalance, StockDiscrepancy, StockMovement


@api_view(["GET"])
def balances(request):
    user = require_user(request)
    allowed = branches_for(user, "inventory.view")
    qs = (StockBalance.objects.filter(location__branch__in=allowed).exclude(qty_on_hand=0, qty_reserved=0)
          .exclude(location__kind=Location.Kind.WASTE)
          .select_related("product__unit", "product__category", "location__branch", "lot"))
    if b := request.query_params.get("branch"):
        qs = qs.filter(location__branch__code=b)
    if loc := request.query_params.get("location"):
        qs = qs.filter(location__code=loc)
    if q := request.query_params.get("q"):
        qs = qs.filter(Q(product__name__icontains=q) | Q(product__sku__icontains=q) | Q(lot__code__icontains=q))
    agg = {}
    for b in qs[:5000]:
        key = (b.product_id, b.location_id)
        r = agg.setdefault(key, {
            "product_id": b.product_id, "sku": b.product.sku, "name": b.product.name, "unit": b.product.unit.code,
            "category": b.product.category.name, "location": b.location.code, "location_kind": b.location.kind,
            "branch": b.location.branch.code, "on_hand": 0, "reserved": 0, "lots": [],
            "reorder_point": b.product.reorder_point, "avg_cost": inv.avg_cost(b.product),
        })
        r["on_hand"] += b.qty_on_hand
        r["reserved"] += b.qty_reserved
        if b.lot:
            r["lots"].append({"id": b.lot_id, "code": b.lot.code, "expiry": b.lot.expiry_date, "qty": b.qty_on_hand,
                              "on_hold": b.lot.on_hold})
    rows = []
    for r in agg.values():
        r["available"] = r["on_hand"] - r["reserved"] if r["location_kind"] not in ("IN_TRANSIT", "QUARANTINE") else 0
        r["value"] = q2(r["on_hand"] * r["avg_cost"])
        r["low"] = r["location_kind"] in ("STORAGE", "COLD", "SALES") and r["on_hand"] <= r["reorder_point"]
        rows.append(r)
    if request.query_params.get("low") == "1":
        rows = [r for r in rows if r["low"]]
    rows.sort(key=lambda r: (r["branch"], r["name"], r["location"]))
    return Response(rows)


@api_view(["GET"])
def movements(request):
    user = require_user(request)
    allowed = branches_for(user, "inventory.view")
    qs = StockMovement.objects.filter(location__branch__in=allowed).select_related("product", "location", "lot", "actor")
    for param, field in (("product", "product__sku"), ("location", "location__code"), ("doc", "doc_id"),
                         ("lot", "lot_id")):
        if v := request.query_params.get(param):
            qs = qs.filter(**{field: v})
    limit = min(int(request.query_params.get("limit", 100)), 500)
    return Response([{
        "at": m.at, "kind": m.kind, "product": m.product.name, "sku": m.product.sku, "location": m.location.code,
        "lot": m.lot.code if m.lot else None, "qty": m.qty, "unit_cost": m.unit_cost, "doc": f"{m.doc_type} {m.doc_id}",
        "note": m.note, "actor": user_ref(m.actor),
    } for m in qs[:limit]])


@api_view(["GET"])
def locations(request):
    user = require_user(request)
    allowed = branches_for(user, "inventory.view")
    qs = Location.objects.filter(branch__in=allowed, is_active=True).select_related("branch")
    if b := request.query_params.get("branch"):
        qs = qs.filter(branch__code=b)
    return Response([{"id": l.pk, "code": l.code, "name": l.name, "branch": l.branch.code, "kind": l.kind,
                      "level": l.level, "parent": l.parent_id, "is_sellable": l.is_sellable} for l in qs])


@api_view(["POST"])
def update_map(request, location_id):
    user = require_user(request)
    loc = get_object_or_404(Location, pk=location_id)
    require(user, "inventory.map_edit", loc.branch)
    for f in ("map_x", "map_y", "map_w", "map_h"):
        if f in request.data:
            setattr(loc, f, max(0, int(request.data[f])))
    loc.save(update_fields=["map_x", "map_y", "map_w", "map_h"])
    from apps.core import audit

    audit.record("inventory.map_edited", actor=user, obj=loc, branch=loc.branch,
                 data={k: getattr(loc, k) for k in ("map_x", "map_y", "map_w", "map_h")})
    return Response({"ok": True})


def _adj_json(a):
    return {"id": a.pk, "number": a.number, "location": a.location.code, "branch": a.location.branch.code,
            "reason": a.reason, "status": a.status, "note": a.note, "value": a.value, "created_at": a.created_at,
            "created_by": user_ref(a.created_by), "approved_by": user_ref(a.approved_by),
            "lines": [{"sku": l.product.sku, "name": l.product.name, "lot": l.lot.code if l.lot else None,
                       "qty_change": l.qty_change} for l in a.lines.all()]}


@api_view(["GET", "POST"])
def adjustments(request):
    user = require_user(request)
    if request.method == "GET":
        allowed = branches_for(user, "inventory.view")
        qs = (StockAdjustment.objects.filter(location__branch__in=allowed).select_related(
            "location__branch", "created_by", "approved_by").prefetch_related("lines__product", "lines__lot")
              .order_by("-id"))
        return Response([_adj_json(a) for a in qs[:100]])
    loc = get_object_or_404(Location, code=request.data.get("location"))
    lines = []
    for l in request.data.get("lines") or []:
        product = get_object_or_404(Product, sku=l.get("sku"))
        lot = get_object_or_404(Lot, pk=l["lot_id"]) if l.get("lot_id") else None
        lines.append({"product": product, "lot": lot, "qty_change": dec(l, "qty_change")})
    adj = workflows.request_adjustment(user, loc, request.data.get("reason", "COUNT"), lines,
                                       note=str(request.data.get("note", ""))[:255])
    return Response(_adj_json(adj), status=201)


@api_view(["POST"])
def approve_adjustment(request, adj_id):
    adj = workflows.approve_adjustment(require_user(request), adj_id)
    return Response(_adj_json(adj))


@api_view(["GET"])
def expiring(request):
    user = require_user(request)
    allowed = set(branches_for(user, "inventory.view").values_list("code", flat=True))
    rows = [r for r in workflows.expiring_lots(request.query_params.get("days")) if r["branch"] in allowed]
    return Response(rows)


@api_view(["POST"])
def lot_hold(request, lot_id):
    lot = workflows.set_lot_hold(require_user(request), lot_id, bool(request.data.get("hold", True)),
                                 str(request.data.get("reason", ""))[:200])
    return Response({"id": lot.pk, "on_hold": lot.on_hold})


@api_view(["GET"])
def discrepancies(request):
    user = require_user(request)
    allowed = branches_for(user, "inventory.view")
    qs = StockDiscrepancy.objects.filter(location__branch__in=allowed).select_related("product", "location__branch")
    if request.query_params.get("status", "OPEN") != "ALL":
        qs = qs.filter(status=request.query_params.get("status", "OPEN"))
    return Response([{"id": d.pk, "created_at": d.created_at, "sku": d.product.sku, "product": d.product.name,
                      "location": d.location.code, "branch": d.location.branch.code, "qty": d.qty,
                      "reason": d.reason, "source": d.source, "status": d.status} for d in qs[:300]])


@api_view(["POST"])
def resolve_discrepancy(request, disc_id):
    user = require_user(request)
    d = get_object_or_404(StockDiscrepancy, pk=disc_id)
    require(user, "inventory.adjust_approve", d.location.branch)
    note = str(request.data.get("note", "")).strip()
    if not note:
        return Response({"error": "invalid", "detail": "A resolution note is required."}, status=400)
    d.status, d.resolved_by, d.resolution_note = StockDiscrepancy.Status.RESOLVED, user, note[:255]
    d.save()
    from apps.core import audit

    audit.record("inventory.discrepancy_resolved", actor=user, obj=d, branch=d.location.branch, data={"note": note})
    return Response({"ok": True})


@api_view(["GET"])
def branches(request):
    require_user(request)
    return Response([{"code": b.code, "name": b.name, "kind": b.kind} for b in Branch.objects.filter(is_active=True)])


@api_view(["GET"])
def products(request):
    require_user(request)
    qs = Product.objects.filter(is_active=True).select_related("unit", "category")
    if k := request.query_params.get("kind"):
        qs = qs.filter(kind__in=k.split(","))
    return Response([{"id": p.pk, "sku": p.sku, "name": p.name, "kind": p.kind, "unit": p.unit.code,
                      "category": p.category.name, "avg_cost": inv.avg_cost(p)} for p in qs])
