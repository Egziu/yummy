"""Stock adjustments, disposals and quality holds (with approvals and accounting)."""
from datetime import timedelta

from django.db import transaction
from django.utils import timezone

from apps.accounting.services import Draft, post
from apps.core import audit
from apps.core.exceptions import BusinessRuleError
from apps.core.models import DocumentSequence
from apps.core.money import ZERO, q2, q3
from apps.iam.permissions import require

from . import services as inv
from .models import Lot, StockAdjustment, StockAdjustmentLine, StockMovement


@transaction.atomic
def request_adjustment(user, location, reason, lines, note=""):
    """lines: [{"product": Product, "qty_change": Decimal, "lot": Lot|None}]"""
    require(user, "inventory.adjust", location.branch)
    if not lines:
        raise BusinessRuleError("An adjustment needs at least one line.")
    adj = StockAdjustment.objects.create(number=DocumentSequence.next("ADJ", "ADJ"), location=location,
                                         reason=reason, note=note, created_by=user)
    for l in lines:
        StockAdjustmentLine.objects.create(adjustment=adj, product=l["product"], lot=l.get("lot"),
                                           qty_change=q3(l["qty_change"]))
    audit.record("inventory.adjustment_requested", actor=user, obj=adj, branch=location.branch,
                 data={"reason": reason, "lines": len(lines)})
    return adj


@transaction.atomic
def approve_adjustment(user, adj_id):
    adj = StockAdjustment.objects.select_for_update().select_related("location__branch").get(pk=adj_id)
    branch = adj.location.branch
    require(user, "inventory.adjust_approve", branch)
    if adj.status != StockAdjustment.Status.SUBMITTED:
        raise BusinessRuleError(f"Adjustment {adj.number} is already {adj.get_status_display().lower()}.")
    if adj.created_by_id == user.pk:
        raise BusinessRuleError("You cannot approve an adjustment you requested (segregation of duties).",
                                code="sod_violation")
    kind = StockMovement.Kind.WASTE if adj.reason in ("DAMAGE", "EXPIRY", "WASTE") else StockMovement.Kind.ADJUSTMENT
    expense_key = "waste" if kind == StockMovement.Kind.WASTE else "shrinkage"
    draft, total = Draft(), ZERO
    for line in adj.lines.select_related("product", "lot"):
        cost = inv.avg_cost(line.product)
        inv._apply(line.product, adj.location, line.qty_change, kind, "ADJ", adj.number, lot=line.lot,
                   unit_cost=cost, actor=user, note=adj.get_reason_display())
        value = q2(line.qty_change * cost)
        total += value
        draft.dr(line.product.inventory_account_key, value, branch)
        draft.cr(expense_key, value, branch)
    adj.status = StockAdjustment.Status.POSTED
    adj.approved_by = user
    adj.approved_at = timezone.now()
    adj.value = q2(total)
    adj.save()
    post(draft, memo=f"Stock adjustment {adj.number} ({adj.get_reason_display()})", source_type="ADJ",
         source_id=adj.number, idempotency_key=f"adj:{adj.number}", branch=branch, user=user)
    audit.record("inventory.adjustment_posted", actor=user, obj=adj, branch=branch, data={"value": str(adj.value)})
    return adj


@transaction.atomic
def set_lot_hold(user, lot_id, hold: bool, reason=""):
    lot = Lot.objects.select_for_update().get(pk=lot_id)
    require(user, "quality.manage")
    lot.on_hold = hold
    lot.save(update_fields=["on_hold"])
    audit.record("quality.lot_hold" if hold else "quality.lot_release", actor=user, obj=lot,
                 data={"reason": reason, "lot": lot.code, "product": lot.product.sku})
    return lot


def expiring_lots(days=None, branch=None):
    from apps.core.models import Setting
    from .models import StockBalance

    days = int(days if days is not None else Setting.get("inventory.expiry_warning_days"))
    limit = timezone.localdate() + timedelta(days=days)
    qs = (StockBalance.objects.filter(qty_on_hand__gt=0, lot__expiry_date__isnull=False,
                                      lot__expiry_date__lte=limit)
          .exclude(location__kind__in=["WASTE"])
          .select_related("product", "lot", "location__branch"))
    if branch:
        qs = qs.filter(location__branch=branch)
    today = timezone.localdate()
    return [
        {"product": b.product.name, "sku": b.product.sku, "lot": b.lot.code, "expiry": b.lot.expiry_date,
         "expired": b.lot.expiry_date < today, "location": b.location.code, "branch": b.location.branch.code,
         "qty": b.qty_on_hand, "value": q2(b.qty_on_hand * inv.avg_cost(b.product)), "lot_id": b.lot_id}
        for b in qs.order_by("lot__expiry_date")
    ]

