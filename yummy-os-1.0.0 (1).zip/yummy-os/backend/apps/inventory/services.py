"""
Stock ledger services. Quantities only change through `_apply`, which writes
an immutable StockMovement and updates the StockBalance projection under a row
lock in the same transaction.

Valuation policy: enterprise moving weighted-average cost (ProductCost).
Picking policy (operational, independent of valuation): FEFO, then FIFO by lot.
"""
import uuid
from dataclasses import dataclass
from decimal import Decimal

from django.db import IntegrityError, transaction
from django.db.models import F, Q, Sum
from django.utils import timezone

from apps.core.exceptions import BusinessRuleError, InsufficientStock
from apps.core.models import Setting
from apps.core.money import ZERO, q3, q4

from .models import Location, Lot, ProductCost, StockBalance, StockDiscrepancy, StockMovement


def _balance(product, location, lot):
    """Fetch and row-lock a balance, creating it if needed."""
    filt = dict(product=product, location=location, lot=lot)
    bal = StockBalance.objects.select_for_update().filter(**filt).first()
    if bal is None:
        try:
            with transaction.atomic():
                StockBalance.objects.create(**filt)
        except IntegrityError:
            pass  # created concurrently
        bal = StockBalance.objects.select_for_update().get(**filt)
    return bal


def avg_cost(product) -> Decimal:
    pc = ProductCost.objects.filter(product=product).first()
    if pc and pc.avg_cost:
        return pc.avg_cost
    return product.standard_cost or ZERO


def _apply(product, location, qty, kind, doc_type, doc_id, *, lot=None, unit_cost=None, actor=None, note="",
           txn=None, allow_negative=False, release_reserved=ZERO):
    qty = q3(qty)
    if qty == 0:
        raise BusinessRuleError("Movement quantity cannot be zero.")
    if not product.is_stocked:
        raise BusinessRuleError(f"{product.name} is not a stocked item.")
    bal = _balance(product, location, lot)
    new_on_hand = bal.qty_on_hand + qty
    new_reserved = bal.qty_reserved - release_reserved
    if new_reserved < 0:
        raise BusinessRuleError("Cannot release more than is reserved.")
    if qty < 0 and not allow_negative and (new_on_hand < 0 or new_on_hand < new_reserved):
        raise InsufficientStock(
            f"Not enough {product.name} at {location.code}: available {bal.available}, requested {-qty}.",
            product=product.sku, location=location.code, available=str(bal.available),
        )
    mv = StockMovement.objects.create(
        txn=txn or uuid.uuid4(), product=product, location=location, lot=lot,
        qty=qty, unit_cost=q4(unit_cost if unit_cost is not None else avg_cost(product)), kind=kind,
        doc_type=doc_type, doc_id=str(doc_id), note=note[:200], actor=actor if getattr(actor, "pk", None) else None,
    )
    StockBalance.objects.filter(pk=bal.pk).update(qty_on_hand=new_on_hand, qty_reserved=new_reserved)
    return mv


def total_on_hand(product) -> Decimal:
    return StockBalance.objects.filter(product=product).aggregate(s=Sum("qty_on_hand"))["s"] or ZERO


@transaction.atomic
def receive(product, location, qty, unit_cost, kind, doc_type, doc_id, *, lot=None, actor=None, note="", txn=None):
    """Inbound stock at a known cost; updates the moving average."""
    qty = q3(qty)
    if qty <= 0:
        raise BusinessRuleError("Received quantity must be positive.")
    pc, _ = ProductCost.objects.select_for_update().get_or_create(product=product,
                                                                  defaults={"avg_cost": product.standard_cost})
    existing = max(total_on_hand(product), ZERO)
    new_avg = (existing * pc.avg_cost + qty * Decimal(unit_cost)) / (existing + qty)
    pc.avg_cost = q4(new_avg)
    pc.save(update_fields=["avg_cost", "updated_at"])
    return _apply(product, location, qty, kind, doc_type, doc_id, lot=lot, unit_cost=unit_cost, actor=actor,
                  note=note, txn=txn)


def get_or_create_lot(product, code, expiry_date=None, **extra):
    lot, created = Lot.objects.get_or_create(product=product, code=code,
                                             defaults={"expiry_date": expiry_date, **extra})
    return lot


@dataclass
class Allocation:
    lot: Lot | None
    qty: Decimal
    balance_id: int


def allocate_fefo(product, location, qty, *, exclude_expired=True, use_reserved=False, on_date=None):
    """Plan which lots to take (earliest expiry first). Returns (allocations, shortfall). Read-only, locks rows."""
    qty = q3(qty)
    today = on_date or timezone.localdate()
    qs = (StockBalance.objects.select_for_update(of=("self",))
          .filter(product=product, location=location, qty_on_hand__gt=0)
          .select_related("lot"))
    qs = qs.exclude(lot__on_hold=True)
    if exclude_expired:
        qs = qs.filter(Q(lot__isnull=True) | Q(lot__expiry_date__isnull=True) | Q(lot__expiry_date__gte=today))
    qs = qs.order_by(F("lot__expiry_date").asc(nulls_last=True), "lot_id", "id")
    out, remaining = [], qty
    for bal in qs:
        if remaining <= 0:
            break
        free = bal.qty_on_hand if use_reserved else bal.qty_on_hand - bal.qty_reserved
        if free <= 0:
            continue
        take = min(free, remaining)
        out.append(Allocation(bal.lot, take, bal.pk))
        remaining -= take
    return out, max(remaining, ZERO)


@transaction.atomic
def consume(product, location, qty, kind, doc_type, doc_id, *, actor=None, note="", txn=None,
            allow_negative=False, exclude_expired=None, discrepancy_source=""):
    """
    Take stock out FEFO. Returns (movements, total_cost). With allow_negative
    (physical events that already happened, e.g. offline sales), any shortfall is
    booked against the un-lotted bucket and a StockDiscrepancy is raised.
    """
    if exclude_expired is None:
        exclude_expired = bool(Setting.get("pos.block_expired_lots"))
    allocations, shortfall = allocate_fefo(product, location, qty, exclude_expired=exclude_expired)
    if shortfall > 0 and not allow_negative:
        avail = q3(Decimal(qty) - shortfall)
        raise InsufficientStock(
            f"Not enough usable {product.name} at {location.code}: available {avail}, requested {q3(qty)}.",
            product=product.sku, location=location.code, available=str(avail),
        )
    cost = avg_cost(product)
    moves = [
        _apply(product, location, -a.qty, kind, doc_type, doc_id, lot=a.lot, unit_cost=cost, actor=actor,
               note=note, txn=txn)
        for a in allocations
    ]
    if shortfall > 0:
        moves.append(_apply(product, location, -shortfall, kind, doc_type, doc_id, lot=None, unit_cost=cost,
                            actor=actor, note=(note + " [shortfall]").strip(), txn=txn, allow_negative=True))
        StockDiscrepancy.objects.create(product=product, location=location, qty=-shortfall,
                                        reason="NEGATIVE_STOCK", source=discrepancy_source or f"{doc_type}:{doc_id}")
    total = sum((-m.qty * m.unit_cost for m in moves), ZERO)
    return moves, total


@transaction.atomic
def move_between(product, src, dst, qty, *, lot=None, kind_out, kind_in, doc_type, doc_id, actor=None, note="",
                 txn=None, release_reserved=ZERO, unit_cost=None):
    cost = unit_cost if unit_cost is not None else avg_cost(product)
    out = _apply(product, src, -qty, kind_out, doc_type, doc_id, lot=lot, unit_cost=cost, actor=actor, note=note,
                 txn=txn, release_reserved=release_reserved)
    inn = _apply(product, dst, qty, kind_in, doc_type, doc_id, lot=lot, unit_cost=cost, actor=actor, note=note,
                 txn=txn)
    return out, inn


def reserve(balance_id, qty):
    bal = StockBalance.objects.select_for_update().get(pk=balance_id)
    if bal.qty_on_hand - bal.qty_reserved < qty:
        raise InsufficientStock("Stock was taken by another operation; please retry.")
    StockBalance.objects.filter(pk=bal.pk).update(qty_reserved=F("qty_reserved") + qty)


def release(product, location, lot, qty):
    bal = _balance(product, location, lot)
    StockBalance.objects.filter(pk=bal.pk).update(qty_reserved=bal.qty_reserved - min(qty, bal.qty_reserved))


def sellable_location(branch) -> Location:
    loc = Location.objects.filter(branch=branch, is_sellable=True, is_active=True).order_by("id").first()
    if loc is None:
        raise BusinessRuleError(f"Branch {branch.code} has no sellable stock location configured.")
    return loc


def in_transit_location(branch) -> Location:
    loc, _ = Location.objects.get_or_create(
        code=f"{branch.code}-TRANSIT",
        defaults={"name": f"In transit to {branch.name}", "branch": branch, "kind": Location.Kind.IN_TRANSIT},
    )
    return loc


def waste_location(branch) -> Location:
    loc, _ = Location.objects.get_or_create(
        code=f"{branch.code}-WASTE",
        defaults={"name": f"Waste {branch.name}", "branch": branch, "kind": Location.Kind.WASTE},
    )
    return loc


def inventory_value(branch=None) -> Decimal:
    qs = StockBalance.objects.exclude(location__kind=Location.Kind.WASTE)
    if branch is not None:
        qs = qs.filter(location__branch=branch)
    total = ZERO
    costs = dict(ProductCost.objects.values_list("product_id", "avg_cost"))
    for pid, q, std in qs.values_list("product_id", "qty_on_hand", "product__standard_cost"):
        total += q * (costs.get(pid) or std or ZERO)
    return total.quantize(Decimal("0.01"))
