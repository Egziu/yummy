from django.contrib import admin

from .models import Location, Lot, StockBalance, StockDiscrepancy


@admin.register(Location)
class LocationAdmin(admin.ModelAdmin):
    list_display = ("code", "name", "branch", "kind", "level", "is_sellable", "capacity_units")
    list_filter = ("branch", "kind", "level")


@admin.register(Lot)
class LotAdmin(admin.ModelAdmin):
    list_display = ("product", "code", "expiry_date", "on_hold")
    list_filter = ("on_hold",)
    readonly_fields = ("on_hold",)


@admin.register(StockBalance)
class StockBalanceAdmin(admin.ModelAdmin):
    list_display = ("product", "location", "lot", "qty_on_hand", "qty_reserved")

    def has_change_permission(self, request, obj=None):
        return False  # balances change only through the stock ledger

    def has_add_permission(self, request):
        return False


admin.site.register(StockDiscrepancy)
