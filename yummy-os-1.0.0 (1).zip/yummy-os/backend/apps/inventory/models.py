import uuid

from django.conf import settings
from django.db import models
from django.db.models import Q

from apps.catalog.models import Product
from apps.core.models import Branch


class Location(models.Model):
    """
    Physical or logical stock location. Warehouses are modelled as a tree:
    Warehouse > Zone > Rack > Shelf > Bin. Map coordinates drive the live floor map.
    """

    class Kind(models.TextChoices):
        STORAGE = "STORAGE", "Storage"
        COLD = "COLD", "Cold room / freezer"
        RECEIVING = "RECEIVING", "Receiving dock"
        DISPATCH = "DISPATCH", "Dispatch area"
        PRODUCTION = "PRODUCTION", "Production floor"
        SALES = "SALES", "Sales floor / counter"
        IN_TRANSIT = "IN_TRANSIT", "In transit"
        QUARANTINE = "QUARANTINE", "Quarantine / QC hold"
        WASTE = "WASTE", "Waste (virtual)"

    class Level(models.TextChoices):
        SITE = "SITE", "Site"
        ZONE = "ZONE", "Zone"
        RACK = "RACK", "Rack"
        SHELF = "SHELF", "Shelf"
        BIN = "BIN", "Bin"

    code = models.CharField(max_length=40, unique=True)
    name = models.CharField(max_length=120)
    branch = models.ForeignKey(Branch, on_delete=models.PROTECT, related_name="locations")
    parent = models.ForeignKey("self", null=True, blank=True, on_delete=models.PROTECT, related_name="children")
    kind = models.CharField(max_length=12, choices=Kind.choices, default=Kind.STORAGE)
    level = models.CharField(max_length=6, choices=Level.choices, default=Level.SITE)
    capacity_units = models.DecimalField(max_digits=14, decimal_places=3, null=True, blank=True)
    is_sellable = models.BooleanField(default=False, help_text="POS sales consume from here")
    is_default_receiving = models.BooleanField(default=False)
    map_x = models.IntegerField(default=0)
    map_y = models.IntegerField(default=0)
    map_w = models.IntegerField(default=0)
    map_h = models.IntegerField(default=0)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["code"]

    def __str__(self):
        return f"{self.code}"

    @property
    def is_available_stock(self):
        return self.kind not in (self.Kind.IN_TRANSIT, self.Kind.QUARANTINE, self.Kind.WASTE)


class Lot(models.Model):
    product = models.ForeignKey(Product, on_delete=models.PROTECT, related_name="lots")
    code = models.CharField(max_length=60)
    expiry_date = models.DateField(null=True, blank=True, db_index=True)
    created_at = models.DateTimeField(auto_now_add=True)
    supplier_ref = models.CharField(max_length=80, blank=True)
    production_order = models.ForeignKey("production.ProductionOrder", null=True, blank=True,
                                         on_delete=models.PROTECT, related_name="output_lots")
    on_hold = models.BooleanField(default=False, help_text="Quality hold / recall - blocked from use")

    class Meta:
        unique_together = [("product", "code")]
        ordering = ["expiry_date", "id"]

    def __str__(self):
        return f"{self.product.sku}/{self.code}"


class StockBalance(models.Model):
    """Projection of the movement ledger, maintained in the same transaction as each movement."""

    product = models.ForeignKey(Product, on_delete=models.PROTECT)
    location = models.ForeignKey(Location, on_delete=models.PROTECT, related_name="balances")
    lot = models.ForeignKey(Lot, null=True, blank=True, on_delete=models.PROTECT)
    qty_on_hand = models.DecimalField(max_digits=16, decimal_places=3, default=0)
    qty_reserved = models.DecimalField(max_digits=16, decimal_places=3, default=0)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["product", "location", "lot"], name="uniq_balance",
                                    nulls_distinct=False),
            models.CheckConstraint(condition=Q(qty_reserved__gte=0), name="reserved_nonneg"),
        ]
        indexes = [models.Index(fields=["location", "product"])]

    @property
    def available(self):
        return self.qty_on_hand - self.qty_reserved


class StockMovement(models.Model):
    """Immutable stock ledger (UPDATE/DELETE blocked by a database trigger)."""

    class Kind(models.TextChoices):
        OPENING = "OPENING", "Opening balance"
        RECEIPT = "RECEIPT", "Supplier receipt"
        PRODUCTION_ISSUE = "PROD_ISSUE", "Issued to production"
        PRODUCTION_OUTPUT = "PROD_OUTPUT", "Production output"
        TRANSFER_OUT = "XFER_OUT", "Transfer out"
        TRANSFER_IN = "XFER_IN", "Transfer in"
        RELOCATE = "RELOCATE", "Relocation"
        SALE = "SALE", "Sale"
        SALE_RETURN = "SALE_RETURN", "Customer return"
        ADJUSTMENT = "ADJUST", "Adjustment"
        WASTE = "WASTE", "Waste / expiry / damage"
        QUARANTINE = "QUARANTINE", "Quarantine move"

    txn = models.UUIDField(default=uuid.uuid4, db_index=True, help_text="Groups movements of one operation")
    at = models.DateTimeField(auto_now_add=True, db_index=True)
    product = models.ForeignKey(Product, on_delete=models.PROTECT)
    location = models.ForeignKey(Location, on_delete=models.PROTECT)
    lot = models.ForeignKey(Lot, null=True, blank=True, on_delete=models.PROTECT)
    qty = models.DecimalField(max_digits=16, decimal_places=3)
    unit_cost = models.DecimalField(max_digits=14, decimal_places=4)
    kind = models.CharField(max_length=12, choices=Kind.choices)
    doc_type = models.CharField(max_length=30)
    doc_id = models.CharField(max_length=60)
    note = models.CharField(max_length=200, blank=True)
    actor = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.PROTECT)

    class Meta:
        indexes = [models.Index(fields=["doc_type", "doc_id"]), models.Index(fields=["lot"])]
        constraints = [models.CheckConstraint(condition=~Q(qty=0), name="movement_nonzero")]
        ordering = ["-at", "-id"]


class ProductCost(models.Model):
    """Enterprise-wide moving weighted-average cost (the inventory valuation policy)."""

    product = models.OneToOneField(Product, on_delete=models.CASCADE, primary_key=True, related_name="cost")
    avg_cost = models.DecimalField(max_digits=14, decimal_places=4, default=0)
    updated_at = models.DateTimeField(auto_now=True)


class StockDiscrepancy(models.Model):
    """Raised when reality and records disagree (offline oversell, transfer shortage, count variance)."""

    class Status(models.TextChoices):
        OPEN = "OPEN", "Open"
        RESOLVED = "RESOLVED", "Resolved"

    created_at = models.DateTimeField(auto_now_add=True)
    product = models.ForeignKey(Product, on_delete=models.PROTECT)
    location = models.ForeignKey(Location, on_delete=models.PROTECT)
    qty = models.DecimalField(max_digits=16, decimal_places=3)
    reason = models.CharField(max_length=40)
    source = models.CharField(max_length=80)
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.OPEN)
    resolved_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.PROTECT)
    resolution_note = models.CharField(max_length=255, blank=True)

    class Meta:
        ordering = ["-created_at"]
        verbose_name_plural = "stock discrepancies"


class StockAdjustment(models.Model):
    """Requested by one user, approved by another (segregation of duties)."""

    class Status(models.TextChoices):
        SUBMITTED = "SUBMITTED", "Submitted"
        POSTED = "POSTED", "Approved & posted"
        REJECTED = "REJECTED", "Rejected"

    class Reason(models.TextChoices):
        COUNT = "COUNT", "Stock count difference"
        DAMAGE = "DAMAGE", "Damage"
        EXPIRY = "EXPIRY", "Expired - disposal"
        WASTE = "WASTE", "Production/service waste"
        FOUND = "FOUND", "Found stock"

    number = models.CharField(max_length=30, unique=True)
    location = models.ForeignKey(Location, on_delete=models.PROTECT)
    reason = models.CharField(max_length=10, choices=Reason.choices)
    note = models.CharField(max_length=255, blank=True)
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.SUBMITTED)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="+")
    created_at = models.DateTimeField(auto_now_add=True)
    approved_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.PROTECT,
                                    related_name="+")
    approved_at = models.DateTimeField(null=True, blank=True)
    value = models.DecimalField(max_digits=16, decimal_places=2, default=0)


class StockAdjustmentLine(models.Model):
    adjustment = models.ForeignKey(StockAdjustment, on_delete=models.CASCADE, related_name="lines")
    product = models.ForeignKey(Product, on_delete=models.PROTECT)
    lot = models.ForeignKey(Lot, null=True, blank=True, on_delete=models.PROTECT)
    qty_change = models.DecimalField(max_digits=16, decimal_places=3)

    class Meta:
        constraints = [models.CheckConstraint(condition=~Q(qty_change=0), name="adj_nonzero")]
