from django.utils import timezone
from rest_framework import authentication, exceptions

from .models import ApiToken, Terminal


class UserTokenAuthentication(authentication.BaseAuthentication):
    """Authorization: Bearer <token> — expiring back-office session tokens."""

    keyword = "Bearer"

    def authenticate(self, request):
        header = authentication.get_authorization_header(request).decode()
        if not header.startswith(self.keyword + " "):
            return None
        raw = header[len(self.keyword) + 1:].strip()
        tok = ApiToken.lookup(raw)
        if tok is None or tok.expires_at < timezone.now():
            raise exceptions.AuthenticationFailed("Session expired or invalid.")
        user = tok.user
        if not user.is_active or user.is_locked():
            raise exceptions.AuthenticationFailed("Account is disabled or locked.")
        now = timezone.now()
        if tok.last_used_at is None or (now - tok.last_used_at).total_seconds() > 60:
            ApiToken.objects.filter(pk=tok.pk).update(last_used_at=now)
        return user, tok

    def authenticate_header(self, request):
        return self.keyword


class TerminalPrincipal:
    """request.user for device-authenticated POS calls; cashier identity travels per operation."""

    is_authenticated = True
    is_active = True
    is_superuser = False
    pk = None
    id = None

    def __init__(self, terminal):
        self.terminal = terminal

    def __str__(self):
        return f"terminal:{self.terminal.code}"


class TerminalAuthentication(authentication.BaseAuthentication):
    header = "HTTP_X_TERMINAL_TOKEN"

    def authenticate(self, request):
        raw = request.META.get(self.header)
        if not raw:
            return None
        term = Terminal.lookup(raw)
        if term is None:
            raise exceptions.AuthenticationFailed("Terminal is not enrolled or has been revoked.")
        Terminal.objects.filter(pk=term.pk).update(last_seen_at=timezone.now())
        return TerminalPrincipal(term), term
