from datetime import timedelta

from django.conf import settings
from django.contrib.auth import authenticate
from django.db import transaction
from django.utils import timezone
from rest_framework import serializers
from rest_framework.decorators import api_view, permission_classes, throttle_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.throttling import AnonRateThrottle

from apps.core import audit
from apps.core.models import Branch

from .models import ApiToken, Terminal, User
from .permissions import branches_for, permissions_of, require, require_user


class LoginThrottle(AnonRateThrottle):
    scope = "login"


class EnrollThrottle(AnonRateThrottle):
    scope = "enroll"


class LoginIn(serializers.Serializer):
    username = serializers.CharField(max_length=150)
    password = serializers.CharField(max_length=256, trim_whitespace=False)


@api_view(["POST"])
@permission_classes([AllowAny])
@throttle_classes([LoginThrottle])
def login(request):
    data = LoginIn(data=request.data)
    data.is_valid(raise_exception=True)
    username = data.validated_data["username"]
    user = User.objects.filter(username=username).first()
    generic = Response({"error": "invalid_credentials", "detail": "Wrong username or password."}, status=401)
    if user is not None and user.is_locked():
        return Response({"error": "locked", "detail": "Account temporarily locked after failed attempts."},
                        status=423)
    authed = authenticate(request, username=username, password=data.validated_data["password"])
    with transaction.atomic():
        if authed is None:
            if user is not None:
                user.failed_logins += 1
                if user.failed_logins >= settings.YUMMY_MAX_FAILED_LOGINS:
                    user.locked_until = timezone.now() + timedelta(minutes=settings.YUMMY_LOCKOUT_MINUTES)
                    user.failed_logins = 0
                user.save(update_fields=["failed_logins", "locked_until"])
                audit.record("auth.login_failed", object_type="iam.User", object_id=user.pk)
            return generic
        authed.failed_logins = 0
        authed.locked_until = None
        authed.last_login = timezone.now()
        authed.save(update_fields=["failed_logins", "locked_until", "last_login"])
        token = ApiToken.issue(authed, request.META.get("HTTP_USER_AGENT", ""))
        audit.record("auth.login", actor=authed, obj=authed)
    return Response({"token": token, "user": _me(authed)})


@api_view(["POST"])
def logout(request):
    user = require_user(request)
    if isinstance(request.auth, ApiToken):
        request.auth.delete()
    audit.record("auth.logout", actor=user, obj=user)
    return Response({"ok": True})


def _me(user):
    return {
        "id": user.pk,
        "username": user.username,
        "name": user.label,
        "is_superuser": user.is_superuser,
        "permissions": sorted(permissions_of(user)),
        "branches": [
            {"id": b.pk, "code": b.code, "name": b.name, "kind": b.kind}
            for b in (branches_for(user, "reports.branch") | branches_for(user, "inventory.view")
                      | branches_for(user, "pos.sell")).distinct().order_by("code")
        ],
    }


@api_view(["GET"])
def me(request):
    return Response(_me(require_user(request)))


class EnrollIn(serializers.Serializer):
    terminal_code = serializers.CharField(max_length=30)
    enrollment_code = serializers.RegexField(r"^\d{8}$")
    app_version = serializers.CharField(max_length=30, required=False, allow_blank=True)


@api_view(["POST"])
@permission_classes([AllowAny])
@throttle_classes([EnrollThrottle])
def enroll_terminal(request):
    data = EnrollIn(data=request.data)
    data.is_valid(raise_exception=True)
    with transaction.atomic():
        term = Terminal.objects.select_for_update().filter(code=data.validated_data["terminal_code"]).first()
        token = term.enroll(data.validated_data["enrollment_code"]) if term else None
        if not token:
            return Response({"error": "enrollment_failed", "detail": "Code is wrong, expired or already used."},
                            status=400)
        term.app_version = data.validated_data.get("app_version", "")
        term.save(update_fields=["app_version"])
        audit.record("terminal.enrolled", obj=term, branch=term.branch, terminal=term)
    return Response({"device_token": token, "terminal": {"code": term.code, "name": term.name,
                                                          "kind": term.kind, "branch": term.branch.code}})


class TerminalIn(serializers.Serializer):
    code = serializers.RegexField(r"^[A-Z0-9\-]{2,30}$")
    name = serializers.CharField(max_length=80)
    branch = serializers.CharField(max_length=20)
    kind = serializers.ChoiceField(choices=Terminal.Kind.choices)


@api_view(["GET", "POST"])
def terminals(request):
    user = require_user(request)
    if request.method == "GET":
        require(user, "sync.monitor")
        allowed = branches_for(user, "sync.monitor")
        rows = Terminal.objects.filter(branch__in=allowed).select_related("branch")
        now = timezone.now()
        return Response([
            {
                "code": t.code, "name": t.name, "branch": t.branch.code, "kind": t.kind,
                "is_active": t.is_active, "enrolled": bool(t.token_hash),
                "last_seen_at": t.last_seen_at, "last_sync_at": t.last_sync_at,
                "reported_pending": t.reported_pending, "app_version": t.app_version,
                "online": bool(t.last_seen_at and (now - t.last_seen_at).total_seconds() < 120),
            }
            for t in rows
        ])
    data = TerminalIn(data=request.data)
    data.is_valid(raise_exception=True)
    branch = Branch.objects.get(code=data.validated_data["branch"])
    require(user, "admin.terminals", branch)
    term, _ = Terminal.objects.get_or_create(
        code=data.validated_data["code"],
        defaults={"name": data.validated_data["name"], "branch": branch, "kind": data.validated_data["kind"]},
    )
    if term.branch_id != branch.pk:
        return Response({"error": "conflict", "detail": "Terminal code belongs to another branch."}, status=409)
    code = term.new_enrollment_code()
    audit.record("terminal.enrollment_code_issued", actor=user, obj=term, branch=branch)
    return Response({"terminal": term.code, "enrollment_code": code, "expires_at": term.enrollment_expires_at})


@api_view(["POST"])
def revoke_terminal(request, code):
    user = require_user(request)
    term = Terminal.objects.select_related("branch").get(code=code)
    require(user, "admin.terminals", term.branch)
    term.is_active = False
    term.token_hash = ""
    term.save(update_fields=["is_active", "token_hash"])
    audit.record("terminal.revoked", actor=user, obj=term, branch=term.branch)
    return Response({"ok": True})
