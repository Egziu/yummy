from django import forms
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin

from .models import Role, RoleAssignment, Terminal, User


class AssignmentInline(admin.TabularInline):
    model = RoleAssignment
    extra = 1


class UserForm(forms.ModelForm):
    new_pin = forms.CharField(required=False, help_text="Set a new 4-8 digit POS PIN", widget=forms.PasswordInput)

    class Meta:
        model = User
        fields = "__all__"


@admin.register(User)
class UserAdmin(BaseUserAdmin):
    form = UserForm
    inlines = [AssignmentInline]
    list_display = ("username", "display_name", "is_active", "locked_until", "last_login")
    fieldsets = BaseUserAdmin.fieldsets + (("Yummy", {"fields": ("display_name", "employee_code",
                                                                 "preferred_language", "new_pin", "locked_until")}),)

    def save_model(self, request, obj, form, change):
        if form.cleaned_data.get("new_pin"):
            obj.set_pin(form.cleaned_data["new_pin"])
        super().save_model(request, obj, form, change)


@admin.register(Role)
class RoleAdmin(admin.ModelAdmin):
    list_display = ("code", "name", "is_system")


@admin.register(Terminal)
class TerminalAdmin(admin.ModelAdmin):
    list_display = ("code", "name", "branch", "kind", "is_active", "last_seen_at", "last_sync_at", "reported_pending")
    exclude = ("token_hash", "enrollment_code_hash")
