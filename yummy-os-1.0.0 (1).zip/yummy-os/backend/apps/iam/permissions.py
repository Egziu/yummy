"""
Server-side authorisation. Every view and service call checks permissions here;
the UI hiding a button is never the control.
"""
from django.db.models import Q

from apps.core.exceptions import PermissionDeniedError
from apps.core.models import Branch

from .models import RoleAssignment, Terminal


def _is_user(user):
    return user is not None and getattr(user, "pk", None) is not None and user.is_authenticated


def has_perm(user, code, branch=None) -> bool:
    if not _is_user(user) or not user.is_active:
        return False
    if user.is_superuser:
        return True
    qs = RoleAssignment.objects.filter(user=user, role__permissions__contains=[code])
    if branch is None:
        return qs.exists()
    branch_id = branch.pk if isinstance(branch, Branch) else branch
    return qs.filter(Q(branch__isnull=True) | Q(branch_id=branch_id)).exists()


def require(user, code, branch=None):
    if not has_perm(user, code, branch):
        where = f" at {branch.code}" if isinstance(branch, Branch) else ""
        raise PermissionDeniedError(f"Missing permission '{code}'{where}.")


def branches_for(user, code):
    """Branches where the user holds `code` (all, if any assignment is unscoped)."""
    if not _is_user(user):
        return Branch.objects.none()
    if user.is_superuser:
        return Branch.objects.all()
    qs = RoleAssignment.objects.filter(user=user, role__permissions__contains=[code])
    if qs.filter(branch__isnull=True).exists():
        return Branch.objects.all()
    return Branch.objects.filter(pk__in=qs.values("branch_id"))


def permissions_of(user, branch=None):
    if not _is_user(user):
        return set()
    from .models import PERMISSIONS

    if user.is_superuser:
        return set(PERMISSIONS)
    qs = RoleAssignment.objects.filter(user=user).select_related("role")
    if branch is not None:
        qs = qs.filter(Q(branch__isnull=True) | Q(branch=branch))
    out = set()
    for a in qs:
        out.update(a.role.permissions)
    return out


def require_terminal(request) -> Terminal:
    term = request.auth if isinstance(request.auth, Terminal) else None
    if term is None:
        raise PermissionDeniedError("This endpoint is only available to enrolled terminals.")
    return term


def require_user(request):
    if not _is_user(request.user):
        raise PermissionDeniedError("A signed-in user is required.")
    return request.user
