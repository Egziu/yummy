import hashlib
import hmac
import secrets
from datetime import timedelta

from django.conf import settings
from django.contrib.auth.models import AbstractUser
from django.db import models
from django.utils import timezone

from apps.core.models import Branch

# ---------------------------------------------------------------------------
# Permission catalogue. Roles are bundles of these codes; assignments scope a
# role to one branch or (branch = NULL) to every branch.
# ---------------------------------------------------------------------------
PERMISSIONS = {
    "pos.sell": "Sell at a POS terminal",
    "pos.discount_override": "Approve discounts above the cashier limit",
    "pos.refund": "Initiate refunds",
    "pos.refund_approve": "Approve refunds (supervisor)",
    "pos.shift_approve": "Approve shift close with cash difference",
    "kds.operate": "Operate the kitchen/barista display",
    "inventory.view": "View stock",
    "inventory.adjust": "Request stock adjustments",
    "inventory.adjust_approve": "Approve stock adjustments and disposals",
    "inventory.map_edit": "Edit warehouse floor maps",
    "transfer.request": "Request stock transfers",
    "transfer.approve": "Approve stock transfers",
    "transfer.dispatch": "Pick and dispatch transfers",
    "transfer.receive": "Receive transfers",
    "production.view": "View production",
    "production.plan": "Create production orders",
    "production.approve": "Approve production orders",
    "production.execute": "Release and complete production orders",
    "recipe.manage": "Create and edit recipes",
    "recipe.approve": "Approve recipe versions",
    "quality.manage": "Quality holds, releases and recalls",
    "procurement.request": "Create purchase orders",
    "procurement.approve": "Approve purchase orders",
    "procurement.receive": "Receive goods",
    "procurement.invoice": "Record supplier invoices",
    "procurement.pay": "Record supplier payments",
    "accounting.view": "View ledgers and statements",
    "accounting.post": "Post manual journals",
    "accounting.period_close": "Lock and reopen periods",
    "reports.executive": "Enterprise dashboards (all branches)",
    "reports.branch": "Branch dashboards",
    "reports.export": "Export reports",
    "sync.monitor": "Monitor terminals and resolve sync conflicts",
    "admin.users": "Manage users and roles",
    "admin.terminals": "Enrol and revoke POS terminals",
    "admin.config": "Change system configuration",
}

DEFAULT_ROLES = {
    "SUPER_ADMIN": ("Super Administrator", list(PERMISSIONS)),
    "CEO": ("CEO", ["reports.executive", "reports.branch", "reports.export", "accounting.view", "inventory.view",
                    "production.view", "sync.monitor", "procurement.approve", "transfer.approve"]),
    "FINANCE_MANAGER": ("Finance Manager", ["accounting.view", "accounting.post", "accounting.period_close",
                                            "procurement.invoice", "procurement.pay", "reports.executive",
                                            "reports.branch", "reports.export", "inventory.view"]),
    "ACCOUNTANT": ("Accountant", ["accounting.view", "accounting.post", "procurement.invoice", "reports.branch",
                                  "reports.export", "inventory.view"]),
    "AUDITOR": ("Internal Auditor", ["accounting.view", "reports.executive", "reports.branch", "reports.export",
                                     "inventory.view", "production.view", "sync.monitor"]),
    "PROCUREMENT_OFFICER": ("Procurement Officer", ["procurement.request", "inventory.view"]),
    "PROCUREMENT_MANAGER": ("Procurement Manager", ["procurement.request", "procurement.approve", "inventory.view"]),
    "WAREHOUSE_MANAGER": ("Warehouse Manager", ["inventory.view", "inventory.adjust", "inventory.adjust_approve",
                                                "inventory.map_edit", "transfer.approve", "transfer.dispatch",
                                                "transfer.receive", "procurement.receive", "quality.manage"]),
    "WAREHOUSE_OFFICER": ("Warehouse Officer", ["inventory.view", "inventory.adjust", "transfer.dispatch",
                                                "transfer.receive", "procurement.receive"]),
    "PRODUCTION_MANAGER": ("Production Manager", ["production.view", "production.plan", "production.approve",
                                                  "production.execute", "recipe.manage", "recipe.approve",
                                                  "inventory.view", "transfer.request", "transfer.receive",
                                                  "quality.manage"]),
    "BAKER": ("Baker", ["production.view", "production.execute"]),
    "QUALITY_OFFICER": ("Quality Control Officer", ["quality.manage", "inventory.view", "production.view"]),
    "BRANCH_MANAGER": ("Shop / Café Manager", ["pos.sell", "pos.discount_override", "pos.refund",
                                               "pos.refund_approve", "pos.shift_approve", "kds.operate",
                                               "inventory.view", "inventory.adjust", "transfer.request",
                                               "transfer.receive", "reports.branch"]),
    "CASHIER": ("Cashier", ["pos.sell", "pos.refund"]),
    "BARISTA": ("Barista / Kitchen", ["kds.operate", "pos.sell"]),
}


class User(AbstractUser):
    display_name = models.CharField(max_length=120, blank=True)
    employee_code = models.CharField(max_length=30, blank=True)
    preferred_language = models.CharField(max_length=5, default="en")
    failed_logins = models.PositiveSmallIntegerField(default=0)
    locked_until = models.DateTimeField(null=True, blank=True)
    # Offline POS PIN verifier: PBKDF2-SHA256(pin, salt, iterations). Never the PIN itself.
    pin_salt = models.CharField(max_length=64, blank=True)
    pin_hash = models.CharField(max_length=128, blank=True)
    pin_iterations = models.PositiveIntegerField(default=0)

    def __str__(self):
        return self.display_name or self.username

    @property
    def label(self):
        return self.display_name or self.get_full_name() or self.username

    def set_pin(self, pin: str):
        if not (pin.isdigit() and 4 <= len(pin) <= 8):
            raise ValueError("PIN must be 4-8 digits")
        self.pin_salt = secrets.token_hex(16)
        self.pin_iterations = settings.YUMMY_PIN_ITERATIONS
        self.pin_hash = hashlib.pbkdf2_hmac(
            "sha256", pin.encode(), bytes.fromhex(self.pin_salt), self.pin_iterations
        ).hex()

    def check_pin(self, pin: str) -> bool:
        if not self.pin_hash:
            return False
        h = hashlib.pbkdf2_hmac("sha256", pin.encode(), bytes.fromhex(self.pin_salt), self.pin_iterations).hex()
        return hmac.compare_digest(h, self.pin_hash)

    def is_locked(self):
        return self.locked_until is not None and self.locked_until > timezone.now()


class Role(models.Model):
    code = models.CharField(max_length=40, unique=True)
    name = models.CharField(max_length=120)
    permissions = models.JSONField(default=list, help_text="List of permission codes")
    is_system = models.BooleanField(default=False)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name

    def clean(self):
        from django.core.exceptions import ValidationError

        unknown = set(self.permissions) - set(PERMISSIONS)
        if unknown:
            raise ValidationError(f"Unknown permission codes: {sorted(unknown)}")


class RoleAssignment(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="assignments")
    role = models.ForeignKey(Role, on_delete=models.PROTECT)
    branch = models.ForeignKey(Branch, null=True, blank=True, on_delete=models.CASCADE,
                               help_text="Empty = all branches")

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["user", "role", "branch"], name="uniq_role_assignment",
                                    nulls_distinct=False)
        ]

    def __str__(self):
        return f"{self.user} · {self.role} @ {self.branch or 'ALL'}"


def _sha256(raw: str) -> str:
    return hashlib.sha256(raw.encode()).hexdigest()


class ApiToken(models.Model):
    """Back-office session token. Only the SHA-256 of the token is stored."""

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="tokens")
    key_hash = models.CharField(max_length=64, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField()
    last_used_at = models.DateTimeField(null=True, blank=True)
    user_agent = models.CharField(max_length=255, blank=True)

    @classmethod
    def issue(cls, user, user_agent=""):
        raw = secrets.token_urlsafe(32)
        cls.objects.create(
            user=user,
            key_hash=_sha256(raw),
            expires_at=timezone.now() + timedelta(hours=settings.YUMMY_TOKEN_TTL_HOURS),
            user_agent=user_agent[:255],
        )
        return raw

    @classmethod
    def lookup(cls, raw):
        return cls.objects.select_related("user").filter(key_hash=_sha256(raw)).first()


class Terminal(models.Model):
    """An enrolled POS / KDS device. Authenticates with a device token (hash stored)."""

    class Kind(models.TextChoices):
        RETAIL = "RETAIL", "Retail POS"
        CAFE = "CAFE", "Café POS"
        KDS = "KDS", "Kitchen display"

    code = models.CharField(max_length=30, unique=True)
    name = models.CharField(max_length=80)
    branch = models.ForeignKey(Branch, on_delete=models.PROTECT, related_name="terminals")
    kind = models.CharField(max_length=10, choices=Kind.choices, default=Kind.RETAIL)
    token_hash = models.CharField(max_length=64, blank=True)
    enrollment_code_hash = models.CharField(max_length=64, blank=True)
    enrollment_expires_at = models.DateTimeField(null=True, blank=True)
    is_active = models.BooleanField(default=True)
    enrolled_at = models.DateTimeField(null=True, blank=True)
    last_seen_at = models.DateTimeField(null=True, blank=True)
    last_sync_at = models.DateTimeField(null=True, blank=True)
    reported_pending = models.PositiveIntegerField(default=0)
    app_version = models.CharField(max_length=30, blank=True)

    class Meta:
        ordering = ["code"]

    def __str__(self):
        return f"{self.code} ({self.branch.code})"

    def new_enrollment_code(self, minutes=30):
        code = f"{secrets.randbelow(10**8):08d}"
        self.enrollment_code_hash = _sha256(code)
        self.enrollment_expires_at = timezone.now() + timedelta(minutes=minutes)
        self.save(update_fields=["enrollment_code_hash", "enrollment_expires_at"])
        return code

    def enroll(self, code):
        if (not self.is_active or not self.enrollment_code_hash or self.enrollment_expires_at is None
                or self.enrollment_expires_at < timezone.now()
                or not hmac.compare_digest(self.enrollment_code_hash, _sha256(code))):
            return None
        raw = secrets.token_urlsafe(32)
        self.token_hash = _sha256(raw)
        self.enrollment_code_hash = ""
        self.enrolled_at = timezone.now()
        self.save(update_fields=["token_hash", "enrollment_code_hash", "enrolled_at"])
        return raw

    @classmethod
    def lookup(cls, raw):
        return cls.objects.select_related("branch").filter(token_hash=_sha256(raw), is_active=True).first()
