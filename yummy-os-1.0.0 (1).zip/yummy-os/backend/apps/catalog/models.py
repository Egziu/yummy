from django.db import models
from django.db.models import Q

from apps.core.models import Branch


class Unit(models.Model):
    code = models.CharField(max_length=10, unique=True)  # kg, g, l, ml, pcs
    name = models.CharField(max_length=40)

    def __str__(self):
        return self.code


class Category(models.Model):
    name = models.CharField(max_length=80)
    parent = models.ForeignKey("self", null=True, blank=True, on_delete=models.PROTECT, related_name="children")
    sort_order = models.PositiveSmallIntegerField(default=0)
    color = models.CharField(max_length=9, default="#C8742B", help_text="POS tile accent")

    class Meta:
        ordering = ["sort_order", "name"]
        verbose_name_plural = "categories"

    def __str__(self):
        return self.name


class TaxRate(models.Model):
    """Rates are configuration — verify current Ethiopian rules with a qualified advisor before activation."""

    code = models.CharField(max_length=20, unique=True)
    name = models.CharField(max_length=80)
    rate = models.DecimalField(max_digits=6, decimal_places=4)
    is_active = models.BooleanField(default=True)

    class Meta:
        constraints = [models.CheckConstraint(condition=Q(rate__gte=0) & Q(rate__lt=1), name="tax_rate_range")]

    def __str__(self):
        return f"{self.name} ({self.rate * 100:.2f}%)"


class Product(models.Model):
    class Kind(models.TextChoices):
        RAW = "RAW", "Raw material"
        PACKAGING = "PACKAGING", "Packaging"
        SEMI = "SEMI", "Semi-finished"
        FINISHED = "FINISHED", "Manufactured finished good"
        RESALE = "RESALE", "Purchased for resale"
        MENU = "MENU", "Café menu item (made to order)"
        SERVICE = "SERVICE", "Service / non-inventory"

    class Station(models.TextChoices):
        NONE = "NONE", "None"
        BARISTA = "BARISTA", "Barista"
        KITCHEN = "KITCHEN", "Kitchen"
        DESSERT = "DESSERT", "Dessert / service"

    sku = models.CharField(max_length=40, unique=True)
    barcode = models.CharField(max_length=64, unique=True, null=True, blank=True)
    name = models.CharField(max_length=120)
    name_local = models.CharField("Amharic / Tigrinya name", max_length=120, blank=True)
    kind = models.CharField(max_length=12, choices=Kind.choices)
    category = models.ForeignKey(Category, on_delete=models.PROTECT, related_name="products")
    unit = models.ForeignKey(Unit, on_delete=models.PROTECT)
    tax_rate = models.ForeignKey(TaxRate, on_delete=models.PROTECT, null=True, blank=True)
    is_sellable = models.BooleanField(default=False)
    track_lots = models.BooleanField(default=True)
    shelf_life_days = models.PositiveIntegerField(null=True, blank=True)
    reorder_point = models.DecimalField(max_digits=14, decimal_places=3, default=0)
    reorder_qty = models.DecimalField(max_digits=14, decimal_places=3, default=0)
    standard_cost = models.DecimalField(max_digits=14, decimal_places=4, default=0)
    station = models.CharField(max_length=10, choices=Station.choices, default=Station.NONE)
    allergens = models.CharField(max_length=200, blank=True, help_text="Comma separated, e.g. gluten,egg,milk")
    color = models.CharField(max_length=9, blank=True)
    is_active = models.BooleanField(default=True)
    version = models.PositiveIntegerField(default=1)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["name"]
        constraints = [
            models.CheckConstraint(condition=Q(reorder_point__gte=0), name="product_reorder_nonneg"),
            models.CheckConstraint(condition=Q(standard_cost__gte=0), name="product_stdcost_nonneg"),
        ]

    def __str__(self):
        return f"{self.sku} · {self.name}"

    @property
    def is_stocked(self):
        return self.kind not in (self.Kind.MENU, self.Kind.SERVICE)

    @property
    def inventory_account_key(self):
        if self.kind in (self.Kind.RAW, self.Kind.PACKAGING):
            return "inventory_raw"
        return "inventory_fg"


class Modifier(models.Model):
    """Café add-on (extra shot, oat milk...). May consume an ingredient."""

    name = models.CharField(max_length=60)
    group = models.CharField(max_length=40, default="Extras")
    price_delta = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    ingredient = models.ForeignKey(Product, null=True, blank=True, on_delete=models.PROTECT, related_name="+")
    ingredient_qty = models.DecimalField(max_digits=12, decimal_places=3, default=0)
    applies_to = models.ManyToManyField(Product, related_name="modifiers", blank=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.group}: {self.name}"


class PriceList(models.Model):
    code = models.CharField(max_length=20, unique=True)
    name = models.CharField(max_length=80)
    branch = models.ForeignKey(Branch, null=True, blank=True, on_delete=models.CASCADE,
                               help_text="Empty = default for all branches")
    tax_inclusive = models.BooleanField(default=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.name


class PriceListItem(models.Model):
    """Effective-dated price. Historic sales keep the price they were charged."""

    price_list = models.ForeignKey(PriceList, on_delete=models.CASCADE, related_name="items")
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name="prices")
    price = models.DecimalField(max_digits=12, decimal_places=2)
    effective_from = models.DateTimeField()
    effective_to = models.DateTimeField(null=True, blank=True)

    class Meta:
        indexes = [models.Index(fields=["product", "effective_from"])]
        constraints = [
            models.CheckConstraint(condition=Q(price__gte=0), name="price_nonneg"),
            models.CheckConstraint(condition=Q(effective_to__isnull=True) | Q(effective_to__gt=models.F("effective_from")),
                                   name="price_period_valid"),
        ]
