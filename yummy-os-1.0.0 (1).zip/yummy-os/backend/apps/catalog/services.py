from django.db.models import Q
from django.utils import timezone

from .models import PriceList, PriceListItem


def active_price_lists(branch):
    """Branch-specific list first, then the enterprise default."""
    return list(
        PriceList.objects.filter(is_active=True)
        .filter(Q(branch=branch) | Q(branch__isnull=True))
        .order_by("branch_id")  # NULLs last in Postgres ascending order -> branch list wins
    )


def resolve_price(product, branch, at=None):
    """Return (price, tax_inclusive) for the product at the branch and moment, or (None, None)."""
    at = at or timezone.now()
    for pl in active_price_lists(branch):
        item = (
            PriceListItem.objects.filter(price_list=pl, product=product, effective_from__lte=at)
            .filter(Q(effective_to__isnull=True) | Q(effective_to__gt=at))
            .order_by("-effective_from")
            .first()
        )
        if item:
            return item.price, pl.tax_inclusive
    return None, None


def branch_price_table(branch, at=None):
    """{product_id: (price, tax_inclusive)} for POS bootstrap."""
    at = at or timezone.now()
    out = {}
    for pl in reversed(active_price_lists(branch)):  # default first, branch overrides
        items = (
            PriceListItem.objects.filter(price_list=pl, effective_from__lte=at)
            .filter(Q(effective_to__isnull=True) | Q(effective_to__gt=at))
            .order_by("product_id", "effective_from")
        )
        for it in items:
            out[it.product_id] = (it.price, pl.tax_inclusive)
    return out
