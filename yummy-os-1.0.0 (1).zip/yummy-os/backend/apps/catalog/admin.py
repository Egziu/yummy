from django.contrib import admin

from .models import Category, Modifier, PriceList, PriceListItem, Product, TaxRate, Unit

admin.site.register(Unit)
admin.site.register(TaxRate)
admin.site.register(Category)


class PriceInline(admin.TabularInline):
    model = PriceListItem
    extra = 0


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ("sku", "name", "kind", "category", "unit", "is_sellable", "is_active")
    list_filter = ("kind", "category", "is_sellable", "is_active")
    search_fields = ("sku", "name", "barcode")
    inlines = [PriceInline]


@admin.register(PriceList)
class PriceListAdmin(admin.ModelAdmin):
    list_display = ("code", "name", "branch", "tax_inclusive", "is_active")


@admin.register(Modifier)
class ModifierAdmin(admin.ModelAdmin):
    list_display = ("name", "group", "price_delta", "ingredient", "ingredient_qty")
    filter_horizontal = ("applies_to",)
