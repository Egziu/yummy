from django.conf import settings
from django.db import models
from django.db.models import Q

from apps.catalog.models import Product
from apps.core.models import Branch
from apps.inventory.models import Location


class Supplier(models.Model):
    code = models.CharField(max_length=20, unique=True)
    name = models.CharField(max_length=120)
    tin = models.CharField("TIN", max_length=40, blank=True)
    phone = models.CharField(max_length=40, blank=True)
    email = models.EmailField(blank=True)
    payment_terms_days = models.PositiveSmallIntegerField(default=30)
    lead_time_days = models.PositiveSmallIntegerField(default=3)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.name


class PurchaseOrder(models.Model):
    class Status(models.TextChoices):
        DRAFT = "DRAFT", "Draft"
        APPROVED = "APPROVED", "Approved"
        PARTIAL = "PARTIAL", "Partially received"
        RECEIVED = "RECEIVED", "Fully received"
        CLOSED = "CLOSED", "Closed"
        CANCELLED = "CANCELLED", "Cancelled"

    number = models.CharField(max_length=30, unique=True)
    supplier = models.ForeignKey(Supplier, on_delete=models.PROTECT, related_name="orders")
    branch = models.ForeignKey(Branch, on_delete=models.PROTECT)
    deliver_to = models.ForeignKey(Location, on_delete=models.PROTECT)
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.DRAFT)
    expected_date = models.DateField(null=True, blank=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="+")
    created_at = models.DateTimeField(auto_now_add=True)
    approved_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.PROTECT,
                                    related_name="+")
    approved_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-id"]

    def __str__(self):
        return self.number


class PurchaseOrderLine(models.Model):
    order = models.ForeignKey(PurchaseOrder, on_delete=models.CASCADE, related_name="lines")
    product = models.ForeignKey(Product, on_delete=models.PROTECT)
    qty = models.DecimalField(max_digits=14, decimal_places=3)
    unit_cost = models.DecimalField(max_digits=14, decimal_places=4)
    qty_received = models.DecimalField(max_digits=14, decimal_places=3, default=0)
    qty_rejected = models.DecimalField(max_digits=14, decimal_places=3, default=0)
    qty_invoiced = models.DecimalField(max_digits=14, decimal_places=3, default=0)

    class Meta:
        constraints = [
            models.CheckConstraint(condition=Q(qty__gt=0) & Q(unit_cost__gte=0), name="pol_positive"),
            models.CheckConstraint(condition=Q(qty_received__gte=0) & Q(qty_invoiced__gte=0), name="pol_counts_nonneg"),
        ]


class GoodsReceipt(models.Model):
    number = models.CharField(max_length=30, unique=True)
    order = models.ForeignKey(PurchaseOrder, on_delete=models.PROTECT, related_name="receipts")
    location = models.ForeignKey(Location, on_delete=models.PROTECT)
    received_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)
    received_at = models.DateTimeField(auto_now_add=True)
    note = models.CharField(max_length=255, blank=True)


class GoodsReceiptLine(models.Model):
    receipt = models.ForeignKey(GoodsReceipt, on_delete=models.CASCADE, related_name="lines")
    order_line = models.ForeignKey(PurchaseOrderLine, on_delete=models.PROTECT)
    qty_accepted = models.DecimalField(max_digits=14, decimal_places=3)
    qty_rejected = models.DecimalField(max_digits=14, decimal_places=3, default=0)
    lot = models.ForeignKey("inventory.Lot", null=True, blank=True, on_delete=models.PROTECT)
    rejection_reason = models.CharField(max_length=160, blank=True)


class SupplierInvoice(models.Model):
    class Status(models.TextChoices):
        POSTED = "POSTED", "Matched & posted"
        HELD = "HELD", "Held - match exception"
        PAID = "PAID", "Paid"

    number = models.CharField(max_length=30, unique=True)
    supplier = models.ForeignKey(Supplier, on_delete=models.PROTECT)
    supplier_ref = models.CharField("Supplier invoice no.", max_length=60)
    order = models.ForeignKey(PurchaseOrder, on_delete=models.PROTECT, related_name="invoices")
    invoice_date = models.DateField()
    subtotal = models.DecimalField(max_digits=16, decimal_places=2)
    tax = models.DecimalField(max_digits=16, decimal_places=2, default=0)
    total = models.DecimalField(max_digits=16, decimal_places=2)
    amount_paid = models.DecimalField(max_digits=16, decimal_places=2, default=0)
    status = models.CharField(max_length=8, choices=Status.choices)
    match_exceptions = models.JSONField(default=list, blank=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="+")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [
            # The same supplier invoice can never be recorded twice.
            models.UniqueConstraint(fields=["supplier", "supplier_ref"], name="uniq_supplier_invoice"),
            models.CheckConstraint(condition=Q(amount_paid__lte=models.F("total")), name="invoice_not_overpaid"),
        ]


class SupplierInvoiceLine(models.Model):
    invoice = models.ForeignKey(SupplierInvoice, on_delete=models.CASCADE, related_name="lines")
    order_line = models.ForeignKey(PurchaseOrderLine, on_delete=models.PROTECT)
    qty = models.DecimalField(max_digits=14, decimal_places=3)
    unit_cost = models.DecimalField(max_digits=14, decimal_places=4)


class SupplierPayment(models.Model):
    number = models.CharField(max_length=30, unique=True)
    invoice = models.ForeignKey(SupplierInvoice, on_delete=models.PROTECT, related_name="payments")
    amount = models.DecimalField(max_digits=16, decimal_places=2)
    method = models.CharField(max_length=20, default="BANK_TRANSFER")
    reference = models.CharField(max_length=80, blank=True)
    paid_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)
    paid_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [models.CheckConstraint(condition=Q(amount__gt=0), name="payment_positive")]
