from django.shortcuts import get_object_or_404
from django.utils import timezone
from rest_framework.decorators import api_view
from rest_framework.response import Response

from apps.catalog.models import Product
from apps.core.api import dec, parse_date, user_ref
from apps.inventory.models import Location
from apps.iam.permissions import branches_for, require_user

from . import services
from .models import PurchaseOrder, Supplier, SupplierInvoice


def _po_json(po):
    return {
        "id": po.pk, "number": po.number, "supplier": po.supplier.name, "supplier_code": po.supplier.code,
        "branch": po.branch.code, "deliver_to": po.deliver_to.code, "status": po.status,
        "status_label": po.get_status_display(), "created_by": user_ref(po.created_by), "created_at": po.created_at,
        "approved_by": user_ref(po.approved_by), "value": services.po_value(po), "expected_date": po.expected_date,
        "lines": [{"id": l.pk, "sku": l.product.sku, "name": l.product.name, "unit": l.product.unit.code, "qty": l.qty,
                   "unit_cost": l.unit_cost, "received": l.qty_received, "rejected": l.qty_rejected,
                   "invoiced": l.qty_invoiced} for l in po.lines.all()],
        "invoices": [{"id": i.pk, "number": i.number, "supplier_ref": i.supplier_ref, "status": i.status,
                      "total": i.total, "paid": i.amount_paid, "exceptions": i.match_exceptions}
                     for i in po.invoices.all()],
    }


def _qs():
    return PurchaseOrder.objects.select_related("supplier", "branch", "deliver_to", "created_by", "approved_by") \
        .prefetch_related("lines__product__unit", "invoices")


@api_view(["GET"])
def suppliers(request):
    require_user(request)
    return Response([{"id": s.pk, "code": s.code, "name": s.name, "lead_time_days": s.lead_time_days}
                     for s in Supplier.objects.filter(is_active=True)])


@api_view(["GET", "POST"])
def purchase_orders(request):
    user = require_user(request)
    if request.method == "GET":
        allowed = branches_for(user, "procurement.request") | branches_for(user, "procurement.approve") | \
            branches_for(user, "procurement.receive") | branches_for(user, "procurement.invoice")
        return Response([_po_json(p) for p in _qs().filter(branch__in=allowed.distinct())[:200]])
    sup = get_object_or_404(Supplier, code=request.data.get("supplier"))
    loc = get_object_or_404(Location, code=request.data.get("deliver_to"))
    lines = [{"product": get_object_or_404(Product, sku=l.get("sku")), "qty": dec(l, "qty", positive=True),
              "unit_cost": dec(l, "unit_cost")} for l in request.data.get("lines") or []]
    po = services.create_po(user, sup, loc, lines)
    return Response(_po_json(_qs().get(pk=po.pk)), status=201)


@api_view(["POST"])
def po_action(request, pid, action):
    user = require_user(request)
    d = request.data
    if action == "approve":
        services.approve_po(user, pid)
    elif action == "receive":
        lines = [{"order_line": l["order_line"], "qty_accepted": dec(l, "qty_accepted", "0"),
                  "qty_rejected": dec(l, "qty_rejected", "0"), "lot_code": l.get("lot_code", ""),
                  "expiry_date": parse_date(l.get("expiry_date"), default=False) or None,
                  "rejection_reason": l.get("rejection_reason", "")} for l in d.get("lines") or []]
        services.receive_goods(user, pid, lines, note=str(d.get("note", ""))[:255])
    elif action == "invoice":
        lines = [{"order_line": l["order_line"], "qty": dec(l, "qty", positive=True), "unit_cost": dec(l, "unit_cost")}
                 for l in d.get("lines") or []]
        services.record_invoice(user, pid, str(d.get("supplier_ref", ""))[:60],
                                parse_date(d.get("invoice_date"), default=timezone.localdate()), lines,
                                dec(d, "tax", "0"))
    else:
        return Response({"error": "not_found"}, status=404)
    return Response(_po_json(_qs().get(pk=pid)))


@api_view(["POST"])
def pay(request, iid):
    user = require_user(request)
    p = services.pay_invoice(user, iid, dec(request.data, "amount", positive=True),
                             request.data.get("method", "BANK_TRANSFER"), str(request.data.get("reference", ""))[:80])
    inv_doc = SupplierInvoice.objects.get(pk=iid)
    return Response({"payment": p.number, "invoice_status": inv_doc.status, "paid": inv_doc.amount_paid})
