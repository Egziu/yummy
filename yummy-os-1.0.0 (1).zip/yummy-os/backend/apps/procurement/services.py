"""Purchase order -> goods receipt -> 3-way-matched invoice -> payment."""
from decimal import Decimal

from django.db import transaction
from django.utils import timezone

from apps.accounting.services import Draft, post
from apps.core import audit
from apps.core.exceptions import BusinessRuleError
from apps.core.models import DocumentSequence, Setting
from apps.core.money import ZERO, q2, q3
from apps.inventory import services as inv
from apps.inventory.models import StockMovement
from apps.iam.permissions import require

from .models import (GoodsReceipt, GoodsReceiptLine, PurchaseOrder, PurchaseOrderLine, SupplierInvoice,
                     SupplierInvoiceLine, SupplierPayment)


@transaction.atomic
def create_po(user, supplier, deliver_to, lines, expected_date=None):
    branch = deliver_to.branch
    require(user, "procurement.request", branch)
    if not lines:
        raise BusinessRuleError("A purchase order needs at least one line.")
    po = PurchaseOrder.objects.create(number=DocumentSequence.next("PO", "PO"), supplier=supplier, branch=branch,
                                      deliver_to=deliver_to, created_by=user, expected_date=expected_date)
    for l in lines:
        PurchaseOrderLine.objects.create(order=po, product=l["product"], qty=q3(l["qty"]),
                                         unit_cost=Decimal(l["unit_cost"]))
    audit.record("procurement.po_created", actor=user, obj=po, branch=branch,
                 data={"supplier": supplier.code, "value": str(po_value(po))})
    return po


def po_value(po):
    return q2(sum((l.qty * l.unit_cost for l in po.lines.all()), ZERO))


@transaction.atomic
def approve_po(user, po_id):
    po = PurchaseOrder.objects.select_for_update().get(pk=po_id)
    require(user, "procurement.approve", po.branch)
    if po.status != PurchaseOrder.Status.DRAFT:
        raise BusinessRuleError(f"{po.number} is not awaiting approval.")
    if po.created_by_id == user.pk:
        raise BusinessRuleError("You cannot approve a purchase order you created (segregation of duties).",
                                code="sod_violation")
    po.status = PurchaseOrder.Status.APPROVED
    po.approved_by = user
    po.approved_at = timezone.now()
    po.save()
    audit.record("procurement.po_approved", actor=user, obj=po, branch=po.branch)
    return po


@transaction.atomic
def receive_goods(user, po_id, lines, location=None, note=""):
    """
    lines: [{"order_line": id, "qty_accepted": D, "qty_rejected": D, "lot_code": str, "expiry_date": date,
             "rejection_reason": str}]
    Accepted goods enter stock at PO cost: Dr Inventory / Cr Goods-received-not-invoiced.
    """
    po = PurchaseOrder.objects.select_for_update().get(pk=po_id)
    location = location or po.deliver_to
    require(user, "procurement.receive", location.branch)
    if po.status not in (PurchaseOrder.Status.APPROVED, PurchaseOrder.Status.PARTIAL):
        raise BusinessRuleError(f"{po.number} cannot be received in status {po.status}.")
    tol = Decimal(str(Setting.get("procurement.qty_tolerance_pct"))) / 100
    gr = GoodsReceipt.objects.create(number=DocumentSequence.next("GRN", "GRN"), order=po, location=location,
                                     received_by=user, note=note)
    draft = Draft()
    for spec in lines:
        pol = PurchaseOrderLine.objects.select_for_update().select_related("product").get(pk=spec["order_line"],
                                                                                         order=po)
        acc = q3(spec.get("qty_accepted", 0))
        rej = q3(spec.get("qty_rejected", 0))
        if acc < 0 or rej < 0 or acc + rej == 0:
            raise BusinessRuleError("Received quantities must be positive.")
        if pol.qty_received + acc > pol.qty * (1 + tol):
            raise BusinessRuleError(f"Over-delivery of {pol.product.name} exceeds tolerance.", code="over_delivery")
        lot = None
        if pol.product.track_lots and acc > 0:
            code = spec.get("lot_code") or f"{gr.number}-{pol.pk}"
            lot = inv.get_or_create_lot(pol.product, code, spec.get("expiry_date"), supplier_ref=po.supplier.code)
        GoodsReceiptLine.objects.create(receipt=gr, order_line=pol, qty_accepted=acc, qty_rejected=rej, lot=lot,
                                        rejection_reason=spec.get("rejection_reason", ""))
        if acc > 0:
            inv.receive(pol.product, location, acc, pol.unit_cost, StockMovement.Kind.RECEIPT, "GRN", gr.number,
                        lot=lot, actor=user)
            value = q2(acc * pol.unit_cost)
            draft.dr(pol.product.inventory_account_key, value, location.branch).cr("grni", value, location.branch)
        pol.qty_received += acc
        pol.qty_rejected += rej
        pol.save(update_fields=["qty_received", "qty_rejected"])
    all_in = all(l.qty_received >= l.qty for l in po.lines.all())
    po.status = PurchaseOrder.Status.RECEIVED if all_in else PurchaseOrder.Status.PARTIAL
    po.save(update_fields=["status"])
    post(draft, memo=f"Goods receipt {gr.number} for {po.number}", source_type="GRN", source_id=gr.number,
         idempotency_key=f"grn:{gr.number}", branch=location.branch, user=user)
    audit.record("procurement.goods_received", actor=user, obj=gr, branch=location.branch,
                 data={"po": po.number, "lines": len(lines)})
    return gr


@transaction.atomic
def record_invoice(user, po_id, supplier_ref, invoice_date, lines, tax=ZERO):
    """
    Three-way match: invoiced qty <= received qty (+tolerance) and price within tolerance of PO.
    Matched invoices post Dr GRNI (+ price variance) + Dr VAT input / Cr Accounts payable.
    Exceptions put the invoice on HELD and nothing is posted to payables.
    """
    po = PurchaseOrder.objects.select_for_update().get(pk=po_id)
    require(user, "procurement.invoice", po.branch)
    if SupplierInvoice.objects.filter(supplier=po.supplier, supplier_ref=supplier_ref).exists():
        raise BusinessRuleError(f"Invoice {supplier_ref} from {po.supplier.name} is already recorded.",
                                code="duplicate_invoice")
    qty_tol = Decimal(str(Setting.get("procurement.qty_tolerance_pct"))) / 100
    price_tol = Decimal(str(Setting.get("procurement.price_tolerance_pct"))) / 100
    exceptions, subtotal, prepared = [], ZERO, []
    for spec in lines:
        pol = PurchaseOrderLine.objects.select_for_update().select_related("product").get(pk=spec["order_line"],
                                                                                         order=po)
        qty, cost = q3(spec["qty"]), Decimal(spec["unit_cost"])
        if pol.qty_invoiced + qty > pol.qty_received * (1 + qty_tol):
            exceptions.append({"line": pol.pk, "product": pol.product.name, "issue": "quantity_exceeds_receipt",
                               "invoiced": str(pol.qty_invoiced + qty), "received": str(pol.qty_received)})
        if cost > pol.unit_cost * (1 + price_tol):
            exceptions.append({"line": pol.pk, "product": pol.product.name, "issue": "price_above_po",
                               "invoice_price": str(cost), "po_price": str(pol.unit_cost)})
        subtotal += q2(qty * cost)
        prepared.append((pol, qty, cost))
    tax = q2(tax)
    inv_doc = SupplierInvoice.objects.create(
        number=DocumentSequence.next("SINV", "SINV"), supplier=po.supplier, supplier_ref=supplier_ref, order=po,
        invoice_date=invoice_date, subtotal=q2(subtotal), tax=tax, total=q2(subtotal) + tax,
        status=SupplierInvoice.Status.HELD if exceptions else SupplierInvoice.Status.POSTED,
        match_exceptions=exceptions, created_by=user,
    )
    for pol, qty, cost in prepared:
        SupplierInvoiceLine.objects.create(invoice=inv_doc, order_line=pol, qty=qty, unit_cost=cost)
    if not exceptions:
        _post_invoice(inv_doc, user)
    audit.record("procurement.invoice_recorded", actor=user, obj=inv_doc, branch=po.branch,
                 data={"status": inv_doc.status, "exceptions": exceptions, "total": str(inv_doc.total)})
    return inv_doc


def _post_invoice(inv_doc, user):
    po, branch = inv_doc.order, inv_doc.order.branch
    draft = Draft()
    for line in inv_doc.lines.select_related("order_line"):
        pol = line.order_line
        received_value = q2(line.qty * pol.unit_cost)
        billed_value = q2(line.qty * line.unit_cost)
        draft.dr("grni", received_value, branch).dr("ppv", billed_value - received_value, branch)
        pol.qty_invoiced += line.qty
        pol.save(update_fields=["qty_invoiced"])
    draft.dr("vat_input", inv_doc.tax, branch).cr("payable", inv_doc.total, branch)
    post(draft, memo=f"Supplier invoice {inv_doc.supplier_ref} ({inv_doc.supplier.name})", source_type="SINV",
         source_id=inv_doc.number, idempotency_key=f"sinv:{inv_doc.number}", date=inv_doc.invoice_date,
         branch=branch, user=user)


@transaction.atomic
def release_held_invoice(user, invoice_id, note):
    inv_doc = SupplierInvoice.objects.select_for_update().get(pk=invoice_id)
    require(user, "procurement.approve", inv_doc.order.branch)
    if inv_doc.status != SupplierInvoice.Status.HELD:
        raise BusinessRuleError("Only held invoices can be released.")
    if inv_doc.created_by_id == user.pk:
        raise BusinessRuleError("The person who recorded the invoice cannot release its exception.",
                                code="sod_violation")
    inv_doc.status = SupplierInvoice.Status.POSTED
    inv_doc.save(update_fields=["status"])
    _post_invoice(inv_doc, user)
    audit.record("procurement.invoice_exception_released", actor=user, obj=inv_doc, data={"note": note})
    return inv_doc


@transaction.atomic
def pay_invoice(user, invoice_id, amount, method="BANK_TRANSFER", reference=""):
    inv_doc = SupplierInvoice.objects.select_for_update().select_related("order__branch").get(pk=invoice_id)
    branch = inv_doc.order.branch
    require(user, "procurement.pay", branch)
    amount = q2(amount)
    if inv_doc.status == SupplierInvoice.Status.HELD:
        raise BusinessRuleError("Held invoices cannot be paid until the match exception is released.",
                                code="invoice_held")
    if inv_doc.created_by_id == user.pk:
        raise BusinessRuleError("The person who recorded the invoice cannot pay it (segregation of duties).",
                                code="sod_violation")
    if amount <= 0 or inv_doc.amount_paid + amount > inv_doc.total:
        raise BusinessRuleError(f"Payment exceeds the outstanding balance of {inv_doc.total - inv_doc.amount_paid}.",
                                code="overpayment")
    pay = SupplierPayment.objects.create(number=DocumentSequence.next("PAY", "PAY"), invoice=inv_doc, amount=amount,
                                         method=method, reference=reference, paid_by=user)
    inv_doc.amount_paid += amount
    if inv_doc.amount_paid == inv_doc.total:
        inv_doc.status = SupplierInvoice.Status.PAID
    inv_doc.save(update_fields=["amount_paid", "status"])
    source = "cash" if method == "CASH" else "bank"
    post(Draft().dr("payable", amount, branch).cr(source, amount, branch),
         memo=f"Payment {pay.number} to {inv_doc.supplier.name}", source_type="PAY", source_id=pay.number,
         idempotency_key=f"pay:{pay.number}", branch=branch, user=user)
    audit.record("procurement.payment", actor=user, obj=pay, branch=branch, data={"amount": str(amount)})
    return pay
