"""
Executive intelligence, control tower, warehouse map, recall trace, accounting
reports and exports. Every figure is computed from transactional records.
"""
import csv
import io
from collections import defaultdict
from datetime import timedelta
from decimal import Decimal

from django.db.models import Count, Q, Sum
from django.db.models.functions import TruncDate, TruncHour
from django.http import HttpResponse
from django.shortcuts import get_object_or_404
from django.utils import timezone
from rest_framework.decorators import api_view
from rest_framework.response import Response

from apps.accounting import services as acct
from apps.accounting.models import FiscalPeriod, JournalEntry
from apps.core import audit
from apps.core.api import parse_date, user_ref
from apps.core.ethiopian import format_ethiopian
from apps.core.models import AuditLog, Branch
from apps.core.money import ZERO, q2
from apps.iam.models import Terminal
from apps.iam.permissions import branches_for, has_perm, require, require_user
from apps.inventory import services as inv
from apps.inventory.models import Location, Lot, StockBalance, StockDiscrepancy, StockMovement
from apps.inventory.workflows import expiring_lots
from apps.pos.models import Sale, SaleLine, SyncOperation
from apps.procurement.models import PurchaseOrder, SupplierInvoice
from apps.production.models import ProductionIssue, ProductionOrder
from apps.transfers.models import TransferOrder


def _scope(user, request):
    """Branches visible to this user for dashboards (executive = all)."""
    if has_perm(user, "reports.executive"):
        qs = Branch.objects.filter(is_active=True)
    else:
        qs = branches_for(user, "reports.branch")
        if not qs.exists():
            require(user, "reports.branch")
    if b := request.query_params.get("branch"):
        qs = qs.filter(code=b)
    return qs


@api_view(["GET"])
def dashboard(request):
    user = require_user(request)
    branches = list(_scope(user, request))
    today = timezone.localdate()
    tz_now = timezone.localtime()
    start_today = tz_now.replace(hour=0, minute=0, second=0, microsecond=0)
    days = int(request.query_params.get("days", 14))
    period_start = start_today - timedelta(days=days - 1)
    sales = Sale.objects.filter(branch__in=branches)

    def agg(qs):
        r = qs.aggregate(total=Sum("total"), tax=Sum("tax_total"), cost=Sum("cost_total"), n=Count("id"),
                         disc=Sum("discount_total"), ref=Sum("refunded_total"))
        net = (r["total"] or ZERO) - (r["tax"] or ZERO)
        gp = net - (r["cost"] or ZERO)
        return {"sales": q2(r["total"] or 0), "net_sales": q2(net), "gross_profit": q2(gp),
                "gross_margin_pct": q2(gp / net * 100) if net else ZERO, "transactions": r["n"],
                "avg_ticket": q2((r["total"] or 0) / r["n"]) if r["n"] else ZERO,
                "discounts": q2(r["disc"] or 0), "refunds": q2(r["ref"] or 0)}

    today_k = agg(sales.filter(created_at__gte=start_today))
    yday_k = agg(sales.filter(created_at__gte=start_today - timedelta(days=1), created_at__lt=start_today))
    week_k = agg(sales.filter(created_at__gte=start_today - timedelta(days=6)))
    month_k = agg(sales.filter(created_at__gte=start_today.replace(day=1)))

    trend_rows = (sales.filter(created_at__gte=period_start).annotate(d=TruncDate("created_at"))
                  .values("d", "branch__code").annotate(t=Sum("total")).order_by("d"))
    trend = defaultdict(dict)
    for r in trend_rows:
        trend[r["d"].isoformat()][r["branch__code"]] = q2(r["t"])
    trend_list = []
    for i in range(days):
        d = (period_start + timedelta(days=i)).date().isoformat()
        trend_list.append({"date": d, **{b.code: trend.get(d, {}).get(b.code, ZERO) for b in branches if b.sells}})

    by_branch = []
    for b in branches:
        if not b.sells:
            continue
        k = agg(sales.filter(branch=b, created_at__gte=start_today.replace(day=1)))
        kt = agg(sales.filter(branch=b, created_at__gte=start_today))
        by_branch.append({"code": b.code, "name": b.name, "kind": b.kind, "month": k, "today": kt})
    by_branch.sort(key=lambda r: -r["month"]["gross_profit"])

    top = (SaleLine.objects.filter(sale__branch__in=branches, sale__created_at__gte=start_today - timedelta(days=6))
           .values("product__name", "product__sku").annotate(qty=Sum("qty"), revenue=Sum("base"), cost=Sum("cost"))
           .order_by("-revenue")[:8])
    hourly = (sales.filter(created_at__gte=start_today - timedelta(days=6)).annotate(h=TruncHour("created_at"))
              .values("h").annotate(t=Sum("total"), n=Count("id")))
    heat = defaultdict(lambda: ZERO)
    for r in hourly:
        lt = timezone.localtime(r["h"])
        heat[(lt.weekday(), lt.hour)] += r["t"]

    bset = [b.pk for b in branches]
    expiring = [e for e in expiring_lots() if e["branch"] in {b.code for b in branches}]
    production_today = ProductionOrder.objects.filter(source_location__branch__in=bset, completed_at__gte=start_today)
    prod = production_today.aggregate(out=Sum("actual_qty"), scrap=Sum("scrap_qty"), n=Count("id"))
    terminals = Terminal.objects.filter(branch__in=bset, is_active=True)
    stale_terms = terminals.filter(Q(last_seen_at__isnull=True) | Q(last_seen_at__lt=timezone.now() - timedelta(minutes=5)))
    pending_sync = terminals.aggregate(p=Sum("reported_pending"))["p"] or 0
    approvals = {
        "purchase_orders": PurchaseOrder.objects.filter(branch__in=bset, status="DRAFT").count(),
        "transfers": TransferOrder.objects.filter(source__branch__in=bset, status="SUBMITTED").count(),
        "production": ProductionOrder.objects.filter(source_location__branch__in=bset, status="DRAFT").count(),
        "held_invoices": SupplierInvoice.objects.filter(order__branch__in=bset, status="HELD").count(),
    }
    payables = SupplierInvoice.objects.filter(order__branch__in=bset).exclude(status="HELD").aggregate(
        t=Sum("total"), p=Sum("amount_paid"))
    tb = acct.trial_balance()

    briefing = []
    if today_k["sales"] and yday_k["sales"]:
        ch = (today_k["sales"] - yday_k["sales"]) / yday_k["sales"] * 100
        briefing.append({"kind": "fact", "text": f"Sales so far today ETB {today_k['sales']:,} "
                                                 f"({'+' if ch >= 0 else ''}{ch:.0f}% vs all of yesterday)."})
    if by_branch:
        best = by_branch[0]
        briefing.append({"kind": "fact", "text": f"Most profitable outlet this month: {best['name']} "
                                                 f"(gross profit ETB {best['month']['gross_profit']:,})."})
        weak = [b for b in by_branch if b["month"]["net_sales"] and b["month"]["gross_margin_pct"] < 45]
        for w in weak[:2]:
            briefing.append({"kind": "attention", "text": f"{w['name']} gross margin is {w['month']['gross_margin_pct']}% "
                                                          f"this month - review discounts and waste."})
    if top:
        briefing.append({"kind": "fact", "text": f"Best seller (7 days): {top[0]['product__name']} "
                                                 f"({top[0]['qty']:.0f} sold)."})
    if expiring:
        val = sum((e["value"] for e in expiring), ZERO)
        briefing.append({"kind": "attention", "text": f"{len(expiring)} lot(s) expire within 2 days "
                                                      f"(ETB {q2(val):,} at cost)."})
    if sum(approvals.values()):
        briefing.append({"kind": "action", "text": f"{sum(approvals.values())} item(s) waiting for approval."})
    open_disc = StockDiscrepancy.objects.filter(location__branch__in=bset, status="OPEN").count()
    if open_disc:
        briefing.append({"kind": "attention", "text": f"{open_disc} open stock discrepancies to investigate."})
    if stale_terms.exists():
        briefing.append({"kind": "attention", "text": f"{stale_terms.count()} terminal(s) not seen for 5+ minutes - "
                                                      f"their latest sales may not be included yet."})

    return Response({
        "generated_at": timezone.now(), "ethiopian_date": format_ethiopian(today),
        "data_status": "provisional" if pending_sync or stale_terms.exists() else "live",
        "pending_sync_ops": pending_sync, "stale_terminals": stale_terms.count(),
        "kpis": {"today": today_k, "yesterday": yday_k, "week": week_k, "month": month_k},
        "inventory_value": inv.inventory_value() if has_perm(user, "reports.executive")
        else sum((inv.inventory_value(b) for b in branches), ZERO),
        "payables_outstanding": q2((payables["t"] or 0) - (payables["p"] or 0)),
        "trend": trend_list, "branches": by_branch,
        "top_products": [{"name": t["product__name"], "sku": t["product__sku"], "qty": t["qty"],
                          "revenue": q2(t["revenue"]), "margin_pct": q2((t["revenue"] - t["cost"]) / t["revenue"] * 100)
                          if t["revenue"] else ZERO} for t in top],
        "heatmap": [{"dow": k[0], "hour": k[1], "total": q2(v)} for k, v in heat.items()],
        "production_today": {"orders": prod["n"], "output": prod["out"] or 0, "scrap": prod["scrap"] or 0},
        "expiring": expiring[:20], "approvals": approvals, "open_discrepancies": open_disc,
        "ledger_balanced": tb["balanced"], "briefing": briefing,
        "definitions": {
            "sales": "Sum of POS receipt totals incl. VAT (synced sales only).",
            "net_sales": "Sales excluding VAT.",
            "gross_profit": "Net sales minus cost of goods (moving-average cost at time of sale).",
            "inventory_value": "On-hand quantity x moving-average cost, all locations except waste.",
        },
    })


@api_view(["GET"])
def control_tower(request):
    user = require_user(request)
    branches = list(_scope(user, request))
    bset = [b.pk for b in branches]
    now = timezone.now()
    nodes = []
    for b in Branch.objects.filter(is_active=True):
        terms = b.terminals.filter(is_active=True)
        online = terms.filter(last_seen_at__gte=now - timedelta(minutes=2)).count()
        start = timezone.localtime().replace(hour=0, minute=0, second=0, microsecond=0)
        s = Sale.objects.filter(branch=b, created_at__gte=start).aggregate(t=Sum("total"), n=Count("id"))
        nodes.append({"code": b.code, "name": b.name, "kind": b.kind, "x": b.map_x, "y": b.map_y,
                      "terminals": terms.count(), "online": online,
                      "pending": terms.aggregate(p=Sum("reported_pending"))["p"] or 0,
                      "sales_today": q2(s["t"] or 0), "tickets_today": s["n"],
                      "stock_value": inv.inventory_value(b),
                      "alerts": StockDiscrepancy.objects.filter(location__branch=b, status="OPEN").count()})
    links = []
    for t in TransferOrder.objects.filter(status__in=["SUBMITTED", "APPROVED", "DISPATCHED"]).select_related(
            "source__branch", "destination__branch"):
        links.append({"number": t.number, "from": t.source.branch.code, "to": t.destination.branch.code,
                      "status": t.status, "age_minutes": int((now - t.requested_at).total_seconds() // 60)})
    stages = [
        ("Purchasing", PurchaseOrder.objects.filter(branch__in=bset, status__in=["DRAFT", "APPROVED", "PARTIAL"]).count(),
         PurchaseOrder.objects.filter(branch__in=bset, status="DRAFT").count()),
        ("Receiving", PurchaseOrder.objects.filter(branch__in=bset, status__in=["APPROVED", "PARTIAL"]).count(), 0),
        ("Production", ProductionOrder.objects.filter(source_location__branch__in=bset,
                                                      status__in=["DRAFT", "APPROVED", "RELEASED"]).count(),
         ProductionOrder.objects.filter(source_location__branch__in=bset, status="DRAFT").count()),
        ("Quality", ProductionOrder.objects.filter(source_location__branch__in=bset, qc_status="HOLD",
                                                   status="COMPLETED").count(), 0),
        ("Dispatch", TransferOrder.objects.filter(status="APPROVED").count(),
         TransferOrder.objects.filter(status="SUBMITTED").count()),
        ("In transit", TransferOrder.objects.filter(status="DISPATCHED").count(), 0),
        ("Selling", Sale.objects.filter(branch__in=bset, created_at__gte=now - timedelta(hours=1)).count(), 0),
        ("Accounting", JournalEntry.objects.filter(posted_at__gte=now - timedelta(hours=24)).count(), 0),
    ]
    workflows = []
    for t in TransferOrder.objects.select_related("source__branch", "destination__branch", "requested_by",
                                                  "approved_by").order_by("-id")[:12]:
        steps = ["SUBMITTED", "APPROVED", "DISPATCHED", "RECEIVED"]
        cur = steps.index(t.status) if t.status in steps else (3 if t.status == "RECONCILED" else -1)
        waiting = {"SUBMITTED": f"approval at {t.source.branch.name}", "APPROVED": "picking & dispatch",
                   "DISPATCHED": f"receipt at {t.destination.branch.name}"}.get(t.status)
        workflows.append({"type": "Transfer", "number": t.number, "title": f"{t.source.branch.code} -> "
                                                                              f"{t.destination.branch.code}",
                          "steps": ["Requested", "Approved", "In transit", "Received"], "current": cur,
                          "status": t.status, "waiting_for": waiting, "exception": t.status == "RECONCILED",
                          "age_minutes": int((now - t.requested_at).total_seconds() // 60)})
    for o in ProductionOrder.objects.select_related("product").order_by("-id")[:8]:
        steps = ["DRAFT", "APPROVED", "RELEASED", "COMPLETED"]
        workflows.append({"type": "Production", "number": o.number, "title": f"{o.planned_qty:.0f} x {o.product.name}",
                          "steps": ["Planned", "Approved", "Baking", "Done"],
                          "current": steps.index(o.status) if o.status in steps else -1, "status": o.status,
                          "waiting_for": {"DRAFT": "production approval", "APPROVED": "material release",
                                          "RELEASED": "completion & QC"}.get(o.status),
                          "exception": o.qc_status == "HOLD", "age_minutes": int((now - o.created_at).total_seconds() // 60)})
    return Response({"nodes": nodes, "links": links,
                     "stages": [{"name": n, "active": a, "awaiting_approval": w} for n, a, w in stages],
                     "workflows": workflows, "generated_at": now})


@api_view(["GET"])
def warehouse_map(request):
    """Live floor map: storage locations with occupancy derived from the stock ledger projection."""
    user = require_user(request)
    branch = get_object_or_404(Branch, code=request.query_params.get("branch", "WH"))
    require(user, "inventory.view", branch)
    today = timezone.localdate()
    soon = today + timedelta(days=2)
    locs = list(Location.objects.filter(branch=branch, is_active=True).exclude(map_w=0))
    ids = [l.pk for l in Location.objects.filter(branch=branch)]
    children = defaultdict(list)
    for l in Location.objects.filter(branch=branch):
        if l.parent_id:
            children[l.parent_id].append(l.pk)

    def subtree(pk):
        out, stack = [pk], [pk]
        while stack:
            for c in children.get(stack.pop(), []):
                out.append(c)
                stack.append(c)
        return out

    bal = defaultdict(list)
    for b in StockBalance.objects.filter(location_id__in=ids, qty_on_hand__gt=0).select_related("product__unit", "lot"):
        bal[b.location_id].append(b)
    picks = defaultdict(int)
    for loc_id, n in (StockMovement.objects.filter(location_id__in=ids, qty__lt=0,
                                                   at__gte=timezone.now() - timedelta(days=7))
                      .values_list("location_id").annotate(n=Count("id"))):
        picks[loc_id] = n
    out = []
    for l in locs:
        items, qty, value, state = [], ZERO, ZERO, "empty"
        flags = set()
        for pk in subtree(l.pk):
            for b in bal.get(pk, []):
                cost = inv.avg_cost(b.product)
                qty += b.qty_on_hand
                value += b.qty_on_hand * cost
                if b.lot and b.lot.on_hold:
                    flags.add("quarantined")
                if b.lot and b.lot.expiry_date and b.lot.expiry_date <= soon:
                    flags.add("expiring")
                if b.qty_on_hand <= b.product.reorder_point:
                    flags.add("low")
                items.append({"sku": b.product.sku, "name": b.product.name, "unit": b.product.unit.code,
                              "qty": b.qty_on_hand, "reserved": b.qty_reserved,
                              "lot": b.lot.code if b.lot else None,
                              "expiry": b.lot.expiry_date if b.lot else None, "on_hold": bool(b.lot and b.lot.on_hold)})
        util = q2(qty / l.capacity_units * 100) if l.capacity_units else None
        if items:
            state = "normal"
            if "low" in flags:
                state = "low"
            if util is not None and util >= 90:
                state = "near_capacity"
            if "expiring" in flags:
                state = "expiring"
            if "quarantined" in flags or l.kind == "QUARANTINE":
                state = "quarantined"
        out.append({"id": l.pk, "code": l.code, "name": l.name, "kind": l.kind, "level": l.level,
                    "x": l.map_x, "y": l.map_y, "w": l.map_w, "h": l.map_h, "utilization_pct": util,
                    "qty": qty, "value": q2(value), "state": state, "items": items, "picks_7d": picks.get(l.pk, 0)})
    recent = (StockMovement.objects.filter(location__branch=branch).select_related("product", "location", "actor")[:25])
    return Response({"branch": branch.code, "locations": out, "generated_at": timezone.now(),
                     "activity": [{"at": m.at, "kind": m.get_kind_display(), "product": m.product.name,
                                   "qty": m.qty, "location": m.location.code, "doc": f"{m.doc_type} {m.doc_id}",
                                   "actor": m.actor.label if m.actor else None} for m in recent]})


@api_view(["GET"])
def recall_trace(request):
    """Forward trace from a suspect lot: batches made with it, their lots, where they went, sold vs on hand."""
    user = require_user(request)
    require(user, "quality.manage")
    lot = get_object_or_404(Lot.objects.select_related("product"), pk=request.query_params.get("lot_id"))
    seen, frontier, batches, lots = {lot.pk}, [lot], [], [lot]
    while frontier:
        nxt = []
        for l in frontier:
            for iss in ProductionIssue.objects.filter(lot=l).select_related("order__product", "order__output_lot"):
                o = iss.order
                batches.append({"order": o.number, "product": o.product.name, "consumed_from": l.code,
                                "qty_consumed": iss.qty, "output_lot": o.output_lot.code if o.output_lot else None,
                                "output_qty": o.actual_qty, "completed_at": o.completed_at})
                if o.output_lot and o.output_lot.pk not in seen:
                    seen.add(o.output_lot.pk)
                    nxt.append(o.output_lot)
                    lots.append(o.output_lot)
        frontier = nxt
    affected = []
    for l in lots:
        on_hand = (StockBalance.objects.filter(lot=l, qty_on_hand__gt=0).exclude(location__kind="WASTE")
                   .select_related("location__branch"))
        sold = StockMovement.objects.filter(lot=l, kind="SALE").aggregate(q=Sum("qty"))["q"] or 0
        sales = list(StockMovement.objects.filter(lot=l, kind="SALE").values_list("doc_id", flat=True).distinct()[:50])
        affected.append({"lot_id": l.pk, "lot": l.code, "product": l.product.name, "on_hold": l.on_hold,
                         "sold_qty": -sold, "sale_receipts": sales,
                         "on_hand": [{"location": b.location.code, "branch": b.location.branch.code,
                                      "qty": b.qty_on_hand} for b in on_hand]})
    audit.record("quality.recall_trace", actor=user, obj=lot, data={"lots": len(lots)})
    return Response({"lot": {"id": lot.pk, "code": lot.code, "product": lot.product.name}, "batches": batches,
                     "affected_lots": affected})


@api_view(["GET"])
def trial_balance(request):
    user = require_user(request)
    require(user, "accounting.view")
    return Response(acct.trial_balance(parse_date(request.query_params.get("date_to"), default=timezone.localdate())))


@api_view(["GET"])
def profit_and_loss(request):
    user = require_user(request)
    require(user, "accounting.view")
    today = timezone.localdate()
    d_from = parse_date(request.query_params.get("from"), default=today.replace(day=1))
    d_to = parse_date(request.query_params.get("to"), default=today)
    out = {"from": d_from, "to": d_to, "consolidated": acct.profit_and_loss(d_from, d_to), "branches": []}
    for b in Branch.objects.filter(is_active=True):
        pl = acct.profit_and_loss(d_from, d_to, b)
        if pl["lines"]:
            out["branches"].append({"code": b.code, "name": b.name, **pl})
    return Response(out)


@api_view(["GET"])
def journals(request):
    user = require_user(request)
    require(user, "accounting.view")
    qs = JournalEntry.objects.prefetch_related("lines__account", "lines__branch").select_related("posted_by")
    if s := request.query_params.get("source"):
        qs = qs.filter(source_type=s)
    return Response([{"number": e.number, "date": e.date, "memo": e.memo, "source": f"{e.source_type} {e.source_id}",
                      "posted_by": user_ref(e.posted_by),
                      "lines": [{"account": f"{l.account.code} {l.account.name}",
                                 "branch": l.branch.code if l.branch else None, "debit": l.debit, "credit": l.credit}
                                for l in e.lines.all()]}
                     for e in qs[: min(int(request.query_params.get("limit", 50)), 300)]])


@api_view(["POST"])
def lock_period(request, year, month):
    user = require_user(request)
    require(user, "accounting.period_close")
    p, _ = FiscalPeriod.objects.get_or_create(year=year, month=month)
    lock = request.data.get("lock", True)
    p.status = FiscalPeriod.Status.LOCKED if lock else FiscalPeriod.Status.OPEN
    p.locked_by, p.locked_at = (user, timezone.now()) if lock else (None, None)
    p.save()
    audit.record("accounting.period_locked" if lock else "accounting.period_reopened", actor=user, obj=p)
    return Response({"period": str(p)})


@api_view(["GET"])
def sync_conflicts(request):
    user = require_user(request)
    require(user, "sync.monitor")
    allowed = branches_for(user, "sync.monitor")
    qs = SyncOperation.objects.filter(status="REJECTED", terminal__branch__in=allowed).select_related(
        "terminal__branch", "resolved_by")
    if request.query_params.get("open", "1") == "1":
        qs = qs.filter(resolved_by__isnull=True)
    return Response([{"op_id": str(o.op_id), "terminal": o.terminal.code, "branch": o.terminal.branch.code,
                      "kind": o.kind, "error": o.result.get("error"), "detail": o.result.get("detail"),
                      "received_at": o.received_at, "payload": o.payload, "resolved_by": user_ref(o.resolved_by),
                      "resolution_note": o.resolution_note} for o in qs[:200]])


@api_view(["POST"])
def resolve_conflict(request, op_id):
    user = require_user(request)
    op = get_object_or_404(SyncOperation, pk=op_id, status="REJECTED")
    require(user, "sync.monitor", op.terminal.branch)
    note = str(request.data.get("note", "")).strip()
    if not note:
        return Response({"error": "invalid", "detail": "Describe how the conflict was resolved."}, status=400)
    op.resolved_by, op.resolution_note = user, note[:255]
    op.save(update_fields=["resolved_by", "resolution_note"])
    audit.record("pos.sync_conflict_resolved", actor=user, object_type="pos.SyncOperation", object_id=op.op_id,
                 branch=op.terminal.branch, data={"note": note})
    return Response({"ok": True})


@api_view(["GET"])
def audit_log(request):
    user = require_user(request)
    require(user, "accounting.view")
    qs = AuditLog.objects.select_related("actor", "branch")
    if a := request.query_params.get("action"):
        qs = qs.filter(action__startswith=a)
    return Response([{"id": e.id, "at": e.at, "actor": user_ref(e.actor), "terminal": e.terminal_code,
                      "action": e.action, "object": f"{e.object_type}:{e.object_id}",
                      "branch": e.branch.code if e.branch else None, "data": e.data, "hash": e.hash[:12]}
                     for e in qs[:200]])


def _csv_safe(v):
    """Neutralise spreadsheet formula injection (=, +, -, @, tab, CR at cell start)."""
    s = "" if v is None else str(v)
    if s and s[0] in ("=", "+", "-", "@", "\t", "\r") and not _is_number(s):
        return "'" + s
    return s


def _is_number(s):
    try:
        Decimal(s)
        return True
    except Exception:
        return False


@api_view(["GET"])
def export_csv(request, report):
    user = require_user(request)
    require(user, "reports.export")
    buf = io.StringIO()
    w = csv.writer(buf)
    if report == "trial-balance":
        require(user, "accounting.view")
        tb = acct.trial_balance()
        w.writerow(["Account", "Name", "Type", "Debit", "Credit"])
        for r in tb["rows"]:
            w.writerow([_csv_safe(x) for x in (r["code"], r["name"], r["type"], r["debit"], r["credit"])])
        w.writerow(["", "TOTAL", "", tb["total_debit"], tb["total_credit"]])
    elif report == "sales":
        branches = _scope(user, request)
        d_from = parse_date(request.query_params.get("from"), default=timezone.localdate() - timedelta(days=30))
        w.writerow(["Receipt", "Branch", "Date", "Cashier", "Type", "Gross", "Discount", "VAT", "Total", "COGS",
                    "Refunded", "Offline", "Flags"])
        for s in Sale.objects.filter(branch__in=branches, created_at__date__gte=d_from).select_related("branch", "cashier")[:50000]:
            w.writerow([_csv_safe(x) for x in (s.number, s.branch.code, timezone.localtime(s.created_at).isoformat(),
                                               s.cashier.label, s.order_type, s.gross, s.discount_total, s.tax_total,
                                               s.total, s.cost_total, s.refunded_total, s.was_offline,
                                               ";".join(f["code"] for f in s.flags))])
    elif report == "stock":
        require(user, "inventory.view")
        allowed = branches_for(user, "inventory.view")
        w.writerow(["Branch", "Location", "SKU", "Product", "Lot", "Expiry", "On hand", "Reserved", "Avg cost", "Value"])
        for b in StockBalance.objects.filter(location__branch__in=allowed).exclude(qty_on_hand=0).select_related(
                "location__branch", "product", "lot"):
            c = inv.avg_cost(b.product)
            w.writerow([_csv_safe(x) for x in (b.location.branch.code, b.location.code, b.product.sku, b.product.name,
                                               b.lot.code if b.lot else "", b.lot.expiry_date if b.lot else "",
                                               b.qty_on_hand, b.qty_reserved, c, q2(b.qty_on_hand * c))])
    else:
        return Response({"error": "not_found"}, status=404)
    audit.record("report.exported", actor=user, object_type="report", object_id=report,
                 data={"params": dict(request.query_params)})
    resp = HttpResponse(buf.getvalue(), content_type="text/csv; charset=utf-8")
    resp["Content-Disposition"] = f'attachment; filename="yummy-{report}-{timezone.localdate()}.csv"'
    return resp
