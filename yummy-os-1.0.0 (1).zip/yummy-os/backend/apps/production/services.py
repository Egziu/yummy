"""
Recipes (nested BOM), costing and production execution.

Costing policy (documented): inventory is valued at ACTUAL batch cost =
issued materials at moving-average cost + applied labour + applied overhead
(overhead driver = direct labour hours). Standard cost is computed for
comparison and variance reporting only; it is never mixed into valuation.
"""
from collections import defaultdict
from datetime import timedelta
from decimal import Decimal

from django.db import transaction
from django.utils import timezone

from apps.accounting.services import Draft, post
from apps.core import audit
from apps.core.exceptions import BusinessRuleError
from apps.core.models import DocumentSequence, Setting
from apps.core.money import ZERO, q2, q3, q4
from apps.inventory import services as inv
from apps.inventory.models import Location, StockMovement

from apps.iam.permissions import require

from .models import ProductionIssue, ProductionOrder, Recipe


def active_recipe(product):
    return (Recipe.objects.filter(product=product, status=Recipe.Status.APPROVED)
            .order_by("-version").prefetch_related("lines__ingredient").first())


def explode(recipe, batches=Decimal("1"), _path=None):
    """
    Ingredient requirements for `batches` batches, recursing through phantom
    (explode=True) lines. Returns ({ingredient_product: qty}, labor_minutes).
    Raises on circular references.
    """
    _path = (_path or ()) + (recipe.product_id,)
    req = defaultdict(lambda: ZERO)
    labor = recipe.labor_minutes * batches
    for line in recipe.lines.select_related("ingredient").all():
        qty = line.qty * batches * (1 + line.waste_pct / 100)
        if line.ingredient_id in _path:
            raise BusinessRuleError(f"Circular recipe: {line.ingredient.name} contains itself.", code="recipe_cycle")
        if line.explode:
            sub = active_recipe(line.ingredient)
            if sub is None:
                raise BusinessRuleError(f"{line.ingredient.name} has no approved recipe to explode.")
            sub_req, sub_labor = explode(sub, qty / sub.output_qty, _path)
            for k, v in sub_req.items():
                req[k] += v
            labor += sub_labor
        else:
            req[line.ingredient] += qty
    return dict(req), labor


def cost_rates():
    return (Decimal(str(Setting.get("costing.labor_rate_per_hour"))),
            Decimal(str(Setting.get("costing.overhead_per_labor_hour"))))


def standard_cost(recipe, qty=None):
    """Cost simulation for `qty` units (default one batch). Returns a breakdown dict."""
    qty = Decimal(qty) if qty is not None else recipe.output_qty
    batches = qty / recipe.output_qty
    req, labor_min = explode(recipe, batches)
    labor_rate, oh_rate = cost_rates()
    materials = []
    mat_total = ZERO
    for product, q in sorted(req.items(), key=lambda kv: kv[0].name):
        c = inv.avg_cost(product)
        materials.append({"sku": product.sku, "name": product.name, "unit": product.unit.code, "qty": q3(q),
                          "unit_cost": q4(c), "cost": q2(q * c)})
        mat_total += q * c
    hours = labor_min / 60
    labor, overhead = hours * labor_rate, hours * oh_rate
    total = mat_total + labor + overhead
    return {"qty": q3(qty), "materials": materials, "material_cost": q2(mat_total), "labor_minutes": q2(labor_min),
            "labor_cost": q2(labor), "overhead_cost": q2(overhead), "total_cost": q2(total),
            "unit_cost": q4(total / qty)}


@transaction.atomic
def approve_recipe(user, recipe_id):
    r = Recipe.objects.select_for_update().get(pk=recipe_id)
    require(user, "recipe.approve")
    if r.status != Recipe.Status.DRAFT:
        raise BusinessRuleError("Only draft recipes can be approved.")
    if r.created_by_id == user.pk:
        raise BusinessRuleError("Recipe author cannot approve their own costing (segregation of duties).",
                                code="sod_violation")
    if not r.lines.exists():
        raise BusinessRuleError("Recipe has no ingredients.")
    explode(r)  # cycle / missing sub-recipe check
    Recipe.objects.filter(product=r.product, status=Recipe.Status.APPROVED).update(status=Recipe.Status.RETIRED)
    r.status, r.approved_by, r.approved_at = Recipe.Status.APPROVED, user, timezone.now()
    r.save()
    cost = standard_cost(r)
    r.product.standard_cost = cost["unit_cost"]
    r.product.save(update_fields=["standard_cost"])
    audit.record("recipe.approved", actor=user, obj=r, data={"version": r.version, "unit_cost": str(cost["unit_cost"])})
    return r


@transaction.atomic
def create_order(user, product, qty, planned_date, source_location, output_location, priority=3):
    require(user, "production.plan", source_location.branch)
    recipe = active_recipe(product)
    if recipe is None:
        raise BusinessRuleError(f"{product.name} has no approved recipe.")
    po = ProductionOrder.objects.create(
        number=DocumentSequence.next("MO", "MO"), recipe=recipe, product=product, planned_qty=q3(qty),
        planned_date=planned_date, priority=priority, workstation=recipe.workstation,
        source_location=source_location, output_location=output_location, created_by=user,
        standard_unit_cost=standard_cost(recipe, qty)["unit_cost"],
    )
    audit.record("production.order_created", actor=user, obj=po, branch=source_location.branch,
                 data={"product": product.sku, "qty": str(qty)})
    return po


@transaction.atomic
def approve_order(user, order_id):
    po = ProductionOrder.objects.select_for_update().get(pk=order_id)
    require(user, "production.approve", po.source_location.branch)
    if po.status != ProductionOrder.Status.DRAFT:
        raise BusinessRuleError(f"{po.number} is not awaiting approval.")
    po.status, po.approved_by = ProductionOrder.Status.APPROVED, user
    po.save(update_fields=["status", "approved_by"])
    audit.record("production.order_approved", actor=user, obj=po, branch=po.source_location.branch)
    return po


def material_check(order):
    """Availability of every ingredient at the source location (FEFO-usable stock)."""
    req, _ = explode(order.recipe, order.planned_qty / order.recipe.output_qty)
    out = []
    for product, qty in req.items():
        allocs, short = inv.allocate_fefo(product, order.source_location, qty)
        out.append({"sku": product.sku, "name": product.name, "required": q3(qty),
                    "available": q3(sum((a.qty for a in allocs), ZERO)), "short": q3(short)})
    return out


@transaction.atomic
def release_order(user, order_id):
    """Issue materials FEFO to WIP. All-or-nothing: any shortage aborts the whole release."""
    po = ProductionOrder.objects.select_for_update().select_related("recipe", "source_location__branch").get(pk=order_id)
    branch = po.source_location.branch
    require(user, "production.execute", branch)
    if po.status != ProductionOrder.Status.APPROVED:
        raise BusinessRuleError(f"{po.number} must be approved before release (status {po.status}).")
    req, _ = explode(po.recipe, po.planned_qty / po.recipe.output_qty)
    draft = Draft()
    total = ZERO
    for product, qty in req.items():
        moves, cost = inv.consume(product, po.source_location, q3(qty), StockMovement.Kind.PRODUCTION_ISSUE, "MO",
                                  po.number, actor=user, exclude_expired=True)
        for m in moves:
            ProductionIssue.objects.create(order=po, product=product, lot=m.lot, qty=-m.qty, unit_cost=m.unit_cost)
        draft.dr("wip", cost, branch).cr(product.inventory_account_key, cost, branch)
        total += cost
    po.material_cost = q2(total)
    po.status, po.released_by, po.released_at = ProductionOrder.Status.RELEASED, user, timezone.now()
    po.save()
    post(draft, memo=f"Materials issued to {po.number}", source_type="MO", source_id=po.number,
         idempotency_key=f"mo-issue:{po.number}", branch=branch, user=user)
    audit.record("production.released", actor=user, obj=po, branch=branch, data={"material_cost": str(po.material_cost)})
    return po


@transaction.atomic
def complete_order(user, order_id, actual_qty, scrap_qty=ZERO, qc_passed=True):
    po = ProductionOrder.objects.select_for_update().select_related("recipe", "product", "output_location__branch",
                                                                    "source_location__branch").get(pk=order_id)
    branch = po.source_location.branch
    require(user, "production.execute", branch)
    if po.status != ProductionOrder.Status.RELEASED:
        raise BusinessRuleError(f"{po.number} is not in production (status {po.status}).")
    actual_qty, scrap_qty = q3(actual_qty), q3(scrap_qty)
    if actual_qty <= 0:
        raise BusinessRuleError("Completed quantity must be positive. Cancel the order to write off materials.")
    _, labor_min = explode(po.recipe, po.planned_qty / po.recipe.output_qty)
    labor_rate, oh_rate = cost_rates()
    hours = labor_min / 60
    po.labor_cost, po.overhead_cost = q2(hours * labor_rate), q2(hours * oh_rate)
    total = po.material_cost + po.labor_cost + po.overhead_cost
    unit = q4(total / actual_qty)
    today = timezone.localdate()
    expiry = today + timedelta(days=po.product.shelf_life_days) if po.product.shelf_life_days else None
    lot = inv.get_or_create_lot(po.product, po.number, expiry, production_order=po, on_hold=not qc_passed)
    dest = po.output_location
    if not qc_passed:
        dest = Location.objects.filter(branch=branch, kind=Location.Kind.QUARANTINE).first() or dest
    inv.receive(po.product, dest, actual_qty, unit, StockMovement.Kind.PRODUCTION_OUTPUT, "MO", po.number, lot=lot,
                actor=user)
    po.actual_qty, po.scrap_qty, po.unit_cost, po.output_lot = actual_qty, scrap_qty, unit, lot
    po.qc_status = ProductionOrder.QC.PASSED if qc_passed else ProductionOrder.QC.HOLD
    po.status, po.completed_by, po.completed_at = ProductionOrder.Status.COMPLETED, user, timezone.now()
    po.save()
    draft = (Draft().dr(po.product.inventory_account_key, total, branch).cr("wip", po.material_cost, branch)
             .cr("applied_labor", po.labor_cost, branch).cr("applied_overhead", po.overhead_cost, branch))
    post(draft, memo=f"Production output {po.number}: {actual_qty} x {po.product.name}", source_type="MO",
         source_id=po.number, idempotency_key=f"mo-output:{po.number}", branch=branch, user=user)
    audit.record("production.completed", actor=user, obj=po, branch=branch,
                 data={"actual": str(actual_qty), "unit_cost": str(unit), "qc": po.qc_status})
    return po
