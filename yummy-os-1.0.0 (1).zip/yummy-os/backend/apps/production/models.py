from django.conf import settings
from django.db import models
from django.db.models import Q

from apps.catalog.models import Product
from apps.inventory.models import Location, Lot


class Recipe(models.Model):
    class Status(models.TextChoices):
        DRAFT = "DRAFT", "Draft"
        APPROVED = "APPROVED", "Approved (active)"
        RETIRED = "RETIRED", "Retired"

    product = models.ForeignKey(Product, on_delete=models.PROTECT, related_name="recipes")
    version = models.PositiveIntegerField(default=1)
    output_qty = models.DecimalField(max_digits=12, decimal_places=3, help_text="Units produced by one batch")
    labor_minutes = models.DecimalField(max_digits=10, decimal_places=2, default=0,
                                        help_text="Direct labour minutes per batch")
    workstation = models.CharField(max_length=40, blank=True)
    instructions = models.TextField(blank=True)
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.DRAFT)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, on_delete=models.PROTECT, related_name="+")
    approved_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.PROTECT,
                                    related_name="+")
    approved_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        unique_together = [("product", "version")]
        ordering = ["product__name", "-version"]
        constraints = [models.CheckConstraint(condition=Q(output_qty__gt=0), name="recipe_output_positive")]

    def __str__(self):
        return f"{self.product.name} v{self.version}"


class RecipeLine(models.Model):
    recipe = models.ForeignKey(Recipe, on_delete=models.CASCADE, related_name="lines")
    ingredient = models.ForeignKey(Product, on_delete=models.PROTECT, related_name="used_in")
    qty = models.DecimalField(max_digits=12, decimal_places=4)
    waste_pct = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    explode = models.BooleanField(default=False, help_text="Phantom: use the ingredient's own recipe instead of stock")

    class Meta:
        constraints = [models.CheckConstraint(condition=Q(qty__gt=0) & Q(waste_pct__gte=0), name="recipe_line_positive")]


class ProductionOrder(models.Model):
    class Status(models.TextChoices):
        DRAFT = "DRAFT", "Planned"
        APPROVED = "APPROVED", "Approved"
        RELEASED = "RELEASED", "In production (materials issued)"
        COMPLETED = "COMPLETED", "Completed & received"
        CANCELLED = "CANCELLED", "Cancelled"

    class QC(models.TextChoices):
        PENDING = "PENDING", "Pending"
        PASSED = "PASSED", "Passed"
        HOLD = "HOLD", "On hold / failed"

    number = models.CharField(max_length=30, unique=True)
    recipe = models.ForeignKey(Recipe, on_delete=models.PROTECT)
    product = models.ForeignKey(Product, on_delete=models.PROTECT)
    planned_qty = models.DecimalField(max_digits=12, decimal_places=3)
    planned_date = models.DateField()
    priority = models.PositiveSmallIntegerField(default=3)
    workstation = models.CharField(max_length=40, blank=True)
    source_location = models.ForeignKey(Location, on_delete=models.PROTECT, related_name="+")
    output_location = models.ForeignKey(Location, on_delete=models.PROTECT, related_name="+")
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.DRAFT)
    qc_status = models.CharField(max_length=8, choices=QC.choices, default=QC.PENDING)
    actual_qty = models.DecimalField(max_digits=12, decimal_places=3, null=True, blank=True)
    scrap_qty = models.DecimalField(max_digits=12, decimal_places=3, default=0)
    material_cost = models.DecimalField(max_digits=16, decimal_places=2, default=0)
    labor_cost = models.DecimalField(max_digits=16, decimal_places=2, default=0)
    overhead_cost = models.DecimalField(max_digits=16, decimal_places=2, default=0)
    unit_cost = models.DecimalField(max_digits=14, decimal_places=4, null=True, blank=True)
    standard_unit_cost = models.DecimalField(max_digits=14, decimal_places=4, null=True, blank=True)
    output_lot = models.ForeignKey(Lot, null=True, blank=True, on_delete=models.PROTECT, related_name="+")
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="+")
    created_at = models.DateTimeField(auto_now_add=True)
    approved_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.PROTECT,
                                    related_name="+")
    released_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.PROTECT,
                                    related_name="+")
    released_at = models.DateTimeField(null=True, blank=True)
    completed_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.PROTECT,
                                     related_name="+")
    completed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-planned_date", "priority", "-id"]
        constraints = [models.CheckConstraint(condition=Q(planned_qty__gt=0), name="po_qty_positive")]

    def __str__(self):
        return self.number

    @property
    def yield_pct(self):
        if self.actual_qty is None:
            return None
        return (self.actual_qty / self.planned_qty * 100).quantize(self.planned_qty.__class__("0.1"))


class ProductionIssue(models.Model):
    """Materials actually issued to an order (lot-level traceability)."""

    order = models.ForeignKey(ProductionOrder, on_delete=models.PROTECT, related_name="issues")
    product = models.ForeignKey(Product, on_delete=models.PROTECT)
    lot = models.ForeignKey(Lot, null=True, blank=True, on_delete=models.PROTECT, related_name="issued_to")
    qty = models.DecimalField(max_digits=14, decimal_places=3)
    unit_cost = models.DecimalField(max_digits=14, decimal_places=4)
