import math
from datetime import timedelta
from decimal import Decimal

from django.db.models import Sum
from django.shortcuts import get_object_or_404
from django.utils import timezone
from rest_framework.decorators import api_view
from rest_framework.response import Response

from apps.catalog.models import Product
from apps.core.api import dec, parse_date, user_ref
from apps.core.money import q3
from apps.inventory.models import Location, StockBalance
from apps.iam.permissions import branches_for, require, require_user

from . import services
from .models import ProductionOrder, Recipe


def _order_json(o, detail=False):
    d = {
        "id": o.pk, "number": o.number, "product": o.product.name, "sku": o.product.sku, "unit": o.product.unit.code,
        "recipe_version": o.recipe.version, "planned_qty": o.planned_qty, "planned_date": o.planned_date,
        "priority": o.priority, "workstation": o.workstation, "status": o.status,
        "status_label": o.get_status_display(), "qc_status": o.qc_status, "actual_qty": o.actual_qty,
        "scrap_qty": o.scrap_qty, "yield_pct": o.yield_pct, "material_cost": o.material_cost,
        "labor_cost": o.labor_cost, "overhead_cost": o.overhead_cost, "unit_cost": o.unit_cost,
        "standard_unit_cost": o.standard_unit_cost, "lot": o.output_lot.code if o.output_lot else None,
        "source": o.source_location.code, "output": o.output_location.code,
        "created_by": user_ref(o.created_by), "released_at": o.released_at, "completed_at": o.completed_at,
    }
    if detail:
        if o.status in ("DRAFT", "APPROVED"):
            d["materials"] = services.material_check(o)
        d["issues"] = [{"sku": i.product.sku, "name": i.product.name, "lot": i.lot.code if i.lot else None,
                        "qty": i.qty, "unit_cost": i.unit_cost} for i in o.issues.select_related("product", "lot")]
        d["cost_simulation"] = services.standard_cost(o.recipe, o.planned_qty)
    return d


def _qs():
    return ProductionOrder.objects.select_related("product__unit", "recipe", "output_lot", "source_location__branch",
                                                  "output_location", "created_by")


@api_view(["GET", "POST"])
def orders(request):
    user = require_user(request)
    if request.method == "GET":
        allowed = branches_for(user, "production.view")
        qs = _qs().filter(source_location__branch__in=allowed)
        if s := request.query_params.get("status"):
            qs = qs.filter(status__in=s.split(","))
        return Response([_order_json(o) for o in qs[:200]])
    product = get_object_or_404(Product, sku=request.data.get("sku"))
    src = get_object_or_404(Location, code=request.data.get("source"))
    out = get_object_or_404(Location, code=request.data.get("output", request.data.get("source")))
    o = services.create_order(user, product, dec(request.data, "qty", positive=True),
                              parse_date(request.data.get("planned_date"), default=timezone.localdate()), src, out,
                              int(request.data.get("priority", 3)))
    return Response(_order_json(_qs().get(pk=o.pk), True), status=201)


@api_view(["GET"])
def order_detail(request, oid):
    user = require_user(request)
    o = get_object_or_404(_qs(), pk=oid)
    require(user, "production.view", o.source_location.branch)
    return Response(_order_json(o, True))


@api_view(["POST"])
def order_action(request, oid, action):
    user = require_user(request)
    if action == "approve":
        services.approve_order(user, oid)
    elif action == "release":
        services.release_order(user, oid)
    elif action == "complete":
        services.complete_order(user, oid, dec(request.data, "actual_qty", positive=True),
                                dec(request.data, "scrap_qty", "0"), bool(request.data.get("qc_passed", True)))
    else:
        return Response({"error": "not_found"}, status=404)
    return Response(_order_json(_qs().get(pk=oid), True))


@api_view(["GET"])
def recipes(request):
    require(require_user(request), "production.view")
    out = []
    for r in Recipe.objects.select_related("product__unit").prefetch_related("lines__ingredient__unit").exclude(
            status=Recipe.Status.RETIRED):
        try:
            cost = services.standard_cost(r)
        except Exception as e:  # e.g. cycle in a draft
            cost = {"error": str(e)}
        out.append({"id": r.pk, "product": r.product.name, "sku": r.product.sku, "version": r.version,
                    "status": r.status, "output_qty": r.output_qty, "unit": r.product.unit.code,
                    "labor_minutes": r.labor_minutes, "workstation": r.workstation,
                    "lines": [{"sku": l.ingredient.sku, "name": l.ingredient.name, "qty": l.qty,
                               "unit": l.ingredient.unit.code, "waste_pct": l.waste_pct, "phantom": l.explode}
                              for l in r.lines.all()],
                    "cost": cost})
    return Response(out)


@api_view(["GET"])
def simulate(request, rid):
    require(require_user(request), "production.view")
    r = get_object_or_404(Recipe, pk=rid)
    return Response(services.standard_cost(r, dec(request.query_params, "qty", r.output_qty, positive=True)))


@api_view(["POST"])
def approve_recipe(request, rid):
    r = services.approve_recipe(require_user(request), rid)
    return Response({"id": r.pk, "status": r.status})


@api_view(["GET"])
def plan(request):
    """
    Smart production suggestion for tomorrow, with its evidence:
      demand  = average daily units sold over the last N days (all branches)
      target  = demand x (1 + safety %)
      have    = finished stock everywhere (excluding quarantine) + open production
      suggest = max(0, target - have), rounded up to whole recipe batches
    """
    user = require_user(request)
    require(user, "production.view")
    from apps.pos.models import SaleLine

    days = int(request.query_params.get("days", 7))
    safety = Decimal(request.query_params.get("safety_pct", "10")) / 100
    since = timezone.now() - timedelta(days=days)
    sold = dict(SaleLine.objects.filter(sale__created_at__gte=since).values("product_id")
                .annotate(q=Sum("qty")).values_list("product_id", "q"))
    rows = []
    for r in Recipe.objects.filter(status=Recipe.Status.APPROVED).select_related("product__unit"):
        p = r.product
        if p.kind not in (Product.Kind.FINISHED, Product.Kind.SEMI):
            continue
        avg = Decimal(sold.get(p.pk) or 0) / days
        stock = (StockBalance.objects.filter(product=p).exclude(location__kind__in=["QUARANTINE", "WASTE"])
                 .exclude(lot__on_hold=True).aggregate(s=Sum("qty_on_hand"))["s"] or 0)
        wip = (ProductionOrder.objects.filter(product=p, status__in=["DRAFT", "APPROVED", "RELEASED"])
               .aggregate(s=Sum("planned_qty"))["s"] or 0)
        if p.kind == Product.Kind.SEMI and not avg and not stock and not wip:
            continue  # phantom sub-recipes are produced inside their parent orders
        target = avg * (1 + safety)
        need = max(Decimal(0), target - stock - wip)
        batches = math.ceil(need / r.output_qty) if need > 0 else 0
        rows.append({"sku": p.sku, "product": p.name, "unit": p.unit.code, "avg_daily_sales": q3(avg),
                     "target": q3(target), "stock": q3(stock), "open_orders": q3(wip), "batch_size": r.output_qty,
                     "suggested_batches": batches, "suggested_qty": q3(batches * r.output_qty),
                     "shelf_life_days": p.shelf_life_days})
    rows.sort(key=lambda x: -x["suggested_qty"])
    return Response({"days": days, "safety_pct": str(safety * 100), "rows": rows,
                     "note": "Recommendation only - a production manager approves every order."})
