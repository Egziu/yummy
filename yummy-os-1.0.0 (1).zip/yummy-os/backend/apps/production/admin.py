from django.contrib import admin

from .models import Recipe, RecipeLine


class LineInline(admin.TabularInline):
    model = RecipeLine
    extra = 1


@admin.register(Recipe)
class RecipeAdmin(admin.ModelAdmin):
    list_display = ("product", "version", "status", "output_qty", "labor_minutes")
    inlines = [LineInline]
    readonly_fields = ("status", "approved_by", "approved_at")
