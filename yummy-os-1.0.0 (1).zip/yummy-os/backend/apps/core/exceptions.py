from django.core.exceptions import ValidationError as DjangoValidationError
from django.db import IntegrityError
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import exception_handler


class BusinessRuleError(Exception):
    """A request that is well-formed but violates a business rule. Returned as HTTP 409."""

    code = "business_rule"

    def __init__(self, message, code=None, **details):
        super().__init__(message)
        self.message = message
        if code:
            self.code = code
        self.details = details


class InsufficientStock(BusinessRuleError):
    code = "insufficient_stock"


class PermissionDeniedError(Exception):
    def __init__(self, message="You do not have permission for this action."):
        super().__init__(message)
        self.message = message


def api_exception_handler(exc, context):
    if isinstance(exc, BusinessRuleError):
        return Response({"error": exc.code, "detail": exc.message, **exc.details}, status=status.HTTP_409_CONFLICT)
    if isinstance(exc, PermissionDeniedError):
        return Response({"error": "forbidden", "detail": exc.message}, status=status.HTTP_403_FORBIDDEN)
    if isinstance(exc, DjangoValidationError):
        return Response({"error": "invalid", "detail": exc.messages}, status=status.HTTP_400_BAD_REQUEST)
    if isinstance(exc, IntegrityError):
        return Response({"error": "integrity", "detail": "The change conflicts with existing data."}, status=409)
    return exception_handler(exc, context)
