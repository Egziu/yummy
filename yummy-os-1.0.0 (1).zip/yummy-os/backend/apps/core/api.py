from datetime import date
from decimal import Decimal, InvalidOperation

from django.shortcuts import get_object_or_404
from rest_framework.exceptions import ValidationError

from .models import Branch


def branch_or_404(code):
    return get_object_or_404(Branch, code=code)


def dec(data, key, default=None, positive=False):
    v = data.get(key, default)
    if v is None:
        raise ValidationError({key: "required"})
    try:
        d = Decimal(str(v))
    except (InvalidOperation, TypeError):
        raise ValidationError({key: "must be a number"})
    if not d.is_finite() or (positive and d <= 0):
        raise ValidationError({key: "must be a positive number" if positive else "invalid number"})
    return d


def parse_date(value, key="date", default=None):
    if not value:
        if default is not None:
            return default
        raise ValidationError({key: "required"})
    try:
        return date.fromisoformat(str(value))
    except ValueError:
        raise ValidationError({key: "use YYYY-MM-DD"})


def user_ref(u):
    return {"id": u.pk, "name": u.label} if u else None
