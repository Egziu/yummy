import hashlib
import json

from django.conf import settings
from django.db import models, transaction
from django.utils import timezone


class Branch(models.Model):
    """A business unit: head office, production, warehouse, shop or café. Unlimited; added by configuration."""

    class Kind(models.TextChoices):
        HEAD_OFFICE = "HEAD_OFFICE", "Head office"
        PRODUCTION = "PRODUCTION", "Production facility"
        WAREHOUSE = "WAREHOUSE", "Warehouse"
        SHOP = "SHOP", "Retail shop"
        CAFE = "CAFE", "Café"

    code = models.CharField(max_length=20, unique=True)
    name = models.CharField(max_length=120)
    kind = models.CharField(max_length=20, choices=Kind.choices)
    address = models.CharField(max_length=255, blank=True)
    phone = models.CharField(max_length=40, blank=True)
    tin = models.CharField("Tax ID (TIN)", max_length=40, blank=True)
    map_x = models.IntegerField(default=0, help_text="Position on the enterprise network map")
    map_y = models.IntegerField(default=0)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["code"]
        verbose_name_plural = "branches"

    def __str__(self):
        return f"{self.code} · {self.name}"

    @property
    def sells(self):
        return self.kind in (self.Kind.SHOP, self.Kind.CAFE)


class Setting(models.Model):
    """Versioned key/value business configuration (thresholds, rates, policies)."""

    key = models.CharField(max_length=80, unique=True)
    value = models.JSONField()
    description = models.CharField(max_length=255, blank=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.key

    DEFAULTS = {
        "costing.labor_rate_per_hour": ("85.00", "Direct labour cost per hour (ETB) applied to production"),
        "costing.overhead_per_labor_hour": ("40.00", "Manufacturing overhead applied per direct labour hour (ETB)"),
        "pos.max_discount_pct_without_approval": ("10", "Line discount % a cashier may give without a supervisor"),
        "pos.block_expired_lots": (True, "Exclude expired lots when consuming stock for sales"),
        "procurement.qty_tolerance_pct": ("2", "Invoice quantity tolerance over received quantity (%)"),
        "procurement.price_tolerance_pct": ("3", "Invoice unit price tolerance over PO price (%)"),
        "inventory.expiry_warning_days": ("2", "Lots expiring within this many days are flagged"),
    }

    @classmethod
    def get(cls, key):
        try:
            return cls.objects.get(key=key).value
        except cls.DoesNotExist:
            return cls.DEFAULTS[key][0]


class DocumentSequence(models.Model):
    """Gap-free document numbering, safe under concurrency (row lock)."""

    key = models.CharField(max_length=40, unique=True)
    prefix = models.CharField(max_length=20)
    next_value = models.PositiveBigIntegerField(default=1)
    padding = models.PositiveSmallIntegerField(default=6)

    @classmethod
    def next(cls, key, prefix=None):
        with transaction.atomic():
            seq, _ = cls.objects.select_for_update().get_or_create(key=key, defaults={"prefix": prefix or key})
            n = seq.next_value
            seq.next_value = n + 1
            seq.save(update_fields=["next_value"])
            return f"{seq.prefix}-{str(n).zfill(seq.padding)}"


class AuditLog(models.Model):
    """
    Append-only, hash-chained audit trail. Each row stores the SHA-256 of its
    content plus the previous row's hash, so any edit or deletion breaks the
    chain (verify with `manage.py verify_audit`). A database trigger also
    rejects UPDATE and DELETE on this table.
    """

    at = models.DateTimeField(default=timezone.now, db_index=True)
    actor = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.PROTECT)
    terminal_code = models.CharField(max_length=40, blank=True)
    action = models.CharField(max_length=80, db_index=True)
    object_type = models.CharField(max_length=60, blank=True)
    object_id = models.CharField(max_length=60, blank=True, db_index=True)
    branch = models.ForeignKey(Branch, null=True, blank=True, on_delete=models.PROTECT)
    data = models.JSONField(default=dict, blank=True)
    prev_hash = models.CharField(max_length=64)
    hash = models.CharField(max_length=64, unique=True)

    class Meta:
        ordering = ["-id"]

    def compute_hash(self):
        payload = json.dumps(
            {
                "actor": self.actor_id,
                "terminal": self.terminal_code,
                "action": self.action,
                "type": self.object_type,
                "id": self.object_id,
                "branch": self.branch_id,
                "data": self.data,
                "prev": self.prev_hash,
                "at": self.at.isoformat(),
            },
            sort_keys=True,
            default=str,
        )
        return hashlib.sha256(payload.encode()).hexdigest()
