from django.db import connection, transaction
from django.utils import timezone

from .models import AuditLog

GENESIS = "0" * 64
_LOCK_KEY = 7_221_001  # advisory lock id serialising audit-chain appends


def record(action, *, actor=None, obj=None, object_type="", object_id="", branch=None, data=None, terminal=None):
    """Append an audit entry inside the caller's transaction."""
    if obj is not None:
        object_type = object_type or obj._meta.label
        object_id = object_id or str(obj.pk)
    with transaction.atomic():
        with connection.cursor() as cur:
            cur.execute("SELECT pg_advisory_xact_lock(%s)", [_LOCK_KEY])
        last = AuditLog.objects.order_by("-id").values_list("hash", flat=True).first()
        entry = AuditLog(
            at=timezone.now(),
            actor=actor if (actor is not None and getattr(actor, "pk", None)) else None,
            terminal_code=getattr(terminal, "code", "") or "",
            action=action,
            object_type=object_type,
            object_id=str(object_id),
            branch=branch,
            data=data or {},
            prev_hash=last or GENESIS,
        )
        entry.hash = entry.compute_hash()
        entry.save()
        return entry


def verify_chain():
    """Return (ok, checked_count, first_bad_id)."""
    prev = GENESIS
    n = 0
    for e in AuditLog.objects.order_by("id").iterator():
        n += 1
        if e.prev_hash != prev or e.compute_hash() != e.hash:
            return False, n, e.id
        prev = e.hash
    return True, n, None
