"""
Database-enforced integrity (cannot be bypassed by application bugs or the ORM):

1. Append-only tables: stock ledger, journal entries/lines, audit log reject UPDATE and DELETE.
2. Every journal entry must balance (sum debit = sum credit) and have >= 2 lines -
   checked by a DEFERRABLE INITIALLY DEFERRED constraint trigger at COMMIT.
"""
from django.db import migrations

APPEND_ONLY = ["inventory_stockmovement", "accounting_journalline", "accounting_journalentry", "core_auditlog"]

SQL = """
CREATE OR REPLACE FUNCTION yummy_reject_mutation() RETURNS trigger AS $$
BEGIN
  RAISE EXCEPTION 'yummy: % on % is not allowed (append-only ledger); post a reversing entry instead',
    TG_OP, TG_TABLE_NAME USING ERRCODE = 'integrity_constraint_violation';
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION yummy_check_journal_balanced() RETURNS trigger AS $$
DECLARE
  d numeric; c numeric; n integer;
BEGIN
  SELECT COALESCE(SUM(debit),0), COALESCE(SUM(credit),0), COUNT(*) INTO d, c, n
    FROM accounting_journalline WHERE entry_id = NEW.entry_id;
  IF d <> c THEN
    RAISE EXCEPTION 'yummy: journal entry % is unbalanced (Dr % / Cr %)', NEW.entry_id, d, c
      USING ERRCODE = 'integrity_constraint_violation';
  END IF;
  IF n < 2 THEN
    RAISE EXCEPTION 'yummy: journal entry % needs at least two lines', NEW.entry_id
      USING ERRCODE = 'integrity_constraint_violation';
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE CONSTRAINT TRIGGER journal_balanced
  AFTER INSERT ON accounting_journalline
  DEFERRABLE INITIALLY DEFERRED
  FOR EACH ROW EXECUTE FUNCTION yummy_check_journal_balanced();
""" + "".join(
    f"""
CREATE TRIGGER {t}_append_only BEFORE UPDATE OR DELETE ON {t}
  FOR EACH ROW EXECUTE FUNCTION yummy_reject_mutation();
"""
    for t in APPEND_ONLY
)

REVERSE = "DROP TRIGGER IF EXISTS journal_balanced ON accounting_journalline;" + "".join(
    f"DROP TRIGGER IF EXISTS {t}_append_only ON {t};" for t in APPEND_ONLY
) + "DROP FUNCTION IF EXISTS yummy_check_journal_balanced(); DROP FUNCTION IF EXISTS yummy_reject_mutation();"


class Migration(migrations.Migration):
    dependencies = [
        ("core", "0002_initial"),
        ("inventory", "0002_initial"),
        ("accounting", "0002_initial"),
    ]
    operations = [migrations.RunSQL(SQL, REVERSE)]
