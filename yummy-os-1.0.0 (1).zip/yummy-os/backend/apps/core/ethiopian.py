"""
Ethiopian (Ge'ez) calendar conversion via Julian Day Numbers.

Ethiopian year has 12 months of 30 days and a 13th month (Pagume) of 5 days,
6 in Ethiopian leap years (year % 4 == 3). Used for receipts and reports; all
storage stays in UTC / Gregorian.
"""
from datetime import date

JD_EPOCH_OFFSET_AMETE_MIHRET = 1723856

MONTHS_EN = [
    "Meskerem", "Tikimt", "Hidar", "Tahsas", "Tir", "Yekatit", "Megabit",
    "Miyazya", "Ginbot", "Sene", "Hamle", "Nehase", "Pagume",
]
MONTHS_AM = ["መስከረም", "ጥቅምት", "ኅዳር", "ታኅሣሥ", "ጥር", "የካቲት", "መጋቢት", "ሚያዝያ", "ግንቦት", "ሰኔ", "ሐምሌ", "ነሐሴ", "ጳጉሜን"]


def _gregorian_to_jdn(d: date) -> int:
    a = (14 - d.month) // 12
    y = d.year + 4800 - a
    m = d.month + 12 * a - 3
    return d.day + (153 * m + 2) // 5 + 365 * y + y // 4 - y // 100 + y // 400 - 32045


def _jdn_to_gregorian(jdn: int) -> date:
    a = jdn + 32044
    b = (4 * a + 3) // 146097
    c = a - 146097 * b // 4
    d = (4 * c + 3) // 1461
    e = c - 1461 * d // 4
    m = (5 * e + 2) // 153
    day = e - (153 * m + 2) // 5 + 1
    month = m + 3 - 12 * (m // 10)
    year = 100 * b + d - 4800 + m // 10
    return date(year, month, day)


def to_ethiopian(d: date) -> tuple[int, int, int]:
    """Gregorian date -> (year, month, day) in the Ethiopian calendar."""
    jdn = _gregorian_to_jdn(d)
    r = (jdn - JD_EPOCH_OFFSET_AMETE_MIHRET) % 1461
    n = r % 365 + 365 * (r // 1460)
    year = 4 * ((jdn - JD_EPOCH_OFFSET_AMETE_MIHRET) // 1461) + r // 365 - r // 1460
    month = n // 30 + 1
    day = n % 30 + 1
    return year, month, day


def from_ethiopian(year: int, month: int, day: int) -> date:
    if not (1 <= month <= 13 and 1 <= day <= 30):
        raise ValueError("invalid Ethiopian date")
    if month == 13 and day > (6 if year % 4 == 3 else 5):
        raise ValueError("Pagume has only 5 days (6 in leap years)")
    jdn = (JD_EPOCH_OFFSET_AMETE_MIHRET + 365) + 365 * (year - 1) + year // 4 + 30 * month + day - 31
    return _jdn_to_gregorian(jdn)


def format_ethiopian(d: date, lang: str = "en") -> str:
    y, m, dd = to_ethiopian(d)
    names = MONTHS_AM if lang == "am" else MONTHS_EN
    return f"{names[m - 1]} {dd}, {y} E.C."
