"""
Exact money and quantity arithmetic.

Money is held as Decimal with 2 places; quantities with 3 places. The POS
pricing algorithm works in integer cents / milli-units so the offline client
(TypeScript) and the server produce bit-identical totals. Both implementations
are tested against the same fixture file: spec/pricing_cases.json.
"""
from decimal import Decimal, ROUND_HALF_UP

CENT = Decimal("0.01")
MILLI = Decimal("0.001")
ZERO = Decimal("0")


def D(value) -> Decimal:
    if isinstance(value, Decimal):
        return value
    if isinstance(value, float):
        raise TypeError("Floats are not accepted for money or quantities; pass str or Decimal.")
    return Decimal(str(value))


def q2(value) -> Decimal:
    return D(value).quantize(CENT, rounding=ROUND_HALF_UP)


def q3(value) -> Decimal:
    return D(value).quantize(MILLI, rounding=ROUND_HALF_UP)


def q4(value) -> Decimal:
    return D(value).quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP)


def div_half_up(numerator: int, denominator: int) -> int:
    """Integer division rounding half away from zero (matches the TS client)."""
    if denominator <= 0:
        raise ValueError("denominator must be positive")
    sign = -1 if numerator < 0 else 1
    n = abs(numerator)
    return sign * ((2 * n + denominator) // (2 * denominator))


def to_cents(amount) -> int:
    return int((q2(amount) * 100).to_integral_value())


def to_milli(qty) -> int:
    return int((q3(qty) * 1000).to_integral_value())


def from_cents(cents: int) -> Decimal:
    return (Decimal(cents) / 100).quantize(CENT)


def rate_bp(rate) -> int:
    """Tax rate (e.g. Decimal('0.15')) as basis points (1500)."""
    return int((D(rate) * 10000).to_integral_value(rounding=ROUND_HALF_UP))


def price_line(unit_price, qty, discount, tax_rate, tax_inclusive: bool) -> dict:
    """
    Canonical POS line pricing. Returns cents integers:
      gross     = unit_price x qty (rounded half-up to the cent)
      discount  = absolute discount on the line (cannot exceed gross)
      net       = gross - discount  (the amount the customer pays for the line
                  when prices are tax-inclusive)
      tax, base = split of the line into VAT and revenue
      total     = amount payable for the line
    """
    price_c = to_cents(unit_price)
    qty_m = to_milli(qty)
    disc_c = to_cents(discount)
    bp = rate_bp(tax_rate)
    if qty_m <= 0:
        raise ValueError("quantity must be positive")
    if price_c < 0 or disc_c < 0:
        raise ValueError("price and discount must not be negative")
    gross = div_half_up(price_c * qty_m, 1000)
    if disc_c > gross:
        raise ValueError("discount exceeds line amount")
    net = gross - disc_c
    if tax_inclusive:
        tax = div_half_up(net * bp, 10000 + bp)
        base = net - tax
        total = net
    else:
        base = net
        tax = div_half_up(base * bp, 10000)
        total = base + tax
    return {"gross": gross, "discount": disc_c, "base": base, "tax": tax, "total": total}
