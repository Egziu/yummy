"""
Run the accounting & inventory invariants against the live database.
Exit code 1 if any invariant fails - suitable for cron / monitoring / post-restore checks.
"""
import sys

from django.core.management.base import BaseCommand
from django.db.models import F, Sum

from apps.accounting.models import JournalEntry
from apps.accounting.services import trial_balance
from apps.core.audit import verify_chain
from apps.inventory.models import StockBalance, StockMovement
from apps.pos.models import Sale, SaleLine
from apps.transfers.models import TransferOrder


def run_checks():
    results = []

    def check(name, ok, detail=""):
        results.append((name, bool(ok), detail))

    tb = trial_balance()
    check("Trial balance: total debits = total credits", tb["balanced"],
          f"Dr {tb['total_debit']} / Cr {tb['total_credit']}")

    unbalanced = [e.number for e in JournalEntry.objects.annotate(d=Sum("lines__debit"), c=Sum("lines__credit"))
                  if e.d != e.c]
    check("Every journal entry balances", not unbalanced, ", ".join(unbalanced[:5]))

    ledger = {(r["product_id"], r["location_id"], r["lot_id"]): r["q"] for r in
              StockMovement.objects.values("product_id", "location_id", "lot_id").annotate(q=Sum("qty"))}
    mismatches = 0
    for b in StockBalance.objects.all():
        if ledger.get((b.product_id, b.location_id, b.lot_id), 0) != b.qty_on_hand:
            mismatches += 1
    proj_keys = set(StockBalance.objects.values_list("product_id", "location_id", "lot_id"))
    missing = [k for k, q in ledger.items() if q and k not in proj_keys]
    check("Stock balances equal the sum of the movement ledger", mismatches == 0 and not missing,
          f"{mismatches} mismatched, {len(missing)} missing")

    neg_reserved = StockBalance.objects.filter(qty_reserved__lt=0).count()
    check("No negative reservations", neg_reserved == 0)

    bad_sales = 0
    for s in Sale.objects.annotate(lt=Sum("lines__total")).only("id", "total"):
        if s.lt != s.total:
            bad_sales += 1
    pay_bad = sum(1 for s in Sale.objects.annotate(pt=Sum("payments__amount")) if s.pt != s.total)
    check("Sale totals equal their lines and payments", bad_sales == 0 and pay_bad == 0,
          f"{bad_sales} line mismatches, {pay_bad} payment mismatches")

    over_refund = SaleLine.objects.filter(qty_refunded__gt=F("qty")).count()
    check("No line refunded beyond the quantity sold", over_refund == 0)

    xfer_bad = []
    for t in TransferOrder.objects.filter(status__in=["RECEIVED", "RECONCILED"]).prefetch_related("lines"):
        for l in t.lines.all():
            moved_out_of_transit = -(StockMovement.objects.filter(doc_type="TR", doc_id=t.number, product=l.product,
                                                                  location__kind="IN_TRANSIT", qty__lt=0)
                                     .aggregate(q=Sum("qty"))["q"] or 0)
            if moved_out_of_transit != l.qty_dispatched:
                xfer_bad.append(t.number)
    check("Every received transfer fully cleared in-transit stock", not xfer_bad, ", ".join(sorted(set(xfer_bad))[:5]))

    ok, n, bad = verify_chain()
    check("Audit log hash chain intact", ok, f"{n} entries checked" + (f", broken at id {bad}" if bad else ""))
    return results


class Command(BaseCommand):
    help = "Verify accounting, inventory, POS and audit invariants."

    def handle(self, *args, **opts):
        results = run_checks()
        failed = 0
        for name, ok, detail in results:
            mark = self.style.SUCCESS("PASS") if ok else self.style.ERROR("FAIL")
            self.stdout.write(f"[{mark}] {name}" + (f"  ({detail})" if detail else ""))
            failed += 0 if ok else 1
        if failed:
            self.stdout.write(self.style.ERROR(f"{failed} invariant(s) failed"))
            sys.exit(1)
        self.stdout.write(self.style.SUCCESS("All invariants hold."))
