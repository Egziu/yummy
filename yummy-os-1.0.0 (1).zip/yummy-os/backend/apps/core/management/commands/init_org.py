"""Initialise a clean organisation: chart of accounts, posting rules, roles, settings. Idempotent."""
from django.core.management.base import BaseCommand
from django.db import transaction

from apps.accounting.services import install_chart
from apps.core.models import Setting
from apps.iam.models import DEFAULT_ROLES, Role


def install_roles():
    for code, (name, perms) in DEFAULT_ROLES.items():
        role, created = Role.objects.get_or_create(code=code, defaults={"name": name, "permissions": perms,
                                                                       "is_system": True})
        if not created and role.is_system:
            role.permissions = perms
            role.name = name
            role.save()


def install_settings():
    for key, (value, desc) in Setting.DEFAULTS.items():
        Setting.objects.get_or_create(key=key, defaults={"value": value, "description": desc})


class Command(BaseCommand):
    help = "Install chart of accounts, posting rules, system roles and default settings (safe to re-run)."

    @transaction.atomic
    def handle(self, *args, **opts):
        install_chart()
        install_roles()
        install_settings()
        self.stdout.write(self.style.SUCCESS("Organisation initialised: accounts, posting rules, roles, settings."))
