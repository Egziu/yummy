"""
Yummy Café & Bakery demonstration environment.

Builds the real organisation (HQ, production, main warehouse, 3 shops, 2 cafés)
and then RUNS THE BUSINESS through the same services the application uses:
purchasing -> receiving -> production -> distribution -> two weeks of POS sales
submitted through the offline sync engine. Every dashboard figure afterwards is
derived from those transactions - nothing is hard-coded.

DEMO ONLY: creates users with a known demo password. Never run against production
(the command refuses when YUMMY_DEBUG is off unless --i-understand-this-is-demo is passed).
"""
import random
import uuid
from datetime import timedelta
from decimal import Decimal

from django.conf import settings
from django.core.management import call_command
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from django.utils import timezone

from apps.catalog.models import Category, Modifier, PriceList, PriceListItem, Product, TaxRate, Unit
from apps.core.models import Branch
from apps.core.money import from_cents, price_line
from apps.iam.models import Role, RoleAssignment, Terminal, User
from apps.inventory.models import Location
from apps.pos.sync import apply_batch
from apps.procurement import services as proc
from apps.procurement.models import Supplier
from apps.production import services as prod
from apps.production.models import Recipe, RecipeLine
from apps.transfers import services as xfer

DEMO_PASSWORD = "Yummy@2026demo"
D = Decimal

BRANCHES = [
    ("HQ", "Yummy Head Office", "HEAD_OFFICE", 450, 60),
    ("PROD", "Central Production", "PRODUCTION", 250, 190),
    ("WH", "Main Warehouse", "WAREHOUSE", 650, 190),
    ("SHOP1", "Yummy Shop 01 - Kebele 14", "SHOP", 110, 360),
    ("SHOP2", "Yummy Shop 02 - Hawelti", "SHOP", 280, 400),
    ("SHOP3", "Yummy Shop 03 - Adi Haki", "SHOP", 450, 400),
    ("CAFE1", "Yummy Café 01 - Romanat", "CAFE", 620, 400),
    ("CAFE2", "Yummy Café 02 - Ayder", "CAFE", 790, 360),
]

# sku, name, local name, kind, category, unit, cost/price, shelf life, extra
RAW = [
    ("RM-FLOUR", "Wheat flour", "ዱቄት", "kg", "85"), ("RM-SUGAR", "Sugar", "ስኳር", "kg", "120"),
    ("RM-EGG", "Eggs", "እንቁላል", "pcs", "12"), ("RM-BUTTER", "Butter", "ቅቤ", "kg", "850"),
    ("RM-MILK", "Fresh milk", "ወተት", "l", "70"), ("RM-YEAST", "Dry yeast", "እርሾ", "kg", "600"),
    ("RM-SALT", "Salt", "ጨው", "kg", "30"), ("RM-COFFEE", "Coffee beans (Tigray roast)", "ቡና", "kg", "900"),
    ("RM-CREAM", "Whipping cream", "ክሬም", "l", "400"), ("RM-COCOA", "Cocoa powder", "ኮኮዋ", "kg", "1200"),
    ("RM-TEA", "Tea leaves", "ሻይ ቅጠል", "kg", "500"),
]
PACK = [("PK-BAG", "Paper bread bag", "pcs", "1.2"), ("PK-BOX", "Cake box", "pcs", "25")]
FINISHED = [  # sku, name, local, unit, price, shelf_days, color, barcode
    ("FG-BREAD-S", "White bread - small", "ዳቦ ትንሽ", "pcs", "20", 2, "#E9B872", "2000000000011"),
    ("FG-BREAD-L", "White bread - large", "ዳቦ ትልቅ", "pcs", "45", 2, "#D9A05B", "2000000000028"),
    ("FG-DABO", "Traditional Dabo", "ሕብስት", "pcs", "110", 3, "#B5793E", "2000000000035"),
    ("FG-CROISSANT", "Butter croissant", "ክሮሳን", "pcs", "60", 2, "#F2C14E", "2000000000042"),
    ("FG-MUFFIN", "Chocolate muffin", "ማፊን", "pcs", "55", 3, "#7B4B2A", "2000000000059"),
    ("FG-COOKIES", "Cookies (pack of 6)", "ኩኪስ", "pcs", "150", 14, "#C98B4B", "2000000000066"),
    ("FG-CAKE", "Chocolate cake (whole)", "ኬክ", "pcs", "1400", 4, "#5C3317", "2000000000073"),
]
MENU = [  # sku, name, local, price, station, color, recipe [(sku, qty)]
    ("MN-ESPRESSO", "Espresso", "ኤስፕሬሶ", "45", "BARISTA", "#3B2416", [("RM-COFFEE", "0.009")]),
    ("MN-MACCHIATO", "Macchiato", "ማኪያቶ", "50", "BARISTA", "#8B5E3C", [("RM-COFFEE", "0.009"), ("RM-MILK", "0.06")]),
    ("MN-CAPPUCCINO", "Cappuccino", "ካፑቺኖ", "70", "BARISTA", "#A47148", [("RM-COFFEE", "0.009"), ("RM-MILK", "0.15")]),
    ("MN-BUNA", "Traditional Buna", "ጀበና ቡና", "35", "BARISTA", "#4A2C1A", [("RM-COFFEE", "0.012"), ("RM-SUGAR", "0.01")]),
    ("MN-TEA", "Spiced tea (Shai)", "ሻይ", "25", "BARISTA", "#B65F2A", [("RM-TEA", "0.003"), ("RM-SUGAR", "0.012")]),
    ("MN-CAKESLICE", "Chocolate cake slice", "ኬክ ቁራጭ", "180", "DESSERT", "#5C3317", [("FG-CAKE", "0.125")]),
]
RECIPES = {  # product sku: (output, labor min, workstation, [(ingredient, qty, phantom)])
    "SF-DOUGH": ("10", "30", "Mixing", [("RM-FLOUR", "6", 0), ("RM-SUGAR", "0.4", 0), ("RM-YEAST", "0.12", 0),
                                       ("RM-SALT", "0.1", 0), ("RM-MILK", "1.0", 0), ("RM-BUTTER", "0.25", 0)]),
    "SF-BATTER": ("5", "30", "Mixing", [("RM-FLOUR", "1.6", 0), ("RM-SUGAR", "1.4", 0), ("RM-EGG", "20", 0),
                                        ("RM-BUTTER", "0.8", 0), ("RM-MILK", "0.8", 0), ("RM-COCOA", "0.3", 0)]),
    "FG-BREAD-S": ("100", "60", "Baking", [("SF-DOUGH", "6", 1), ("PK-BAG", "100", 0)]),
    "FG-BREAD-L": ("50", "50", "Baking", [("SF-DOUGH", "7.5", 1), ("PK-BAG", "50", 0)]),
    "FG-DABO": ("20", "90", "Baking", [("RM-FLOUR", "8", 0), ("RM-SUGAR", "0.5", 0), ("RM-YEAST", "0.15", 0),
                                       ("RM-SALT", "0.1", 0), ("RM-BUTTER", "0.3", 0)]),
    "FG-CROISSANT": ("60", "120", "Pastry", [("RM-FLOUR", "3", 0), ("RM-BUTTER", "1.2", 0), ("RM-SUGAR", "0.3", 0),
                                             ("RM-YEAST", "0.06", 0), ("RM-MILK", "1", 0), ("RM-EGG", "6", 0)]),
    "FG-MUFFIN": ("48", "60", "Pastry", [("RM-FLOUR", "2.4", 0), ("RM-SUGAR", "1.2", 0), ("RM-EGG", "16", 0),
                                         ("RM-BUTTER", "0.5", 0), ("RM-MILK", "1.2", 0), ("RM-COCOA", "0.2", 0)]),
    "FG-COOKIES": ("40", "80", "Pastry", [("RM-FLOUR", "3", 0), ("RM-SUGAR", "1.5", 0), ("RM-BUTTER", "0.9", 0),
                                          ("RM-EGG", "10", 0), ("PK-BAG", "40", 0)]),
    "FG-CAKE": ("4", "120", "Decoration", [("SF-BATTER", "4.8", 1), ("RM-CREAM", "2", 0), ("PK-BOX", "4", 0)]),
}
# Daily demand per outlet (mean units) used to simulate realistic sales
DEMAND = {
    "SHOP": {"FG-BREAD-S": 30, "FG-BREAD-L": 12, "FG-DABO": 4, "FG-CROISSANT": 6, "FG-MUFFIN": 5, "FG-COOKIES": 2,
             "FG-CAKE": 0.4},
    "CAFE": {"FG-BREAD-S": 6, "FG-CROISSANT": 8, "FG-MUFFIN": 6, "FG-COOKIES": 1, "MN-ESPRESSO": 18,
             "MN-MACCHIATO": 40, "MN-CAPPUCCINO": 16, "MN-BUNA": 22, "MN-TEA": 14, "MN-CAKESLICE": 6},
}


class Command(BaseCommand):
    help = "Create the Yummy demo organisation and simulate two weeks of operations."

    def add_arguments(self, parser):
        parser.add_argument("--days", type=int, default=14)
        parser.add_argument("--i-understand-this-is-demo", action="store_true")

    def handle(self, *args, days, **opts):
        if not settings.DEBUG and not opts["i_understand_this_is_demo"]:
            raise CommandError("seed_demo creates demo users with a known password. Refusing on a non-debug "
                               "deployment; pass --i-understand-this-is-demo for a disposable staging copy.")
        if Branch.objects.exists():
            raise CommandError("Database already has branches. seed_demo only runs on an empty database.")
        self.rng = random.Random(2026)
        call_command("init_org", stdout=self.stdout)
        with transaction.atomic():
            self.build_master_data()
        self.stdout.write("Master data created. Running procurement, production and distribution...")
        self.run_supply_chain(days)
        self.stdout.write(f"Simulating {days} days of POS sales through the sync engine...")
        self.simulate_sales(days)
        self.leave_open_work()
        self.report()

    # ------------------------------------------------------------------ master data
    def build_master_data(self):
        self.b = {}
        for code, name, kind, x, y in BRANCHES:
            self.b[code] = Branch.objects.create(code=code, name=name, kind=kind, map_x=x, map_y=y,
                                                 address="Mekelle, Tigray", phone="+251 34 440 0000",
                                                 tin="0000000000")
        L = Location.Kind
        V = Location.Level
        wh = self.b["WH"]

        def loc(code, name, branch, kind=L.STORAGE, level=V.SITE, parent=None, rect=(0, 0, 0, 0), cap=None, **kw):
            return Location.objects.create(code=code, name=name, branch=branch, kind=kind, level=level, parent=parent,
                                           map_x=rect[0], map_y=rect[1], map_w=rect[2], map_h=rect[3],
                                           capacity_units=cap, **kw)

        site = loc("WH", "Main warehouse", wh)
        za = loc("WH-A", "Zone A - Dry store", wh, level=V.ZONE, parent=site, rect=(20, 20, 380, 230))
        zb = loc("WH-B", "Zone B - Cold room", wh, kind=L.COLD, level=V.ZONE, parent=site, rect=(420, 20, 260, 230))
        zc = loc("WH-C", "Zone C - Finished goods", wh, level=V.ZONE, parent=site, rect=(20, 270, 420, 190))
        self.loc = {
            "WH-A-R1": loc("WH-A-R1", "Rack A1 - Flour & grains", wh, level=V.RACK, parent=za, rect=(40, 60, 100, 170), cap=D("2000")),
            "WH-A-R2": loc("WH-A-R2", "Rack A2 - Sugar, salt, cocoa", wh, level=V.RACK, parent=za, rect=(160, 60, 100, 170), cap=D("1200")),
            "WH-A-R3": loc("WH-A-R3", "Rack A3 - Packaging & tea", wh, level=V.RACK, parent=za, rect=(280, 60, 100, 170), cap=D("12000")),
            "WH-B-F1": loc("WH-B-F1", "Cold shelf B1 - Dairy", wh, kind=L.COLD, level=V.SHELF, parent=zb, rect=(440, 60, 100, 170), cap=D("600")),
            "WH-B-F2": loc("WH-B-F2", "Cold shelf B2 - Eggs & coffee", wh, kind=L.COLD, level=V.SHELF, parent=zb, rect=(560, 60, 100, 170), cap=D("3000")),
            "WH-C-R1": loc("WH-C-R1", "FG rack C1 - Breads", wh, level=V.RACK, parent=zc, rect=(40, 300, 180, 140), cap=D("6000")),
            "WH-C-R2": loc("WH-C-R2", "FG rack C2 - Pastry & cakes", wh, level=V.RACK, parent=zc, rect=(240, 300, 180, 140), cap=D("3000")),
            "WH-RCV": loc("WH-RCV", "Receiving dock", wh, kind=L.RECEIVING, level=V.ZONE, parent=site, rect=(460, 270, 100, 90), is_default_receiving=True),
            "WH-DSP": loc("WH-DSP", "Dispatch bay", wh, kind=L.DISPATCH, level=V.ZONE, parent=site, rect=(580, 270, 100, 90)),
            "WH-QC": loc("WH-QC", "Quarantine cage", wh, kind=L.QUARANTINE, level=V.ZONE, parent=site, rect=(460, 380, 220, 80)),
            "PROD-FLOOR": loc("PROD-FLOOR", "Production floor & ingredient store", self.b["PROD"], kind=L.PRODUCTION),
            "PROD-QC": loc("PROD-QC", "Production QC hold", self.b["PROD"], kind=L.QUARANTINE),
        }
        for code in ("SHOP1", "SHOP2", "SHOP3", "CAFE1", "CAFE2"):
            self.loc[f"{code}-FLOOR"] = loc(f"{code}-FLOOR", f"{self.b[code].name} counter", self.b[code],
                                            kind=L.SALES, is_sellable=True)

        units = {c: Unit.objects.create(code=c, name=n) for c, n in [("kg", "Kilogram"), ("l", "Litre"), ("pcs", "Piece")]}
        vat = TaxRate.objects.create(code="VAT15", name="VAT", rate=D("0.15"))
        cats = {n: Category.objects.create(name=n, sort_order=i, color=c) for i, (n, c) in enumerate(
            [("Breads", "#D9A05B"), ("Pastry", "#F2C14E"), ("Cakes", "#5C3317"), ("Coffee", "#4A2C1A"),
             ("Tea & others", "#B65F2A"), ("Ingredients", "#7A8B6F"), ("Packaging", "#8C8C8C"),
             ("Semi-finished", "#A0A0A0")])}
        P = Product.Kind
        self.p = {}
        for sku, name, local, unit, cost in RAW:
            self.p[sku] = Product.objects.create(sku=sku, name=name, name_local=local, kind=P.RAW, unit=units[unit],
                                                 category=cats["Ingredients"], standard_cost=D(cost),
                                                 reorder_point=D("20") if unit != "pcs" else D("300"),
                                                 reorder_qty=D("100"), shelf_life_days=None)
        for sku, name, unit, cost in PACK:
            self.p[sku] = Product.objects.create(sku=sku, name=name, kind=P.PACKAGING, unit=units[unit],
                                                 category=cats["Packaging"], standard_cost=D(cost), track_lots=False,
                                                 reorder_point=D("500"))
        for sku, name in (("SF-DOUGH", "Bread dough base"), ("SF-BATTER", "Chocolate cake batter")):
            self.p[sku] = Product.objects.create(sku=sku, name=name, kind=P.SEMI, unit=units["kg"],
                                                 category=cats["Semi-finished"], track_lots=False)
        price_default = PriceList.objects.create(code="DEFAULT", name="Standard prices (VAT incl.)", tax_inclusive=True)
        cafe_lists = [PriceList.objects.create(code=f"{c}-MENU", name=f"{c} café menu", branch=self.b[c],
                                               tax_inclusive=True) for c in ("CAFE1", "CAFE2")]
        start = timezone.now() - timedelta(days=60)
        for sku, name, local, unit, price, shelf, color, barcode in FINISHED:
            cat = cats["Cakes"] if "CAKE" in sku else cats["Breads"] if ("BREAD" in sku or "DABO" in sku) else cats["Pastry"]
            p = Product.objects.create(sku=sku, name=name, name_local=local, kind=P.FINISHED, unit=units[unit],
                                       category=cat, tax_rate=vat, is_sellable=True, shelf_life_days=shelf,
                                       color=color, barcode=barcode, reorder_point=D("20"),
                                       allergens="gluten,milk" + (",egg" if sku in ("FG-CROISSANT", "FG-MUFFIN", "FG-COOKIES", "FG-CAKE") else ""))
            self.p[sku] = p
            PriceListItem.objects.create(price_list=price_default, product=p, price=D(price), effective_from=start)
        for sku, name, local, price, station, color, _ in MENU:
            p = Product.objects.create(sku=sku, name=name, name_local=local, kind=P.MENU, unit=units["pcs"],
                                       category=cats["Cakes"] if "CAKE" in sku else cats["Tea & others"] if "TEA" in sku else cats["Coffee"],
                                       tax_rate=vat, is_sellable=True, station=station, color=color, track_lots=False,
                                       allergens="milk" if sku in ("MN-MACCHIATO", "MN-CAPPUCCINO") else "")
            self.p[sku] = p
            for pl in cafe_lists:
                PriceListItem.objects.create(price_list=pl, product=p, price=D(price), effective_from=start)
        shot = Modifier.objects.create(name="Extra shot", group="Coffee", price_delta=D("15"),
                                       ingredient=self.p["RM-COFFEE"], ingredient_qty=D("0.009"))
        milk = Modifier.objects.create(name="Extra milk", group="Coffee", price_delta=D("10"),
                                       ingredient=self.p["RM-MILK"], ingredient_qty=D("0.08"))
        nosugar = Modifier.objects.create(name="No sugar", group="Preferences", price_delta=D("0"))
        for sku in ("MN-ESPRESSO", "MN-MACCHIATO", "MN-CAPPUCCINO"):
            shot.applies_to.add(self.p[sku])
            milk.applies_to.add(self.p[sku])
        for sku in ("MN-BUNA", "MN-TEA", "MN-MACCHIATO"):
            nosugar.applies_to.add(self.p[sku])

        # ---- people
        roles = {r.code: r for r in Role.objects.all()}

        def person(username, name, role_codes, branch=None, pin=None, superuser=False):
            u = User.objects.create(username=username, display_name=name, is_superuser=superuser, is_staff=superuser)
            u.set_password(DEMO_PASSWORD)
            if pin:
                u.set_pin(pin)
            u.save()
            for rc in role_codes:
                RoleAssignment.objects.create(user=u, role=roles[rc], branch=self.b[branch] if branch else None)
            return u

        self.u = {
            "admin": person("admin", "System Administrator", ["SUPER_ADMIN"], superuser=True),
            "ceo": person("ceo", "Egziu (CEO)", ["CEO"]),
            "finance": person("finance", "Hiwet G. (Finance Mgr)", ["FINANCE_MANAGER"]),
            "accountant": person("accountant", "Selam T. (Accountant)", ["ACCOUNTANT"]),
            "auditor": person("auditor", "Internal Auditor", ["AUDITOR"]),
            "buyer": person("buyer", "Dawit K. (Procurement)", ["PROCUREMENT_OFFICER"], "WH"),
            "procmgr": person("procmgr", "Mulu A. (Procurement Mgr)", ["PROCUREMENT_MANAGER"]),
            "whmgr": person("whmgr", "Berhe H. (Warehouse Mgr)", ["WAREHOUSE_MANAGER"], "WH"),
            "whclerk": person("whclerk", "Kiros M. (Storekeeper)", ["WAREHOUSE_OFFICER"], "WH"),
            "prodmgr": person("prodmgr", "Tsega W. (Production Mgr)", ["PRODUCTION_MANAGER"], "PROD"),
            "chef": person("chef", "Head Baker Abraha", ["PRODUCTION_MANAGER"], "PROD"),
            "baker": person("baker", "Baker Gebre", ["BAKER"], "PROD", pin="2468"),
            "qa": person("qa", "Quality Officer Rahel", ["QUALITY_OFFICER"]),
        }
        RoleAssignment.objects.create(user=self.u["prodmgr"], role=roles["PRODUCTION_MANAGER"], branch=self.b["WH"])
        RoleAssignment.objects.create(user=self.u["chef"], role=roles["PRODUCTION_MANAGER"], branch=self.b["WH"])
        self.term = {}
        for i, code in enumerate(("SHOP1", "SHOP2", "SHOP3", "CAFE1", "CAFE2"), start=1):
            self.u[f"{code}-mgr"] = person(f"{code.lower()}.manager", f"{self.b[code].name.split(' - ')[0]} Manager",
                                           ["BRANCH_MANAGER"], code, pin=f"{i}{i}{i}{i}")
            self.u[f"{code}-cash"] = person(f"{code.lower()}.cashier", f"Cashier {code.title()}", ["CASHIER"], code,
                                            pin=f"{i}0{i}0")
            if code.startswith("CAFE"):
                person(f"{code.lower()}.barista", f"Barista {code.title()}", ["BARISTA"], code, pin=f"{i}{i}00")
            kind = Terminal.Kind.CAFE if code.startswith("CAFE") else Terminal.Kind.RETAIL
            self.term[code] = Terminal.objects.create(code=f"{code}-T1", name=f"{code} counter 1", branch=self.b[code],
                                                      kind=kind)
        Terminal.objects.create(code="CAFE1-KDS", name="Café 01 barista screen", branch=self.b["CAFE1"],
                                kind=Terminal.Kind.KDS)
        self.sup = {
            "MILL": Supplier.objects.create(code="SUP-MILL", name="Mekelle Flour Mill PLC", tin="0012345678", lead_time_days=2),
            "DAIRY": Supplier.objects.create(code="SUP-DAIRY", name="Enda Selassie Dairy Union", lead_time_days=1),
            "GEN": Supplier.objects.create(code="SUP-GEN", name="Tigray General Trading", lead_time_days=4),
            "COFFEE": Supplier.objects.create(code="SUP-COFFEE", name="Raya Coffee Roasters", lead_time_days=3),
        }

    # ------------------------------------------------------------------ operations
    def approve_recipes(self):
        u, p = self.u, self.p
        # authored by the production manager, approved by the head baker (segregation of duties)
        for sku, (out, labor, ws, lines) in list(RECIPES.items()) + [
            (m[0], ("1", "0", "Bar", [(s, q, 0) for s, q in m[6]])) for m in MENU
        ]:
            r = Recipe.objects.create(product=p[sku], output_qty=D(out), labor_minutes=D(labor), workstation=ws,
                                      created_by=u["prodmgr"])
            for ing, qty, phantom in lines:
                is_raw = p[ing].kind == Product.Kind.RAW and sku in RECIPES
                RecipeLine.objects.create(recipe=r, ingredient=p[ing], qty=D(qty), explode=bool(phantom),
                                          waste_pct=D("2") if is_raw else D("0"))
        order = ["SF-DOUGH", "SF-BATTER"] + [s for s in RECIPES if not s.startswith("SF-")] + [m[0] for m in MENU]
        for sku in order:
            prod.approve_recipe(u["chef"], Recipe.objects.get(product=p[sku]).pk)

    def plan_sales(self, days):
        """Generate the sales calendar first so stock can be sized to it (deterministic)."""
        now = timezone.localtime()
        self.plan = {}
        self.need = {}  # (branch_code, sku) -> qty
        for code in ("SHOP1", "SHOP2", "SHOP3", "CAFE1", "CAFE2"):
            demand = DEMAND[self.b[code].kind]
            scale = {"SHOP1": 1.15, "SHOP2": 0.85, "SHOP3": 1.0, "CAFE1": 1.2, "CAFE2": 0.9}[code]
            day_plans = []
            for d in range(days - 1, -1, -1):
                day = (now - timedelta(days=d)).replace(hour=7, minute=0, second=0, microsecond=0)
                weekend = day.weekday() >= 5
                last_hour = max(now.hour, 8) if d == 0 else 20
                target_units = sum(demand.values()) * scale * (1.15 if weekend else 1) * self.rng.uniform(0.85, 1.15)
                baskets, units = [], 0
                while units < target_units:
                    minute = int(self.rng.triangular(0, (last_hour - 7) * 60, 90 if self.rng.random() < 0.5 else 600))
                    at = day + timedelta(minutes=minute)
                    if d == 0 and at > now:
                        units += 1
                        continue
                    items = {}
                    for _k in range(self.rng.choice([1, 1, 1, 2, 2, 3])):
                        sku = self.rng.choices(list(demand), weights=list(demand.values()))[0]
                        q = 1 if self.rng.random() < 0.75 else 2
                        items[sku] = items.get(sku, 0) + q
                        units += q
                    baskets.append((at, items))
                    for sku, q in items.items():
                        self.need[(code, sku)] = self.need.get((code, sku), 0) + q
                baskets.sort(key=lambda b: b[0])
                day_plans.append((d, day, last_hour, baskets))
            self.plan[code] = day_plans

    def run_supply_chain(self, days=14):
        u, p, L = self.u, self.p, self.loc
        today = timezone.localdate()
        self.approve_recipes()
        self.plan_sales(days)

        # finished goods needed per outlet (+6% buffer), menu items exploded into ingredients
        fg_need, cafe_ing = {}, {}
        for (code, sku), q in self.need.items():
            prod_ = p[sku]
            if prod_.kind == Product.Kind.MENU:
                req, _ = prod.explode(prod.active_recipe(prod_), D(q))
                for ing, iq in req.items():
                    if ing.kind == Product.Kind.FINISHED:
                        fg_need[(code, ing.sku)] = fg_need.get((code, ing.sku), D(0)) + iq
                    else:
                        cafe_ing[(code, ing.sku)] = cafe_ing.get((code, ing.sku), D(0)) + iq
            else:
                fg_need[(code, sku)] = fg_need.get((code, sku), D(0)) + D(q)
        # extra-shot / extra-milk modifiers and a little buffer for cafés
        for code in ("CAFE1", "CAFE2"):
            cafe_ing[(code, "RM-COFFEE")] = cafe_ing.get((code, "RM-COFFEE"), D(0)) * D("1.25")
            cafe_ing[(code, "RM-MILK")] = cafe_ing.get((code, "RM-MILK"), D(0)) * D("1.15")
        # what was sold + 6% + about two days of fresh stock left on the shelf at the end of the simulation
        self.fg_send = {k: (v * D("1.06") + v / days * 2).to_integral_value(rounding="ROUND_CEILING")
                        for k, v in fg_need.items()}
        totals = {}
        for (code, sku), q in self.fg_send.items():
            totals[sku] = totals.get(sku, D(0)) + q
        batches = {}
        for sku, q in totals.items():
            r = prod.active_recipe(p[sku])
            batches[sku] = int((q * D("1.05") / r.output_qty).to_integral_value(rounding="ROUND_CEILING"))
        raw_prod = {}
        for sku, n in batches.items():
            r = prod.active_recipe(p[sku])
            req, _ = prod.explode(r, D(n))
            for ing, q in req.items():
                raw_prod[ing.sku] = raw_prod.get(ing.sku, D(0)) + q
        raw_total = dict(raw_prod)
        for (code, sku), q in cafe_ing.items():
            raw_total[sku] = raw_total.get(sku, D(0)) + q

        # purchasing: buyer raises, procurement manager approves, storekeeper receives, accountant invoices,
        # finance pays (half the invoices remain open as payables).
        cost = dict((r[0], r[4]) for r in RAW)
        cost.update({s: c for s, _n, _u, c in PACK})
        supplier_of = {"RM-FLOUR": "MILL", "RM-MILK": "DAIRY", "RM-BUTTER": "DAIRY", "RM-CREAM": "DAIRY",
                       "RM-EGG": "DAIRY", "RM-COFFEE": "COFFEE"}
        shelf_of = {"WH-A-R1": "RM-FLOUR", "WH-B-F1": "RM-MILK RM-BUTTER RM-CREAM", "WH-B-F2": "RM-EGG RM-COFFEE",
                    "WH-A-R3": "PK-BAG PK-BOX RM-TEA"}

        def shelf(sku):
            for code, skus in shelf_of.items():
                if sku in skus.split():
                    return code
            return "WH-A-R2"

        groups = {}
        for sku, q in raw_total.items():
            qty = (q * D("1.15")).to_integral_value(rounding="ROUND_CEILING") + 5
            groups.setdefault((supplier_of.get(sku, "GEN"), shelf(sku)), []).append(
                (sku, qty, (D(cost[sku]) * D(str(self.rng.choice(["0.97", "0.98", "1", "1.01"])))).quantize(D("0.01"))))
        for n, ((sup, loc_code), lines) in enumerate(sorted(groups.items())):
            po = proc.create_po(u["buyer"], self.sup[sup], L[loc_code],
                                [{"product": p[s], "qty": q, "unit_cost": c} for s, q, c in lines])
            proc.approve_po(u["procmgr"], po.pk)
            receipt_lines = []
            for pol in po.lines.all():
                life = {"RM-MILK": 6, "RM-CREAM": 8, "RM-EGG": 20, "RM-BUTTER": 45}.get(pol.product.sku, 180)
                receipt_lines.append({"order_line": pol.pk, "qty_accepted": pol.qty, "qty_rejected": 0,
                                      "lot_code": f"{self.sup[sup].code[-4:]}-{today:%y%m%d}-{n}{pol.pk}",
                                      "expiry_date": today + timedelta(days=life)})
            proc.receive_goods(u["whclerk"], po.pk, receipt_lines)
            sub = sum((l.qty * l.unit_cost for l in po.lines.all()), D(0)).quantize(D("0.01"))
            inv_doc = proc.record_invoice(u["accountant"], po.pk, f"INV-{1000 + n}", today,
                                          [{"order_line": l.pk, "qty": l.qty, "unit_cost": l.unit_cost}
                                           for l in po.lines.all()], tax=(sub * D("0.15")).quantize(D("0.01")))
            if n % 2 == 0:
                proc.pay_invoice(u["finance"], inv_doc.pk, inv_doc.total, "BANK_TRANSFER", f"CBE-TRF-{4400 + n}")

        def move(src, dst, lines, requester, note="", driver="Yohannes"):
            if not lines:
                return
            t = xfer.request_transfer(requester, L[src], L[dst], [{"product": p[s], "qty": q} for s, q in lines],
                                      note=note)
            xfer.approve_transfer(u["whmgr"], t.pk)
            xfer.dispatch_transfer(u["whclerk"], t.pk, driver=driver, vehicle="3-AA-41237")
            return t

        # stage ingredients to the production floor
        by_shelf = {}
        for sku, q in raw_prod.items():
            by_shelf.setdefault(shelf(sku), []).append((sku, (q * D("1.03")).to_integral_value(rounding="ROUND_CEILING")))
        for src, lines in sorted(by_shelf.items()):
            t = move(src, "PROD-FLOOR", lines, u["prodmgr"], "Ingredient staging", "Internal")
            xfer.receive_transfer(u["prodmgr"], t.pk)
        # café ingredients (coffee, milk, sugar, tea) to the café counters
        for code in ("CAFE1", "CAFE2"):
            by_shelf = {}
            for (c, sku), q in cafe_ing.items():
                if c == code:
                    by_shelf.setdefault(shelf(sku), []).append((sku, (q * D("1.05")).quantize(D("0.001"))))
            for src, lines in sorted(by_shelf.items()):
                t = move(src, f"{code}-FLOOR", lines, self.u[f"{code}-mgr"], "Café ingredients")
                xfer.receive_transfer(self.u[f"{code}-mgr"], t.pk)

        # production runs
        for sku, n in batches.items():
            r = prod.active_recipe(p[sku])
            dest = L["WH-C-R1"] if ("BREAD" in sku or "DABO" in sku) else L["WH-C-R2"]
            for i in range(n):
                o = prod.create_order(u["prodmgr"], p[sku], r.output_qty, today, L["PROD-FLOOR"], dest)
                prod.approve_order(u["chef"], o.pk)
                prod.release_order(u["baker"], o.pk)
                yield_factor = D(self.rng.choice(["1", "1", "1", "0.98", "0.99"]))
                actual = (r.output_qty * yield_factor).to_integral_value()
                prod.complete_order(u["baker"], o.pk, actual, r.output_qty - actual, qc_passed=True)

        # distribution to outlets
        for code in ("SHOP1", "SHOP2", "SHOP3", "CAFE1", "CAFE2"):
            bread, other = [], []
            for (c, sku), q in sorted(self.fg_send.items()):
                if c != code:
                    continue
                (bread if sku in ("FG-BREAD-S", "FG-BREAD-L", "FG-DABO") else other).append((sku, q))
            for lines, src in ((bread, "WH-C-R1"), (other, "WH-C-R2")):
                t = move(src, f"{code}-FLOOR", lines, self.u[f"{code}-mgr"], "Replenishment")
                if t is None:
                    continue
                if code == "SHOP2" and src == "WH-C-R1":
                    # one realistic exception: 4 loaves crushed in the van, 2 missing
                    line = t.lines.get(product=p["FG-BREAD-S"])
                    xfer.receive_transfer(self.u[f"{code}-mgr"], t.pk, [
                        {"line": line.pk, "qty_received": line.qty_dispatched - 6, "qty_damaged": 4,
                         "note": "4 crushed in transit, 2 short"}])
                else:
                    xfer.receive_transfer(self.u[f"{code}-mgr"], t.pk)

    def simulate_sales(self, days):
        from apps.pos.models import Shift
        from apps.pos.sync import expected_cash

        for code in ("SHOP1", "SHOP2", "SHOP3", "CAFE1", "CAFE2"):
            term = self.term[code]
            cashier, manager = self.u[f"{code}-cash"], self.u[f"{code}-mgr"]
            seq = 0
            for d, day, last_hour, baskets in self.plan[code]:
                shift_id = str(uuid.uuid4())
                ops = [self._op("shift_open", day, {"shift_id": shift_id, "cashier_id": cashier.pk,
                                                     "opening_float": "500.00", "opened_at": day.isoformat()})]
                for at, items in baskets:
                    seq += 1
                    ops.append(self._sale_op(term, shift_id, cashier, manager, at, items, seq, code))
                for i in range(0, len(ops), 150):
                    res = apply_batch(term, ops[i:i + 150])
                    bad = [r for r in res if r["status"] != "APPLIED"]
                    if bad:
                        raise CommandError(f"Simulation op failed: {bad[:2]}")
                if d == 0:
                    continue  # today's shift is still open
                close_at = day.replace(hour=21, minute=30)
                exp = expected_cash(Shift.objects.get(pk=shift_id))
                diff = D(self.rng.choice(["0", "0", "0", "0", "0", "-20", "10", "-5"]))
                apply_batch(term, [self._op("shift_close", close_at, {
                    "shift_id": shift_id, "counted_cash": str(exp + diff), "closed_at": close_at.isoformat(),
                    "closed_by_id": cashier.pk, "approver_id": manager.pk if diff else None})])
            Terminal.objects.filter(pk=term.pk).update(last_seen_at=timezone.now(), last_sync_at=timezone.now(),
                                                       app_version="1.0.0")

    def _op(self, kind, at, payload):
        return {"op_id": str(uuid.uuid4()), "kind": kind, "created_at": at.isoformat(), "payload": payload}

    def _sale_op(self, term, shift_id, cashier, manager, at, items, seq, code):
        p = self.p
        lines, total_c = [], 0
        for i, (sku, qty) in enumerate(items.items(), start=1):
            prod_ = p[sku]
            from apps.catalog.services import resolve_price

            price, _incl = resolve_price(prod_, term.branch, at)
            mods = []
            if prod_.sku in ("MN-MACCHIATO", "MN-CAPPUCCINO") and self.rng.random() < 0.15:
                m = Modifier.objects.get(name="Extra shot")
                mods = [{"id": m.pk, "name": m.name, "price_delta": str(m.price_delta)}]
                price += m.price_delta
            discount = D("0")
            if self.rng.random() < 0.04:
                discount = (price * qty * D("0.05")).quantize(D("0.01"))
            calc = price_line(price, D(qty), discount, prod_.tax_rate.rate, True)
            total_c += calc["total"]
            lines.append({"line_no": i, "product_id": prod_.pk, "qty": str(qty), "unit_price": str(price),
                          "discount": str(discount), "tax_rate": str(prod_.tax_rate.rate),
                          "total": str(from_cents(calc["total"])), "modifiers": mods})
        total = from_cents(total_c)
        method = self.rng.choices(["CASH", "TELEBIRR", "CBE_BIRR", "BANK_TRANSFER"], weights=[70, 18, 9, 3])[0]
        pay = {"method": method, "amount": str(total), "reference": "" if method == "CASH" else f"TX{self.rng.randint(10**7, 10**8)}"}
        if method == "CASH":
            pay["tendered"] = str(((total // 50) + 1) * 50)
        is_cafe = code.startswith("CAFE")
        return self._op("sale", at, {
            "id": str(uuid.uuid4()), "number": f"{term.code}-{seq:06d}", "shift_id": shift_id, "cashier_id": cashier.pk,
            "created_at": at.isoformat(), "order_type": self.rng.choice(["DINE_IN", "TAKEAWAY"]) if is_cafe else "RETAIL",
            "table_label": f"T{self.rng.randint(1, 12)}" if is_cafe else "", "tax_inclusive": True,
            "lines": lines, "payments": [pay], "totals": {"total": str(total)}, "was_offline": self.rng.random() < 0.08,
        })

    def leave_open_work(self):
        """Realistic pending items so dashboards show approvals, expiries and exceptions."""
        u, p, L = self.u, self.p, self.loc
        today = timezone.localdate()
        po = proc.create_po(u["buyer"], self.sup["MILL"], L["WH-A-R1"],
                            [{"product": p["RM-FLOUR"], "qty": D("800"), "unit_cost": D("84")}])
        po2 = proc.create_po(u["buyer"], self.sup["DAIRY"], L["WH-B-F1"],
                             [{"product": p["RM-MILK"], "qty": D("120"), "unit_cost": D("70")}])
        proc.approve_po(u["procmgr"], po2.pk)
        pol = po2.lines.first()
        proc.receive_goods(u["whclerk"], po2.pk, [{"order_line": pol.pk, "qty_accepted": D("120"),
                                                   "lot_code": f"DAIRY-{today:%y%m%d}-X",
                                                   "expiry_date": today + timedelta(days=1)}])
        proc.record_invoice(u["accountant"], po2.pk, "INV-2001", today,
                            [{"order_line": pol.pk, "qty": D("120"), "unit_cost": D("78")}], tax=D("1404"))
        xfer.request_transfer(self.u["SHOP1-mgr"], L["WH-C-R1"], L["SHOP1-FLOOR"],
                              [{"product": p["FG-BREAD-S"], "qty": D("120")}, {"product": p["FG-DABO"], "qty": D("10")}],
                              note="Weekend top-up")
        t = xfer.request_transfer(self.u["CAFE1-mgr"], L["WH-C-R2"], L["CAFE1-FLOOR"],
                                  [{"product": p["FG-CROISSANT"], "qty": D("30")}])
        xfer.approve_transfer(u["whmgr"], t.pk)
        xfer.dispatch_transfer(u["whclerk"], t.pk, driver="Yohannes", vehicle="3-AA-41237")
        prod.create_order(u["prodmgr"], p["FG-BREAD-S"], D("200"), today + timedelta(days=1), L["PROD-FLOOR"],
                          L["WH-C-R1"])
        _ = po

    def report(self):
        from apps.core.management.commands.verify_integrity import run_checks

        self.stdout.write(self.style.SUCCESS("\nDemo organisation ready."))
        self.stdout.write(f"Back-office users (password: {DEMO_PASSWORD}): admin, ceo, finance, accountant, auditor, "
                          "buyer, procmgr, whmgr, whclerk, prodmgr, chef, qa, shop1.manager ... cafe2.manager")
        self.stdout.write("POS PINs: SHOP1 manager 1111 / cashier 1010, SHOP2 2222 / 2020, SHOP3 3333 / 3030, "
                          "CAFE1 4444 / 4040, CAFE2 5555 / 5050")
        self.stdout.write("Terminal enrollment codes (valid 24h):")
        for t in Terminal.objects.all():
            self.stdout.write(f"  {t.code:<10} {t.new_enrollment_code(minutes=24 * 60)}")
        for name, ok, detail in run_checks():
            self.stdout.write(f"  [{'PASS' if ok else 'FAIL'}] {name} {detail}")
