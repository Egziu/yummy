#!/bin/sh
# Runs inside the `backup` container: a base backup on start, then every night at 01:30 (Addis Ababa).
set -u
export TZ=Africa/Addis_Ababa
sh /scripts/backup.sh || echo "BACKUP FAILED $(date)" >> /backups/backup-history.log
while true; do
  now=$(date +%H%M)
  if [ "$now" = "0130" ]; then
    sh /scripts/backup.sh || echo "BACKUP FAILED $(date)" >> /backups/backup-history.log
    sleep 61
  fi
  sleep 30
done
