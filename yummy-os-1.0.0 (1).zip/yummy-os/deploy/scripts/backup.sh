#!/bin/sh
# One backup cycle: physical base backup (for point-in-time recovery with the WAL archive)
# + logical dump (portable second layer), optional encryption, verification, retention.
set -eu
STAMP=$(date -u +%Y%m%dT%H%M%SZ)
DEST=/backups
mkdir -p "$DEST/base" "$DEST/logical"

echo "[$STAMP] base backup"
pg_basebackup -D "$DEST/base/$STAMP" -Ft -z -X none -c fast --label="yummy-$STAMP"
echo "[$STAMP] logical dump"
pg_dump -Fc -f "$DEST/logical/yummy-$STAMP.dump"

# verification: archive lists must be readable, otherwise the backup is useless
pg_restore --list "$DEST/logical/yummy-$STAMP.dump" > /dev/null
tar -tzf "$DEST/base/$STAMP/base.tar.gz" > /dev/null

if [ -n "${BACKUP_PASSPHRASE:-}" ]; then
  for f in "$DEST/logical/yummy-$STAMP.dump" "$DEST/base/$STAMP/base.tar.gz"; do
    gpg --batch --yes --pinentry-mode loopback --passphrase "$BACKUP_PASSPHRASE" --symmetric --cipher-algo AES256 -o "$f.gpg" "$f"
    rm -f "$f"
  done
fi

echo "$STAMP ok $(du -sh "$DEST/base/$STAMP" | cut -f1)" >> "$DEST/backup-history.log"
# retention (WAL older than the oldest kept base backup is no longer needed)
find "$DEST/base" -mindepth 1 -maxdepth 1 -type d -mtime "+${BACKUP_RETENTION_DAYS:-14}" -exec rm -rf {} +
find "$DEST/logical" -type f -mtime "+${BACKUP_RETENTION_DAYS:-14}" -delete
find /wal-archive -type f -mtime "+$(( ${BACKUP_RETENTION_DAYS:-14} + 1 ))" -delete
echo "[$STAMP] done"
