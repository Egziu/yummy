#!/bin/bash
# Disaster-recovery rehearsal on a throw-away local PostgreSQL 16 cluster (Debian/Ubuntu layout).
# Measures real RPO/RTO for: base backup + WAL archive -> catastrophic loss -> point-in-time restore.
#
#   sudo deploy/scripts/pitr_drill.sh /path/to/seeded.dump
#
# Never touches the production cluster: everything lives under $WORK on ports 5433/5434.
set -euo pipefail
DUMP="${1:?usage: pitr_drill.sh seeded.dump}"
BIN=/usr/lib/postgresql/16/bin
WORK=${WORK:-/tmp/yummy-pitr-drill}
REPO="$(cd "$(dirname "$0")/../.." && pwd)"
as_pg() { su postgres -c "$*"; }
log() { echo "[$(date +%H:%M:%S)] $*"; }

rm -rf "$WORK"; mkdir -p "$WORK"/{wal,base}; chown -R postgres "$WORK"; chmod 700 "$WORK"
cp "$DUMP" "$WORK/seed.dump"; chown postgres "$WORK/seed.dump"

log "1. primary cluster with WAL archiving"
as_pg "$BIN/initdb -D $WORK/primary -U postgres --auth=trust >/dev/null"
cat >> "$WORK/primary/postgresql.conf" <<CONF
port = 5433
wal_level = replica
archive_mode = on
archive_command = 'test ! -f $WORK/wal/%f && cp %p $WORK/wal/%f'
unix_socket_directories = '$WORK'
CONF
as_pg "$BIN/pg_ctl -D $WORK/primary -l $WORK/primary.log -w start >/dev/null"
as_pg "psql -h $WORK -p 5433 -qc \"CREATE ROLE yummy LOGIN PASSWORD 'yummy'\" -c 'CREATE DATABASE yummy OWNER yummy'"
as_pg "pg_restore -h $WORK -p 5433 -d yummy --no-owner --role=yummy $WORK/seed.dump"

log "2. base backup"
as_pg "$BIN/pg_basebackup -h $WORK -p 5433 -D $WORK/base/b1 -Ft -z -X none -c fast" 2>&1 | grep -v "^$" || true

log "3. business continues after the backup: 3 new POS sales arrive via the sync engine"
cd "$REPO/backend"
export YUMMY_DEBUG=1 DATABASE_URL="postgres://yummy:yummy@localhost:5433/yummy"
python3 - <<'PY'
import os, sys, uuid
sys.path.insert(0, ".")
import django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "yummy.settings")
django.setup()
from decimal import Decimal
from django.utils import timezone
from apps.catalog.models import Product
from apps.core.money import from_cents, price_line
from apps.iam.models import Terminal, User
from apps.pos.models import Sale
from apps.pos.sync import apply_batch
t = Terminal.objects.get(code="SHOP3-T1")
cashier = User.objects.get(username="shop3.cashier")
bread = Product.objects.get(sku="FG-BREAD-S")
sid = str(uuid.uuid4())
ops = [{"op_id": str(uuid.uuid4()), "kind": "shift_open", "created_at": timezone.now().isoformat(),
        "payload": {"shift_id": sid, "cashier_id": cashier.pk, "opening_float": "0", "opened_at": timezone.now().isoformat()}}]
for i in range(3):
    c = price_line(Decimal("20"), Decimal("2"), Decimal("0"), bread.tax_rate.rate, True)
    tot = str(from_cents(c["total"]))
    ops.append({"op_id": str(uuid.uuid4()), "kind": "sale", "created_at": timezone.now().isoformat(), "payload": {
        "id": str(uuid.uuid4()), "number": f"DRILL-{i}-{uuid.uuid4().hex[:6]}", "shift_id": sid, "cashier_id": cashier.pk,
        "created_at": timezone.now().isoformat(), "tax_inclusive": True,
        "lines": [{"line_no": 1, "product_id": bread.pk, "qty": "2", "unit_price": "20", "discount": "0",
                   "tax_rate": str(bread.tax_rate.rate), "total": tot}],
        "payments": [{"method": "CASH", "amount": tot}], "totals": {"total": tot}}})
res = apply_batch(t, ops)
assert all(r["status"] == "APPLIED" for r in res), res
print("sales_after_backup", Sale.objects.count())
PY
SALES_GOOD=$(as_pg "psql -h $WORK -p 5433 -d yummy -Atc 'select count(*) from pos_sale'")
JE_GOOD=$(as_pg "psql -h $WORK -p 5433 -d yummy -Atc 'select count(*) from accounting_journalentry'")
sleep 1
TARGET=$(as_pg "psql -h $WORK -p 5433 -d yummy -Atc \"select to_char(clock_timestamp(),'YYYY-MM-DD HH24:MI:SS.US TZH')\"")
sleep 1
log "   recovery target = $TARGET  (sales=$SALES_GOOD, journals=$JE_GOOD)"

log "4. DISASTER: an operator drops the application schema"
as_pg "psql -h $WORK -p 5433 -d yummy -qc 'DROP SCHEMA public CASCADE' 2>/dev/null"
as_pg "psql -h $WORK -p 5433 -d yummy -Atc 'select pg_switch_wal()'" >/dev/null
sleep 2
as_pg "$BIN/pg_ctl -D $WORK/primary -m fast -w stop >/dev/null"

log "5. restore base backup + replay WAL to the target time"
T0=$(date +%s)
mkdir -p "$WORK/restored"; chown postgres "$WORK/restored"; chmod 700 "$WORK/restored"
as_pg "tar -xzf $WORK/base/b1/base.tar.gz -C $WORK/restored"
cat >> "$WORK/restored/postgresql.auto.conf" <<CONF
port = 5434
archive_mode = off
restore_command = 'cp $WORK/wal/%f %p'
recovery_target_time = '$TARGET'
recovery_target_action = 'promote'
CONF
touch "$WORK/restored/recovery.signal"; chown postgres "$WORK/restored/recovery.signal" "$WORK/restored/postgresql.auto.conf"
as_pg "$BIN/pg_ctl -D $WORK/restored -l $WORK/restored.log -w -t 300 start >/dev/null"
for i in $(seq 1 60); do
  [ "$(as_pg "psql -h $WORK -p 5434 -d yummy -Atc 'select pg_is_in_recovery()'" 2>/dev/null)" = "f" ] && break; sleep 1
done
SALES_REST=$(as_pg "psql -h $WORK -p 5434 -d yummy -Atc 'select count(*) from pos_sale'")
JE_REST=$(as_pg "psql -h $WORK -p 5434 -d yummy -Atc 'select count(*) from accounting_journalentry'")

log "6. verify application invariants on the restored database"
export DATABASE_URL="postgres://yummy:yummy@localhost:5434/yummy"
python3 -c "
import os, sys; sys.path.insert(0, '.')
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'yummy.settings')
import django; django.setup()
from django.core.management import call_command
call_command('verify_integrity')
"
T1=$(date +%s)
grep -E "recovery stopping|starting point-in-time" "$WORK/restored.log" | sed 's/^/   pg: /' || true

echo
echo "================ DRILL RESULT ================"
echo "sales before disaster : $SALES_GOOD   restored: $SALES_REST"
echo "journals before       : $JE_GOOD   restored: $JE_REST"
echo "data lost (RPO)       : $(( SALES_GOOD - SALES_REST )) sales, $(( JE_GOOD - JE_REST )) journals (target time $TARGET)"
echo "restore+verify (RTO)  : $(( T1 - T0 )) s on this machine"
[ "$SALES_GOOD" = "$SALES_REST" ] && [ "$JE_GOOD" = "$JE_REST" ] && echo "RESULT: PASS" || { echo "RESULT: FAIL"; exit 1; }
as_pg "$BIN/pg_ctl -D $WORK/restored -m fast -w stop >/dev/null"
