#!/bin/sh
# Point-in-time restore into an EMPTY data directory (never over the live one).
#   restore-pitr.sh /backups/base/20261009T223000Z "2026-10-10 14:05:00+03" /var/lib/postgresql/restore
# Then start PostgreSQL on that directory, run `manage.py verify_integrity`, and only after sign-off
# switch the application to it (documented in docs/OPERATIONS.md).
set -eu
BASE="$1"; TARGET_TIME="$2"; DATA="$3"
[ -d "$DATA" ] && [ "$(ls -A "$DATA")" ] && { echo "refusing: $DATA is not empty"; exit 2; }
mkdir -p "$DATA" && chmod 700 "$DATA"
if [ -f "$BASE/base.tar.gz.gpg" ]; then
  gpg --batch --pinentry-mode loopback --passphrase "$BACKUP_PASSPHRASE" -d "$BASE/base.tar.gz.gpg" | tar -xz -C "$DATA"
else
  tar -xzf "$BASE/base.tar.gz" -C "$DATA"
fi
cat >> "$DATA/postgresql.auto.conf" <<CONF
restore_command = 'cp /wal-archive/%f %p'
recovery_target_time = '$TARGET_TIME'
recovery_target_action = 'promote'
CONF
touch "$DATA/recovery.signal"
echo "Prepared $DATA for recovery to $TARGET_TIME. Start postgres on it and watch the log for 'recovery stopping'."
