export interface Modifier { id: number; name: string; group: string; price_delta: string }
export interface Product {
  id: number; sku: string; barcode: string; name: string; name_local: string; category_id: number; unit: string;
  kind: string; price: string; tax_inclusive: boolean; tax_rate: string; station: string; color: string;
  allergens: string; stock: number | null; is_stocked: boolean; modifiers: Modifier[];
}
export interface Cashier { id: number; name: string; pin_salt: string; pin_hash: string; pin_iterations: number; permissions: string[] }
export interface Bootstrap {
  terminal: { code: string; name: string; kind: "RETAIL" | "CAFE" | "KDS" };
  branch: { code: string; name: string; kind: string; address: string; phone: string; tin: string };
  settings: { max_discount_pct: string; currency: string };
  categories: { id: number; name: string; color: string; sort: number }[];
  products: Product[];
  cashiers: Cashier[];
  payment_methods: string[];
  catalog_version: string;
  last_receipt_seq: number;
  server_time: string;
  ethiopian_date: string;
}
export interface CartLine {
  key: string; product: Product; qty: string; unitPrice: string; discount: string; modifiers: Modifier[]; note: string;
  sentToKitchen?: string; // qty already sent (café)
}
export interface PaymentEntry { method: string; amount: string; tendered?: string; reference?: string }
export interface LocalSaleLine {
  line_no: number; product_id: number; name: string; qty: string; unit_price: string; discount: string;
  tax_rate: string; total: string; tax: string; modifiers: { id: number; name: string; price_delta: string }[];
  qty_refunded: string; is_stocked: boolean;
}
export interface LocalSale {
  id: string; number: string; created_at: string; shift_id: string; cashier_id: number; cashier_name: string;
  order_type: string; table_label: string; lines: LocalSaleLine[]; payments: PaymentEntry[];
  gross: number; discount: number; tax: number; total: number; status: "pending" | "synced" | "rejected";
  offline: boolean; refunded: number; error?: string;
}
export interface Shift {
  id: string; cashier_id: number; cashier_name: string; opened_at: string; opening_float: string;
}
export interface OutboxOp {
  seq?: number; op_id: string; kind: string; created_at: string; payload: Record<string, unknown>;
  attempts: number; last_error?: string; label: string;
}
export interface RejectedOp extends OutboxOp { error: string; detail: string; rejected_at: string }
export interface Tab { label: string; order_type: string; lines: CartLine[]; opened_at: string; updated_at: string }
