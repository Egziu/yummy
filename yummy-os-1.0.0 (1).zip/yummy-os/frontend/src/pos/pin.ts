/** Offline cashier PIN verification: PBKDF2-SHA256 with the salted verifier delivered in bootstrap. */
import type { Cashier } from "./types";

const hex = (buf: ArrayBuffer) => Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
const fromHex = (h: string) => new Uint8Array(h.match(/.{2}/g)!.map((b) => parseInt(b, 16)));

export async function derive(pin: string, saltHex: string, iterations: number): Promise<string> {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(pin), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt: fromHex(saltHex), iterations }, key, 256);
  return hex(bits);
}

function timingSafeEqual(a: string, b: string) {
  if (a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}

export async function verifyPin(cashier: Cashier, pin: string): Promise<boolean> {
  if (!cashier.pin_hash) return false;
  return timingSafeEqual(await derive(pin, cashier.pin_salt, cashier.pin_iterations), cashier.pin_hash);
}

/** Find which authorised person a PIN belongs to (used for supervisor approvals). */
export async function findApprover(cashiers: Cashier[], pin: string, permission: string, excludeId?: number) {
  for (const c of cashiers) {
    if (c.id === excludeId || !c.permissions.includes(permission)) continue;
    if (await verifyPin(c, pin)) return c;
  }
  return null;
}
