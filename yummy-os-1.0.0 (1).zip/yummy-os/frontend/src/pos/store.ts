/** POS session helpers shared by the screens. */
import { centsToStr, priceLine, toCents } from "../lib/money";
import { commitSale, db, enqueue, kvGet, makeOp } from "./db";
import { SyncEngine } from "./sync";
import type { Bootstrap, CartLine, Cashier, LocalSale, PaymentEntry, Product, Shift } from "./types";

export const engine = new SyncEngine(() => kvGet<string>("deviceToken"));

export function unitPriceWithMods(p: Product, mods: { price_delta: string }[]) {
  return centsToStr(toCents(p.price) + mods.reduce((s, m) => s + toCents(m.price_delta), 0));
}

export function lineCalc(l: CartLine) {
  return priceLine(l.unitPrice, l.qty, l.discount, l.product.tax_rate, l.product.tax_inclusive);
}

export function cartTotals(lines: CartLine[]) {
  let gross = 0, discount = 0, tax = 0, total = 0;
  for (const l of lines) {
    const c = lineCalc(l);
    gross += c.gross; discount += c.discount; tax += c.tax; total += c.total;
  }
  return { gross, discount, tax, total };
}

export async function finalizeSale(opts: {
  boot: Bootstrap; shift: Shift; cashier: Cashier; lines: CartLine[]; payments: PaymentEntry[];
  orderType: string; tableLabel: string; discountApproverId?: number; online: boolean;
  customerName?: string; customerTin?: string;
}): Promise<LocalSale> {
  const { boot, shift, cashier, lines, payments } = opts;
  const id = crypto.randomUUID();
  const createdAt = new Date().toISOString();
  const totals = cartTotals(lines);
  const saleLines = lines.map((l, i) => {
    const c = lineCalc(l);
    return {
      line_no: i + 1, product_id: l.product.id, name: l.product.name, qty: l.qty, unit_price: l.unitPrice,
      discount: l.discount, tax_rate: l.product.tax_rate, total: centsToStr(c.total), tax: centsToStr(c.tax),
      modifiers: l.modifiers.map((m) => ({ id: m.id, name: m.name, price_delta: m.price_delta })), qty_refunded: "0",
      is_stocked: l.product.is_stocked,
    };
  });
  return commitSale((number) => {
    const sale: LocalSale = {
      id, number, created_at: createdAt, shift_id: shift.id, cashier_id: cashier.id, cashier_name: cashier.name,
      order_type: opts.orderType, table_label: opts.tableLabel, lines: saleLines, payments,
      gross: totals.gross, discount: totals.discount, tax: totals.tax, total: totals.total, status: "pending",
      offline: !opts.online, refunded: 0,
    };
    const payload = {
      id, number, shift_id: shift.id, cashier_id: cashier.id, created_at: createdAt, order_type: opts.orderType,
      table_label: opts.tableLabel, tax_inclusive: lines.every((l) => l.product.tax_inclusive),
      customer_name: opts.customerName ?? "", customer_tin: opts.customerTin ?? "",
      lines: saleLines.map(({ name: _n, tax: _t, qty_refunded: _q, is_stocked: _s, ...rest }) => rest),
      payments, totals: { total: centsToStr(totals.total) }, was_offline: !opts.online,
      discount_approver_id: opts.discountApproverId ?? null,
    };
    return { sale, op: makeOp("sale", payload, `Sale ${number} · ETB ${centsToStr(totals.total)}`) };
  }, boot.terminal.code);
}

export async function shiftSummary(shiftId: string, openingFloat: string) {
  const d = await db();
  const sales = await d.getAllFromIndex("sales", "by_shift", shiftId);
  const cash = (await d.getAll("cash")).filter((c) => c.shift_id === shiftId);
  const byMethod: Record<string, number> = {};
  let cashRefunds = 0;
  for (const s of sales) {
    for (const p of s.payments) byMethod[p.method] = (byMethod[p.method] ?? 0) + toCents(p.amount);
  }
  const refunds = ((await kvGet<{ shift_id: string; method: string; amount: number }[]>("refundLog")) ?? [])
    .filter((r) => r.shift_id === shiftId);
  for (const r of refunds) if (r.method === "CASH") cashRefunds += r.amount;
  const cin = cash.filter((c) => c.kind === "IN").reduce((s, c) => s + toCents(c.amount), 0);
  const cout = cash.filter((c) => c.kind === "OUT").reduce((s, c) => s + toCents(c.amount), 0);
  const expected = toCents(openingFloat) + (byMethod.CASH ?? 0) - cashRefunds + cin - cout;
  const total = sales.reduce((s, x) => s + x.total, 0);
  return { count: sales.length, total, byMethod, cashRefunds, cashIn: cin, cashOut: cout, expected,
    pending: sales.filter((s) => s.status === "pending").length };
}

export { enqueue, makeOp };
