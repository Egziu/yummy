export type Lang = "en" | "am";
const AM: Record<string, string> = {
  "Sign in": "ግባ", "Enter PIN": "ፒን ያስገቡ", "Who is selling?": "ማን ይሸጣል?", "Open shift": "ፈረቃ ክፈት",
  "Opening cash": "መነሻ ጥሬ ገንዘብ", "Search or scan barcode": "ፈልግ ወይም ባርኮድ ቃኝ", "All": "ሁሉም", "Cart is empty": "ጋሪው ባዶ ነው",
  "Tap a product to start a sale": "ሽያጭ ለመጀመር ምርት ይንኩ", "Subtotal": "ንዑስ ድምር", "VAT": "ተ.እ.ታ", "Discount": "ቅናሽ",
  "Total": "ጠቅላላ", "Charge": "ክፈል", "Hold": "ያዝ", "Clear": "አጽዳ", "Payment": "ክፍያ", "Cash": "ጥሬ ገንዘብ",
  "Tendered": "የተሰጠ", "Change": "መልስ", "Complete sale": "ሽያጭ ጨርስ", "Receipt": "ደረሰኝ", "New sale": "አዲስ ሽያጭ",
  "Print": "አትም", "Refund": "ተመላሽ", "Close shift": "ፈረቃ ዝጋ", "Lock": "ቆልፍ", "Online": "መስመር ላይ", "Offline": "ከመስመር ውጪ",
  "pending": "በመጠባበቅ ላይ", "Send to kitchen": "ወደ ማብሰያ ላክ", "Tables": "ጠረጴዛዎች", "Takeaway": "ይዞ መሄድ", "Dine-in": "እዚሁ",
};
export const t = (lang: Lang, s: string) => (lang === "am" ? AM[s] ?? s : s);
