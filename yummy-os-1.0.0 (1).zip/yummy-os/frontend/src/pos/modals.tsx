import { useEffect, useMemo, useState } from "react";
import { formatEthiopian } from "../lib/ethiopian";
import { centsToStr, fmt, refundAmounts, toCents } from "../lib/money";
import { ago, Keypad, Modal, useToast } from "../lib/ui";
import { db, kvGet, kvSet, makeOp, recentSales, uuid } from "./db";
import { findApprover } from "./pin";
import { engine, shiftSummary } from "./store";
import type { Bootstrap, Cashier, LocalSale, Modifier, OutboxOp, PaymentEntry, Product, RejectedOp, Shift } from "./types";

const METHOD_LABEL: Record<string, string> = {
  CASH: "Cash", TELEBIRR: "telebirr", CBE_BIRR: "CBE Birr", BANK_TRANSFER: "Bank transfer", CARD: "Card",
};

/* ----------------------------------------------------------- approval PIN */
export function ApprovalPin({ cashiers, permission, excludeId, title, onApproved, onClose }: {
  cashiers: Cashier[]; permission: string; excludeId?: number; title: string;
  onApproved: (c: Cashier) => void; onClose: () => void;
}) {
  const [pin, setPin] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  async function key(k: string) {
    if (busy) return;
    if (k === "C") return setPin("");
    if (k === "⌫") return setPin((p) => p.slice(0, -1));
    const next = (pin + k).slice(0, 8);
    setPin(next);
    setErr("");
    if (next.length >= 4) {
      setBusy(true);
      const who = await findApprover(cashiers, next, permission, excludeId);
      setBusy(false);
      if (who) onApproved(who);
      else if (next.length >= 6) { setErr("PIN not recognised for this approval"); setPin(""); }
    }
  }
  return (
    <Modal title={title} onClose={onClose}>
      <p className="muted small">A supervisor enters their own PIN. The approval is recorded with their name.</p>
      <div className="pin-dots">{Array.from({ length: Math.max(4, pin.length) }).map((_, i) => <span key={i} className={i < pin.length ? "on" : ""} />)}</div>
      {err && <p className="center" style={{ color: "var(--bad)" }}>{err}</p>}
      <Keypad onKey={key} />
    </Modal>
  );
}

/* ----------------------------------------------------------- modifiers */
export function ModifierPicker({ product, onAdd, onClose }: { product: Product; onAdd: (m: Modifier[]) => void; onClose: () => void }) {
  const [sel, setSel] = useState<number[]>([]);
  const groups = useMemo(() => {
    const g: Record<string, Modifier[]> = {};
    for (const m of product.modifiers) (g[m.group] ??= []).push(m);
    return g;
  }, [product]);
  return (
    <Modal title={product.name} onClose={onClose}>
      {Object.entries(groups).map(([g, mods]) => (
        <div key={g} className="col" style={{ marginBottom: 12 }}>
          <div className="muted small">{g}</div>
          <div className="row wrap">
            {mods.map((m) => (
              <button key={m.id} className={sel.includes(m.id) ? "primary" : ""}
                onClick={() => setSel((s) => (s.includes(m.id) ? s.filter((x) => x !== m.id) : [...s, m.id]))}>
                {m.name}{toCents(m.price_delta) ? ` +${fmt(toCents(m.price_delta))}` : ""}
              </button>
            ))}
          </div>
        </div>
      ))}
      <div className="row">
        <button className="grow" onClick={() => onAdd([])}>Plain</button>
        <button className="accent grow lg" onClick={() => onAdd(product.modifiers.filter((m) => sel.includes(m.id)))}>Add</button>
      </div>
    </Modal>
  );
}

/* ----------------------------------------------------------- discount */
export function DiscountModal({ lineGross, maxPct, onApply, onClose }: {
  lineGross: number; maxPct: number; onApply: (cents: number, needsApproval: boolean) => void; onClose: () => void;
}) {
  const [mode, setMode] = useState<"pct" | "amt">("pct");
  const [v, setV] = useState("");
  const cents = mode === "pct" ? Math.round((lineGross * Number(v || 0)) / 100) : toCents(v || "0");
  const pct = lineGross ? (cents / lineGross) * 100 : 0;
  const over = cents > lineGross;
  return (
    <Modal title="Line discount" onClose={onClose}>
      <div className="row" style={{ marginBottom: 10 }}>
        <button className={mode === "pct" ? "primary" : ""} onClick={() => setMode("pct")}>Percent</button>
        <button className={mode === "amt" ? "primary" : ""} onClick={() => setMode("amt")}>Amount</button>
        <div className="right num" style={{ fontSize: 22, fontWeight: 700 }}>{v || "0"}{mode === "pct" ? "%" : " ETB"}</div>
      </div>
      <p className="muted small">= ETB {fmt(Math.min(cents, lineGross))} off. Cashier limit {maxPct}% — above that a supervisor approves.</p>
      <Keypad extra="." onKey={(k) => setV((x) => (k === "⌫" ? x.slice(0, -1) : k === "C" ? "" : (x + k).slice(0, 8)))} />
      <div className="row" style={{ marginTop: 12 }}>
        <button className="grow" onClick={() => onApply(0, false)}>Remove discount</button>
        <button className="accent grow lg" disabled={over || cents <= 0} onClick={() => onApply(cents, pct > maxPct)}>
          {pct > maxPct ? "Needs approval" : "Apply"}
        </button>
      </div>
    </Modal>
  );
}

/* ----------------------------------------------------------- payment */
export function PaymentModal({ total, methods, onDone, onClose }: {
  total: number; methods: string[]; onDone: (p: PaymentEntry[]) => void; onClose: () => void;
}) {
  const [paid, setPaid] = useState<PaymentEntry[]>([]);
  const [method, setMethod] = useState("CASH");
  const [entry, setEntry] = useState("");
  const [ref, setRef] = useState("");
  const paidC = paid.reduce((s, p) => s + toCents(p.amount), 0);
  const remaining = total - paidC;
  const entryC = entry ? toCents(entry) : remaining;
  const change = method === "CASH" ? Math.max(0, entryC - remaining) : 0;
  const canAdd = remaining > 0 && entryC > 0 && (method === "CASH" || entryC <= remaining);
  const quick = [remaining, ...[50, 100, 200, 500, 1000].map((n) => n * 100).filter((n) => n > remaining)].slice(0, 5);

  function add() {
    const applied = Math.min(entryC, remaining);
    const p: PaymentEntry = { method, amount: centsToStr(applied) };
    if (method === "CASH") p.tendered = centsToStr(entryC);
    else p.reference = ref.trim();
    const next = [...paid, p];
    setPaid(next); setEntry(""); setRef("");
    if (paidC + applied === total) onDone(next);
  }
  return (
    <Modal title={<>Payment · <span className="num">ETB {fmt(total)}</span></>} onClose={onClose}>
      <div className="paygrid" style={{ marginBottom: 12 }}>
        {methods.map((m) => <button key={m} className={method === m ? "on" : ""} onClick={() => setMethod(m)}>{METHOD_LABEL[m] ?? m}</button>)}
      </div>
      {paid.length > 0 && (
        <div className="card pad small" style={{ marginBottom: 10 }}>
          {paid.map((p, i) => <div key={i} className="row"><span>{METHOD_LABEL[p.method]}</span><span className="right num">{fmt(toCents(p.amount))}</span></div>)}
          <div className="row" style={{ fontWeight: 700 }}><span>Remaining</span><span className="right num">{fmt(remaining)}</span></div>
        </div>
      )}
      <div className="row" style={{ alignItems: "baseline" }}>
        <span className="muted">{method === "CASH" ? "Tendered" : "Amount"}</span>
        <span className="right num" style={{ fontSize: 30, fontWeight: 750 }}>{fmt(entryC)}</span>
      </div>
      {method === "CASH" ? (
        <>
          <div className="quick-cash" style={{ margin: "8px 0" }}>
            {quick.map((q) => <button key={q} onClick={() => setEntry(centsToStr(q))}>{fmt(q)}</button>)}
          </div>
          <div className="row" style={{ margin: "4px 0 10px" }}>
            <span className="muted">Change due</span><span className="right num" style={{ fontSize: 22, fontWeight: 700, color: "var(--good)" }}>{fmt(change)}</span>
          </div>
        </>
      ) : (
        <label className="field" style={{ margin: "8px 0 10px" }}>Transaction reference (from the customer's phone or bank SMS)
          <input value={ref} onChange={(e) => setRef(e.target.value)} placeholder="e.g. telebirr TXN ID" autoFocus />
        </label>
      )}
      <Keypad extra="." onKey={(k) => setEntry((x) => (k === "⌫" ? x.slice(0, -1) : k === "C" ? "" : (x + k).slice(0, 10)))} />
      <button className="accent lg" style={{ width: "100%", marginTop: 12 }} disabled={!canAdd || (method !== "CASH" && !ref.trim())} onClick={add}>
        {Math.min(entryC, remaining) === remaining ? "Complete sale" : `Add ${METHOD_LABEL[method]} ${fmt(entryC)}`}
      </button>
    </Modal>
  );
}

/* ----------------------------------------------------------- receipt */
export function Receipt({ sale, boot }: { sale: LocalSale; boot: Bootstrap }) {
  const d = new Date(sale.created_at);
  const tendered = sale.payments.find((p) => p.method === "CASH" && p.tendered);
  return (
    <div className="receipt">
      <div className="c"><b style={{ fontSize: 16 }}>YUMMY CAFÉ &amp; BAKERY</b></div>
      <div className="c">{boot.branch.name}</div>
      <div className="c">{boot.branch.address} · {boot.branch.phone}</div>
      {boot.branch.tin && <div className="c">TIN {boot.branch.tin}</div>}
      <hr />
      <div className="r"><span>Receipt</span><span>{sale.number}</span></div>
      <div className="r"><span>{d.toLocaleDateString("en-GB")} {d.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })}</span><span>{formatEthiopian(d)}</span></div>
      <div className="r"><span>Cashier</span><span>{sale.cashier_name}</span></div>
      {sale.table_label && <div className="r"><span>Table</span><span>{sale.table_label}</span></div>}
      <hr />
      {sale.lines.map((l) => (
        <div key={l.line_no}>
          <div className="r"><span>{l.name}</span><span>{fmt(toCents(l.total))}</span></div>
          <div className="r" style={{ color: "#555" }}><span>&nbsp; {l.qty} x {fmt(toCents(l.unit_price))}{toCents(l.discount) ? ` -${fmt(toCents(l.discount))}` : ""}</span></div>
          {l.modifiers.map((m) => <div key={m.id} style={{ color: "#555" }}>&nbsp;&nbsp;+ {m.name}</div>)}
        </div>
      ))}
      <hr />
      {sale.discount > 0 && <div className="r"><span>Discounts</span><span>-{fmt(sale.discount)}</span></div>}
      <div className="r"><span>VAT included</span><span>{fmt(sale.tax)}</span></div>
      <div className="r" style={{ fontSize: 16, fontWeight: 700 }}><span>TOTAL ETB</span><span>{fmt(sale.total)}</span></div>
      {sale.payments.map((p, i) => <div key={i} className="r"><span>{METHOD_LABEL[p.method]}{p.reference ? ` ${p.reference}` : ""}</span><span>{fmt(toCents(p.amount))}</span></div>)}
      {tendered && <div className="r"><span>Tendered / change</span><span>{fmt(toCents(tendered.tendered!))} / {fmt(toCents(tendered.tendered!) - toCents(tendered.amount))}</span></div>}
      <hr />
      {sale.offline && <div className="c">Recorded offline · synchronised later</div>}
      <div className="c">Thank you! · እናመሰግናለን!</div>
      <div className="c" style={{ fontSize: 11 }}>Igniting taste, every day.</div>
    </div>
  );
}

/* ----------------------------------------------------------- cash in / out */
export function CashModal({ shift, cashier, onClose }: { shift: Shift; cashier: Cashier; onClose: () => void }) {
  const toast = useToast();
  const [kind, setKind] = useState<"IN" | "OUT">("OUT");
  const [amount, setAmount] = useState("");
  const [reason, setReason] = useState("Cash drop to safe");
  async function save() {
    const id = uuid();
    const at = new Date().toISOString();
    const d = await db();
    const tx = d.transaction(["cash", "outbox"], "readwrite");
    await tx.objectStore("cash").add({ id, shift_id: shift.id, kind, amount, reason, at });
    await tx.objectStore("outbox").add(makeOp("cash_move", { id, shift_id: shift.id, kind, amount, reason, at, user_id: cashier.id },
      `Cash ${kind.toLowerCase()} ${amount}`));
    await tx.done;
    engine.kick();
    toast(`Cash ${kind === "IN" ? "added" : "removed"}: ETB ${amount}`, "good");
    onClose();
  }
  return (
    <Modal title="Cash in / out" onClose={onClose}>
      <div className="row" style={{ marginBottom: 10 }}>
        <button className={kind === "OUT" ? "primary" : ""} onClick={() => { setKind("OUT"); setReason("Cash drop to safe"); }}>Cash out / drop</button>
        <button className={kind === "IN" ? "primary" : ""} onClick={() => { setKind("IN"); setReason("Change float top-up"); }}>Cash in</button>
      </div>
      <label className="field">Reason<input value={reason} onChange={(e) => setReason(e.target.value)} /></label>
      <div className="num" style={{ fontSize: 28, fontWeight: 700, margin: "12px 0" }}>ETB {amount || "0"}</div>
      <Keypad extra="." onKey={(k) => setAmount((x) => (k === "⌫" ? x.slice(0, -1) : k === "C" ? "" : (x + k).slice(0, 10)))} />
      <button className="accent lg" style={{ width: "100%", marginTop: 12 }} disabled={!amount || toCents(amount) <= 0 || !reason.trim()} onClick={save}>Record</button>
    </Modal>
  );
}

/* ----------------------------------------------------------- close shift */
export function CloseShiftModal({ shift, cashier, boot, onClosed, onClose }: {
  shift: Shift; cashier: Cashier; boot: Bootstrap; onClosed: () => void; onClose: () => void;
}) {
  const [sum, setSum] = useState<Awaited<ReturnType<typeof shiftSummary>> | null>(null);
  const [counted, setCounted] = useState("");
  const [approve, setApprove] = useState(false);
  useEffect(() => { void shiftSummary(shift.id, shift.opening_float).then(setSum); }, [shift]);
  if (!sum) return null;
  const diff = counted === "" ? 0 : toCents(counted) - sum.expected;
  async function finish(approverId?: number) {
    await (await db()).add("outbox", makeOp("shift_close", {
      shift_id: shift.id, counted_cash: counted || "0", closed_at: new Date().toISOString(), closed_by_id: cashier.id,
      approver_id: approverId ?? null,
    }, `Close shift · counted ${counted}`));
    await kvSet("shift", null);
    engine.kick();
    onClosed();
  }
  return (
    <>
      <Modal title="Close shift — cash count" onClose={onClose}>
        <div className="card pad small col" style={{ gap: 4, marginBottom: 12 }}>
          <div className="row"><span>Sales</span><span className="right num">{sum.count} · ETB {fmt(sum.total)}</span></div>
          {Object.entries(sum.byMethod).map(([m, c]) => <div className="row" key={m}><span className="muted">{METHOD_LABEL[m]}</span><span className="right num">{fmt(c)}</span></div>)}
          <div className="row"><span className="muted">Opening float</span><span className="right num">{fmt(toCents(shift.opening_float))}</span></div>
          <div className="row"><span className="muted">Cash refunds / in / out</span><span className="right num">-{fmt(sum.cashRefunds)} / +{fmt(sum.cashIn)} / -{fmt(sum.cashOut)}</span></div>
          <div className="row" style={{ fontWeight: 700 }}><span>Expected cash in drawer</span><span className="right num">{fmt(sum.expected)}</span></div>
          {sum.pending > 0 && <div className="badge warn">{sum.pending} sale(s) not yet synced — they will sync before the close</div>}
        </div>
        <div className="row" style={{ alignItems: "baseline" }}>
          <span className="muted">Counted cash</span>
          <span className="right num" style={{ fontSize: 28, fontWeight: 750 }}>{counted || "0"}</span>
        </div>
        {counted !== "" && <p className="num" style={{ color: diff === 0 ? "var(--good)" : "var(--bad)", fontWeight: 700 }}>
          {diff === 0 ? "Balanced" : diff > 0 ? `Over by ${fmt(diff)}` : `Short by ${fmt(-diff)}`}</p>}
        <Keypad extra="." onKey={(k) => setCounted((x) => (k === "⌫" ? x.slice(0, -1) : k === "C" ? "" : (x + k).slice(0, 10)))} />
        <div className="row" style={{ marginTop: 12 }}>
          <button className="grow" onClick={() => window.print()}>Print X report</button>
          <button className="accent grow lg" disabled={counted === ""} onClick={() => (diff !== 0 ? setApprove(true) : finish())}>
            {diff !== 0 ? "Supervisor sign-off" : "Close shift"}
          </button>
        </div>
      </Modal>
      {approve && <ApprovalPin cashiers={boot.cashiers} permission="pos.shift_approve" title="Approve cash difference"
        onApproved={(c) => finish(c.id)} onClose={() => setApprove(false)} />}
    </>
  );
}

/* ----------------------------------------------------------- refunds */
export function RefundModal({ boot, shift, cashier, onClose }: { boot: Bootstrap; shift: Shift; cashier: Cashier; onClose: () => void }) {
  const toast = useToast();
  const [sales, setSales] = useState<LocalSale[]>([]);
  const [sel, setSel] = useState<LocalSale | null>(null);
  const [qty, setQty] = useState<Record<number, string>>({});
  const [reason, setReason] = useState("");
  const [restock, setRestock] = useState(true);
  const [lookup, setLookup] = useState("");
  const [approve, setApprove] = useState(false);
  useEffect(() => { void recentSales(40).then(setSales); }, []);
  const canRefund = cashier.permissions.includes("pos.refund");

  async function find() {
    const local = sales.find((s) => s.number === lookup.trim());
    if (local) return setSel(local);
    try {
      const res = await fetch(`/api/pos/sales/${encodeURIComponent(lookup.trim())}`, {
        headers: { "X-Terminal-Token": (await kvGet<string>("deviceToken")) ?? "" } });
      if (!res.ok) return toast("Receipt not found at this branch", "bad");
      const s = await res.json();
      setSel({
        id: s.id, number: s.number, created_at: s.created_at, shift_id: s.shift_id, cashier_id: 0, cashier_name: "",
        order_type: "", table_label: "", payments: s.payments, gross: 0, discount: 0, tax: 0, total: toCents(s.total),
        status: "synced", offline: false, refunded: toCents(s.refunded_total),
        lines: s.lines.map((l: Record<string, string>) => ({ ...l, unit_price: "0", discount: "0", tax_rate: "0", modifiers: [] })),
      });
    } catch { toast("Offline — only receipts from this terminal can be refunded right now", "bad"); }
  }

  const lines = sel?.lines.filter((l) => Number(qty[l.line_no] || 0) > 0) ?? [];
  let amount = 0;
  for (const l of lines) amount += refundAmounts(l.total, l.tax, l.qty, l.qty_refunded, qty[l.line_no]).amount;
  const valid = sel && lines.length > 0 && reason.trim() && lines.every((l) => Number(qty[l.line_no]) <= Number(l.qty) - Number(l.qty_refunded));

  async function commit(approver: Cashier) {
    if (!sel) return;
    const id = uuid();
    const number = `R-${boot.terminal.code}-${Date.now().toString().slice(-7)}`;
    const method = sel.payments[0]?.method ?? "CASH";
    const d = await db();
    const tx = d.transaction(["sales", "outbox", "kv"], "readwrite");
    await tx.objectStore("outbox").add(makeOp("refund", {
      id, number, sale_id: sel.id, shift_id: shift.id, cashier_id: cashier.id, approver_id: approver.id,
      created_at: new Date().toISOString(), reason, method, restock, amount: centsToStr(amount),
      lines: lines.map((l) => ({ line_no: l.line_no, qty: qty[l.line_no] })),
    }, `Refund ${number} · ETB ${centsToStr(amount)}`));
    const stored = await tx.objectStore("sales").get(sel.id);
    if (stored) {
      stored.lines = stored.lines.map((l) => ({ ...l, qty_refunded: String(Number(l.qty_refunded) + Number(qty[l.line_no] || 0)) }));
      stored.refunded += amount;
      await tx.objectStore("sales").put(stored);
    }
    const log = ((await tx.objectStore("kv").get("refundLog")) as { shift_id: string; method: string; amount: number }[] | undefined) ?? [];
    await tx.objectStore("kv").put([...log, { shift_id: shift.id, method, amount }], "refundLog");
    await tx.done;
    engine.kick();
    toast(`Refund recorded · give back ETB ${fmt(amount)} (${METHOD_LABEL[method]})`, "good");
    onClose();
  }

  return (
    <>
      <Modal title="Refund" onClose={onClose} wide>
        {!canRefund && <p className="badge bad">You are not allowed to start refunds.</p>}
        {!sel ? (
          <>
            <div className="row" style={{ marginBottom: 10 }}>
              <input placeholder="Receipt number, e.g. SHOP1-T1-000123" value={lookup} onChange={(e) => setLookup(e.target.value)} onKeyDown={(e) => e.key === "Enter" && find()} />
              <button onClick={find}>Find</button>
            </div>
            <div className="scroll">
              <table className="data">
                <thead><tr><th>Receipt</th><th>Time</th><th className="num">Total</th><th>Status</th></tr></thead>
                <tbody>{sales.map((s) => (
                  <tr key={s.id} onClick={() => setSel(s)} style={{ cursor: "pointer" }}>
                    <td>{s.number}</td><td className="muted">{new Date(s.created_at).toLocaleString("en-GB")}</td>
                    <td className="num">{fmt(s.total)}</td>
                    <td><span className={`badge ${s.status === "synced" ? "good" : s.status === "rejected" ? "bad" : "warn"}`}>{s.status}</span></td>
                  </tr>))}</tbody>
              </table>
            </div>
          </>
        ) : (
          <div className="col">
            <div className="row"><b>{sel.number}</b><span className="muted">{new Date(sel.created_at).toLocaleString("en-GB")}</span><button className="right ghost" onClick={() => setSel(null)}>Change</button></div>
            <table className="data">
              <thead><tr><th>Item</th><th className="num">Sold</th><th className="num">Refunded</th><th className="num">Refund qty</th></tr></thead>
              <tbody>{sel.lines.map((l) => (
                <tr key={l.line_no}><td>{l.name}</td><td className="num">{l.qty}</td><td className="num">{l.qty_refunded}</td>
                  <td className="num" style={{ width: 120 }}>
                    <input type="number" min={0} step="1" max={Number(l.qty) - Number(l.qty_refunded)} value={qty[l.line_no] ?? ""}
                      onChange={(e) => setQty({ ...qty, [l.line_no]: e.target.value })} />
                  </td></tr>))}</tbody>
            </table>
            <label className="field">Reason<input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="e.g. stale, wrong item" /></label>
            <label className="row small"><input type="checkbox" style={{ width: 18, minHeight: 18 }} checked={restock} onChange={(e) => setRestock(e.target.checked)} /> Return item to sellable stock</label>
            <div className="row"><span className="muted">Refund amount</span><b className="right num" style={{ fontSize: 22 }}>ETB {fmt(amount)}</b></div>
            <button className="accent lg" disabled={!valid || !canRefund} onClick={() => setApprove(true)}>Supervisor approval</button>
          </div>
        )}
      </Modal>
      {approve && <ApprovalPin cashiers={boot.cashiers} permission="pos.refund_approve" excludeId={cashier.id}
        title="Approve refund (different person)" onApproved={(c) => { setApprove(false); void commit(c); }} onClose={() => setApprove(false)} />}
    </>
  );
}

/* ----------------------------------------------------------- sync centre */
export function SyncCentre({ boot, onClose, onCatalog }: { boot: Bootstrap; onClose: () => void; onCatalog: (b: Bootstrap) => void }) {
  const toast = useToast();
  const [st, setSt] = useState(engine.state);
  const [queue, setQueue] = useState<OutboxOp[]>([]);
  const [rej, setRej] = useState<RejectedOp[]>([]);
  useEffect(() => engine.subscribe(setSt), []);
  useEffect(() => {
    void (async () => { const d = await db(); setQueue(await d.getAll("outbox", undefined, 200)); setRej(await d.getAll("rejected")); })();
  }, [st]);
  return (
    <Modal title="Sync centre" onClose={onClose} wide>
      <div className="kpis" style={{ marginBottom: 12 }}>
        <div className="card kpi"><div className="label">Connection</div><div className="value" style={{ fontSize: 20 }}>
          {st.forcedOffline ? "Practice offline" : st.online ? "Online" : "Offline"}</div></div>
        <div className="card kpi"><div className="label">Waiting to sync</div><div className="value">{st.pending}</div></div>
        <div className="card kpi"><div className="label">Needs review</div><div className="value" style={{ color: st.rejected ? "var(--bad)" : undefined }}>{st.rejected}</div></div>
        <div className="card kpi"><div className="label">Last sync</div><div className="value" style={{ fontSize: 20 }}>{ago(st.lastSyncAt)}</div></div>
      </div>
      {st.lastError && <p className="badge warn" style={{ marginBottom: 10 }}>{st.lastError}</p>}
      <div className="row wrap" style={{ marginBottom: 14 }}>
        <button className="primary" onClick={() => engine.kick()}>Sync now</button>
        <button onClick={async () => { try { const b = await engine.refreshCatalog(); if (b) { onCatalog(b); toast("Prices & products updated", "good"); } } catch { toast("Cannot reach the server", "bad"); } }}>Refresh prices &amp; products</button>
        <label className="row small right"><input type="checkbox" style={{ width: 18, minHeight: 18 }} checked={st.forcedOffline}
          onChange={(e) => void engine.setForcedOffline(e.target.checked)} /> Practice offline mode (simulate no internet)</label>
      </div>
      <p className="muted small">Catalogue {boot.catalog_version} · updated {ago(st.lastCatalogAt)}. Sales keep working without internet; everything below is stored safely on this device and uploads in order.</p>
      {rej.length > 0 && (
        <>
          <h3 style={{ margin: "12px 0 6px", color: "var(--bad)" }}>Needs manager review</h3>
          <table className="data"><tbody>{rej.map((r) => (
            <tr key={r.op_id}><td>{r.label}</td><td><span className="badge bad">{r.error}</span> <span className="small">{r.detail}</span></td>
              <td><button className="ghost small" onClick={() => void engine.dismissRejected(r.op_id)}>Acknowledge</button></td></tr>))}</tbody></table>
          <p className="muted small">The server kept a copy of every rejected item for the back office (Sync monitor) — acknowledging here only clears this screen.</p>
        </>
      )}
      <h3 style={{ margin: "12px 0 6px" }}>Queue</h3>
      {queue.length === 0 ? <p className="muted">Everything is synchronised.</p> : (
        <div className="scroll" style={{ maxHeight: 260 }}>
          <table className="data"><thead><tr><th>#</th><th>Operation</th><th>Created</th><th>Attempts</th></tr></thead>
            <tbody>{queue.map((q) => <tr key={q.seq}><td className="num">{q.seq}</td><td>{q.label}</td><td className="muted">{new Date(q.created_at).toLocaleTimeString("en-GB")}</td><td className="num">{q.attempts}{q.last_error ? ` · ${q.last_error}` : ""}</td></tr>)}</tbody>
          </table>
        </div>)}
    </Modal>
  );
}

export { METHOD_LABEL };
