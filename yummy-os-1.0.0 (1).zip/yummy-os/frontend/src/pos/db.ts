/**
 * Durable local storage for the offline POS (IndexedDB).
 * A sale, its outbox operation and the receipt counter are written in ONE
 * IndexedDB transaction, so a power cut can never leave a printed receipt
 * without a queued sync operation (or vice versa).
 */
import { openDB, type DBSchema, type IDBPDatabase } from "idb";
import type { Bootstrap, LocalSale, OutboxOp, RejectedOp, Shift, Tab, CartLine } from "./types";

interface PosDB extends DBSchema {
  kv: { key: string; value: unknown };
  outbox: { key: number; value: OutboxOp; indexes: { by_op: string } };
  rejected: { key: string; value: RejectedOp };
  sales: { key: string; value: LocalSale; indexes: { by_number: string; by_shift: string } };
  tabs: { key: string; value: Tab };
  held: { key: string; value: { id: string; lines: CartLine[]; at: string; label: string } };
  cash: { key: string; value: { id: string; shift_id: string; kind: "IN" | "OUT"; amount: string; reason: string; at: string } };
}

let dbp: Promise<IDBPDatabase<PosDB>> | null = null;
export const DB_NAME = "yummy-pos";

export function db() {
  if (!dbp) {
    dbp = openDB<PosDB>(DB_NAME, 1, {
      upgrade(d) {
        d.createObjectStore("kv");
        const o = d.createObjectStore("outbox", { keyPath: "seq", autoIncrement: true });
        o.createIndex("by_op", "op_id", { unique: true });
        d.createObjectStore("rejected", { keyPath: "op_id" });
        const s = d.createObjectStore("sales", { keyPath: "id" });
        s.createIndex("by_number", "number", { unique: true });
        s.createIndex("by_shift", "shift_id");
        d.createObjectStore("tabs", { keyPath: "label" });
        d.createObjectStore("held", { keyPath: "id" });
        d.createObjectStore("cash", { keyPath: "id" });
      },
    });
  }
  return dbp;
}

/** Close and forget the connection (tests, or wiping a terminal). */
export async function resetDbHandle() {
  if (dbp) (await dbp).close();
  dbp = null;
}

export async function kvGet<T>(key: string): Promise<T | undefined> {
  return (await (await db()).get("kv", key)) as T | undefined;
}
export async function kvSet(key: string, value: unknown) {
  await (await db()).put("kv", value, key);
}

export const uuid = () =>
  (globalThis.crypto && "randomUUID" in globalThis.crypto)
    ? globalThis.crypto.randomUUID()
    : "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
      const r = (Math.random() * 16) | 0;
      return (c === "x" ? r : (r & 0x3) | 0x8).toString(16);
    });

export function makeOp(kind: string, payload: Record<string, unknown>, label: string): OutboxOp {
  return { op_id: uuid(), kind, created_at: new Date().toISOString(), payload, attempts: 0, label };
}

export async function enqueue(op: OutboxOp) {
  await (await db()).add("outbox", op);
}

/** Atomically: reserve receipt number, store the local sale, queue its sync operation. */
export async function commitSale(build: (number: string) => { sale: LocalSale; op: OutboxOp }, terminalCode: string) {
  const d = await db();
  const tx = d.transaction(["kv", "sales", "outbox"], "readwrite");
  const kv = tx.objectStore("kv");
  const seq = (((await kv.get("receiptSeq")) as number | undefined) ?? 0) + 1;
  const number = `${terminalCode}-${String(seq).padStart(6, "0")}`;
  const { sale, op } = build(number);
  await kv.put(seq, "receiptSeq");
  await tx.objectStore("sales").add(sale);
  await tx.objectStore("outbox").add(op);
  await tx.done;
  return sale;
}

export async function outboxAll(limit = 1000) {
  return (await db()).getAll("outbox", undefined, limit);
}
export async function outboxCount() { return (await db()).count("outbox"); }
export async function rejectedAll() { return (await db()).getAll("rejected"); }

export async function currentShift() { return kvGet<Shift | null>("shift"); }
export async function bootstrapData() { return kvGet<Bootstrap>("bootstrap"); }

export async function salesForShift(shiftId: string) {
  return (await db()).getAllFromIndex("sales", "by_shift", shiftId);
}
export async function recentSales(limit = 60) {
  const all = await (await db()).getAll("sales");
  return all.sort((a, b) => b.created_at.localeCompare(a.created_at)).slice(0, limit);
}
