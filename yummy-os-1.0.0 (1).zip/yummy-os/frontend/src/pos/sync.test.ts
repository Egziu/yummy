import "fake-indexeddb/auto";
import { beforeEach, describe, expect, it } from "vitest";
import { commitSale, db, DB_NAME, makeOp, enqueue, resetDbHandle } from "./db";
import { SyncEngine } from "./sync";
import type { LocalSale } from "./types";

type Handler = (body: { ops: { op_id: string; kind: string }[] }) => { status: number; body?: unknown } | "network-error";

function fakeServer(handler: Handler) {
  const calls: { path: string; body: { ops: { op_id: string; kind: string }[] } }[] = [];
  const fn = (async (input: RequestInfo | URL, init?: RequestInit) => {
    const path = String(input);
    const body = init?.body ? JSON.parse(String(init.body)) : { ops: [] };
    calls.push({ path, body });
    if (path.endsWith("/heartbeat")) return new Response("{}", { status: 200 });
    const r = handler(body);
    if (r === "network-error") throw new TypeError("Failed to fetch");
    return new Response(JSON.stringify(r.body ?? {}), { status: r.status });
  }) as typeof fetch;
  return { fn, calls };
}

const sale = (id: string, number: string): LocalSale => ({
  id, number, created_at: new Date().toISOString(), shift_id: "s1", cashier_id: 1, cashier_name: "c", order_type: "RETAIL",
  table_label: "", lines: [], payments: [], gross: 0, discount: 0, tax: 0, total: 1500, status: "pending", offline: true, refunded: 0,
});

beforeEach(async () => {
  await resetDbHandle();
  await new Promise<void>((res) => { const r = indexedDB.deleteDatabase(DB_NAME); r.onsuccess = () => res(); r.onerror = () => res(); });
});

describe("offline outbox", () => {
  it("assigns receipt numbers atomically and keeps everything while offline", async () => {
    for (let i = 0; i < 3; i++) {
      await commitSale((n) => ({ sale: sale(`id${i}`, n), op: makeOp("sale", { id: `id${i}`, number: n }, n) }), "SHOP1-T1");
    }
    const server = fakeServer(() => "network-error");
    const eng = new SyncEngine(async () => "tok", server.fn);
    await eng.init();
    expect(await eng.pushOnce()).toBe(false);
    expect(eng.state.online).toBe(false);
    const d = await db();
    expect(await d.count("outbox")).toBe(3);
    const numbers = (await d.getAll("sales")).map((s) => s.number).sort();
    expect(numbers).toEqual(["SHOP1-T1-000001", "SHOP1-T1-000002", "SHOP1-T1-000003"]);
  });

  it("uploads in order, removes applied ops, quarantines rejected ones and stops at RETRY", async () => {
    for (const k of ["shift_open", "sale", "sale", "sale"]) {
      if (k === "sale") {
        await commitSale((n) => ({ sale: sale(n, n), op: makeOp("sale", { id: n, number: n }, n) }), "T");
      } else await enqueue(makeOp(k, {}, k));
    }
    const server = fakeServer((b) => ({
      status: 200,
      body: { results: b.ops.map((o, i) => ({ op_id: o.op_id, status: i === 2 ? "REJECTED" : i === 3 ? "RETRY" : "APPLIED", error: i === 2 ? "totals_mismatch" : undefined })) },
    }));
    const eng = new SyncEngine(async () => "tok", server.fn);
    expect(await eng.pushOnce()).toBe(false);
    const d = await db();
    const sent = server.calls.find((c) => c.path.endsWith("/sync"))!.body.ops.map((o) => o.kind);
    expect(sent).toEqual(["shift_open", "sale", "sale", "sale"]);
    expect((await d.getAll("outbox")).map((o) => o.label)).toEqual(["T-000003"]);
    expect((await d.getAll("rejected"))[0].error).toBe("totals_mismatch");
    const sales = Object.fromEntries((await d.getAll("sales")).map((s) => [s.number, s.status]));
    expect(sales).toEqual({ "T-000001": "synced", "T-000002": "rejected", "T-000003": "pending" });
    expect(eng.state.rejected).toBe(1);
  });

  it("re-sends after a lost response without creating duplicates (idempotent op ids)", async () => {
    await enqueue(makeOp("sale", { id: "x" }, "x"));
    let first = true;
    const seen: string[] = [];
    const server = fakeServer((b) => {
      seen.push(...b.ops.map((o) => o.op_id));
      if (first) { first = false; return "network-error"; } // server committed, but the reply was lost
      return { status: 200, body: { results: b.ops.map((o) => ({ op_id: o.op_id, status: "APPLIED" })) } };
    });
    const eng = new SyncEngine(async () => "tok", server.fn);
    expect(await eng.pushOnce()).toBe(false);
    expect(await eng.pushOnce()).toBe(true);
    expect(seen[0]).toBe(seen[1]); // same op id both times -> server applies it once
    expect(await (await db()).count("outbox")).toBe(0);
  });

  it("forced offline mode never calls the network", async () => {
    await enqueue(makeOp("sale", { id: "y" }, "y"));
    const server = fakeServer(() => ({ status: 200, body: { results: [] } }));
    const eng = new SyncEngine(async () => "tok", server.fn);
    await eng.setForcedOffline(true);
    expect(await eng.pushOnce()).toBe(false);
    expect(server.calls.length).toBe(0);
  });
});
