import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { formatEthiopian } from "../lib/ethiopian";
import { centsToStr, fmt, qtyStr, toCents, toMilli } from "../lib/money";
import { ago, Modal, useTheme, useToast } from "../lib/ui";
import { db, makeOp, uuid } from "./db";
import { t, type Lang } from "./i18n";
import { ApprovalPin, CashModal, CloseShiftModal, DiscountModal, ModifierPicker, PaymentModal, Receipt, RefundModal, SyncCentre } from "./modals";
import { cartTotals, engine, finalizeSale, lineCalc, unitPriceWithMods } from "./store";
import type { Bootstrap, CartLine, Cashier, LocalSale, Modifier, PaymentEntry, Product, Shift, Tab } from "./types";

const TABLES = Array.from({ length: 12 }, (_, i) => `T${i + 1}`);

export function Sell({ boot, setBoot, cashier, shift, lang, setLang, onLock, onShiftClosed }: {
  boot: Bootstrap; setBoot: (b: Bootstrap) => void; cashier: Cashier; shift: Shift; lang: Lang; setLang: (l: Lang) => void;
  onLock: () => void; onShiftClosed: () => void;
}) {
  const toast = useToast();
  const [, toggleTheme] = useTheme();
  const isCafe = boot.terminal.kind === "CAFE";
  const [lines, setLines] = useState<CartLine[]>([]);
  const [selKey, setSelKey] = useState<string | null>(null);
  const [cat, setCat] = useState<number | "all">("all");
  const [q, setQ] = useState("");
  const [orderType, setOrderType] = useState(isCafe ? "DINE_IN" : "RETAIL");
  const [table, setTable] = useState(isCafe ? "T1" : "");
  const [tabsWithItems, setTabsWithItems] = useState<string[]>([]);
  const [sync, setSync] = useState(engine.state);
  const [modal, setModal] = useState<null | "pay" | "refund" | "close" | "sync" | "cash" | "held" | "discount" | "approveDiscount" | "tables">(null);
  const [modsFor, setModsFor] = useState<Product | null>(null);
  const [receipt, setReceipt] = useState<LocalSale | null>(null);
  const [discountApprover, setDiscountApprover] = useState<number | undefined>();
  const [pendingDiscount, setPendingDiscount] = useState<number | null>(null);
  const [held, setHeld] = useState<{ id: string; lines: CartLine[]; at: string; label: string }[]>([]);
  const searchRef = useRef<HTMLInputElement>(null);

  useEffect(() => engine.subscribe(setSync), []);

  // ---- café tabs persist per table so an order survives refreshes and power cuts
  const tabLabel = isCafe ? (orderType === "TAKEAWAY" ? "TAKEAWAY" : table) : "";
  useEffect(() => {
    if (!isCafe) return;
    void (async () => {
      const tab = await (await db()).get("tabs", tabLabel);
      setLines(tab?.lines ?? []);
      setSelKey(null);
    })();
  }, [isCafe, tabLabel]);
  const persistTab = useCallback(async (ls: CartLine[]) => {
    if (!isCafe) return;
    const d = await db();
    if (ls.length) {
      const tab: Tab = { label: tabLabel, order_type: orderType, lines: ls, opened_at: new Date().toISOString(), updated_at: new Date().toISOString() };
      await d.put("tabs", tab);
    } else await d.delete("tabs", tabLabel);
    setTabsWithItems((await d.getAll("tabs")).map((x) => x.label));
  }, [isCafe, tabLabel, orderType]);
  useEffect(() => { void (async () => setTabsWithItems((await (await db()).getAll("tabs")).map((x) => x.label)))(); }, []);

  const update = useCallback((fn: (ls: CartLine[]) => CartLine[]) => {
    setLines((prev) => {
      const next = fn(prev);
      void persistTab(next);
      return next;
    });
  }, [persistTab]);

  const products = useMemo(() => {
    const term = q.trim().toLowerCase();
    return boot.products.filter((p) => (cat === "all" || p.category_id === cat) &&
      (!term || p.name.toLowerCase().includes(term) || p.sku.toLowerCase().includes(term) || p.barcode === term || p.name_local.includes(term)));
  }, [boot.products, cat, q]);

  const addProduct = useCallback((p: Product, mods: Modifier[] = []) => {
    const unitPrice = unitPriceWithMods(p, mods);
    const sig = `${p.id}|${mods.map((m) => m.id).sort().join(",")}`;
    update((ls) => {
      const i = ls.findIndex((l) => `${l.product.id}|${l.modifiers.map((m) => m.id).sort().join(",")}` === sig && toCents(l.discount) === 0);
      if (i >= 0) {
        const copy = [...ls];
        copy[i] = { ...copy[i], qty: qtyStr(toMilli(copy[i].qty) + 1000) };
        setSelKey(copy[i].key);
        return copy;
      }
      const line: CartLine = { key: uuid(), product: p, qty: "1", unitPrice, discount: "0", modifiers: mods, note: "" };
      setSelKey(line.key);
      return [...ls, line];
    });
  }, [update]);

  const tapProduct = (p: Product) => (p.modifiers.length ? setModsFor(p) : addProduct(p));

  // ---- barcode scanner (keyboard wedge): fast keystrokes ending in Enter
  useEffect(() => {
    let buf = "", last = 0;
    const h = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (modal || (target && ["INPUT", "TEXTAREA"].includes(target.tagName) && target !== searchRef.current)) return;
      const now = Date.now();
      if (now - last > 60) buf = "";
      last = now;
      if (e.key === "Enter" && buf.length >= 6) {
        const p = boot.products.find((x) => x.barcode === buf || x.sku === buf);
        if (p) { addProduct(p); toast(`Scanned ${p.name}`); } else toast(`Unknown barcode ${buf}`, "bad");
        buf = "";
        e.preventDefault();
      } else if (/^[0-9A-Za-z-]$/.test(e.key)) buf += e.key;
      if (e.key === "F2") { e.preventDefault(); searchRef.current?.focus(); }
      if (e.key === "F9" && lines.length) { e.preventDefault(); setModal("pay"); }
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [boot.products, addProduct, toast, modal, lines.length]);

  const totals = cartTotals(lines);
  const sel = lines.find((l) => l.key === selKey) ?? null;
  const maxPct = Number(boot.settings.max_discount_pct || 0);
  const canOverride = cashier.permissions.includes("pos.discount_override");

  function changeQty(l: CartLine, deltaMilli: number) {
    update((ls) => ls.flatMap((x) => {
      if (x.key !== l.key) return [x];
      const m = toMilli(x.qty) + deltaMilli;
      return m <= 0 ? [] : [{ ...x, qty: qtyStr(m) }];
    }));
  }

  function applyDiscount(cents: number) {
    if (!sel) return;
    update((ls) => ls.map((x) => (x.key === sel.key ? { ...x, discount: centsToStr(cents) } : x)));
  }

  async function sendToKitchen() {
    const pending = lines.filter((l) => l.product.station !== "NONE" && toMilli(l.qty) > toMilli(l.sentToKitchen ?? "0"));
    if (!pending.length) return toast("Nothing new to send");
    const byStation: Record<string, CartLine[]> = {};
    for (const l of pending) (byStation[l.product.station] ??= []).push(l);
    const d = await db();
    for (const [station, ls] of Object.entries(byStation)) {
      await d.add("outbox", makeOp("kitchen_ticket", {
        id: uuid(), station, order_ref: tabLabel, order_type: orderType, created_at: new Date().toISOString(),
        items: ls.map((l) => ({ name: l.product.name, qty: qtyStr(toMilli(l.qty) - toMilli(l.sentToKitchen ?? "0")),
          modifiers: l.modifiers.map((m) => m.name), note: l.note })),
      }, `Ticket ${tabLabel} → ${station}`));
    }
    update((ls) => ls.map((l) => (l.product.station !== "NONE" ? { ...l, sentToKitchen: l.qty } : l)));
    engine.kick();
    toast(`Sent to ${Object.keys(byStation).join(" & ").toLowerCase()}`, "good");
  }

  async function complete(payments: PaymentEntry[]) {
    setModal(null);
    try {
      const sale = await finalizeSale({ boot, shift, cashier, lines, payments, orderType, tableLabel: isCafe ? tabLabel : "",
        discountApproverId: discountApprover, online: sync.online && !sync.forcedOffline });
      setReceipt(sale);
      setLines([]); setSelKey(null); setDiscountApprover(undefined);
      if (isCafe) await persistTab([]);
      engine.kick();
    } catch (e) {
      toast(`Could not save the sale: ${e instanceof Error ? e.message : e}`, "bad");
    }
  }

  async function hold() {
    if (!lines.length) return;
    await (await db()).put("held", { id: uuid(), lines, at: new Date().toISOString(), label: `${lines.length} item(s) · ${fmt(totals.total)}` });
    setLines([]); toast("Sale held");
  }
  async function openHeld() { setHeld(await (await db()).getAll("held")); setModal("held"); }

  const lowStock = (p: Product) => p.is_stocked && p.stock !== null && p.stock <= 5;
  const pill = sync.forcedOffline || !sync.online ? "offline" : sync.lastError ? "error" : "online";

  return (
    <div className="pos">
      <div className="pos-top">
        <div className="brand">Yummy<span>.</span></div>
        <div className="who">{boot.branch.name} · {boot.terminal.code}<br />{cashier.name} · {formatEthiopian(new Date(), lang)}</div>
        <button className={`syncpill ${pill} right`} onClick={() => setModal("sync")} title="Sync centre">
          <span className="dot" />
          {pill === "online" ? t(lang, "Online") : t(lang, "Offline")}
          {sync.pending > 0 && <span>· {sync.pending} {t(lang, "pending")}</span>}
          {sync.rejected > 0 && <span>· {sync.rejected} ⚠</span>}
        </button>
        <button onClick={() => setModal("refund")}>{t(lang, "Refund")}</button>
        <button onClick={() => setModal("cash")}>Cash</button>
        {!isCafe && <button onClick={openHeld}>Held</button>}
        <button onClick={() => setModal("close")}>{t(lang, "Close shift")}</button>
        <button onClick={() => setLang(lang === "en" ? "am" : "en")}>{lang === "en" ? "አማ" : "EN"}</button>
        <button onClick={toggleTheme} title="Light / dark theme">☾</button>
        <button onClick={onLock}>{t(lang, "Lock")}</button>
      </div>
      <div className="pos-main">
        <div className="pos-left">
          <input ref={searchRef} value={q} onChange={(e) => setQ(e.target.value)} placeholder={`${t(lang, "Search or scan barcode")} (F2)`}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                const exact = boot.products.find((p) => p.barcode === q.trim() || p.sku.toLowerCase() === q.trim().toLowerCase());
                const pick = exact ?? (products.length === 1 ? products[0] : null);
                if (pick) { tapProduct(pick); setQ(""); }
              }
            }} />
          <div className="cats">
            <button className={cat === "all" ? "on" : ""} onClick={() => setCat("all")}>{t(lang, "All")}</button>
            {boot.categories.map((c) => <button key={c.id} className={cat === c.id ? "on" : ""} onClick={() => setCat(c.id)}>{c.name}</button>)}
          </div>
          <div className="grid">
            {products.map((p) => (
              <button key={p.id} className="ptile" style={{ ["--tile" as string]: p.color }} onClick={() => tapProduct(p)}>
                {p.is_stocked && p.stock !== null && <span className={`stock ${lowStock(p) ? "low" : ""}`} title="On hand at last sync">{Math.max(0, Math.floor(p.stock))}</span>}
                <span><div className="pname">{lang === "am" && p.name_local ? p.name_local : p.name}</div>
                  <div className="plocal">{lang === "am" ? p.name : p.name_local}</div></span>
                <span className="pprice">{fmt(toCents(p.price))}</span>
              </button>
            ))}
            {products.length === 0 && <p className="muted">No products match.</p>}
          </div>
        </div>
        <div className="cart">
          <div className="cart-head">
            {isCafe ? (
              <>
                <button className={orderType === "DINE_IN" ? "primary" : ""} onClick={() => setOrderType("DINE_IN")}>{t(lang, "Dine-in")}</button>
                <button className={orderType === "TAKEAWAY" ? "primary" : ""} onClick={() => setOrderType("TAKEAWAY")}>{t(lang, "Takeaway")}</button>
                {orderType === "DINE_IN" && <button onClick={() => setModal("tables")}>Table {table} ▾</button>}
              </>
            ) : <b>Current sale</b>}
            <span className="right muted small">{lines.length} item(s)</span>
          </div>
          <div className="cart-lines">
            {lines.length === 0 ? (
              <div className="empty"><div className="big">🥐</div><b>{t(lang, "Cart is empty")}</b><div>{t(lang, "Tap a product to start a sale")}</div></div>
            ) : lines.map((l) => {
              const c = lineCalc(l);
              return (
                <div key={l.key} className={`cline ${l.key === selKey ? "sel" : ""}`} onClick={() => setSelKey(l.key)}>
                  <div>
                    <div style={{ fontWeight: 600 }}>{l.product.name}</div>
                    <div className="meta">{l.qty} × {fmt(toCents(l.unitPrice))}{l.modifiers.length ? ` · ${l.modifiers.map((m) => m.name).join(", ")}` : ""}
                      {c.discount ? ` · −${fmt(c.discount)}` : ""}{l.sentToKitchen ? ` · sent ${l.sentToKitchen}` : ""}</div>
                    {l.key === selKey && (
                      <div className="qtybtns" onClick={(e) => e.stopPropagation()}>
                        <button onClick={() => changeQty(l, -1000)} aria-label="Decrease">−</button>
                        <button onClick={() => changeQty(l, 1000)} aria-label="Increase">+</button>
                        <button onClick={() => setModal("discount")}>%</button>
                        <button className="danger" onClick={() => changeQty(l, -toMilli(l.qty))}>Remove</button>
                      </div>
                    )}
                  </div>
                  <div className="amt">{fmt(c.total)}</div>
                </div>
              );
            })}
          </div>
          <div className="cart-foot">
            <div className="totals">
              <span className="muted">{t(lang, "Subtotal")}</span><span>{fmt(totals.gross)}</span>
              {totals.discount > 0 && <><span className="muted">{t(lang, "Discount")}</span><span>−{fmt(totals.discount)}</span></>}
              <span className="muted">{t(lang, "VAT")} (incl.)</span><span>{fmt(totals.tax)}</span>
              <span className="grand">{t(lang, "Total")}</span><span className="grand">{fmt(totals.total)}</span>
            </div>
            <div className="row">
              {isCafe ? <button className="grow" disabled={!lines.length} onClick={sendToKitchen}>{t(lang, "Send to kitchen")}</button>
                : <button className="grow" disabled={!lines.length} onClick={hold}>{t(lang, "Hold")}</button>}
              <button className="grow" disabled={!lines.length} onClick={() => { if (confirm("Clear this order?")) update(() => []); }}>{t(lang, "Clear")}</button>
            </div>
            <button className="accent lg" disabled={!lines.length} onClick={() => setModal("pay")}>{t(lang, "Charge")} · ETB {fmt(totals.total)} (F9)</button>
          </div>
        </div>
      </div>

      {modsFor && <ModifierPicker product={modsFor} onClose={() => setModsFor(null)} onAdd={(m) => { addProduct(modsFor, m); setModsFor(null); }} />}
      {modal === "pay" && <PaymentModal total={totals.total} methods={boot.payment_methods} onClose={() => setModal(null)} onDone={complete} />}
      {modal === "discount" && sel && (
        <DiscountModal lineGross={lineCalc(sel).gross} maxPct={maxPct} onClose={() => setModal(null)} onApply={(cents, needs) => {
          if (needs && !canOverride) { setPendingDiscount(cents); setModal("approveDiscount"); return; }
          if (needs && canOverride) setDiscountApprover(cashier.id);
          applyDiscount(cents); setModal(null);
        }} />
      )}
      {modal === "approveDiscount" && (
        <ApprovalPin cashiers={boot.cashiers} permission="pos.discount_override" title="Approve discount" onClose={() => setModal(null)}
          onApproved={(c) => { setDiscountApprover(c.id); if (pendingDiscount !== null) applyDiscount(pendingDiscount); setModal(null); toast(`Discount approved by ${c.name}`, "good"); }} />
      )}
      {modal === "refund" && <RefundModal boot={boot} shift={shift} cashier={cashier} onClose={() => setModal(null)} />}
      {modal === "cash" && <CashModal shift={shift} cashier={cashier} onClose={() => setModal(null)} />}
      {modal === "close" && <CloseShiftModal shift={shift} cashier={cashier} boot={boot} onClose={() => setModal(null)} onClosed={onShiftClosed} />}
      {modal === "sync" && <SyncCentre boot={boot} onClose={() => setModal(null)} onCatalog={setBoot} />}
      {modal === "tables" && (
        <Modal title={t(lang, "Tables")} onClose={() => setModal(null)}>
          <div className="paygrid">
            {TABLES.map((x) => <button key={x} className={x === table ? "on" : ""} onClick={() => { setTable(x); setModal(null); }}>
              {x}{tabsWithItems.includes(x) ? " ●" : ""}</button>)}
          </div>
          <p className="muted small" style={{ marginTop: 10 }}>● = open order. Orders are saved on this device until paid.</p>
        </Modal>
      )}
      {modal === "held" && (
        <Modal title="Held sales" onClose={() => setModal(null)}>
          {held.length === 0 ? <p className="muted">No held sales.</p> : held.map((h) => (
            <div key={h.id} className="row" style={{ padding: "8px 0", borderBottom: "1px solid var(--line)" }}>
              <span>{h.label}</span><span className="muted small">{ago(h.at)}</span>
              <button className="right primary" onClick={async () => { await (await db()).delete("held", h.id); setLines(h.lines); setModal(null); }}>Resume</button>
            </div>))}
        </Modal>
      )}
      {receipt && (
        <Modal title={<>{t(lang, "Receipt")} {receipt.offline && <span className="badge warn">saved offline</span>}</>} onClose={() => setReceipt(null)}>
          <Receipt sale={receipt} boot={boot} />
          <div className="row" style={{ marginTop: 14 }}>
            <button className="grow" onClick={() => window.print()}>{t(lang, "Print")}</button>
            <button className="accent grow lg" autoFocus onClick={() => setReceipt(null)}>{t(lang, "New sale")}</button>
          </div>
        </Modal>
      )}
    </div>
  );
}
