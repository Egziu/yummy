/**
 * Store-and-forward sync engine.
 *
 * - The outbox is uploaded strictly in order (IndexedDB auto-increment key).
 * - APPLIED: removed from the outbox (and the local sale marked synced).
 * - REJECTED: moved to the "rejected" store, surfaced to staff, kept for the manager. Never silently dropped.
 * - RETRY / network error: kept; retried with exponential backoff.
 * Every operation carries a UUID, so re-sending after a lost response is harmless (server is idempotent).
 */
import { db, kvGet, kvSet } from "./db";
import type { Bootstrap, RejectedOp } from "./types";

export interface SyncState {
  online: boolean;
  forcedOffline: boolean;
  syncing: boolean;
  pending: number;
  rejected: number;
  lastSyncAt: string | null;
  lastCatalogAt: string | null;
  lastError: string | null;
}

type Listener = (s: SyncState) => void;
type FetchFn = typeof fetch;

export class SyncEngine {
  state: SyncState = {
    online: typeof navigator === "undefined" ? true : navigator.onLine, forcedOffline: false, syncing: false,
    pending: 0, rejected: 0, lastSyncAt: null, lastCatalogAt: null, lastError: null,
  };
  private listeners = new Set<Listener>();
  private timer: ReturnType<typeof setTimeout> | null = null;
  private backoffMs = 2000;
  private running = false;
  private fetchFn: FetchFn;
  batchSize = 50;

  constructor(private token: () => Promise<string | undefined>, fetchFn?: FetchFn, private base = "") {
    this.fetchFn = fetchFn ?? ((...a) => fetch(...a));
  }

  subscribe(fn: Listener) {
    this.listeners.add(fn);
    fn(this.state);
    return () => { this.listeners.delete(fn); };
  }

  private set(patch: Partial<SyncState>) {
    this.state = { ...this.state, ...patch };
    this.listeners.forEach((l) => l(this.state));
  }

  async init() {
    const d = await db();
    this.set({
      forcedOffline: Boolean(await kvGet<boolean>("forcedOffline")),
      lastSyncAt: (await kvGet<string>("lastSyncAt")) ?? null,
      lastCatalogAt: (await kvGet<string>("bootstrapAt")) ?? null,
      pending: await d.count("outbox"),
      rejected: await d.count("rejected"),
    });
  }

  start() {
    if (this.running) return;
    this.running = true;
    if (typeof window !== "undefined") {
      window.addEventListener("online", () => this.kick());
      window.addEventListener("offline", () => this.set({ online: false }));
    }
    void this.loop();
  }

  stop() {
    this.running = false;
    if (this.timer) clearTimeout(this.timer);
  }

  /** Try to sync now (after a sale, when the network returns, or when staff tap "Sync now"). */
  kick() {
    if (this.timer) clearTimeout(this.timer);
    this.backoffMs = 2000;
    void this.loop();
  }

  async setForcedOffline(v: boolean) {
    await kvSet("forcedOffline", v);
    this.set({ forcedOffline: v, online: v ? false : this.state.online });
    if (!v) this.kick();
  }

  private async loop() {
    if (this.timer) clearTimeout(this.timer);
    let delay = 15000;
    try {
      const ok = await this.pushOnce();
      if (ok) {
        this.backoffMs = 2000;
        const left = (await db()).count("outbox");
        delay = (await left) > 0 ? 300 : 15000;
        const lastCat = this.state.lastCatalogAt ? Date.parse(this.state.lastCatalogAt) : 0;
        if (Date.now() - lastCat > 5 * 60_000) await this.refreshCatalog().catch(() => undefined);
      } else {
        delay = this.backoffMs;
        this.backoffMs = Math.min(this.backoffMs * 2, 60_000);
      }
    } catch {
      delay = this.backoffMs;
    }
    if (this.running) this.timer = setTimeout(() => void this.loop(), delay);
  }

  private async headers(): Promise<Record<string, string>> {
    const t = await this.token();
    return { "Content-Type": "application/json", ...(t ? { "X-Terminal-Token": t } : {}) };
  }

  private async request(path: string, init: RequestInit, timeoutMs = 15000) {
    const ctrl = typeof AbortController !== "undefined" ? new AbortController() : null;
    const timer = ctrl ? setTimeout(() => ctrl.abort(), timeoutMs) : null;
    try {
      return await this.fetchFn(this.base + path, { ...init, headers: await this.headers(), signal: ctrl?.signal });
    } finally {
      if (timer) clearTimeout(timer);
    }
  }

  /** Upload one batch. Returns false when offline/failed (caller backs off). */
  async pushOnce(): Promise<boolean> {
    const d = await db();
    const pending = await d.count("outbox");
    this.set({ pending });
    if (this.state.forcedOffline) {
      this.set({ online: false });
      return false;
    }
    const ops = await d.getAll("outbox", undefined, this.batchSize);
    this.set({ syncing: ops.length > 0 });
    let res: Response;
    try {
      res = ops.length
        ? await this.request("/api/pos/sync", {
          method: "POST",
          body: JSON.stringify({
            pending_count: pending,
            ops: ops.map((o) => ({ op_id: o.op_id, kind: o.kind, created_at: o.created_at, payload: o.payload })),
          }),
        })
        : await this.request("/api/pos/heartbeat", { method: "POST", body: JSON.stringify({ pending_count: 0, app_version: "1.0.0" }) });
    } catch (e) {
      this.set({ online: false, syncing: false, lastError: "Network unavailable - working offline" });
      return false;
    }
    if (res.status === 401 || res.status === 403) {
      this.set({ online: true, syncing: false, lastError: "This terminal is not authorised (revoked?) - contact a manager" });
      return false;
    }
    if (!res.ok) {
      this.set({ online: true, syncing: false, lastError: `Server error ${res.status} - will retry` });
      return false;
    }
    const body = await res.json();
    const results: { op_id: string; status: string; error?: string; detail?: string }[] = body.results ?? [];
    const byId = new Map(ops.map((o) => [o.op_id, o]));
    const tx = d.transaction(["outbox", "rejected", "sales"], "readwrite");
    let stop = false;
    for (const r of results) {
      const op = byId.get(r.op_id);
      if (!op || op.seq === undefined) continue;
      if (r.status === "APPLIED") {
        await tx.objectStore("outbox").delete(op.seq);
        if (op.kind === "sale") await markSale(tx.objectStore("sales"), String(op.payload.id), "synced");
      } else if (r.status === "REJECTED") {
        const rej: RejectedOp = { ...op, error: r.error ?? "rejected", detail: r.detail ?? "", rejected_at: new Date().toISOString() };
        await tx.objectStore("rejected").put(rej);
        await tx.objectStore("outbox").delete(op.seq);
        if (op.kind === "sale") await markSale(tx.objectStore("sales"), String(op.payload.id), "rejected", r.detail);
      } else {
        await tx.objectStore("outbox").put({ ...op, attempts: op.attempts + 1, last_error: r.detail });
        stop = true;
        break;
      }
    }
    await tx.done;
    const now = new Date().toISOString();
    if (ops.length) await kvSet("lastSyncAt", now);
    this.set({
      online: true, syncing: false, lastError: stop ? "Some operations are waiting - retrying" : null,
      lastSyncAt: ops.length ? now : this.state.lastSyncAt,
      pending: await d.count("outbox"), rejected: await d.count("rejected"),
    });
    return !stop;
  }

  async refreshCatalog(): Promise<Bootstrap | null> {
    if (this.state.forcedOffline) return null;
    const res = await this.request("/api/pos/bootstrap", { method: "GET" });
    if (!res.ok) throw new Error(`bootstrap ${res.status}`);
    const data = (await res.json()) as Bootstrap;
    const local = ((await kvGet<number>("receiptSeq")) ?? 0);
    if (data.last_receipt_seq > local) await kvSet("receiptSeq", data.last_receipt_seq);
    await kvSet("bootstrap", data);
    const now = new Date().toISOString();
    await kvSet("bootstrapAt", now);
    this.set({ lastCatalogAt: now, online: true });
    return data;
  }

  async dismissRejected(opId: string) {
    await (await db()).delete("rejected", opId);
    this.set({ rejected: await (await db()).count("rejected") });
  }
}

async function markSale(store: { get: (k: string) => Promise<unknown>; put: (v: never) => Promise<unknown> },
  id: string, status: "synced" | "rejected", error?: string) {
  const s = (await store.get(id)) as Record<string, unknown> | undefined;
  if (s) await store.put({ ...s, status, error } as never);
}
