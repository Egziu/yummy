import { useCallback, useEffect, useState } from "react";
import { Keypad, initials, useTheme, useToast } from "../lib/ui";
import { db, kvGet, kvSet, makeOp } from "./db";
import { t, type Lang } from "./i18n";
import { verifyPin } from "./pin";
import { engine } from "./store";
import { Sell } from "./Sell";
import { KdsBoard } from "../kds/KdsBoard";
import type { Bootstrap, Cashier, Shift } from "./types";

type Phase = "loading" | "enroll" | "login" | "open" | "sell";

export function PosApp() {
  const toast = useToast();
  const [phase, setPhase] = useState<Phase>("loading");
  const [boot, setBoot] = useState<Bootstrap | null>(null);
  const [cashier, setCashier] = useState<Cashier | null>(null);
  const [shift, setShift] = useState<Shift | null>(null);
  const [lang, setLang] = useState<Lang>("en");
  useTheme();

  const load = useCallback(async () => {
    const token = await kvGet<string>("deviceToken");
    if (!token) return setPhase("enroll");
    await engine.init();
    engine.start();
    let b = await kvGet<Bootstrap>("bootstrap");
    try { b = (await engine.refreshCatalog()) ?? b; } catch { /* offline: use cached catalogue */ }
    if (!b) { toast("No catalogue cached yet and the server is unreachable", "bad"); return setPhase("enroll"); }
    setBoot(b);
    setShift((await kvGet<Shift | null>("shift")) ?? null);
    setPhase("login");
  }, [toast]);

  useEffect(() => { void load(); }, [load]);
  useEffect(() => {
    if ("serviceWorker" in navigator && import.meta.env.PROD) void navigator.serviceWorker.register("/sw.js");
  }, []);

  if (phase === "loading") return <div className="landing"><div className="skeleton" style={{ width: 240, height: 24 }} /></div>;
  if (phase === "enroll") return <Enroll onDone={load} />;
  if (!boot) return null;
  if (boot.terminal.kind === "KDS") return <KdsBoard boot={boot} />;
  if (phase === "login" || !cashier) {
    return <Login boot={boot} lang={lang} setLang={setLang} openShift={shift} onLogin={(c) => {
      setCashier(c);
      if (shift && shift.cashier_id !== c.id && !c.permissions.includes("pos.shift_approve")) {
        toast(`A shift opened by ${shift.cashier_name} is still open. They (or a manager) must close it first.`, "bad");
        setCashier(null);
        return;
      }
      setPhase(shift ? "sell" : "open");
    }} />;
  }
  if (phase === "open" || !shift) {
    return <OpenShift boot={boot} cashier={cashier} lang={lang} onOpened={(s) => { setShift(s); setPhase("sell"); }}
      onBack={() => { setCashier(null); setPhase("login"); }} />;
  }
  return <Sell boot={boot} setBoot={setBoot} cashier={cashier} shift={shift} lang={lang} setLang={setLang}
    onLock={() => { setCashier(null); setPhase("login"); }}
    onShiftClosed={() => { setShift(null); setCashier(null); setPhase("login"); toast("Shift closed. Goodbye!", "good"); }} />;
}

function Enroll({ onDone }: { onDone: () => void }) {
  const [code, setCode] = useState("");
  const [enroll, setEnroll] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true); setErr("");
    try {
      const res = await fetch("/api/terminals/enroll", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ terminal_code: code.trim().toUpperCase(), enrollment_code: enroll.trim(), app_version: "1.0.0" }),
      });
      const body = await res.json();
      if (!res.ok) throw new Error(body.detail ?? "Enrollment failed");
      await kvSet("deviceToken", body.device_token);
      await kvSet("terminal", body.terminal);
      onDone();
    } catch (e2) {
      setErr(e2 instanceof Error ? e2.message : "Cannot reach the server - enrollment needs internet once");
    } finally { setBusy(false); }
  }
  return (
    <div className="landing">
      <form className="card pad col" style={{ width: "min(420px, 100%)", gap: 14 }} onSubmit={submit}>
        <div className="wordmark">Yummy<span>.</span>POS</div>
        <p className="muted">Enrol this device once (internet required). A manager creates the one-time code in the back office → Sync monitor.</p>
        <label className="field">Terminal code<input value={code} onChange={(e) => setCode(e.target.value)} placeholder="SHOP1-T1" required /></label>
        <label className="field">8-digit enrolment code<input value={enroll} inputMode="numeric" pattern="\d{8}" onChange={(e) => setEnroll(e.target.value)} required /></label>
        {err && <p style={{ color: "var(--bad)" }}>{err}</p>}
        <button className="primary lg" disabled={busy}>{busy ? "Enrolling…" : "Enrol terminal"}</button>
      </form>
    </div>
  );
}

function Login({ boot, lang, setLang, openShift, onLogin }: {
  boot: Bootstrap; lang: Lang; setLang: (l: Lang) => void; openShift: Shift | null; onLogin: (c: Cashier) => void;
}) {
  const [who, setWho] = useState<Cashier | null>(null);
  const [pin, setPin] = useState("");
  const [err, setErr] = useState("");
  const [tries, setTries] = useState(0);
  const [lockedUntil, setLockedUntil] = useState(0);
  const sellers = boot.cashiers.filter((c) => c.permissions.includes("pos.sell"));
  async function key(k: string) {
    if (!who || Date.now() < lockedUntil) return;
    if (k === "C") return setPin("");
    if (k === "⌫") return setPin((p) => p.slice(0, -1));
    const next = (pin + k).slice(0, 8);
    setPin(next); setErr("");
    if (next.length >= 4 && await verifyPin(who, next)) onLogin(who);  // auto sign-in on a correct PIN
  }
  async function submit() {
    if (!who) return;
    if (await verifyPin(who, pin)) return onLogin(who);
    const n = tries + 1;
    setTries(n); setPin("");
    if (n >= 5) { setLockedUntil(Date.now() + 60_000); setErr("Too many wrong PINs - wait one minute"); setTries(0); }
    else setErr("Wrong PIN");
  }
  return (
    <div className="landing">
      <div className="card pad col" style={{ width: "min(760px, 100%)", gap: 16 }}>
        <div className="row">
          <div className="wordmark" style={{ fontSize: 30 }}>Yummy<span>.</span></div>
          <div className="muted">{boot.branch.name} · {boot.terminal.code}</div>
          <button className="right ghost" onClick={() => setLang(lang === "en" ? "am" : "en")}>{lang === "en" ? "አማርኛ" : "English"}</button>
        </div>
        {openShift && <div className="badge warn">Open shift: {openShift.cashier_name} since {new Date(openShift.opened_at).toLocaleTimeString("en-GB")}</div>}
        {!who ? (
          <>
            <h2>{t(lang, "Who is selling?")}</h2>
            <div className="cashier-grid">
              {sellers.map((c) => (
                <button key={c.id} onClick={() => { setWho(c); setPin(""); setErr(""); }}>
                  <span className="avatar">{initials(c.name)}</span><span>{c.name}</span>
                </button>
              ))}
            </div>
            {sellers.length === 0 && <p className="muted">No cashiers with a PIN are assigned to this branch yet.</p>}
          </>
        ) : (
          <div className="col" style={{ maxWidth: 340, margin: "0 auto", width: "100%" }}>
            <div className="row"><span className="avatar">{initials(who.name)}</span><b>{who.name}</b><button className="right ghost" onClick={() => setWho(null)}>Change</button></div>
            <h3 className="center">{t(lang, "Enter PIN")}</h3>
            <div className="pin-dots">{Array.from({ length: Math.max(4, pin.length) }).map((_, i) => <span key={i} className={i < pin.length ? "on" : ""} />)}</div>
            {err && <p className="center" style={{ color: "var(--bad)" }}>{err}</p>}
            <Keypad onKey={key} extra="C" />
            <button className="primary lg" onClick={submit} disabled={pin.length < 4}>{t(lang, "Sign in")}</button>
            <p className="muted small center">Works offline — the PIN is checked on this device.</p>
          </div>
        )}
      </div>
    </div>
  );
}

function OpenShift({ boot, cashier, lang, onOpened, onBack }: {
  boot: Bootstrap; cashier: Cashier; lang: Lang; onOpened: (s: Shift) => void; onBack: () => void;
}) {
  const [amount, setAmount] = useState("500");
  async function open() {
    const s: Shift = { id: crypto.randomUUID(), cashier_id: cashier.id, cashier_name: cashier.name,
      opened_at: new Date().toISOString(), opening_float: amount || "0" };
    const d = await db();
    const tx = d.transaction(["kv", "outbox"], "readwrite");
    await tx.objectStore("outbox").add(makeOp("shift_open", {
      shift_id: s.id, cashier_id: cashier.id, opening_float: s.opening_float, opened_at: s.opened_at,
    }, `Open shift · ${cashier.name}`));
    await tx.objectStore("kv").put(s, "shift");
    await tx.done;
    engine.kick();
    onOpened(s);
  }
  return (
    <div className="landing">
      <div className="card pad col" style={{ width: "min(380px, 100%)" }}>
        <h2>{t(lang, "Open shift")}</h2>
        <p className="muted">{cashier.name} · {boot.terminal.name}. Count the opening float in the drawer.</p>
        <div className="row" style={{ alignItems: "baseline" }}><span className="muted">{t(lang, "Opening cash")}</span>
          <span className="right num" style={{ fontSize: 30, fontWeight: 750 }}>ETB {amount || "0"}</span></div>
        <Keypad extra="." onKey={(k) => setAmount((x) => (k === "⌫" ? x.slice(0, -1) : k === "C" ? "" : (x + k).slice(0, 9)))} />
        <div className="row"><button onClick={onBack}>Back</button><button className="accent lg grow" onClick={open}>{t(lang, "Open shift")}</button></div>
      </div>
    </div>
  );
}
