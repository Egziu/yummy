import { useState } from "react";
import { money, fmt, toCents } from "../lib/money";
import { Badge } from "../lib/ui";
import { download, useApi } from "./api";
import { BarList, Heatmap, StackedBars } from "./charts";
import { can, useMe } from "./Office";

interface K { sales: string; net_sales: string; gross_profit: string; gross_margin_pct: string; transactions: number; avg_ticket: string; discounts: string; refunds: string }
interface Dash {
  generated_at: string; ethiopian_date: string; data_status: string; pending_sync_ops: number; stale_terminals: number;
  kpis: { today: K; yesterday: K; week: K; month: K }; inventory_value: string; payables_outstanding: string;
  trend: Record<string, string>[]; branches: { code: string; name: string; kind: string; month: K; today: K }[];
  top_products: { name: string; sku: string; qty: string; revenue: string; margin_pct: string }[];
  heatmap: { dow: number; hour: number; total: string }[]; production_today: { orders: number; output: string; scrap: string };
  expiring: { product: string; lot: string; expiry: string; expired: boolean; branch: string; qty: string; value: string }[];
  approvals: Record<string, number>; open_discrepancies: number; ledger_balanced: boolean;
  briefing: { kind: string; text: string }[]; definitions: Record<string, string>;
}

function Delta({ now, before }: { now: string; before: string }) {
  const a = toCents(now), b = toCents(before);
  if (!b) return <div className="delta muted">—</div>;
  const pct = ((a - b) / b) * 100;
  return <div className={`delta ${pct >= 0 ? "up" : "down"}`}>{pct >= 0 ? "▲" : "▼"} {Math.abs(pct).toFixed(0)}% vs yesterday (full day)</div>;
}

export function Dashboard() {
  const me = useMe();
  const [branch, setBranch] = useState("");
  const { data: d, error } = useApi<Dash>(`reports/dashboard?days=14${branch ? `&branch=${branch}` : ""}`, 30000);
  if (error) return <p className="badge bad">{error}</p>;
  if (!d) return <div className="kpis">{[1, 2, 3, 4].map((i) => <div key={i} className="card kpi"><div className="skeleton" style={{ height: 50 }} /></div>)}</div>;
  const keys = d.branches.map((b) => b.code);
  const k = d.kpis;
  return (
    <>
      <div className="page-head">
        <div>
          <h1>Good {new Date().getHours() < 12 ? "morning" : new Date().getHours() < 17 ? "afternoon" : "evening"}, {me.name.split(" ")[0]}</h1>
          <div className="sub">{new Date().toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long", year: "numeric" })} · {d.ethiopian_date}</div>
        </div>
        <div className="right row">
          {d.data_status === "live" ? <Badge kind="good"><span className="dot" /> Live data</Badge>
            : <Badge kind="warn" ><span className="dot" /> Provisional · {d.pending_sync_ops} ops pending, {d.stale_terminals} terminal(s) silent</Badge>}
          <select value={branch} onChange={(e) => setBranch(e.target.value)} style={{ width: 190 }} aria-label="Branch filter">
            <option value="">All outlets</option>
            {d.branches.map((b) => <option key={b.code} value={b.code}>{b.name}</option>)}
          </select>
          {can(me, "reports.export") && <button onClick={() => download("reports/export/sales.csv", "yummy-sales.csv")}>Export sales CSV</button>}
        </div>
      </div>

      <div className="kpis">
        <div className="card kpi" title={d.definitions.sales}><div className="label">Sales today</div><div className="value">{money(k.today.sales)}</div><Delta now={k.today.sales} before={k.yesterday.sales} /></div>
        <div className="card kpi" title={d.definitions.gross_profit}><div className="label">Gross profit · month</div><div className="value">{money(k.month.gross_profit)}</div><div className="delta muted">{k.month.gross_margin_pct}% margin on {money(k.month.net_sales)} net</div></div>
        <div className="card kpi"><div className="label">Transactions today</div><div className="value">{k.today.transactions}</div><div className="delta muted">avg ticket ETB {money(k.today.avg_ticket)}</div></div>
        <div className="card kpi" title={d.definitions.inventory_value}><div className="label">Inventory value</div><div className="value">{money(d.inventory_value)}</div><div className="delta muted">payables open ETB {money(d.payables_outstanding)}</div></div>
        <div className="card kpi"><div className="label">Sales · 7 days</div><div className="value">{money(k.week.sales)}</div><div className="delta muted">{k.week.transactions} receipts · refunds {money(k.week.refunds)}</div></div>
      </div>

      <div className="two">
        <div className="card pad"><h3>Sales by outlet · last 14 days (ETB, VAT incl.)</h3><StackedBars rows={d.trend} keys={keys} /></div>
        <div className="card pad">
          <h3>Daily briefing</h3>
          <ul className="brief">{d.briefing.map((b, i) => <li key={i} className={b.kind}>{b.text}</li>)}</ul>
          <p className="muted small">Facts come straight from posted transactions. Nothing here is a prediction.</p>
          <div className="row wrap" style={{ marginTop: 8 }}>
            <Badge kind={d.ledger_balanced ? "good" : "bad"}>{d.ledger_balanced ? "Ledger balanced" : "Ledger out of balance"}</Badge>
            {Object.entries(d.approvals).map(([kk, v]) => v > 0 && <Badge key={kk} kind="info">{v} {kk.replace("_", " ")}</Badge>)}
          </div>
        </div>
      </div>

      <div className="three">
        <div className="card pad">
          <h3>Outlet ranking · month (gross profit)</h3>
          <BarList rows={d.branches.map((b) => ({ label: b.name, value: toCents(b.month.gross_profit), note: `${fmt(toCents(b.month.gross_profit))} · ${b.month.gross_margin_pct}%` }))} />
        </div>
        <div className="card pad">
          <h3>Best sellers · 7 days</h3>
          <table className="data"><tbody>{d.top_products.map((p) => (
            <tr key={p.sku}><td>{p.name}</td><td className="num">{Number(p.qty).toFixed(0)}</td><td className="num">{money(p.revenue)}</td><td className="num muted">{p.margin_pct}%</td></tr>))}</tbody></table>
        </div>
        <div className="card pad">
          <h3>When customers buy · 7 days</h3>
          <Heatmap cells={d.heatmap} />
          <p className="muted small" style={{ marginTop: 8 }}>Production today: {d.production_today.orders} batches · {Number(d.production_today.output).toFixed(0)} units out · {Number(d.production_today.scrap).toFixed(0)} scrap</p>
        </div>
      </div>

      <div className="card pad">
        <div className="row"><h3>Expiring within 2 days</h3>{d.open_discrepancies > 0 && <Badge kind="warn">{d.open_discrepancies} open stock discrepancies</Badge>}</div>
        {d.expiring.length === 0 ? <p className="muted">Nothing close to expiry.</p> : (
          <table className="data"><thead><tr><th>Product</th><th>Lot</th><th>Branch</th><th>Expiry</th><th className="num">Qty</th><th className="num">Value at cost</th></tr></thead>
            <tbody>{d.expiring.map((e, i) => (
              <tr key={i}><td>{e.product}</td><td>{e.lot}</td><td>{e.branch}</td><td>{e.expiry} {e.expired && <Badge kind="bad">expired</Badge>}</td>
                <td className="num">{Number(e.qty).toFixed(1)}</td><td className="num">{money(e.value)}</td></tr>))}</tbody></table>)}
      </div>
    </>
  );
}
