import { useEffect, useRef, useState } from "react";
import { money } from "../lib/money";
import { ago, Badge, useToast } from "../lib/ui";
import { post, useApi } from "./api";
import { can, useMe } from "./Office";

interface Loc { id: number; code: string; name: string; kind: string; level: string; x: number; y: number; w: number; h: number;
  utilization_pct: string | null; qty: string; value: string; state: string; picks_7d: number;
  items: { sku: string; name: string; unit: string; qty: string; reserved: string; lot: string | null; expiry: string | null; on_hold: boolean }[] }
interface MapData { branch: string; locations: Loc[]; generated_at: string;
  activity: { at: string; kind: string; product: string; qty: string; location: string; doc: string; actor: string | null }[] }

const STATE: Record<string, { fill: string; label: string }> = {
  empty: { fill: "var(--surface-2)", label: "Empty" }, normal: { fill: "color-mix(in srgb, var(--good) 22%, var(--surface))", label: "Normal" },
  low: { fill: "color-mix(in srgb, var(--warn) 30%, var(--surface))", label: "Low stock" },
  near_capacity: { fill: "color-mix(in srgb, var(--info) 30%, var(--surface))", label: "Near capacity" },
  expiring: { fill: "color-mix(in srgb, var(--bad) 28%, var(--surface))", label: "Expiring soon" },
  quarantined: { fill: "repeating-linear-gradient(45deg, var(--bad-bg), var(--bad-bg) 6px, var(--surface) 6px, var(--surface) 12px)", label: "Quarantined" },
};

export function WarehouseMap() {
  const me = useMe();
  const toast = useToast();
  const { data, error, reload } = useApi<MapData>("reports/warehouse-map?branch=WH", 5000);
  const [sel, setSel] = useState<number | null>(null);
  const [heat, setHeat] = useState(false);
  const [edit, setEdit] = useState(false);
  const [drag, setDrag] = useState<{ id: number; dx: number; dy: number } | null>(null);
  const [local, setLocal] = useState<Record<number, { x: number; y: number }>>({});
  const svgRef = useRef<SVGSVGElement>(null);
  const [stale, setStale] = useState(false);
  useEffect(() => { setStale(Boolean(error)); }, [error]);

  if (!data) return error ? <p className="badge bad">{error}</p> : <div className="skeleton" style={{ height: 400 }} />;
  const locs = data.locations.map((l) => ({ ...l, ...(local[l.id] ?? {}) }));
  const zones = locs.filter((l) => l.level === "ZONE" && !["RECEIVING", "DISPATCH", "QUARANTINE"].includes(l.kind));
  const cells = locs.filter((l) => !zones.includes(l));
  const selected = locs.find((l) => l.id === sel) ?? null;
  const maxPicks = Math.max(1, ...cells.map((c) => c.picks_7d));

  function pt(e: React.PointerEvent) {
    const r = svgRef.current!.getBoundingClientRect();
    return { x: ((e.clientX - r.left) / r.width) * 720, y: ((e.clientY - r.top) / r.height) * 480 };
  }
  async function drop(id: number) {
    const p = local[id];
    setDrag(null);
    if (!p) return;
    try { await post(`inventory/locations/${id}/map`, { map_x: Math.round(p.x), map_y: Math.round(p.y) }); toast("Layout saved", "good"); reload(); }
    catch (e) { toast((e as Error).message, "bad"); }
  }

  return (
    <>
      <div className="page-head">
        <div><h1>Smart store map · Main warehouse</h1>
          <div className="sub">Every shelf is a real stock location. Colours come from the stock ledger and refresh every 5 s · {ago(data.generated_at)}</div></div>
        <div className="right row">
          {stale && <Badge kind="warn">Connection lost — showing last known state</Badge>}
          <button className={heat ? "primary" : ""} onClick={() => setHeat(!heat)}>Pick-frequency heatmap</button>
          {can(me, "inventory.map_edit") && <button className={edit ? "accent" : ""} onClick={() => setEdit(!edit)}>{edit ? "Done editing" : "Edit layout"}</button>}
        </div>
      </div>
      <div className="split">
        <div className="card pad">
          <svg ref={svgRef} viewBox="0 0 720 480" width="100%" style={{ touchAction: "none", userSelect: "none" }}
            onPointerMove={(e) => { if (drag) { const p = pt(e); setLocal({ ...local, [drag.id]: { x: p.x - drag.dx, y: p.y - drag.dy } }); } }}
            onPointerUp={() => drag && drop(drag.id)}>
            <rect x="4" y="4" width="712" height="472" rx="14" fill="none" stroke="var(--line-2)" strokeWidth="2" strokeDasharray="6 6" />
            {zones.map((z) => (
              <g key={z.id}>
                <rect x={z.x} y={z.y} width={z.w} height={z.h} rx="12" fill={z.kind === "COLD" ? "color-mix(in srgb, var(--info) 8%, transparent)" : "color-mix(in srgb, var(--accent) 6%, transparent)"} stroke="var(--line-2)" />
                <text x={z.x + 12} y={z.y + 22} fontSize="13" fontWeight="700" fill="var(--ink-2)">{z.name}</text>
                <text x={z.x + z.w - 12} y={z.y + 22} textAnchor="end" fontSize="10.5" fill="var(--muted)">ETB {money(z.value)}</text>
              </g>
            ))}
            {cells.map((c) => {
              const s = STATE[c.state] ?? STATE.normal;
              const heatFill = `color-mix(in srgb, var(--bad) ${Math.round((c.picks_7d / maxPicks) * 85)}%, var(--surface))`;
              const fill = heat ? heatFill : s.fill.startsWith("repeating") ? "var(--bad-bg)" : s.fill;
              return (
                <g key={c.id} style={{ cursor: edit ? "move" : "pointer" }}
                  onPointerDown={(e) => { if (edit) { const p = pt(e); setDrag({ id: c.id, dx: p.x - c.x, dy: p.y - c.y }); (e.target as Element).setPointerCapture?.(e.pointerId); } }}
                  onClick={() => !edit && setSel(c.id)}>
                  <rect x={c.x} y={c.y} width={c.w} height={c.h} rx="9" fill={fill}
                    stroke={sel === c.id ? "var(--ink)" : "var(--line-2)"} strokeWidth={sel === c.id ? 3 : 1.2}
                    strokeDasharray={c.state === "quarantined" ? "5 4" : undefined} />
                  <text x={c.x + 8} y={c.y + 18} fontSize="11.5" fontWeight="700" fill="var(--ink)">{c.code.replace("WH-", "")}</text>
                  {c.h > 60 && <text x={c.x + 8} y={c.y + 34} fontSize="10" fill="var(--ink-2)">{c.items.length} SKU · {Number(c.qty).toFixed(0)} u</text>}
                  {c.utilization_pct !== null && c.h > 60 && (
                    <g>
                      <rect x={c.x + 8} y={c.y + c.h - 16} width={c.w - 16} height="6" rx="3" fill="var(--surface-2)" />
                      <rect x={c.x + 8} y={c.y + c.h - 16} width={Math.min(1, Number(c.utilization_pct) / 100) * (c.w - 16)} height="6" rx="3" fill="var(--ink-2)" />
                    </g>
                  )}
                  {heat && <text x={c.x + c.w - 8} y={c.y + 18} textAnchor="end" fontSize="10" fill="var(--ink)">{c.picks_7d} picks</text>}
                  <title>{c.name} · {s.label}</title>
                </g>
              );
            })}
          </svg>
          <div className="chart-legend" style={{ marginTop: 8 }}>{Object.entries(STATE).map(([k, v]) => <span key={k}><i style={{ background: v.fill.startsWith("repeating") ? "var(--bad-bg)" : v.fill, border: "1px solid var(--line-2)" }} />{v.label}</span>)}<span>bar = capacity used</span></div>
        </div>
        <div className="col">
          <div className="card pad">
            {!selected ? <p className="muted">Select a rack or shelf to see exactly what is on it.</p> : (
              <>
                <div className="row"><h3>{selected.name}</h3><Badge>{STATE[selected.state]?.label}</Badge></div>
                <p className="muted small">{selected.code} · {selected.kind.toLowerCase()} · {selected.utilization_pct ? `${selected.utilization_pct}% of capacity` : "no capacity set"} · ETB {money(selected.value)}</p>
                <table className="data"><thead><tr><th>Item / lot</th><th className="num">Qty</th></tr></thead>
                  <tbody>{selected.items.map((i, k) => (
                    <tr key={k}><td>{i.name}<div className="small muted">{i.lot ?? "no lot"}{i.expiry ? ` · exp ${i.expiry}` : ""}{i.on_hold && " · HOLD"}</div></td>
                      <td className="num">{Number(i.qty).toFixed(1)} {i.unit}{Number(i.reserved) > 0 && <div className="small muted">{Number(i.reserved).toFixed(0)} reserved</div>}</td></tr>))}</tbody></table>
                {selected.items.length === 0 && <p className="muted">Empty.</p>}
              </>
            )}
          </div>
          <div className="card pad">
            <h3>Live activity</h3>
            <div className="scroll" style={{ maxHeight: 320 }}>
              {data.activity.map((a, i) => (
                <div key={i} className="small" style={{ padding: "6px 0", borderBottom: "1px solid var(--line)" }}>
                  <b>{a.kind}</b> · {a.product} <span className="num">{Number(a.qty) > 0 ? "+" : ""}{Number(a.qty).toFixed(1)}</span> @ {a.location}
                  <div className="muted">{a.doc} · {a.actor ?? "system"} · {ago(a.at)}</div>
                </div>))}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
