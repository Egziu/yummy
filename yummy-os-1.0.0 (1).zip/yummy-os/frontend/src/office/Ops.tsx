import { useState } from "react";
import { money } from "../lib/money";
import { ago, Badge, Modal, useToast } from "../lib/ui";
import { download, post, useApi } from "./api";
import { can, useMe } from "./Office";

type Row = Record<string, any>; // eslint-disable-line @typescript-eslint/no-explicit-any

function useAction(reload: () => void) {
  const toast = useToast();
  return async (path: string, body: unknown = {}, ok = "Done") => {
    try { await post(path, body); toast(ok, "good"); reload(); return true; }
    catch (e) { toast((e as Error).message, "bad"); return false; }
  };
}

const statusKind = (s: string): "good" | "warn" | "bad" | "info" | undefined =>
  ({ RECEIVED: "good", COMPLETED: "good", POSTED: "good", PAID: "good", RECONCILED: "warn", HELD: "bad", DRAFT: "info",
     SUBMITTED: "info", APPROVED: "info", DISPATCHED: "warn", RELEASED: "warn", PARTIAL: "warn", CANCELLED: undefined } as Record<string, "good" | "warn" | "bad" | "info" | undefined>)[s];

/* =========================================================== Inventory */
export function Inventory() {
  const me = useMe();
  const [tab, setTab] = useState<"stock" | "expiring" | "disc" | "adj">("stock");
  const [q, setQ] = useState("");
  const [branch, setBranch] = useState("");
  const [low, setLow] = useState(false);
  const stock = useApi<Row[]>(tab === "stock" ? `inventory/balances?q=${encodeURIComponent(q)}${branch ? `&branch=${branch}` : ""}${low ? "&low=1" : ""}` : null);
  const exp = useApi<Row[]>(tab === "expiring" ? "inventory/expiring?days=3" : null);
  const disc = useApi<Row[]>(tab === "disc" ? "inventory/discrepancies" : null);
  const adj = useApi<Row[]>(tab === "adj" ? "inventory/adjustments" : null);
  const act = useAction(() => { disc.reload(); adj.reload(); exp.reload(); });
  const total = (stock.data ?? []).reduce((s, r) => s + Number(r.value), 0);
  return (
    <>
      <div className="page-head"><div><h1>Inventory</h1><div className="sub">Physical, reserved and available stock from the immutable movement ledger.</div></div>
        {can(me, "reports.export") && <button className="right" onClick={() => download("reports/export/stock.csv", "yummy-stock.csv")}>Export stock CSV</button>}</div>
      <div className="tabs">
        {[["stock", "Stock on hand"], ["expiring", "Expiry watch"], ["disc", "Discrepancies"], ["adj", "Adjustments & disposals"]].map(([k, l]) =>
          <button key={k} className={tab === k ? "on" : ""} onClick={() => setTab(k as typeof tab)}>{l}</button>)}
      </div>
      {tab === "stock" && (
        <div className="card pad col">
          <div className="row wrap">
            <input style={{ maxWidth: 320 }} placeholder="Search product, SKU or lot" value={q} onChange={(e) => setQ(e.target.value)} />
            <select style={{ maxWidth: 200 }} value={branch} onChange={(e) => setBranch(e.target.value)}>
              <option value="">All sites</option>{me.branches.map((b) => <option key={b.code} value={b.code}>{b.name}</option>)}</select>
            <label className="row small"><input type="checkbox" style={{ width: 18, minHeight: 18 }} checked={low} onChange={(e) => setLow(e.target.checked)} />Below reorder point</label>
            <span className="right muted">Value at cost: <b className="num">ETB {total.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</b></span>
          </div>
          <div className="scroll" style={{ maxHeight: 620 }}>
            <table className="data"><thead><tr><th>Product</th><th>Site / location</th><th className="num">On hand</th><th className="num">Reserved</th><th className="num">Available</th><th>Lots (FEFO order)</th><th className="num">Value</th></tr></thead>
              <tbody>{(stock.data ?? []).map((r, i) => (
                <tr key={i}><td><b>{r.name}</b><div className="small muted">{r.sku}</div></td>
                  <td>{r.branch} · {r.location}{r.location_kind === "IN_TRANSIT" && <> <Badge kind="warn">in transit</Badge></>}{r.location_kind === "QUARANTINE" && <> <Badge kind="bad">quarantine</Badge></>}</td>
                  <td className="num" style={{ color: Number(r.on_hand) < 0 ? "var(--bad)" : undefined }}>{Number(r.on_hand).toFixed(2)} {r.unit}</td>
                  <td className="num">{Number(r.reserved) ? Number(r.reserved).toFixed(2) : "—"}</td>
                  <td className="num">{Number(r.available).toFixed(2)} {r.low && <Badge kind="warn">low</Badge>}</td>
                  <td className="small">{r.lots.slice(0, 3).map((l: Row) => <div key={l.id}>{l.code}{l.expiry ? ` · ${l.expiry}` : ""} · {Number(l.qty).toFixed(1)}{l.on_hold ? " · HOLD" : ""}</div>)}{r.lots.length > 3 && <span className="muted">+{r.lots.length - 3} more</span>}</td>
                  <td className="num">{money(r.value)}</td></tr>))}</tbody></table>
          </div>
        </div>
      )}
      {tab === "expiring" && (
        <div className="card pad">
          <p className="muted small">Expired lots are automatically excluded from picking and POS consumption. Dispose of them with an approved adjustment.</p>
          <table className="data"><thead><tr><th>Product</th><th>Lot</th><th>Where</th><th>Expiry</th><th className="num">Qty</th><th className="num">Value</th><th /></tr></thead>
            <tbody>{(exp.data ?? []).map((r, i) => (
              <tr key={i}><td>{r.product}</td><td>{r.lot}</td><td>{r.branch} · {r.location}</td><td>{r.expiry} {r.expired ? <Badge kind="bad">expired</Badge> : <Badge kind="warn">soon</Badge>}</td>
                <td className="num">{Number(r.qty).toFixed(2)}</td><td className="num">{money(r.value)}</td>
                <td>{can(me, "inventory.adjust") && <button className="danger" onClick={() => act("inventory/adjustments", {
                  location: r.location, reason: r.expired ? "EXPIRY" : "WASTE", note: `Disposal of lot ${r.lot}`,
                  lines: [{ sku: r.sku, lot_id: r.lot_id, qty_change: `-${r.qty}` }] }, "Disposal requested - needs approval")}>Request disposal</button>}</td></tr>))}</tbody></table>
          {exp.data?.length === 0 && <p className="muted">Nothing expiring in the next 3 days.</p>}
        </div>
      )}
      {tab === "disc" && (
        <div className="card pad">
          <p className="muted small">Raised automatically when reality and records disagree: offline overselling, transit shortages, count differences.</p>
          <table className="data"><thead><tr><th>When</th><th>Product</th><th>Where</th><th className="num">Qty</th><th>Reason</th><th>Source</th><th /></tr></thead>
            <tbody>{(disc.data ?? []).map((d) => (
              <tr key={d.id}><td className="muted">{ago(d.created_at)}</td><td>{d.product}</td><td>{d.branch} · {d.location}</td><td className="num">{Number(d.qty).toFixed(2)}</td>
                <td><Badge kind="warn">{d.reason.replace("_", " ").toLowerCase()}</Badge></td><td className="small">{d.source}</td>
                <td>{can(me, "inventory.adjust_approve") && <button onClick={() => { const n = prompt("How was this resolved?"); if (n) void act(`inventory/discrepancies/${d.id}/resolve`, { note: n }, "Resolved"); }}>Resolve</button>}</td></tr>))}</tbody></table>
          {disc.data?.length === 0 && <p className="muted">No open discrepancies.</p>}
        </div>
      )}
      {tab === "adj" && (
        <div className="card pad">
          <table className="data"><thead><tr><th>No.</th><th>Where</th><th>Reason</th><th>Lines</th><th>Requested</th><th>Status</th><th className="num">Value</th><th /></tr></thead>
            <tbody>{(adj.data ?? []).map((a) => (
              <tr key={a.id}><td>{a.number}</td><td>{a.branch} · {a.location}</td><td>{a.reason}</td>
                <td className="small">{a.lines.map((l: Row, i: number) => <div key={i}>{l.name} {Number(l.qty_change).toFixed(2)}{l.lot ? ` (${l.lot})` : ""}</div>)}</td>
                <td className="small">{a.created_by?.name}<div className="muted">{ago(a.created_at)}</div></td>
                <td><Badge kind={statusKind(a.status)}>{a.status}</Badge>{a.approved_by && <div className="small muted">by {a.approved_by.name}</div>}</td>
                <td className="num">{money(a.value)}</td>
                <td>{a.status === "SUBMITTED" && can(me, "inventory.adjust_approve") && <button className="primary" onClick={() => act(`inventory/adjustments/${a.id}/approve`, {}, "Approved and posted")}>Approve</button>}</td></tr>))}</tbody></table>
          {adj.data?.length === 0 && <p className="muted">No adjustments yet.</p>}
        </div>
      )}
    </>
  );
}

/* =========================================================== Transfers */
export function Transfers() {
  const me = useMe();
  const list = useApi<Row[]>("transfers", 10000);
  const act = useAction(list.reload);
  const [creating, setCreating] = useState(false);
  const [receiving, setReceiving] = useState<Row | null>(null);
  return (
    <>
      <div className="page-head"><div><h1>Transfers &amp; distribution</h1><div className="sub">Request → approve (stock reserved FEFO) → dispatch (in transit) → receive (differences reconciled).</div></div>
        {can(me, "transfer.request") && <button className="right accent" onClick={() => setCreating(true)}>New request</button>}</div>
      <div className="card pad scroll" style={{ maxHeight: "none" }}>
        <table className="data"><thead><tr><th>No.</th><th>Route</th><th>Lines</th><th>Status</th><th>People</th><th /></tr></thead>
          <tbody>{(list.data ?? []).map((t) => (
            <tr key={t.id}>
              <td><b>{t.number}</b><div className="small muted">{ago(t.requested_at)}</div></td>
              <td>{t.source} → {t.destination}</td>
              <td className="small">{t.lines.map((l: Row) => <div key={l.id}>{l.name}: {Number(l.requested).toFixed(0)} req{Number(l.dispatched) ? ` · ${Number(l.dispatched).toFixed(0)} sent` : ""}{Number(l.received) ? ` · ${Number(l.received).toFixed(0)} recv` : ""}{Number(l.damaged) ? ` · ${Number(l.damaged).toFixed(0)} damaged` : ""}</div>)}</td>
              <td><Badge kind={statusKind(t.status)}>{t.status_label}</Badge></td>
              <td className="small muted">req {t.requested_by?.name}{t.approved_by && <><br />appr {t.approved_by.name}</>}{t.driver && <><br />driver {t.driver}</>}</td>
              <td className="row">
                {t.status === "SUBMITTED" && <button className="primary" onClick={() => act(`transfers/${t.id}/approve`, {}, "Approved & reserved")}>Approve</button>}
                {t.status === "APPROVED" && <button className="primary" onClick={() => { const dname = prompt("Driver name", "Yohannes") ?? ""; void act(`transfers/${t.id}/dispatch`, { driver: dname }, "Dispatched"); }}>Dispatch</button>}
                {t.status === "DISPATCHED" && <button className="accent" onClick={() => setReceiving(t)}>Receive</button>}
                {["SUBMITTED", "APPROVED"].includes(t.status) && <button className="ghost" onClick={() => act(`transfers/${t.id}/cancel`, { reason: "Cancelled in back office" }, "Cancelled")}>Cancel</button>}
              </td>
            </tr>))}</tbody></table>
      </div>
      {creating && <NewTransfer onClose={() => setCreating(false)} onDone={() => { setCreating(false); list.reload(); }} />}
      {receiving && <ReceiveTransfer t={receiving} onClose={() => setReceiving(null)} onDone={() => { setReceiving(null); list.reload(); }} />}
    </>
  );
}

function NewTransfer({ onClose, onDone }: { onClose: () => void; onDone: () => void }) {
  const locs = useApi<Row[]>("inventory/locations");
  const prods = useApi<Row[]>("products?kind=FINISHED,RAW,PACKAGING,RESALE");
  const toast = useToast();
  const [src, setSrc] = useState("WH-C-R1");
  const [dst, setDst] = useState("");
  const [lines, setLines] = useState<{ sku: string; qty: string }[]>([{ sku: "", qty: "" }]);
  async function save() {
    try { await post("transfers", { source: src, destination: dst, lines: lines.filter((l) => l.sku && Number(l.qty) > 0) }); toast("Request submitted", "good"); onDone(); }
    catch (e) { toast((e as Error).message, "bad"); }
  }
  const opts = (locs.data ?? []).filter((l) => !["IN_TRANSIT", "WASTE"].includes(l.kind));
  return (
    <Modal title="New transfer request" onClose={onClose}>
      <div className="col">
        <label className="field">From<select value={src} onChange={(e) => setSrc(e.target.value)}>{opts.map((l) => <option key={l.id} value={l.code}>{l.branch} · {l.name}</option>)}</select></label>
        <label className="field">To<select value={dst} onChange={(e) => setDst(e.target.value)}><option value="">Choose…</option>{opts.map((l) => <option key={l.id} value={l.code}>{l.branch} · {l.name}</option>)}</select></label>
        {lines.map((l, i) => (
          <div key={i} className="row">
            <select value={l.sku} onChange={(e) => setLines(lines.map((x, k) => (k === i ? { ...x, sku: e.target.value } : x)))}>
              <option value="">Product…</option>{(prods.data ?? []).map((p) => <option key={p.sku} value={p.sku}>{p.name}</option>)}</select>
            <input style={{ width: 110 }} placeholder="Qty" inputMode="decimal" value={l.qty} onChange={(e) => setLines(lines.map((x, k) => (k === i ? { ...x, qty: e.target.value } : x)))} />
          </div>))}
        <button className="ghost" onClick={() => setLines([...lines, { sku: "", qty: "" }])}>+ Add line</button>
        <button className="accent lg" disabled={!dst || dst === src} onClick={save}>Submit request</button>
      </div>
    </Modal>
  );
}

function ReceiveTransfer({ t, onClose, onDone }: { t: Row; onClose: () => void; onDone: () => void }) {
  const toast = useToast();
  const [vals, setVals] = useState<Record<number, { r: string; d: string }>>(Object.fromEntries(t.lines.map((l: Row) => [l.id, { r: String(Number(l.dispatched)), d: "0" }])));
  async function save() {
    try {
      await post(`transfers/${t.id}/receive`, { lines: t.lines.map((l: Row) => ({ line: l.id, qty_received: vals[l.id].r, qty_damaged: vals[l.id].d })) });
      toast("Received - stock and ledger updated", "good"); onDone();
    } catch (e) { toast((e as Error).message, "bad"); }
  }
  return (
    <Modal title={`Receive ${t.number}`} onClose={onClose}>
      <p className="muted small">Count what arrived. Damaged goods go to waste; anything missing becomes a transit-shortage discrepancy.</p>
      <table className="data"><thead><tr><th>Item</th><th className="num">Sent</th><th>Good</th><th>Damaged</th></tr></thead>
        <tbody>{t.lines.map((l: Row) => (
          <tr key={l.id}><td>{l.name}</td><td className="num">{Number(l.dispatched).toFixed(0)}</td>
            <td><input value={vals[l.id].r} onChange={(e) => setVals({ ...vals, [l.id]: { ...vals[l.id], r: e.target.value } })} /></td>
            <td><input value={vals[l.id].d} onChange={(e) => setVals({ ...vals, [l.id]: { ...vals[l.id], d: e.target.value } })} /></td></tr>))}</tbody></table>
      <button className="accent lg" style={{ width: "100%", marginTop: 12 }} onClick={save}>Confirm receipt</button>
    </Modal>
  );
}

/* =========================================================== Production */
export function Production() {
  const me = useMe();
  const [tab, setTab] = useState<"plan" | "orders" | "recipes">("orders");
  const orders = useApi<Row[]>(tab === "orders" ? "production/orders" : null, 10000);
  const plan = useApi<Row>(tab === "plan" ? "production/plan" : null);
  const recipes = useApi<Row[]>(tab === "recipes" ? "production/recipes" : null);
  const act = useAction(() => { orders.reload(); plan.reload(); });
  const [completing, setCompleting] = useState<Row | null>(null);
  return (
    <>
      <div className="page-head"><div><h1>Production</h1><div className="sub">Plan → approve → release (FEFO material issue to WIP) → complete (actual batch costing, lot created).</div></div></div>
      <div className="tabs">{[["orders", "Production orders"], ["plan", "Smart planner"], ["recipes", "Recipes & costing"]].map(([k, l]) =>
        <button key={k} className={tab === k ? "on" : ""} onClick={() => setTab(k as typeof tab)}>{l}</button>)}</div>
      {tab === "orders" && (
        <div className="card pad">
          <table className="data"><thead><tr><th>Order</th><th>Product</th><th className="num">Planned</th><th className="num">Actual</th><th>Status</th><th className="num">Unit cost (std → actual)</th><th /></tr></thead>
            <tbody>{(orders.data ?? []).map((o) => (
              <tr key={o.id}><td><b>{o.number}</b><div className="small muted">{o.planned_date} · {o.workstation}</div></td>
                <td>{o.product}<div className="small muted">recipe v{o.recipe_version}{o.lot ? ` · lot ${o.lot}` : ""}</div></td>
                <td className="num">{Number(o.planned_qty).toFixed(0)}</td>
                <td className="num">{o.actual_qty ? `${Number(o.actual_qty).toFixed(0)} (${o.yield_pct}%)` : "—"}</td>
                <td><Badge kind={statusKind(o.status)}>{o.status_label}</Badge>{o.qc_status === "HOLD" && <Badge kind="bad">QC hold</Badge>}</td>
                <td className="num">{money(o.standard_unit_cost)}{o.unit_cost && <> → <b>{money(o.unit_cost)}</b></>}</td>
                <td className="row">
                  {o.status === "DRAFT" && can(me, "production.approve") && <button className="primary" onClick={() => act(`production/orders/${o.id}/approve`, {}, "Approved")}>Approve</button>}
                  {o.status === "APPROVED" && can(me, "production.execute") && <button className="primary" onClick={() => act(`production/orders/${o.id}/release`, {}, "Materials issued to WIP")}>Release</button>}
                  {o.status === "RELEASED" && can(me, "production.execute") && <button className="accent" onClick={() => setCompleting(o)}>Complete</button>}
                </td></tr>))}</tbody></table>
        </div>
      )}
      {tab === "plan" && plan.data && (
        <div className="card pad">
          <p className="muted small">{plan.data.note} Demand = average daily units sold over the last {plan.data.days} days + {plan.data.safety_pct}% safety, minus usable stock and open orders, rounded up to whole batches.</p>
          <table className="data"><thead><tr><th>Product</th><th className="num">Avg daily sales</th><th className="num">Target</th><th className="num">Stock</th><th className="num">Open orders</th><th className="num">Suggest</th><th /></tr></thead>
            <tbody>{plan.data.rows.map((r: Row) => (
              <tr key={r.sku}><td>{r.product}<div className="small muted">batch {Number(r.batch_size).toFixed(0)} {r.unit} · shelf life {r.shelf_life_days ?? "—"} d</div></td>
                <td className="num">{Number(r.avg_daily_sales).toFixed(1)}</td><td className="num">{Number(r.target).toFixed(0)}</td>
                <td className="num">{Number(r.stock).toFixed(0)}</td><td className="num">{Number(r.open_orders).toFixed(0)}</td>
                <td className="num"><b>{Number(r.suggested_qty).toFixed(0)}</b>{r.suggested_batches ? ` (${r.suggested_batches} batch)` : ""}</td>
                <td>{r.suggested_batches > 0 && can(me, "production.plan") && <button className="primary" onClick={() => act("production/orders", { sku: r.sku, qty: r.suggested_qty, source: "PROD-FLOOR", output: r.sku.includes("BREAD") || r.sku.includes("DABO") ? "WH-C-R1" : "WH-C-R2" }, "Production order planned")}>Plan order</button>}</td></tr>))}</tbody></table>
        </div>
      )}
      {tab === "recipes" && (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(330px, 1fr))", gap: 14 }}>
          {(recipes.data ?? []).map((r) => (
            <div key={r.id} className="card pad">
              <div className="row"><h3>{r.product}</h3><Badge kind={r.status === "APPROVED" ? "good" : "info"}>v{r.version} {r.status.toLowerCase()}</Badge></div>
              <p className="muted small">Batch {Number(r.output_qty)} {r.unit} · {Number(r.labor_minutes)} labour min · {r.workstation}</p>
              <table className="data"><tbody>{r.lines.map((l: Row) => <tr key={l.sku}><td>{l.name}{l.phantom && <> <Badge>sub-recipe</Badge></>}</td><td className="num">{Number(l.qty)} {l.unit}{Number(l.waste_pct) ? ` +${Number(l.waste_pct)}%` : ""}</td></tr>)}</tbody></table>
              {r.cost?.unit_cost && <div className="row" style={{ marginTop: 8 }}><span className="muted small">materials {money(r.cost.material_cost)} · labour {money(r.cost.labor_cost)} · overhead {money(r.cost.overhead_cost)}</span><b className="right num">ETB {money(r.cost.unit_cost)}/{r.unit}</b></div>}
            </div>))}
        </div>
      )}
      {completing && <CompleteOrder o={completing} onClose={() => setCompleting(null)} onDone={() => { setCompleting(null); orders.reload(); }} />}
    </>
  );
}

function CompleteOrder({ o, onClose, onDone }: { o: Row; onClose: () => void; onDone: () => void }) {
  const toast = useToast();
  const [qty, setQty] = useState(String(Number(o.planned_qty)));
  const [scrap, setScrap] = useState("0");
  const [qc, setQc] = useState(true);
  async function save() {
    try { await post(`production/orders/${o.id}/complete`, { actual_qty: qty, scrap_qty: scrap, qc_passed: qc }); toast("Batch received into stock", "good"); onDone(); }
    catch (e) { toast((e as Error).message, "bad"); }
  }
  return (
    <Modal title={`Complete ${o.number}`} onClose={onClose}>
      <div className="col">
        <label className="field">Good units produced<input value={qty} onChange={(e) => setQty(e.target.value)} inputMode="decimal" /></label>
        <label className="field">Scrap<input value={scrap} onChange={(e) => setScrap(e.target.value)} inputMode="decimal" /></label>
        <label className="row"><input type="checkbox" style={{ width: 18, minHeight: 18 }} checked={qc} onChange={(e) => setQc(e.target.checked)} /> Quality check passed (unticked → quarantine &amp; lot hold)</label>
        <button className="accent lg" onClick={save}>Complete &amp; receive</button>
      </div>
    </Modal>
  );
}

/* =========================================================== Procurement */
export function Procurement() {
  const me = useMe();
  const list = useApi<Row[]>("procurement/orders", 15000);
  const act = useAction(list.reload);
  return (
    <>
      <div className="page-head"><div><h1>Procurement</h1><div className="sub">PO → approval (different person) → goods receipt → three-way-matched invoice → payment.</div></div></div>
      <div className="card pad">
        <table className="data"><thead><tr><th>PO</th><th>Supplier</th><th>Lines</th><th className="num">Value</th><th>Status</th><th>Invoices</th><th /></tr></thead>
          <tbody>{(list.data ?? []).map((p) => (
            <tr key={p.id}><td><b>{p.number}</b><div className="small muted">{p.created_by?.name} · {ago(p.created_at)}</div></td>
              <td>{p.supplier}<div className="small muted">to {p.deliver_to}</div></td>
              <td className="small">{p.lines.map((l: Row) => <div key={l.id}>{l.name}: {Number(l.qty)} @ {money(l.unit_cost)} · recv {Number(l.received)}</div>)}</td>
              <td className="num">{money(p.value)}</td>
              <td><Badge kind={statusKind(p.status)}>{p.status_label}</Badge></td>
              <td className="small">{p.invoices.map((i: Row) => <div key={i.id}><Badge kind={statusKind(i.status)}>{i.status}</Badge> {i.supplier_ref} · {money(i.total)} paid {money(i.paid)}
                {i.exceptions?.length > 0 && <div style={{ color: "var(--bad)" }}>{i.exceptions.map((x: Row) => x.issue.replaceAll("_", " ")).join(", ")}</div>}
                {i.status === "POSTED" && can(me, "procurement.pay") && <button className="ghost small" onClick={() => act(`procurement/invoices/${i.id}/pay`, { amount: (Number(i.total) - Number(i.paid)).toFixed(2), reference: "CBE transfer" }, "Payment recorded")}>Pay balance</button>}</div>)}</td>
              <td className="row">
                {p.status === "DRAFT" && can(me, "procurement.approve") && <button className="primary" onClick={() => act(`procurement/orders/${p.id}/approve`, {}, "Approved")}>Approve</button>}
                {["APPROVED", "PARTIAL"].includes(p.status) && can(me, "procurement.receive") && <button className="primary" onClick={() => act(`procurement/orders/${p.id}/receive`, {
                  lines: p.lines.filter((l: Row) => Number(l.received) < Number(l.qty)).map((l: Row) => ({ order_line: l.id, qty_accepted: (Number(l.qty) - Number(l.received)).toFixed(3) })) }, "Goods received into stock")}>Receive all</button>}
              </td></tr>))}</tbody></table>
      </div>
    </>
  );
}
