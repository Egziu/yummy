import { money } from "../lib/money";
import { ago, Badge } from "../lib/ui";
import { useApi } from "./api";

interface Tower {
  generated_at: string;
  nodes: { code: string; name: string; kind: string; x: number; y: number; terminals: number; online: number; pending: number;
    sales_today: string; tickets_today: number; stock_value: string; alerts: number }[];
  links: { number: string; from: string; to: string; status: string; age_minutes: number }[];
  stages: { name: string; active: number; awaiting_approval: number }[];
  workflows: { type: string; number: string; title: string; steps: string[]; current: number; status: string;
    waiting_for: string | null; exception: boolean; age_minutes: number }[];
}
const KIND_ICON: Record<string, string> = { HEAD_OFFICE: "HQ", PRODUCTION: "♨", WAREHOUSE: "▦", SHOP: "🛍", CAFE: "☕" };

export function ControlTower() {
  const { data: d, error } = useApi<Tower>("reports/control-tower", 5000);
  if (error) return <p className="badge bad">{error}</p>;
  if (!d) return <div className="skeleton" style={{ height: 300 }} />;
  const pos = new Map(d.nodes.map((n) => [n.code, n]));
  return (
    <>
      <div className="page-head"><div><h1>Live operations control tower</h1>
        <div className="sub">Refreshes every 5 s from committed transactions · updated {ago(d.generated_at)}</div></div></div>

      <div className="card pad">
        <h3>Enterprise network</h3>
        <svg viewBox="0 0 900 500" width="100%" role="img" aria-label="Network of Yummy sites">
          <defs>
            <marker id="arr" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 z" fill="var(--accent)" /></marker>
          </defs>
          {/* static supply lines */}
          {d.nodes.filter((n) => n.kind === "SHOP" || n.kind === "CAFE").map((n) => {
            const wh = pos.get("WH");
            return wh ? <line key={`s${n.code}`} x1={wh.x} y1={wh.y} x2={n.x} y2={n.y} stroke="var(--line-2)" strokeWidth="1.5" /> : null;
          })}
          {pos.get("PROD") && pos.get("WH") && <line x1={pos.get("PROD")!.x} y1={pos.get("PROD")!.y} x2={pos.get("WH")!.x} y2={pos.get("WH")!.y} stroke="var(--line-2)" strokeWidth="1.5" />}
          {d.links.map((l) => {
            const a = pos.get(l.from), b = pos.get(l.to);
            if (!a || !b) return null;
            const moving = l.status === "DISPATCHED";
            return (
              <line key={l.number} x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke={moving ? "var(--accent)" : "var(--info)"} strokeWidth="3"
                strokeDasharray="8 7" markerEnd="url(#arr)">
                {moving && <animate attributeName="stroke-dashoffset" from="30" to="0" dur="1s" repeatCount="indefinite" />}
                <title>{l.number} · {l.status} · {l.age_minutes} min</title>
              </line>
            );
          })}
          {d.nodes.map((n) => {
            const sells = n.kind === "SHOP" || n.kind === "CAFE";
            const offline = sells && n.terminals > 0 && n.online === 0;
            return (
              <g key={n.code} transform={`translate(${n.x},${n.y})`}>
                <circle r="34" fill="var(--surface)" stroke={offline ? "var(--bad)" : n.alerts ? "var(--warn)" : "var(--good)"} strokeWidth="3" />
                <text textAnchor="middle" y="-4" fontSize="16">{KIND_ICON[n.kind]}</text>
                <text textAnchor="middle" y="14" fontSize="10.5" fontWeight="700" fill="var(--ink)">{n.code}</text>
                <text textAnchor="middle" y="52" fontSize="11" fill="var(--ink-2)">{sells ? `ETB ${money(n.sales_today)}` : `stock ${money(n.stock_value)}`}</text>
                {sells && <text textAnchor="middle" y="66" fontSize="10" fill={offline ? "var(--bad)" : "var(--muted)"}>
                  {offline ? "offline" : `${n.online}/${n.terminals} online`}{n.pending ? ` · ${n.pending} queued` : ""}</text>}
                <title>{n.name}</title>
              </g>
            );
          })}
        </svg>
        <div className="chart-legend"><span><i style={{ background: "var(--accent)" }} />goods in transit (animated)</span><span><i style={{ background: "var(--info)" }} />requested / approved transfer</span><span><i style={{ background: "var(--bad)" }} />outlet offline</span></div>
      </div>

      <div className="card pad">
        <h3>Supply chain flow</h3>
        <div style={{ display: "grid", gridTemplateColumns: `repeat(${d.stages.length}, 1fr)`, gap: 8 }}>
          {d.stages.map((s, i) => (
            <div key={s.name} className="card pad" style={{ boxShadow: "none", background: "var(--surface-2)", position: "relative" }}>
              <div className="muted small">{i + 1}. {s.name}</div>
              <div style={{ fontSize: 26, fontFamily: "var(--font-display)" }}>{s.active}</div>
              {s.awaiting_approval > 0 && <Badge kind="info">{s.awaiting_approval} to approve</Badge>}
            </div>
          ))}
        </div>
      </div>

      <div className="card pad">
        <h3>Workflows in motion</h3>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: 12 }}>
          {d.workflows.map((w) => (
            <div key={w.number} className="card pad" style={{ boxShadow: "none" }}>
              <div className="row"><Badge kind={w.exception ? "warn" : w.current === w.steps.length - 1 ? "good" : "info"}>{w.type}</Badge><b>{w.number}</b><span className="right muted small">{w.age_minutes < 120 ? `${w.age_minutes} min` : `${Math.floor(w.age_minutes / 60)} h`}</span></div>
              <div style={{ marginTop: 6 }}>{w.title}</div>
              <div className="steps">{w.steps.map((s, i) => <div key={s} className={`s ${i < w.current || (i === w.current && w.current === w.steps.length - 1) ? "done" : i === w.current ? "cur" : ""}`} title={s} />)}</div>
              <div className="row small muted" style={{ justifyContent: "space-between" }}>{w.steps.map((s) => <span key={s}>{s}</span>)}</div>
              {w.waiting_for && <div className="small" style={{ marginTop: 6 }}>Waiting for <b>{w.waiting_for}</b></div>}
              {w.exception && <div className="small" style={{ color: "var(--warn)" }}>Completed with exceptions — review discrepancies</div>}
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
