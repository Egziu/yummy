import { useCallback, useEffect, useRef, useState } from "react";

const KEY = "yummy.office.token";

export function getToken() {
  try { return sessionStorage.getItem(KEY); } catch { return null; }
}
export function setToken(t: string | null) {
  try { if (t) sessionStorage.setItem(KEY, t); else sessionStorage.removeItem(KEY); } catch { /* private mode */ }
}

export class ApiError extends Error {
  constructor(public status: number, message: string, public body?: unknown) { super(message); }
}

export async function api<T = unknown>(path: string, init: RequestInit = {}): Promise<T> {
  const token = getToken();
  const res = await fetch(`/api/${path}`, {
    ...init,
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}), ...(init.headers ?? {}) },
  });
  if (res.status === 401) {
    setToken(null);
    window.dispatchEvent(new Event("yummy:logout"));
  }
  const text = await res.text();
  const body = text ? JSON.parse(text) : null;
  if (!res.ok) {
    const msg = body?.detail ? (Array.isArray(body.detail) ? body.detail.join(" ") : String(body.detail)) : JSON.stringify(body);
    throw new ApiError(res.status, msg, body);
  }
  return body as T;
}

export const post = <T = unknown>(path: string, data: unknown = {}) => api<T>(path, { method: "POST", body: JSON.stringify(data) });

/** Load data, optionally refreshing every `everyMs`. */
export function useApi<T>(path: string | null, everyMs?: number) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const live = useRef(true);
  const load = useCallback(async () => {
    if (!path) return;
    try {
      const d = await api<T>(path);
      if (live.current) { setData(d); setError(null); }
    } catch (e) {
      if (live.current) setError(e instanceof ApiError && e.status === 403 ? "You don't have access to this view." : String((e as Error).message));
    } finally { if (live.current) setLoading(false); }
  }, [path]);
  useEffect(() => {
    live.current = true;
    setLoading(true);
    void load();
    const id = everyMs ? setInterval(load, everyMs) : undefined;
    return () => { live.current = false; if (id) clearInterval(id); };
  }, [load, everyMs]);
  return { data, error, loading, reload: load };
}

export async function download(path: string, filename: string) {
  const res = await fetch(`/api/${path}`, { headers: { Authorization: `Bearer ${getToken()}` } });
  if (!res.ok) throw new ApiError(res.status, "Export not allowed");
  const blob = await res.blob();
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  URL.revokeObjectURL(a.href);
}
