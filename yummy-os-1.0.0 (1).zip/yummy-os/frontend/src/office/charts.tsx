/** Small dependency-free SVG charts with consistent palette. */
import { Fragment, useState } from "react";
import { fmt, toCents } from "../lib/money";

export const SERIES = ["#c7741f", "#2f5f8a", "#2f7d4f", "#8a4f9e", "#b3361f", "#6b7f2a", "#4e6e8e", "#9a6b3c"];

export function StackedBars({ rows, keys }: { rows: Record<string, string | number>[]; keys: string[] }) {
  const [hover, setHover] = useState<number | null>(null);
  const W = 720, H = 240, P = { l: 52, r: 10, t: 10, b: 28 };
  const totals = rows.map((r) => keys.reduce((s, k) => s + toCents(String(r[k] ?? 0)), 0));
  const max = Math.max(1, ...totals);
  const nice = niceMax(max);
  const bw = (W - P.l - P.r) / Math.max(1, rows.length);
  const y = (v: number) => H - P.b - (v / nice) * (H - P.t - P.b);
  return (
    <div>
      <svg viewBox={`0 0 ${W} ${H}`} width="100%" role="img" aria-label="Sales trend by outlet">
        {[0, 0.25, 0.5, 0.75, 1].map((f) => (
          <g key={f}>
            <line x1={P.l} x2={W - P.r} y1={y(nice * f)} y2={y(nice * f)} stroke="var(--line)" />
            <text x={P.l - 6} y={y(nice * f) + 4} textAnchor="end" fontSize="10" fill="var(--muted)">{short(nice * f)}</text>
          </g>
        ))}
        {rows.map((r, i) => {
          let acc = 0;
          return (
            <g key={i} onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)}>
              <rect x={P.l + i * bw} y={P.t} width={bw} height={H - P.t - P.b} fill={hover === i ? "var(--surface-2)" : "transparent"} />
              {keys.map((k, ki) => {
                const v = toCents(String(r[k] ?? 0));
                const y0 = y(acc), y1 = y(acc + v);
                acc += v;
                return <rect key={k} x={P.l + i * bw + bw * 0.18} width={bw * 0.64} y={y1} height={Math.max(0, y0 - y1)} fill={SERIES[ki % SERIES.length]} rx="2" />;
              })}
              {(i % Math.ceil(rows.length / 10) === 0) && <text x={P.l + i * bw + bw / 2} y={H - 10} textAnchor="middle" fontSize="10" fill="var(--muted)">{String(r.date).slice(5)}</text>}
            </g>
          );
        })}
      </svg>
      <div className="row wrap" style={{ justifyContent: "space-between" }}>
        <div className="chart-legend">{keys.map((k, i) => <span key={k}><i style={{ background: SERIES[i % SERIES.length] }} />{k}</span>)}</div>
        <span className="small muted num">{hover !== null ? `${rows[hover].date}: ETB ${fmt(totals[hover])}` : "Hover a day for its total"}</span>
      </div>
    </div>
  );
}

export function Heatmap({ cells }: { cells: { dow: number; hour: number; total: string }[] }) {
  const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  const hours = Array.from({ length: 15 }, (_, i) => i + 7);
  const map = new Map(cells.map((c) => [`${c.dow}-${c.hour}`, toCents(c.total)]));
  const max = Math.max(1, ...map.values());
  return (
    <div style={{ display: "grid", gridTemplateColumns: `36px repeat(${hours.length}, 1fr)`, gap: 3, fontSize: 10 }}>
      <span />
      {hours.map((h) => <span key={h} className="muted center">{h}</span>)}
      {days.map((d, di) => (
        <Fragment key={d}>
          <span className="muted">{d}</span>
          {hours.map((h) => {
            const v = map.get(`${di}-${h}`) ?? 0;
            return <span key={`${d}${h}`} title={`${d} ${h}:00 · ETB ${fmt(v)}`}
              style={{ height: 18, borderRadius: 4, background: v ? `color-mix(in srgb, var(--accent) ${Math.round(15 + (v / max) * 85)}%, var(--surface-2))` : "var(--surface-2)" }} />;
          })}
        </Fragment>
      ))}
    </div>
  );
}

export function BarList({ rows }: { rows: { label: string; value: number; note?: string }[] }) {
  const max = Math.max(1, ...rows.map((r) => r.value));
  return (
    <div className="col" style={{ gap: 8 }}>
      {rows.map((r) => (
        <div key={r.label}>
          <div className="row small"><span>{r.label}</span><span className="right num">{r.note ?? fmt(r.value)}</span></div>
          <div style={{ height: 8, background: "var(--surface-2)", borderRadius: 6 }}>
            <div style={{ width: `${(r.value / max) * 100}%`, height: "100%", background: "var(--accent)", borderRadius: 6 }} />
          </div>
        </div>
      ))}
    </div>
  );
}

function niceMax(v: number) {
  const p = 10 ** Math.floor(Math.log10(v));
  return Math.ceil(v / p) * p;
}
function short(cents: number) {
  const v = cents / 100;
  return v >= 1e6 ? `${(v / 1e6).toFixed(1)}M` : v >= 1e3 ? `${Math.round(v / 1e3)}k` : String(Math.round(v));
}
