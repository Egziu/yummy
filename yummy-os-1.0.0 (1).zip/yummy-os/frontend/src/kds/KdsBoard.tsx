import { useEffect, useState } from "react";
import { kvGet } from "../pos/db";
import type { Bootstrap } from "../pos/types";

interface Ticket { id: string; station: string; order_ref: string; order_type: string; status: string; created_at: string;
  items: { name: string; qty: string; modifiers: string[]; note: string }[] }

const NEXT: Record<string, { to: string; label: string }> = {
  NEW: { to: "PREPARING", label: "Start" }, PREPARING: { to: "READY", label: "Ready" }, READY: { to: "SERVED", label: "Served" },
};

/** Kitchen / barista display. Needs the local network to reach the server; the POS still prints/holds tickets offline. */
export function KdsBoard({ boot }: { boot: Bootstrap }) {
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [station, setStation] = useState<string>("");
  const [online, setOnline] = useState(true);
  const [, tick] = useState(0);

  async function load() {
    try {
      const token = (await kvGet<string>("deviceToken")) ?? "";
      const res = await fetch(`/api/kds/tickets${station ? `?station=${station}` : ""}`, { headers: { "X-Terminal-Token": token } });
      if (!res.ok) throw new Error();
      setTickets(await res.json());
      setOnline(true);
    } catch { setOnline(false); }
  }
  useEffect(() => {
    void load();
    const a = setInterval(load, 4000);
    const b = setInterval(() => tick((x) => x + 1), 15000);
    return () => { clearInterval(a); clearInterval(b); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [station]);

  async function bump(tk: Ticket) {
    const n = NEXT[tk.status];
    if (!n) return;
    setTickets((ts) => ts.map((x) => (x.id === tk.id ? { ...x, status: n.to } : x)).filter((x) => x.status !== "SERVED"));
    await fetch(`/api/kds/tickets/${tk.id}`, { method: "POST", headers: { "Content-Type": "application/json",
      "X-Terminal-Token": (await kvGet<string>("deviceToken")) ?? "" }, body: JSON.stringify({ status: n.to }) }).catch(() => setOnline(false));
  }

  return (
    <div className="kds">
      <div className="row">
        <h1 style={{ color: "#f0ac45" }}>Yummy · {boot.branch.name}</h1>
        <span className="badge" style={{ background: online ? "#183224" : "#3d1b13", color: online ? "#6cc191" : "#f08a72" }}>
          {online ? "Live" : "Reconnecting…"}</span>
        <div className="right row">
          {["", "BARISTA", "KITCHEN", "DESSERT"].map((s) => (
            <button key={s} onClick={() => setStation(s)} style={{ background: station === s ? "#f0ac45" : "#2a1d14", color: station === s ? "#1a120c" : "#f4eadc", border: 0 }}>
              {s || "All stations"}</button>))}
        </div>
      </div>
      <div className="kds-grid">
        {tickets.map((tk) => {
          const mins = Math.floor((Date.now() - Date.parse(tk.created_at)) / 60000);
          return (
            <div key={tk.id} className={`ticket ${tk.status} ${mins >= 8 && tk.status !== "READY" ? "late" : ""}`}>
              <div className="row"><b style={{ fontSize: 22 }}>{tk.order_ref}</b><span className="right">{mins} min</span></div>
              <div className="small" style={{ opacity: .7 }}>{tk.station} · {tk.order_type === "TAKEAWAY" ? "Takeaway" : "Dine-in"} · {tk.status}</div>
              <ul style={{ paddingLeft: 18, fontSize: 17 }}>
                {tk.items.map((i, k) => <li key={k}><b>{i.qty}×</b> {i.name}{i.modifiers.length ? <div className="small" style={{ color: "#f0ac45" }}>+ {i.modifiers.join(", ")}</div> : null}
                  {i.note && <div className="small">“{i.note}”</div>}</li>)}
              </ul>
              {NEXT[tk.status] && <button onClick={() => bump(tk)}>{NEXT[tk.status].label}</button>}
            </div>
          );
        })}
        {tickets.length === 0 && <p style={{ opacity: .6 }}>No open tickets. New orders appear here automatically.</p>}
      </div>
    </div>
  );
}
