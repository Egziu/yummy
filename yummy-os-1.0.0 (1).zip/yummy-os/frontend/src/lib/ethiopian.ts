/** Gregorian -> Ethiopian calendar (mirrors apps/core/ethiopian.py). */
const EPOCH = 1723856;
export const MONTHS_EN = ["Meskerem", "Tikimt", "Hidar", "Tahsas", "Tir", "Yekatit", "Megabit", "Miyazya", "Ginbot",
  "Sene", "Hamle", "Nehase", "Pagume"];
export const MONTHS_AM = ["መስከረም", "ጥቅምት", "ኅዳር", "ታኅሣሥ", "ጥር", "የካቲት", "መጋቢት", "ሚያዝያ", "ግንቦት", "ሰኔ", "ሐምሌ", "ነሐሴ", "ጳጉሜን"];

const fdiv = (a: number, b: number) => Math.floor(a / b);
const mod = (a: number, b: number) => ((a % b) + b) % b;

function gregorianToJdn(y: number, m: number, d: number): number {
  const a = fdiv(14 - m, 12);
  const yy = y + 4800 - a;
  const mm = m + 12 * a - 3;
  return d + fdiv(153 * mm + 2, 5) + 365 * yy + fdiv(yy, 4) - fdiv(yy, 100) + fdiv(yy, 400) - 32045;
}

export function toEthiopian(date: Date): [number, number, number] {
  const jdn = gregorianToJdn(date.getFullYear(), date.getMonth() + 1, date.getDate());
  const r = mod(jdn - EPOCH, 1461);
  const n = mod(r, 365) + 365 * fdiv(r, 1460);
  const year = 4 * fdiv(jdn - EPOCH, 1461) + fdiv(r, 365) - fdiv(r, 1460);
  return [year, fdiv(n, 30) + 1, mod(n, 30) + 1];
}

export function formatEthiopian(date: Date, lang: "en" | "am" = "en"): string {
  const [y, m, d] = toEthiopian(date);
  return `${(lang === "am" ? MONTHS_AM : MONTHS_EN)[m - 1]} ${d}, ${y} E.C.`;
}
