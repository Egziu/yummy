import { describe, expect, it } from "vitest";
import spec from "../../../spec/pricing_cases.json";
import { centsToStr, divHalfUp, fmt, priceLine, refundAmounts, toCents } from "./money";
import { formatEthiopian, toEthiopian } from "./ethiopian";

describe("pricing parity with the server (spec/pricing_cases.json)", () => {
  it.each(spec.cases.map((c) => [c.name, c] as const))("%s", (_n, c) => {
    expect(priceLine(c.unit_price, c.qty, c.discount, c.tax_rate, c.tax_inclusive)).toEqual(c.expect);
  });
});

describe("money helpers", () => {
  it("parses decimals exactly and rounds half away from zero", () => {
    expect(toCents("0.1")).toBe(10);
    expect(toCents("1.005")).toBe(101);
    expect(toCents("-2.345")).toBe(-235);
    expect(() => toCents("1e5")).toThrow();
    expect(divHalfUp(-5, 2)).toBe(-3);
  });
  it("formats", () => {
    expect(fmt(123456)).toBe("1,234.56");
    expect(centsToStr(-5)).toBe("-0.05");
  });
  it("refunds split exactly with no rounding drift (server parity)", () => {
    const a = refundAmounts("45.00", "5.87", "3", "0", "1");
    const b = refundAmounts("45.00", "5.87", "3", "1", "2");
    expect(a).toEqual({ amount: 1500, tax: 196 });
    expect(a.amount + b.amount).toBe(4500);
    expect(a.tax + b.tax).toBe(587);
  });
});

describe("Ethiopian calendar", () => {
  it("matches the server reference dates", () => {
    expect(toEthiopian(new Date(2026, 8, 11))).toEqual([2019, 1, 1]);
    expect(toEthiopian(new Date(2027, 8, 12))).toEqual([2020, 1, 1]);
    expect(toEthiopian(new Date(2027, 8, 11))).toEqual([2019, 13, 6]);
    expect(formatEthiopian(new Date(2026, 9, 9))).toBe("Meskerem 29, 2019 E.C.");
  });
});
