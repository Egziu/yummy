/**
 * Exact POS arithmetic, bit-identical to apps/core/money.py on the server.
 * Money is integer cents, quantities integer milli-units, tax rates basis points.
 * Never use binary floats for money: offline receipts must equal the server's books.
 */

/** Parse a decimal string ("12.5", "-0.75") into an integer scaled by 10^places, rounding half away from zero. */
export function toScaled(value: string | number, places: number): number {
  const s = String(value).trim();
  if (!/^-?\d*(\.\d*)?$/.test(s) || s === "" || s === "-" || s === ".") throw new Error(`Not a number: ${value}`);
  const neg = s.startsWith("-");
  const [intPart, fracPart = ""] = (neg ? s.slice(1) : s).split(".");
  const frac = fracPart.padEnd(places + 1, "0");
  let n = Number(intPart || "0") * 10 ** places + Number(frac.slice(0, places) || "0");
  if (Number(frac[places]) >= 5) n += 1;
  if (!Number.isSafeInteger(n)) throw new Error("Amount too large");
  return neg ? -n : n;
}

export const toCents = (v: string | number) => toScaled(v, 2);
export const toMilli = (v: string | number) => toScaled(v, 3);
export const rateBp = (v: string | number) => toScaled(v, 4);

/** Integer division rounding half away from zero (matches Python div_half_up). */
export function divHalfUp(numerator: number, denominator: number): number {
  if (denominator <= 0) throw new Error("denominator must be positive");
  const sign = numerator < 0 ? -1 : 1;
  const n = Math.abs(numerator);
  return sign * Math.floor((2 * n + denominator) / (2 * denominator));
}

export interface LineCalc {
  gross: number;
  discount: number;
  base: number;
  tax: number;
  total: number;
}

export function priceLine(unitPrice: string, qty: string, discount: string, taxRate: string, taxInclusive: boolean): LineCalc {
  const priceC = toCents(unitPrice);
  const qtyM = toMilli(qty);
  const discC = toCents(discount);
  const bp = rateBp(taxRate);
  if (qtyM <= 0) throw new Error("quantity must be positive");
  if (priceC < 0 || discC < 0) throw new Error("price and discount must not be negative");
  // price_c * qty_m stays well inside 2^53 for any realistic till amount (checked)
  if (!Number.isSafeInteger(priceC * qtyM)) throw new Error("Amount too large");
  const gross = divHalfUp(priceC * qtyM, 1000);
  if (discC > gross) throw new Error("discount exceeds line amount");
  const net = gross - discC;
  if (taxInclusive) {
    const tax = divHalfUp(net * bp, 10000 + bp);
    return { gross, discount: discC, base: net - tax, tax, total: net };
  }
  const tax = divHalfUp(net * bp, 10000);
  return { gross, discount: discC, base: net, tax, total: net + tax };
}

/** cents -> "1,234.50" */
export function fmt(cents: number, opts: { symbol?: boolean } = {}): string {
  const neg = cents < 0;
  const abs = Math.abs(cents);
  const whole = Math.floor(abs / 100).toLocaleString("en-US");
  const s = `${neg ? "-" : ""}${whole}.${String(abs % 100).padStart(2, "0")}`;
  return opts.symbol ? `ETB ${s}` : s;
}

/** cents -> "1234.50" for the API */
export function centsToStr(cents: number): string {
  const neg = cents < 0;
  const abs = Math.abs(cents);
  return `${neg ? "-" : ""}${Math.floor(abs / 100)}.${String(abs % 100).padStart(2, "0")}`;
}

/** Format a decimal string for display (keeps exactness, adds thousands separators). */
export function money(v: string | number | null | undefined, symbol = false): string {
  if (v === null || v === undefined || v === "") return "—";
  return fmt(toCents(v), { symbol });
}

/** Proportional refund for `qty` of a sold line; the last unit takes the exact remainder (server parity). */
export function refundAmounts(lineTotal: string, lineTax: string, lineQty: string, qtyRefundedBefore: string, qty: string) {
  const totalC = toCents(lineTotal), taxC = toCents(lineTax);
  const lq = toMilli(lineQty), prior = toMilli(qtyRefundedBefore), now = toMilli(qty);
  const share = (c: number, m: number) => divHalfUp(c * m, lq);
  if (prior + now === lq) return { amount: totalC - share(totalC, prior), tax: taxC - share(taxC, prior) };
  return { amount: share(totalC, prior + now) - share(totalC, prior), tax: share(taxC, prior + now) - share(taxC, prior) };
}

export function qtyStr(milli: number): string {
  const s = (milli / 1000).toFixed(3);
  return s.replace(/\.?0+$/, "");
}
