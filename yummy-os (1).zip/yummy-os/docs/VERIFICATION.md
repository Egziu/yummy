# Verification evidence

## Release 1.1.0 — 12 October 2026 (Africa/Addis_Ababa)

Same Linux VM and toolchain as 1.0 (Python 3.13.16, Node 22.22.0, PostgreSQL 16.15, Chromium via Playwright).
Output copied verbatim (trimmed where marked). The 1.0 evidence follows below and still applies.

**Backend** `cd backend && YUMMY_DEBUG=1 python -m pytest -q --create-db` → `377 passed` (347 from 1.0 + 30 new:
`tests/test_management.py` 14, `tests/test_branch_server.py` 16).
**Frontend** `npx tsc -b` (no errors) · `npx vitest run` → `Tests 312 passed` · production build pre-compressed:
main bundle 427 kB → 127 kB gzip / **109 kB brotli** on the wire (measured with curl against the running server).

**Branch-server browser test** `python e2e/run_branch_e2e.py` — real processes: HQ gunicorn on the seeded
database, a SHOP1 branch server (own empty database) and its sync agent; HQ is killed with SIGKILL mid-trading.

```
1. HQ back office: product, price, recipe (author + different approver), new cashier
  ✓ hq-new-product ✓ hq-set-price ✓ hq-products ✓ hq-add-cashier
  ✓ hq-recipe-new-version ✓ hq-recipe-awaiting-approval ✓ hq-recipe-approved
2. HQ: branch server + new till; enrol the branch server
  ✓ hq-branch-server-code
  enrolling: Enrolled as SHOP1-SRV-397C for SHOP1 (Yummy Shop 01 - Kebele 14). 13 products, 4 terminals received.
  ✓ hq-sync-page-branch-online
3. Branch till via the branch server: new cashier, new product, new price
  ✓ branch-landing ✓ branch-till-sale-new-product
4. HQ goes DOWN - the branch keeps going
  ✓ branch-till-online-while-hq-down ✓ branch-refund-approved-hq-down ✓ branch-hub-hq-down
5. HQ comes back - the queue drains in order, exactly once
  ✓ branch-hub-drained
  ✓ HQ received exactly 3 offline sales + the refund (no loss, no duplicates)
  ✓ hq-sync-after-recovery
[PASS] Trial balance: total debits = total credits  (Dr 630407.46 / Cr 630407.46)
[PASS] Every journal entry balances
[PASS] Stock balances equal the sum of the movement ledger  (0 mismatched, 0 missing)
[PASS] Sale totals equal their lines and payments  (0 line mismatches, 0 payment mismatches)
[PASS] No line refunded beyond the quantity sold
[PASS] Audit log hash chain intact  (761 entries checked)        (other PASS lines trimmed)
SALES 4 REFUNDS 1
BRANCH E2E PASSED
```
Screenshots: `e2e/screenshots-branch/`. The 1.0 browser test (`run_e2e.py`) was re-run on this build: `E2E PASSED`.

**Branch → HQ over TLS with the LAN certificate authority** (`./yummy setup`, HQ gunicorn with the generated
certificate, branch enrolment):
```
--- without CA (must fail):   HQ unreachable: [SSL: CERTIFICATE_VERIFY_FAILED] ... self-signed certificate in certificate chain
--- plain http (must be refused): HQ address must use https:// (set YUMMY_ALLOW_INSECURE_HQ=1 only for a closed test network)
--- with CA:                  Enrolled as SHOP2-SRV-TLS for SHOP2 (Yummy Shop 02 - Hawelti). 12 products, 2 terminals received.
```
The CA is name-constrained: a certificate it issues for `evil.example.com` fails verification
(`error 47 at 0 depth lookup: permitted subtree violation`); `./yummy certs ... 8.8.8.8` is refused.

**Throughput** (same VM, 3 gunicorn workers): direct tills `e2e/load_test.py --sales 60` → `300 / 300 (0 errors)`,
`33.2 sales/s`, p95 189 ms. Branch server: `500 sales accepted offline in 2.72 s (5.4 ms each)`; catch-up after the
outage `501 ops forwarded to HQ in 27.2 s (18 ops/s)` — a full day's trading at one branch drains in about a minute.

**HTTP hardening** (curl): `Content-Security-Policy: default-src 'self'; script-src 'self'; ... frame-ancestors 'none' ...`,
`Permissions-Policy: camera=(), microphone=() ...`, API answers `Cache-Control: no-store`, hashed assets
`Cache-Control: max-age=315360000, public, immutable`.

**Independent review.** A separate reviewer (no part in writing the code) audited the change and reported 4
critical/high and 4 medium issues, all reproduced with tests: account takeover by branch-scoped user admins, self
widening of admin scope, a malformed or orphaned operation stalling a branch's queue, a till told "rejected" while HQ
booked the operation, HQ staff password hashes reaching branches, unscoped price changes, PIN uniqueness bypass by
moving branches, and the CA key mounted into containers. All were fixed with regression tests (bottom sections of
the two new test files); a second review pass confirmed the fixes and found one regression (a held operation could
let its till's later operations jump ahead), which was fixed and covered by
`test_held_op_parks_its_till_but_not_the_branch`.

**Not run for 1.1:** Docker image build / Compose stacks on this VM (no container registry access — Railway builds
the same Dockerfile), installing the CA on physical Android/Windows devices, multi-day soak test, more than one
branch server live at the same time against one HQ (each pair verified separately).

---

## Release 1.0.0

All results below were produced on **9 October 2026** (Africa/Addis_Ababa) on code revision **`ab41e37`**, in a
Linux VM: Python 3.13.16, Node 22.22.0, PostgreSQL 16.15, Chromium (Playwright). Output is copied verbatim
(trimmed only where marked). Anything not listed here was **not run**.

## 1. Backend test suite — PostgreSQL, real constraints and triggers

Command: `cd backend && YUMMY_DEBUG=1 python -m pytest -q`

```
347 passed in 13.58s
```

313 of these are the shared pricing cases + calendar checks; 34 are scenario/integration tests:

| Spec scenario | Test(s) |
|---|---|
| A — procurement | `test_scenario_a_procurement_flow`, `test_three_way_match_holds_price_and_quantity_exceptions`, `test_invoice_recorder_cannot_pay_it`, `test_po_segregation_of_duties_and_permissions` |
| B — production | `test_scenario_b_production_fefo_costing_and_journals`, `test_nested_recipe_explosion_and_cycle_detection`, `test_release_is_all_or_nothing_on_shortage`, `test_qc_failure_goes_to_quarantine_and_is_not_sellable` |
| C — distribution | `test_scenario_c_transfer_lifecycle_with_damage_and_shortage` (incl. double receipt refused), `test_transfer_partial_approval_and_cancel_releases_reservation`, `test_requester_cannot_approve_own_transfer`, `test_concurrent_approvals_cannot_oversell_reserved_stock` (two threads, real row locks) |
| D — retail sale | `test_scenario_d_retail_sale_effects`, `test_sync_records_stock_movements_with_receipt_reference`, `test_price_difference_is_flagged_not_rejected`, `test_large_discount_requires_supervisor` |
| E — café order | `test_scenario_e_cafe_order_consumes_recipe_and_modifiers` |
| F — refund | `test_scenario_f_refund_rules` (SoD, excess refund refused, exact remainder, restock) |
| G — network outage | `test_scenario_g_offline_burst_oversell_ordering_and_retry`, `test_replaying_the_same_operation_is_idempotent`, `test_tampered_totals_are_rejected_and_kept_for_review` |
| H — expired product | `test_scenario_h_expired_stock_blocked_then_disposed_with_approval`, `test_recall_trace_follows_ingredient_lot_into_finished_goods` |
| I — unauthorised access | `test_scenario_i_cashier_is_denied_server_side`, `test_branch_manager_only_sees_own_branch`, `test_terminal_cannot_act_for_another_branch_or_shift`, `test_terminal_enrollment_single_use_and_revocation`, `test_login_lockout_and_token_expiry` |
| Invariants / tamper | `test_append_only_ledgers_reject_update_and_delete`, `test_unbalanced_journal_rejected_by_database`, `test_locked_period_blocks_posting`, `test_audit_chain_detects_tampering`, `test_csv_exports_neutralise_formula_injection` |
| API end to end | `test_pos_end_to_end_over_http` (enrol → bootstrap → offline PIN verifier → sync → lookup → dashboard) |

## 2. Frontend tests

Command: `cd frontend && npx vitest run`

```
 Test Files  2 passed (2)
      Tests  312 passed (312)
```

Includes every case of `spec/pricing_cases.json` (the TypeScript POS reproduces the server to the cent), refund
split parity, Ethiopian calendar, and the sync engine against an in-memory IndexedDB: atomic receipt numbering,
ordered upload, APPLIED/REJECTED/RETRY handling, lost-response retry without duplicates, practice-offline mode.

Type check and production build: `npx tsc -b` (no errors) · `npx vite build` → `index-*.js 385 kB (118 kB gzip)`.

## 3. Real-browser end-to-end test (Scenario G in a browser)

Command: `python e2e/run_e2e.py` against gunicorn (3 workers, `YUMMY_DEBUG` off) on the seeded database.

```
1. enrol terminal                                   ✓ pos-enrol ✓ pos-cashier-select
2. sign in and sell online                          ✓ pos-cart-online ✓ pos-receipt-online
3. network cut - keep selling                       ✓ pos-offline-queue
4. reload while offline (service worker shell + on-device PIN)
                                                    ✓ pos-offline-receipt-after-reload ✓ pos-sync-centre-offline
5. network back - queue drains in order             ✓ pos-synced
  ✓ server received exactly 5 sales (no loss, no duplicates)
6. back office                                      ✓ dashboard ✓ control-tower ✓ warehouse-map ✓ transfers
                                                    ✓ sync-monitor ✓ production ✓ accounting ✓ inventory ✓ smart-planner
7. café: modifiers, table tab, send to kitchen, KDS bump, pay
                                                    ✓ cafe-tab-T4 ✓ kds-barista-screen ✓ cafe-receipt
8. refund with supervisor approval (different person) ✓ cafe-refund-approved
E2E PASSED
```

Screenshots: `e2e/screenshots/`. After the run: `python manage.py verify_integrity` → all invariants hold.

## 4. Demo data built through the real services

`python manage.py seed_demo --days 14` purchased, received, staged, produced, distributed and then submitted
**3,306 POS sales through the sync engine**, then checked:

```
[PASS] Trial balance: total debits = total credits Dr 615668.34 / Cr 615668.34
[PASS] Every journal entry balances
[PASS] Stock balances equal the sum of the movement ledger 0 mismatched, 0 missing
[PASS] No negative reservations
[PASS] Sale totals equal their lines and payments 0 line mismatches, 0 payment mismatches
[PASS] No line refunded beyond the quantity sold
[PASS] Every received transfer fully cleared in-transit stock
[PASS] Audit log hash chain intact 631 entries checked
```

## 5. Concurrency / latency

Command: `python e2e/load_test.py --sales 60` (5 terminals uploading concurrently, one sale per request)

```
sales synced : 300 / 300 (0 errors)
throughput   : 39.6 sales/s with 5 concurrent terminals
latency ms   : p50 123 · p95 153 · max 181
```

Then `verify_integrity` → all invariants hold. (Shared dev VM, 3 gunicorn workers; re-measure on the production server.)

## 6. Disaster-recovery drill (Scenario J)

Command: `bash deploy/scripts/pitr_drill.sh seeded.dump` — throw-away cluster with WAL archiving; base backup;
3 more sales synced **after** the backup; then `DROP SCHEMA public CASCADE`; restore + WAL replay to the moment
before the disaster; application invariants verified on the restored copy.

```
pg: LOG:  starting point-in-time recovery to 2026-10-09 20:03:30.569827+03
pg: LOG:  recovery stopping before commit of transaction 1378, time 2026-10-09 20:03:31.678375+03
================ DRILL RESULT ================
sales before disaster : 3309   restored: 3309
journals before       : 3570   restored: 3570
data lost (RPO)       : 0 sales, 0 journals (target time 2026-10-09 20:03:30.569827 +03)
restore+verify (RTO)  : 2 s on this machine
RESULT: PASS
```

## 7. Security configuration check

`python manage.py check --deploy` with production settings: the only security warning is `security.W021`
(HSTS preload not enabled — optional, enable once the domain is final). The remaining warnings are drf-spectacular
notes that function-based views lack serializer metadata (OpenAPI documentation is incomplete, not a security issue).

## NOT RUN in this environment

| Item | Reason |
|---|---|
| `docker compose build` / container start | No container registry access from the build VM. Run before go-live. |
| Backup sidecar (`backup-loop.sh`) inside Compose, GPG encryption path | Depends on the container stack. The drill exercised the same PostgreSQL mechanisms directly. |
| Real payment providers, receipt printers, cash drawers, barcode scanners | No hardware/credentials. Scanner input is tested as keyboard input only. |
| Independent penetration test, dependency/secret scanning | To be commissioned / added to CI. |
| Multi-hour soak test, large data volumes (years of sales) | Not performed. |
| User acceptance testing with Yummy staff | Requires the pilot. |
