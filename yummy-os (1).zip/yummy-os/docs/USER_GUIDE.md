# Quick guides

## Cashier (shop)
1. Open `/pos` on the counter device → tap your name → enter your PIN.
2. First login of the day: count the opening float → **Open shift**.
3. Tap products (or scan the barcode / type and press Enter). Tap a line for − / + / % / Remove.
4. **Charge (F9)** → choose the payment. Cash: tap a quick amount, give the change shown. telebirr / CBE Birr / bank: type the transaction reference from the customer's SMS.
5. **New sale.** Print the receipt if the customer wants it.
6. The pill at the top shows **Online** or **Offline · N pending**. Offline is fine — keep selling. Never clear the browser data.
7. End of day: **Close shift** → count the drawer → if it differs, your manager enters their PIN.

Refunds: **Refund** → pick the receipt (or type its number) → quantities, reason → your manager approves with their own PIN.

## Café staff
Choose **Dine-in + Table** or **Takeaway**. Drinks with options open a modifier panel. **Send to kitchen** sends new items to the barista / kitchen / dessert screens. Orders stay on the table until paid — even after a refresh.

## Barista / kitchen screen
Tickets appear by station. Tap **Start → Ready → Served**. Tickets older than 8 minutes get a red outline.

## Shop / café manager (back office `/office`)
Request stock (**Transfers → New request**), receive deliveries (**Receive**: enter good and damaged quantities), see your branch dashboard, investigate discrepancies.

## Warehouse
**Transfers**: approve (stock is reserved first-expiry-first), dispatch (driver), see in-transit. **Warehouse map**: click a rack to see lots; *Edit layout* to drag racks. **Inventory**: expiry watch → request disposal; approve adjustments (someone else must have requested them).

## Production
**Smart planner** suggests batches from recent sales and stock. **Production orders**: approve → release (ingredients issued) → complete (good units, scrap, QC). Recipes: an author writes a new version in **Recipes** (Setup); a different person approves it there.

## Finance
**Accounting**: P&L by branch, trial balance, journals, lock a period after month-end review. **Procurement**: invoices held by the three-way match need a manager release; the person who recorded an invoice cannot pay it.

## Setting up products, prices, recipes and people (back office → Setup)
* **Products & prices** → *New product*: name, SKU, type (raw material, finished good, café menu item…), category,
  unit, VAT, shelf life, reorder point. Tick *Sold at the tills*, save, then **Prices** to set the selling price on
  each price list (empty = not sold there). Changes reach the tills on their next sync; old receipts keep old prices.
  *Categories* and *Café add-ons* (extra shot, no sugar…) are on the same page.
* **Recipes** → *New recipe* or *New version* on a card: batch size, labour minutes, ingredient lines (tick
  *sub-recipe* for in-house items like dough). It is saved as a **draft**; a different person with approval rights
  presses **Approve**. Only then is it used for production, stock consumption and costing.
* **People & access** → *Add person*: username, name, password (back-office staff) and/or till PIN (4–8 digits,
  unique within a branch), and one or more roles, each for one branch or all. *Edit* to reset a password or PIN,
  unlock, change roles or disable (disabling signs the person out everywhere).
* **Terminals & sync** → *New till / screen* gives a one-time enrolment code; *Add branch server* sets up a
  shop's or café's own server (see LAN_INSTALL.md).

## Branch server (at a shop or café)
Tills and kitchen screens open the **branch server's** address (e.g. `https://shop1.yummy.lan/pos`). Everything works
with no internet. The manager signs in at `https://shop1.yummy.lan/office` to see: link to head office, operations
waiting to be sent, today's sales and takings per till, open kitchen tickets, and anything rejected. **Sync now**
forces a send when the link is back (it also happens automatically every few seconds).

## Management
**Executive dashboard** (all outlets, live or provisional), **Control tower** (network, flow, workflows), **Quality & recall** (trace a lot, hold it), **Terminals & sync** (enrol/revoke devices, review rejected operations), **Audit trail**.
