# Installing Yummy OS on a local network (HQ + branch servers)

## The layout

```
                         internet / VPN (HTTPS)
   ┌──────────────────────────────┐            ┌──────────────────────────────┐
   │ HEAD-OFFICE SERVER (HQ)      │◀──────────▶│ BRANCH SERVER  (one per shop │
   │ system of record: stock      │  exactly-  │ or café, on the branch LAN)  │
   │ ledger, accounts, purchasing,│  once,     │ tills · kitchen screens ·    │
   │ production, products, people │  in order  │ refunds · branch view        │
   └──────────────────────────────┘            └──────────────▲───────────────┘
     back office, warehouse, production                        │ branch Wi-Fi / LAN
     and any till without a branch server            tills, KDS screens, manager PC
```

* **HQ** is the only set of books. It can be a PC at head office or a cloud server (Railway, a VPS).
* A **branch server** is optional. Without one, tills talk to HQ directly and each till keeps selling
  offline on its own. **With** one, the whole branch keeps running when the internet is down:
  café orders still reach the kitchen screen, any till can refund another till's receipt, the
  manager sees the day's takings, and new prices and staff arrive as soon as the link returns.
* The branch server stores every till operation in its own database and forwards it to HQ in the
  order it happened. HQ applies each one with exactly the same checks as a till that talks to HQ
  directly, and ignores anything it has already applied, so nothing is lost or counted twice.
* Branch servers only receive what that branch needs: its products and prices, the PIN checks for
  its own staff, and the password checks for that branch's managers. HQ staff and super-admin
  credentials never leave HQ.

## What you need

| | HQ (on site) | Branch server |
|---|---|---|
| Computer | 4 cores, 8 GB RAM, 256 GB SSD | any mini PC: 2 cores, 4 GB RAM, 128 GB SSD |
| Software | Linux (Ubuntu 24.04 LTS) with Docker + Docker Compose, `openssl` | same |
| Network | fixed LAN address; reachable by branches over the internet or a VPN | fixed LAN address on the branch network |
| Power | UPS (≥ 30 min) | UPS (≥ 30 min); the queue of unsent sales lives on this machine |

Give each server a fixed address in the router (DHCP reservation) and a name, e.g. `hq.yummy.lan`
and `shop1.yummy.lan` (router DNS entry, or the hosts file on each device).

## 1 · Install HQ

```bash
git clone <your copy of yummy-os> && cd yummy-os/deploy
./yummy setup hq hq.yummy.lan 192.168.10.5     # secrets in .env + a LAN certificate
./yummy up hq                                   # builds and starts; migrations run automatically
./yummy admin                                   # create the first administrator
./yummy status
```

Open `https://hq.yummy.lan/office`, sign in, then set up the business in the back office:
**Products & prices**, **Recipes**, **People & access**, **Terminals & sync**.

*HQ in the cloud instead?* Use the Railway deployment (root `Dockerfile` + `railway.json`, see README) or any VPS with a
public certificate; branches then need no special trust step.

## 2 · Trust the certificate on every device (local CA only)

`./yummy setup` creates a private certificate authority for the LAN. Browsers only allow the
offline till (service worker, on-device PIN check) on a trusted HTTPS address, so install
`deploy/certs/yummy-local-ca.crt` **once on every till, tablet and PC**:

* **Android**: copy the file to the device → Settings → Security → Encryption & credentials →
  Install a certificate → **CA certificate**.
* **Windows**: double-click the file → Install certificate → Local machine → *Place all certificates in
  the following store* → **Trusted Root Certification Authorities**.
* **iPad / iPhone**: open the file → install the profile → Settings → General → About →
  Certificate trust settings → enable full trust.
* **Linux / Chromebook**: Settings → Privacy & security → Manage certificates → Authorities → Import.

The authority can only vouch for your LAN names and private addresses (X.509 name constraints), so even if its
key leaked it could not impersonate real websites. Still keep `deploy/ca/ca.key` private (it is never mounted into a
container) and back it up offline.

## 3 · Add a branch server

**At HQ** → back office → *Terminals & sync* → **Add branch server** → choose the branch → you get a
one-time 8-digit code (valid 1 hour) and the exact command to run.

**On the branch PC:**

```bash
cd yummy-os/deploy
./yummy setup branch shop1.yummy.lan 192.168.20.5
./yummy trust-hq-ca /path/to/hq-yummy-local-ca.crt   # only if HQ uses the local CA (copy it from HQ)
./yummy up branch
./yummy branch-enrol https://hq.yummy.lan SHOP1-SRV 12345678
./yummy status          # shows branch, HQ address, last contact, operations waiting
```

The branch server immediately receives the branch's products, prices, staff PINs and tills, and
then keeps them up to date every few seconds while the link is up.

## 4 · Point the branch tills and screens at the branch server

On each till / kitchen screen open **`https://shop1.yummy.lan/pos`** (the branch server, not HQ) and
enrol it with a code from HQ (*Terminals & sync → Enrolment code*, or **New till / screen**).
Enrolling needs the HQ link once; after that the device never needs the internet.

> A till that was used with HQ directly keeps its unsent sales in that browser for HQ's address.
> Let it finish syncing (the pill shows **Online**, nothing pending) **before** opening the branch
> server's address on it.

Branch managers sign in at `https://shop1.yummy.lan/office` with their usual username and password
to see the branch view: link to HQ, operations waiting, sales and takings per till, kitchen tickets,
and anything that needs a manager.

## Everyday operation

| Situation | What happens |
|---|---|
| Internet down at a branch | Nothing changes for staff. The branch view shows *Head office: offline* and *Waiting to send* growing. When the link returns the queue drains by itself (or press **Sync now**). |
| HQ down | Same as above for every branch. Back-office work waits for HQ. |
| Price / product / staff change at HQ | Reaches the branch server within seconds while the link is up, and each till on its next sync. |
| Till's Wi-Fi down | The till itself keeps selling offline, as before, and catches up with the branch server. |
| Branch server PC broken | Tills keep selling offline on their own. Replace the PC, restore its latest backup, or install fresh and enrol again; tills catch up when it is back. Operations already accepted by the old server and not yet sent to HQ are only on its disk - hence the UPS and the nightly backup. |
| Revoke a till or branch server | *Terminals & sync → Revoke* at HQ. A branch server stops at once; a till is refused by its branch server on the next data refresh (seconds while online). |

## Backups

* **HQ**: base backup + continuous WAL archive (point-in-time recovery) + nightly logical dump, kept 14 days.
  See `OPERATIONS.md`.
* **Branch server**: nightly logical dump kept 7 days (`./yummy backup-now` for an extra one). The branch
  holds little that HQ doesn't already have once the queue is empty.
* Set `BACKUP_PASSPHRASE` in `.env` / `.env.branch` to encrypt backups, and copy `deploy/backups`
  off the machine regularly.

## Security notes

* All traffic is HTTPS. A branch server refuses a plain-`http://` HQ address (a closed test network
  can override this with `YUMMY_ALLOW_INSECURE_HQ=1`; never in production).
* A branch server authenticates to HQ with its own credential (only a SHA-256 of it is stored at HQ)
  and can only act for tills of its own branch; HQ rejects anything else and records it.
* Secrets live in `.env` / `.env.branch` (mode 600). The branch's HQ credential is stored in the branch
  database; protect the PC (disk encryption, locked room) like a cash drawer.
* The database is never exposed on the network; only ports 80 (redirect) and 443 are published.
