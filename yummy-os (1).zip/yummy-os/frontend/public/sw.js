/* Yummy OS service worker: keeps the app shell available offline.
   API calls are never cached here - the POS keeps its data in IndexedDB. */
const CACHE = "yummy-shell-v3";
const SHELL = ["/", "/index.html", "/manifest.webmanifest", "/icon.svg"];

self.addEventListener("install", (e) => {
  // cache the shell AND the hashed bundles it references, so a cold reload works with no network
  e.waitUntil((async () => {
    const c = await caches.open(CACHE);
    await c.addAll(SHELL);
    const html = await (await fetch("/index.html", { cache: "no-store" })).text();
    const assets = [...new Set(html.match(/\/assets\/[^"']+/g) || [])];
    await c.addAll(assets);
    await self.skipWaiting();
  })());
});
self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim()),
  );
});
self.addEventListener("fetch", (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== "GET" || url.origin !== self.location.origin) return;
  if (url.pathname.startsWith("/api/") || url.pathname.startsWith("/admin")) return;
  if (e.request.mode === "navigate") {
    // network first so new releases arrive; cached shell when offline
    e.respondWith(
      fetch(e.request).then((r) => {
        const copy = r.clone();
        caches.open(CACHE).then((c) => c.put("/index.html", copy));
        return r;
      }).catch(() => caches.match("/index.html")),
    );
    return;
  }
  // hashed build assets: cache first, fill on first use
  e.respondWith(
    caches.match(e.request).then((hit) => hit || fetch(e.request).then((r) => {
      if (r.ok) { const copy = r.clone(); caches.open(CACHE).then((c) => c.put(e.request, copy)); }
      return r;
    })),
  );
});
