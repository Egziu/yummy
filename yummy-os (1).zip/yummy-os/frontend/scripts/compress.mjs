// Pre-compress the production build so the server can send small files without compressing per request.
import { readdirSync, readFileSync, statSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { brotliCompressSync, constants, gzipSync } from "node:zlib";

const root = new URL("../dist", import.meta.url).pathname;
const exts = /\.(js|css|html|svg|webmanifest|json)$/;
let n = 0;
function walk(dir) {
  for (const f of readdirSync(dir)) {
    const p = join(dir, f);
    if (statSync(p).isDirectory()) { walk(p); continue; }
    if (!exts.test(f) || f === "sw.js") continue; // keep the service worker byte-identical for update checks
    const buf = readFileSync(p);
    if (buf.length < 1024) continue;
    writeFileSync(`${p}.gz`, gzipSync(buf, { level: 9 }));
    writeFileSync(`${p}.br`, brotliCompressSync(buf, { params: { [constants.BROTLI_PARAM_QUALITY]: 11 } }));
    n++;
  }
}
walk(root);
console.log(`pre-compressed ${n} files (gzip + brotli)`);
