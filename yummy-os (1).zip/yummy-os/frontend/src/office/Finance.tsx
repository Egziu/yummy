import { useState } from "react";
import { money } from "../lib/money";
import { ago, Badge, Modal, useToast } from "../lib/ui";
import { api, download, post, useApi } from "./api";
import { can, useMe } from "./Office";

type Row = Record<string, any>; // eslint-disable-line @typescript-eslint/no-explicit-any

/* =========================================================== Accounting */
export function Accounting() {
  const me = useMe();
  const toast = useToast();
  const [tab, setTab] = useState<"pnl" | "tb" | "je">("pnl");
  const tb = useApi<Row>(tab === "tb" ? "accounting/trial-balance" : null);
  const pnl = useApi<Row>(tab === "pnl" ? "accounting/pnl" : null);
  const je = useApi<Row[]>(tab === "je" ? "accounting/journals?limit=80" : null);
  const now = new Date();
  return (
    <>
      <div className="page-head"><div><h1>Accounting</h1><div className="sub">Double-entry general ledger posted automatically by every business event. Posted journals are immutable.</div></div>
        <div className="right row">
          {can(me, "reports.export") && <button onClick={() => download("reports/export/trial-balance.csv", "trial-balance.csv")}>Export trial balance</button>}
          {can(me, "accounting.period_close") && <button onClick={async () => {
            const m = prompt("Lock which period? (YYYY-MM)", `${now.getFullYear()}-${String(now.getMonth()).padStart(2, "0")}`);
            if (!m) return;
            const [y, mo] = m.split("-").map(Number);
            try { await post(`accounting/periods/${y}/${mo}/lock`, { lock: true }); toast(`Period ${m} locked`, "good"); } catch (e) { toast((e as Error).message, "bad"); }
          }}>Lock period…</button>}
        </div></div>
      <div className="tabs">{[["pnl", "Profit & loss by branch"], ["tb", "Trial balance"], ["je", "Journal register"]].map(([k, l]) =>
        <button key={k} className={tab === k ? "on" : ""} onClick={() => setTab(k as typeof tab)}>{l}</button>)}</div>
      {tab === "pnl" && pnl.data && (
        <>
          <div className="kpis">
            <div className="card kpi"><div className="label">Revenue (net of VAT, returns)</div><div className="value">{money(pnl.data.consolidated.revenue)}</div><div className="delta muted">{pnl.data.from} → {pnl.data.to}</div></div>
            <div className="card kpi"><div className="label">Expenses incl. COGS</div><div className="value">{money(pnl.data.consolidated.expenses)}</div></div>
            <div className="card kpi"><div className="label">Net result</div><div className="value" style={{ color: Number(pnl.data.consolidated.net_profit) < 0 ? "var(--bad)" : "var(--good)" }}>{money(pnl.data.consolidated.net_profit)}</div><div className="delta muted">before unallocated overheads &amp; payroll</div></div>
          </div>
          <div className="card pad scroll" style={{ maxHeight: "none" }}>
            <table className="data"><thead><tr><th>Branch</th><th className="num">Revenue</th><th className="num">Expenses</th><th className="num">Result</th><th>Lines</th></tr></thead>
              <tbody>{pnl.data.branches.map((b: Row) => (
                <tr key={b.code}><td><b>{b.name}</b></td><td className="num">{money(b.revenue)}</td><td className="num">{money(b.expenses)}</td>
                  <td className="num" style={{ color: Number(b.net_profit) < 0 ? "var(--bad)" : undefined }}><b>{money(b.net_profit)}</b></td>
                  <td className="small">{b.lines.map((l: Row) => <div key={l.code}>{l.code} {l.name}: {money(l.amount)}</div>)}</td></tr>))}</tbody></table>
            <p className="muted small">Production applies labour and overhead to inventory (contra accounts 5110/5120); branch results become true operating profit once payroll and shared overheads are posted and allocated.</p>
          </div>
        </>
      )}
      {tab === "tb" && tb.data && (
        <div className="card pad">
          <Badge kind={tb.data.balanced ? "good" : "bad"}>{tb.data.balanced ? "Debits equal credits" : "OUT OF BALANCE"}</Badge>
          <table className="data" style={{ marginTop: 10 }}><thead><tr><th>Account</th><th>Type</th><th className="num">Debit</th><th className="num">Credit</th></tr></thead>
            <tbody>{tb.data.rows.map((r: Row) => <tr key={r.code}><td>{r.code} {r.name}</td><td className="muted">{r.type.toLowerCase()}</td><td className="num">{Number(r.debit) ? money(r.debit) : ""}</td><td className="num">{Number(r.credit) ? money(r.credit) : ""}</td></tr>)}
              <tr><td><b>Total</b></td><td /><td className="num"><b>{money(tb.data.total_debit)}</b></td><td className="num"><b>{money(tb.data.total_credit)}</b></td></tr></tbody></table>
        </div>
      )}
      {tab === "je" && (
        <div className="col">{(je.data ?? []).map((e) => (
          <div key={e.number} className="card pad">
            <div className="row"><b>{e.number}</b><span>{e.memo}</span><span className="right muted small">{e.date} · {e.source} · {e.posted_by?.name ?? "system"}</span></div>
            <table className="data" style={{ marginTop: 6 }}><tbody>{e.lines.map((l: Row, i: number) => (
              <tr key={i}><td>{l.account}</td><td className="muted">{l.branch}</td><td className="num">{Number(l.debit) ? money(l.debit) : ""}</td><td className="num">{Number(l.credit) ? money(l.credit) : ""}</td></tr>))}</tbody></table>
          </div>))}</div>
      )}
    </>
  );
}

/* =========================================================== Quality & recall */
export function Quality() {
  const toast = useToast();
  const [q, setQ] = useState("");
  const stock = useApi<Row[]>(q.length >= 2 ? `inventory/balances?q=${encodeURIComponent(q)}` : null);
  const [trace, setTrace] = useState<Row | null>(null);
  const lots = new Map<number, Row>();
  for (const r of stock.data ?? []) for (const l of r.lots) lots.set(l.id, { ...l, product: r.name });
  async function run(id: number) {
    try { setTrace(await api(`reports/recall?lot_id=${id}`)); } catch (e) { toast((e as Error).message, "bad"); }
  }
  async function hold(id: number, h: boolean) {
    try { await post(`inventory/lots/${id}/hold`, { hold: h, reason: "Recall investigation" }); toast(h ? "Lot on hold - blocked from use" : "Lot released", "good"); }
    catch (e) { toast((e as Error).message, "bad"); }
  }
  return (
    <>
      <div className="page-head"><div><h1>Quality &amp; recall</h1><div className="sub">Trace any ingredient lot forward to batches, finished-goods lots, outlets and receipts — in seconds.</div></div></div>
      <div className="card pad col">
        <input placeholder="Search a product or lot (e.g. milk, flour, DAIRY-)" value={q} onChange={(e) => setQ(e.target.value)} style={{ maxWidth: 420 }} />
        <table className="data"><thead><tr><th>Lot</th><th>Product</th><th>Expiry</th><th className="num">Qty</th><th /></tr></thead>
          <tbody>{[...lots.values()].slice(0, 40).map((l) => (
            <tr key={l.id}><td>{l.code}</td><td>{l.product}</td><td>{l.expiry ?? "—"}</td><td className="num">{Number(l.qty).toFixed(2)}</td>
              <td className="row"><button className="primary" onClick={() => run(l.id)}>Trace forward</button>
                <button className="danger" onClick={() => hold(l.id, !l.on_hold)}>{l.on_hold ? "Release hold" : "Put on hold"}</button></td></tr>))}</tbody></table>
      </div>
      {trace && (
        <Modal title={`Recall trace · ${trace.lot.product} lot ${trace.lot.code}`} onClose={() => setTrace(null)} wide>
          <h3>Batches made with this lot</h3>
          {trace.batches.length === 0 ? <p className="muted">Not used in production.</p> : (
            <table className="data"><tbody>{trace.batches.map((b: Row, i: number) => <tr key={i}><td>{b.order}</td><td>{b.product}</td><td className="num">{Number(b.qty_consumed).toFixed(2)} used</td><td>→ lot {b.output_lot} ({Number(b.output_qty ?? 0).toFixed(0)})</td></tr>)}</tbody></table>)}
          <h3 style={{ marginTop: 14 }}>Where the affected stock is now</h3>
          <table className="data"><thead><tr><th>Lot</th><th>Product</th><th className="num">Sold</th><th>On hand</th><th /></tr></thead>
            <tbody>{trace.affected_lots.map((a: Row) => (
              <tr key={a.lot_id}><td>{a.lot}{a.on_hold && <> <Badge kind="bad">hold</Badge></>}</td><td>{a.product}</td><td className="num">{Number(a.sold_qty).toFixed(0)}{a.sale_receipts.length ? <div className="small muted">{a.sale_receipts.slice(0, 3).join(", ")}{a.sale_receipts.length > 3 ? "…" : ""}</div> : null}</td>
                <td className="small">{a.on_hand.map((o: Row) => <div key={o.location}>{o.branch} · {o.location}: {Number(o.qty).toFixed(1)}</div>)}</td>
                <td><button className="danger" onClick={() => hold(a.lot_id, true)}>Hold lot</button></td></tr>))}</tbody></table>
        </Modal>
      )}
    </>
  );
}

/* =========================================================== Terminals & sync */
export function SyncMonitor() {
  const me = useMe();
  const toast = useToast();
  const terms = useApi<Row[]>("terminals", 10000);
  const conflicts = useApi<Row[]>("sync/conflicts", 15000);
  const servers = useApi<Row[]>("replica/servers", 10000);
  const [code, setCode] = useState<Row | null>(null);
  const [srvCode, setSrvCode] = useState<Row | null>(null);
  const [newSrv, setNewSrv] = useState<Row | null>(null);
  const [newTerm, setNewTerm] = useState<Row | null>(null);
  async function issueServer(s: Row) {
    try { setSrvCode(await post("replica/servers", s)); setNewSrv(null); servers.reload(); }
    catch (e) { toast((e as Error).message, "bad"); }
  }
  async function createTerminal(t: Row) {
    try { setCode(await post("terminals", t)); setNewTerm(null); terms.reload(); }
    catch (e) { toast((e as Error).message, "bad"); }
  }
  async function issue(t: Row) {
    try { setCode(await post("terminals", { code: t.code, name: t.name, branch: t.branch, kind: t.kind })); }
    catch (e) { toast((e as Error).message, "bad"); }
  }
  return (
    <>
      <div className="page-head"><div><h1>Terminals &amp; offline sync</h1><div className="sub">Every POS keeps selling offline and uploads in order when connected. Nothing is dropped: rejected operations wait here for a manager.</div></div>
        {can(me, "admin.terminals") && <button className="right accent" onClick={() => setNewTerm({ code: "", name: "", branch: me.branches[0]?.code ?? "", kind: "RETAIL" })}>New till / screen</button>}</div>
      <div className="card pad">
        <div className="row"><h3 className="grow">Branch servers</h3>
          {can(me, "admin.terminals") && <button onClick={() => setNewSrv({ code: "", name: "", branch: me.branches[0]?.code ?? "" })}>Add branch server</button>}</div>
        <p className="muted small">A branch server keeps a shop or café running on its own network when the internet is down — tills, kitchen screens and refunds — and forwards everything here in order.</p>
        {(servers.data ?? []).length === 0 ? <p className="muted">No branch servers yet. Tills talk to this server directly.</p> : (
          <table className="data"><thead><tr><th>Server</th><th>Branch</th><th>Status</th><th>Last contact</th><th className="num">Waiting at branch</th><th className="num">Rejected</th><th className="num">Held</th><th className="num">Delivered</th><th /></tr></thead>
            <tbody>{(servers.data ?? []).map((s) => (
              <tr key={s.code}><td><b>{s.code}</b><div className="small muted">{s.name}{s.app_version ? ` · v${s.app_version}` : ""}</div></td><td>{s.branch_name}</td>
                <td>{!s.is_active ? <Badge kind="bad">revoked</Badge> : !s.enrolled ? <Badge>not enrolled</Badge> : s.online ? <Badge kind="good"><span className="dot" />online</Badge> : <Badge kind="warn">offline</Badge>}</td>
                <td className="muted">{ago(s.last_seen_at)}</td><td className="num">{s.pending}</td><td className="num">{s.rejected}</td><td className="num">{s.held ? <Badge kind="warn">{s.held}</Badge> : 0}</td><td className="num">{s.ops_applied}</td>
                <td className="row">{can(me, "admin.terminals") && s.is_active && <>
                  <button onClick={() => issueServer({ code: s.code, name: s.name, branch: s.branch })}>Enrolment code</button>
                  <button className="danger" onClick={async () => { if (confirm(`Revoke ${s.code}? It will stop syncing immediately.`)) { await post(`replica/servers/${s.code}/revoke`); servers.reload(); } }}>Revoke</button></>}</td></tr>))}</tbody></table>)}
      </div>
      <div className="card pad">
        <table className="data"><thead><tr><th>Terminal</th><th>Branch</th><th>Status</th><th>Last seen</th><th>Last sync</th><th className="num">Queued on device</th><th /></tr></thead>
          <tbody>{(terms.data ?? []).map((t) => (
            <tr key={t.code}><td><b>{t.code}</b><div className="small muted">{t.name} · {t.kind}{t.app_version ? ` · v${t.app_version}` : ""}</div></td><td>{t.branch}</td>
              <td>{!t.is_active ? <Badge kind="bad">revoked</Badge> : !t.enrolled ? <Badge>not enrolled</Badge> : t.online ? <Badge kind="good"><span className="dot" />online</Badge> : <Badge kind="warn">offline</Badge>}</td>
              <td className="muted">{ago(t.last_seen_at)}</td><td className="muted">{ago(t.last_sync_at)}</td><td className="num">{t.reported_pending}</td>
              <td className="row">{can(me, "admin.terminals") && <>
                <button onClick={() => issue(t)}>Enrolment code</button>
                {t.enrolled && t.is_active && <button className="danger" onClick={async () => { if (confirm(`Revoke ${t.code}? The device will stop syncing.`)) { await post(`terminals/${t.code}/revoke`); terms.reload(); } }}>Revoke</button>}
              </>}</td></tr>))}</tbody></table>
      </div>
      <div className="card pad">
        <h3>Rejected operations awaiting review</h3>
        {(conflicts.data ?? []).length === 0 ? <p className="muted">No open conflicts. 👍</p> : (
          <table className="data"><thead><tr><th>Received</th><th>Terminal</th><th>Operation</th><th>Reason</th><th /></tr></thead>
            <tbody>{(conflicts.data ?? []).map((c) => (
              <tr key={c.op_id}><td className="muted">{ago(c.received_at)}</td><td>{c.terminal}</td><td>{c.kind} {c.payload?.number ?? ""}</td>
                <td><Badge kind="bad">{c.error}</Badge> <span className="small">{c.detail}</span></td>
                <td><button onClick={async () => { const n = prompt("Resolution (e.g. re-entered correctly as receipt …)"); if (n) { await post(`sync/conflicts/${c.op_id}/resolve`, { note: n }); conflicts.reload(); } }}>Resolve</button></td></tr>))}</tbody></table>)}
      </div>
      {newSrv && (
        <Modal title="Add branch server" onClose={() => setNewSrv(null)}>
          <div className="col">
            <label className="field">Branch<select value={newSrv.branch} onChange={(e) => setNewSrv({ ...newSrv, branch: e.target.value, code: newSrv.code || `${e.target.value}-SRV` })}>
              {me.branches.map((b) => <option key={b.code} value={b.code}>{b.name}</option>)}</select></label>
            <label className="field">Server code<input value={newSrv.code} placeholder={`${newSrv.branch}-SRV`} onChange={(e) => setNewSrv({ ...newSrv, code: e.target.value.toUpperCase() })} /></label>
            <label className="field">Name<input value={newSrv.name} placeholder="Back-room PC" onChange={(e) => setNewSrv({ ...newSrv, name: e.target.value })} /></label>
            <button className="primary lg" onClick={() => issueServer({ ...newSrv, code: newSrv.code || `${newSrv.branch}-SRV`, name: newSrv.name || `${newSrv.branch} server` })}>Create &amp; get enrolment code</button>
          </div>
        </Modal>
      )}
      {srvCode && (
        <Modal title={`Enrol ${srvCode.server}`} onClose={() => setSrvCode(null)}>
          <p>On the branch server, run:</p>
          <pre className="small" style={{ whiteSpace: "pre-wrap", background: "var(--bg-2, #0001)", padding: 10, borderRadius: 8 }}>{`./yummy branch-enrol ${window.location.origin} ${srvCode.server} ${srvCode.enrollment_code}`}</pre>
          <div className="center num" style={{ fontSize: 44, letterSpacing: 6, fontWeight: 800, margin: "14px 0" }}>{srvCode.enrollment_code}</div>
          <p className="muted small">Valid until {new Date(srvCode.expires_at).toLocaleTimeString("en-GB")}. Single use.</p>
        </Modal>
      )}
      {newTerm && (
        <Modal title="New till or kitchen screen" onClose={() => setNewTerm(null)}>
          <div className="col">
            <label className="field">Branch<select value={newTerm.branch} onChange={(e) => setNewTerm({ ...newTerm, branch: e.target.value })}>
              {me.branches.map((b) => <option key={b.code} value={b.code}>{b.name}</option>)}</select></label>
            <label className="field">Device code<input value={newTerm.code} placeholder={`${newTerm.branch}-T2`} onChange={(e) => setNewTerm({ ...newTerm, code: e.target.value.toUpperCase() })} /></label>
            <label className="field">Name<input value={newTerm.name} placeholder="Counter 2" onChange={(e) => setNewTerm({ ...newTerm, name: e.target.value })} /></label>
            <label className="field">Type<select value={newTerm.kind} onChange={(e) => setNewTerm({ ...newTerm, kind: e.target.value })}>
              <option value="RETAIL">Shop till</option><option value="CAFE">Café till</option><option value="KDS">Kitchen / barista screen</option></select></label>
            <button className="primary lg" disabled={!newTerm.code} onClick={() => createTerminal({ ...newTerm, name: newTerm.name || newTerm.code })}>Create &amp; get enrolment code</button>
          </div>
        </Modal>
      )}
      {code && (
        <Modal title={`Enrol ${code.terminal}`} onClose={() => setCode(null)}>
          <p>On the device, open <b>/pos</b>, enter terminal code <b>{code.terminal}</b> and this one-time code:</p>
          <div className="center num" style={{ fontSize: 44, letterSpacing: 6, fontWeight: 800, margin: "14px 0" }}>{code.enrollment_code}</div>
          <p className="muted small">Valid until {new Date(code.expires_at).toLocaleTimeString("en-GB")}. Single use. Issuing a new code does not log out an already-enrolled device; use Revoke for that.</p>
        </Modal>
      )}
    </>
  );
}

/* =========================================================== Audit */
export function AuditPage() {
  const [prefix, setPrefix] = useState("");
  const log = useApi<Row[]>(`audit${prefix ? `?action=${prefix}` : ""}`);
  return (
    <>
      <div className="page-head"><div><h1>Audit trail</h1><div className="sub">Append-only and hash-chained: each entry seals the previous one. Verify any time with <code>manage.py verify_integrity</code>.</div></div>
        <select className="right" style={{ width: 220 }} value={prefix} onChange={(e) => setPrefix(e.target.value)}>
          <option value="">All events</option>{["auth", "pos", "inventory", "transfer", "production", "procurement", "quality", "accounting", "report", "terminal"].map((p) => <option key={p}>{p}</option>)}
        </select></div>
      <div className="card pad">
        <table className="data"><thead><tr><th>When</th><th>Who</th><th>Event</th><th>Object</th><th>Details</th><th>Seal</th></tr></thead>
          <tbody>{(log.data ?? []).map((e) => (
            <tr key={e.id}><td className="muted">{new Date(e.at).toLocaleString("en-GB")}</td><td>{e.actor?.name ?? e.terminal ?? "system"}</td><td><code>{e.action}</code></td>
              <td className="small">{e.object}{e.branch ? ` @ ${e.branch}` : ""}</td><td className="small muted" style={{ maxWidth: 320, overflow: "hidden", textOverflow: "ellipsis" }}>{JSON.stringify(e.data)}</td><td className="small num">{e.hash}</td></tr>))}</tbody></table>
      </div>
    </>
  );
}
