import { useMemo, useState } from "react";
import { money } from "../lib/money";
import { ago, Badge, Modal, useToast } from "../lib/ui";
import { patch, post, useApi } from "./api";
import { can, useMe } from "./Office";

type Row = Record<string, any>; // eslint-disable-line @typescript-eslint/no-explicit-any
interface Meta {
  categories: { id: number; name: string; color: string; sort_order: number; parent_id: number | null }[];
  units: { id: number; code: string; name: string }[];
  tax_rates: { id: number; code: string; name: string; rate: string }[];
  price_lists: { id: number; code: string; name: string; branch: string | null; tax_inclusive: boolean }[];
  kinds: { value: string; label: string }[];
  stations: { value: string; label: string }[];
}

const errText = (e: unknown) => (e as Error).message;

/* =========================================================== Products & prices */
export function Products() {
  const me = useMe();
  const toast = useToast();
  const [q, setQ] = useState("");
  const [kind, setKind] = useState("");
  const [tab, setTab] = useState<"products" | "categories" | "modifiers">("products");
  const meta = useApi<Meta>("catalog/meta");
  const list = useApi<Row[]>(tab === "products" ? `catalog/products?q=${encodeURIComponent(q)}${kind ? `&kind=${kind}` : ""}` : null);
  const mods = useApi<Row[]>(tab === "modifiers" ? "catalog/modifiers" : null);
  const [editing, setEditing] = useState<Row | null>(null);
  const [pricing, setPricing] = useState<Row | null>(null);
  const [cat, setCat] = useState<Row | null>(null);
  const [mod, setMod] = useState<Row | null>(null);
  const canEdit = can(me, "catalog.manage");
  const lists = meta.data?.price_lists ?? [];
  return (
    <>
      <div className="page-head"><div><h1>Products &amp; prices</h1>
        <div className="sub">Everything you buy, make or sell. Price changes take effect immediately and reach every till on its next sync; past receipts keep the price they were sold at.</div></div>
        {canEdit && tab === "products" && <button className="right accent" onClick={() => setEditing({})}>New product</button>}
        {canEdit && tab === "categories" && <button className="right accent" onClick={() => setCat({})}>New category</button>}
        {canEdit && tab === "modifiers" && <button className="right accent" onClick={() => setMod({ applies_to: [] })}>New add-on</button>}
      </div>
      <div className="tabs">{[["products", "Products"], ["categories", "Categories"], ["modifiers", "Café add-ons"]].map(([k, l]) =>
        <button key={k} className={tab === k ? "on" : ""} onClick={() => setTab(k as typeof tab)}>{l}</button>)}</div>

      {tab === "products" && (
        <div className="card pad col">
          <div className="row wrap">
            <input style={{ maxWidth: 320 }} placeholder="Search name, SKU, barcode" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search products" />
            <select style={{ maxWidth: 240 }} value={kind} onChange={(e) => setKind(e.target.value)} aria-label="Filter by type">
              <option value="">All types</option>{meta.data?.kinds.map((k) => <option key={k.value} value={k.value}>{k.label}</option>)}</select>
            <span className="right muted small">{list.data?.length ?? 0} items</span>
          </div>
          {list.error && <p className="muted">{list.error}</p>}
          <div className="scroll" style={{ maxHeight: 640 }}>
            <table className="data"><thead><tr><th>Product</th><th>Type</th><th>Category</th>{lists.map((l) => <th key={l.code} className="num">{l.name}</th>)}<th className="num">Std cost</th><th>Status</th><th /></tr></thead>
              <tbody>{(list.data ?? []).map((p) => (
                <tr key={p.id}>
                  <td><b>{p.name}</b>{p.name_local && <span className="muted"> · {p.name_local}</span>}<div className="small muted">{p.sku}{p.barcode ? ` · ${p.barcode}` : ""} · {p.unit}</div></td>
                  <td className="small">{p.kind_label}{p.is_sellable && <> <Badge kind="good">sold</Badge></>}</td>
                  <td className="small">{p.category}</td>
                  {lists.map((l) => <td key={l.code} className="num">{p.prices[l.code] ? money(p.prices[l.code]) : <span className="muted">—</span>}</td>)}
                  <td className="num">{money(p.standard_cost)}</td>
                  <td>{p.is_active ? <Badge kind="good">active</Badge> : <Badge>inactive</Badge>}</td>
                  <td className="row" style={{ justifyContent: "flex-end" }}>
                    {can(me, "price.manage") && p.is_sellable && <button onClick={() => setPricing(p)}>Prices</button>}
                    {canEdit && <button onClick={() => setEditing(p)}>Edit</button>}
                  </td></tr>))}</tbody></table>
          </div>
        </div>
      )}

      {tab === "categories" && (
        <div className="card pad">
          <table className="data"><thead><tr><th>Category</th><th>Order</th><th>Inside</th><th /></tr></thead>
            <tbody>{(meta.data?.categories ?? []).map((c) => (
              <tr key={c.id}><td><span className="swatch" style={{ background: c.color }} />{c.name}</td><td>{c.sort_order}</td>
                <td className="muted">{meta.data?.categories.find((x) => x.id === c.parent_id)?.name ?? "—"}</td>
                <td>{canEdit && <button onClick={() => setCat(c)}>Edit</button>}</td></tr>))}</tbody></table>
        </div>
      )}

      {tab === "modifiers" && (
        <div className="card pad">
          <p className="muted small">Add-ons appear on the till when a drink is tapped. If an add-on uses an ingredient, that stock is consumed with every sale.</p>
          <table className="data"><thead><tr><th>Add-on</th><th>Group</th><th className="num">Price</th><th>Uses</th><th>For</th><th /></tr></thead>
            <tbody>{(mods.data ?? []).map((m) => (
              <tr key={m.id}><td><b>{m.name}</b> {!m.is_active && <Badge>off</Badge>}</td><td>{m.group}</td><td className="num">+{money(m.price_delta)}</td>
                <td className="small">{m.ingredient ? `${Number(m.ingredient_qty)} × ${m.ingredient}` : "—"}</td>
                <td className="small muted">{m.applies_to.length} products</td>
                <td>{canEdit && <button onClick={() => setMod(m)}>Edit</button>}</td></tr>))}</tbody></table>
        </div>
      )}

      {editing && meta.data && <ProductForm meta={meta.data} p={editing} onClose={() => setEditing(null)}
        onSaved={() => { setEditing(null); list.reload(); }} />}
      {pricing && <PriceForm p={pricing} lists={lists} onClose={() => setPricing(null)} onSaved={() => { setPricing(null); list.reload(); toast("Price updated - tills pick it up on their next sync", "good"); }} />}
      {cat && meta.data && <CategoryForm c={cat} cats={meta.data.categories} onClose={() => setCat(null)} onSaved={() => { setCat(null); meta.reload(); }} />}
      {mod && <ModifierForm m={mod} onClose={() => setMod(null)} onSaved={() => { setMod(null); mods.reload(); }} />}
    </>
  );
}

function ProductForm({ meta, p, onClose, onSaved }: { meta: Meta; p: Row; onClose: () => void; onSaved: () => void }) {
  const toast = useToast();
  const isNew = !p.id;
  const [f, setF] = useState<Row>(() => ({
    sku: "", barcode: "", name: "", name_local: "", kind: "FINISHED", category_id: meta.categories[0]?.id,
    unit_id: meta.units.find((u) => u.code === "pcs")?.id ?? meta.units[0]?.id, tax_rate_id: meta.tax_rates[0]?.id ?? null,
    is_sellable: false, track_lots: true, shelf_life_days: "", reorder_point: "0", reorder_qty: "0", station: "NONE",
    allergens: "", color: "", is_active: true, ...p,
  }));
  const set = (k: string, v: unknown) => setF((x) => ({ ...x, [k]: v }));
  const madeToOrder = f.kind === "MENU" || f.kind === "SERVICE";
  async function save(e: React.FormEvent) {
    e.preventDefault();
    const body = { ...f, shelf_life_days: f.shelf_life_days === "" || f.shelf_life_days === null ? null : Number(f.shelf_life_days),
      tax_rate_id: f.tax_rate_id || null, category_id: Number(f.category_id), unit_id: Number(f.unit_id) };
    try {
      if (isNew) await post("catalog/products", body); else await patch(`catalog/products/${p.id}`, body);
      toast(isNew ? `${f.name} created` : `${f.name} saved`, "good");
      onSaved();
    } catch (e2) { toast(errText(e2), "bad"); }
  }
  return (
    <Modal title={isNew ? "New product" : `Edit ${p.name}`} onClose={onClose} wide>
      <form className="col" onSubmit={save}>
        <div className="form-grid">
          <label className="field span2">Name<input required value={f.name} onChange={(e) => set("name", e.target.value)} /></label>
          <label className="field">Local name (Amharic / Tigrinya)<input value={f.name_local} onChange={(e) => set("name_local", e.target.value)} /></label>
          <label className="field">SKU (code)<input required value={f.sku} onChange={(e) => set("sku", e.target.value.toUpperCase())} pattern="[A-Za-z0-9][A-Za-z0-9\-_.]{1,39}" /></label>
          <label className="field">Barcode<input value={f.barcode} onChange={(e) => set("barcode", e.target.value)} inputMode="numeric" /></label>
          <label className="field">Type<select value={f.kind} onChange={(e) => set("kind", e.target.value)}>{meta.kinds.map((k) => <option key={k.value} value={k.value}>{k.label}</option>)}</select></label>
          <label className="field">Category<select value={f.category_id} onChange={(e) => set("category_id", e.target.value)}>{meta.categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
          <label className="field">Unit<select value={f.unit_id} onChange={(e) => set("unit_id", e.target.value)}>{meta.units.map((u) => <option key={u.id} value={u.id}>{u.code} · {u.name}</option>)}</select></label>
          <label className="field">VAT<select value={f.tax_rate_id ?? ""} onChange={(e) => set("tax_rate_id", e.target.value ? Number(e.target.value) : null)}>
            <option value="">No VAT</option>{meta.tax_rates.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}</select></label>
          <label className="field">Kitchen / bar screen<select value={f.station} onChange={(e) => set("station", e.target.value)}>{meta.stations.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}</select></label>
          {!madeToOrder && <label className="field">Shelf life (days)<input value={f.shelf_life_days ?? ""} onChange={(e) => set("shelf_life_days", e.target.value)} inputMode="numeric" /></label>}
          {!madeToOrder && <label className="field">Reorder point<input value={f.reorder_point} onChange={(e) => set("reorder_point", e.target.value)} inputMode="decimal" /></label>}
          {!madeToOrder && <label className="field">Reorder quantity<input value={f.reorder_qty} onChange={(e) => set("reorder_qty", e.target.value)} inputMode="decimal" /></label>}
          <label className="field">Allergens<input value={f.allergens} placeholder="gluten,egg,milk" onChange={(e) => set("allergens", e.target.value.toLowerCase())} /></label>
          <label className="field">Till tile colour<input type="color" value={f.color || "#c8742b"} onChange={(e) => set("color", e.target.value)} /></label>
        </div>
        <div className="row wrap" style={{ gap: 18 }}>
          <label className="chk"><input type="checkbox" checked={f.is_sellable} onChange={(e) => set("is_sellable", e.target.checked)} />Sold at the tills</label>
          {!madeToOrder && <label className="chk"><input type="checkbox" checked={f.track_lots} onChange={(e) => set("track_lots", e.target.checked)} />Track lots &amp; expiry</label>}
          <label className="chk"><input type="checkbox" checked={f.is_active} onChange={(e) => set("is_active", e.target.checked)} />Active</label>
        </div>
        {f.is_sellable && isNew && <p className="muted small">After saving, use <b>Prices</b> to set the selling price - a product without a price does not appear on the tills.</p>}
        {(f.kind === "MENU" || f.kind === "FINISHED" || f.kind === "SEMI") && <p className="muted small">Ingredients come from the product's approved recipe (Production → Recipes).</p>}
        <div className="row"><button type="button" onClick={onClose}>Cancel</button><button className="primary right">Save</button></div>
      </form>
    </Modal>
  );
}

function PriceForm({ p, lists, onClose, onSaved }: { p: Row; lists: Meta["price_lists"]; onClose: () => void; onSaved: () => void }) {
  const toast = useToast();
  const [vals, setVals] = useState<Record<string, string>>(() => Object.fromEntries(lists.map((l) => [l.code, p.prices[l.code] ?? ""])));
  async function save() {
    try {
      for (const l of lists) {
        const now = vals[l.code]?.trim() ?? "";
        const was = p.prices[l.code] ?? "";
        if (now === was || (now && was && Number(now) === Number(was))) continue;
        if (now === "") await post(`catalog/products/${p.id}/price/remove`, { price_list: l.code });
        else await post(`catalog/products/${p.id}/price`, { price_list: l.code, price: now });
      }
      onSaved();
    } catch (e) { toast(errText(e), "bad"); }
  }
  return (
    <Modal title={`Prices · ${p.name}`} onClose={onClose}>
      <div className="col">
        <p className="muted small">Leave a price list empty to stop selling the product there. A branch-specific list overrides the default.</p>
        {lists.map((l) => (
          <label key={l.code} className="field">{l.name}{l.branch ? ` (${l.branch})` : " (all branches)"} · ETB {l.tax_inclusive ? "incl. VAT" : "excl. VAT"}
            <input value={vals[l.code]} inputMode="decimal" onChange={(e) => setVals((v) => ({ ...v, [l.code]: e.target.value }))} /></label>))}
        <button className="primary lg" onClick={save}>Save prices</button>
      </div>
    </Modal>
  );
}

function CategoryForm({ c, cats, onClose, onSaved }: { c: Row; cats: Meta["categories"]; onClose: () => void; onSaved: () => void }) {
  const toast = useToast();
  const [f, setF] = useState<Row>({ name: "", color: "#C8742B", sort_order: 0, parent_id: null, ...c });
  async function save() {
    try {
      const body = { ...f, sort_order: Number(f.sort_order) || 0, parent_id: f.parent_id ? Number(f.parent_id) : null, color: f.color.toUpperCase() };
      if (c.id) await patch(`catalog/categories/${c.id}`, body); else await post("catalog/categories", body);
      onSaved();
    } catch (e) { toast(errText(e), "bad"); }
  }
  return (
    <Modal title={c.id ? `Edit ${c.name}` : "New category"} onClose={onClose}>
      <div className="col">
        <label className="field">Name<input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></label>
        <label className="field">Colour on the till<input type="color" value={f.color} onChange={(e) => setF({ ...f, color: e.target.value })} /></label>
        <label className="field">Order<input value={f.sort_order} inputMode="numeric" onChange={(e) => setF({ ...f, sort_order: e.target.value })} /></label>
        <label className="field">Inside<select value={f.parent_id ?? ""} onChange={(e) => setF({ ...f, parent_id: e.target.value || null })}>
          <option value="">— top level —</option>{cats.filter((x) => x.id !== c.id).map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}</select></label>
        <button className="primary lg" onClick={save}>Save</button>
      </div>
    </Modal>
  );
}

function ModifierForm({ m, onClose, onSaved }: { m: Row; onClose: () => void; onSaved: () => void }) {
  const toast = useToast();
  const prods = useApi<Row[]>("catalog/products?active=1");
  const [f, setF] = useState<Row>({ name: "", group: "Extras", price_delta: "0", ingredient_id: null, ingredient_qty: "0", is_active: true, ...m });
  const sellable = (prods.data ?? []).filter((p) => p.is_sellable);
  const stocked = (prods.data ?? []).filter((p) => ["RAW", "PACKAGING", "SEMI", "RESALE", "FINISHED"].includes(p.kind));
  async function save() {
    try {
      const body = { ...f, ingredient_id: f.ingredient_id ? Number(f.ingredient_id) : null };
      if (m.id) await patch(`catalog/modifiers/${m.id}`, body); else await post("catalog/modifiers", body);
      toast("Add-on saved", "good");
      onSaved();
    } catch (e) { toast(errText(e), "bad"); }
  }
  const toggle = (id: number) => setF((x) => ({ ...x, applies_to: x.applies_to.includes(id) ? x.applies_to.filter((i: number) => i !== id) : [...x.applies_to, id] }));
  return (
    <Modal title={m.id ? `Edit ${m.name}` : "New café add-on"} onClose={onClose} wide>
      <div className="col">
        <div className="form-grid">
          <label className="field">Name<input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></label>
          <label className="field">Group<input value={f.group} onChange={(e) => setF({ ...f, group: e.target.value })} /></label>
          <label className="field">Extra price (ETB)<input value={f.price_delta} inputMode="decimal" onChange={(e) => setF({ ...f, price_delta: e.target.value })} /></label>
          <label className="field">Uses ingredient<select value={f.ingredient_id ?? ""} onChange={(e) => setF({ ...f, ingredient_id: e.target.value || null })}>
            <option value="">— none —</option>{stocked.map((p) => <option key={p.id} value={p.id}>{p.name} ({p.unit})</option>)}</select></label>
          {f.ingredient_id && <label className="field">Quantity used<input value={f.ingredient_qty} inputMode="decimal" onChange={(e) => setF({ ...f, ingredient_qty: e.target.value })} /></label>}
        </div>
        <label className="chk"><input type="checkbox" checked={f.is_active} onChange={(e) => setF({ ...f, is_active: e.target.checked })} />Offered at the tills</label>
        <div className="muted small">Offer it on:</div>
        <div className="row wrap" style={{ gap: 6 }}>{sellable.map((p) => (
          <button type="button" key={p.id} className={f.applies_to.includes(p.id) ? "primary" : ""} style={{ minHeight: 34 }} onClick={() => toggle(p.id)}>{p.name}</button>))}</div>
        <button className="primary lg" onClick={save}>Save add-on</button>
      </div>
    </Modal>
  );
}

/* =========================================================== Recipes */
export function Recipes() {
  const me = useMe();
  const toast = useToast();
  const recipes = useApi<Row[]>("production/recipes");
  const [editing, setEditing] = useState<Row | null>(null);
  const [filter, setFilter] = useState("");
  const rows = (recipes.data ?? []).filter((r) => !filter || r.product.toLowerCase().includes(filter.toLowerCase()) || r.sku.toLowerCase().includes(filter.toLowerCase()));
  const drafts = rows.filter((r) => r.status === "DRAFT");
  async function act(path: string, ok: string) {
    try { await post(path); toast(ok, "good"); recipes.reload(); } catch (e) { toast(errText(e), "bad"); }
  }
  const card = (r: Row) => (
    <div key={r.id} className="card pad">
      <div className="row"><h3 className="grow">{r.product}</h3><Badge kind={r.status === "APPROVED" ? "good" : "warn"}>v{r.version} {r.status === "APPROVED" ? "active" : "draft"}</Badge></div>
      <p className="muted small">Batch makes {Number(r.output_qty)} {r.unit} · {Number(r.labor_minutes)} labour min{r.workstation ? ` · ${r.workstation}` : ""}</p>
      <table className="data"><tbody>{r.lines.map((l: Row) => <tr key={l.sku}><td>{l.name}{l.phantom && <> <Badge>sub-recipe</Badge></>}</td>
        <td className="num">{Number(l.qty)} {l.unit}{Number(l.waste_pct) ? ` +${Number(l.waste_pct)}% waste` : ""}</td></tr>)}</tbody></table>
      {r.cost?.unit_cost ? <div className="row" style={{ marginTop: 8 }}><span className="muted small">materials {money(r.cost.material_cost)} · labour {money(r.cost.labor_cost)} · overhead {money(r.cost.overhead_cost)}</span>
        <b className="right num">ETB {money(r.cost.unit_cost)}/{r.unit}</b></div>
        : r.cost?.error ? <p className="small" style={{ color: "var(--bad)" }}>{r.cost.error}</p> : null}
      <div className="small muted" style={{ marginTop: 6 }}>Written by {r.created_by?.name ?? "—"}{r.approved_by ? ` · approved by ${r.approved_by.name} ${ago(r.approved_at)}` : ""}</div>
      <div className="row" style={{ marginTop: 10 }}>
        {r.status === "DRAFT" && can(me, "recipe.approve") && (r.created_by?.id === me.id
          ? <span className="small muted">Another person must approve your recipe.</span>
          : <button className="primary" onClick={() => act(`production/recipes/${r.id}/approve`, `${r.product} v${r.version} approved - now used for sales and costing`)}>Approve</button>)}
        {r.status === "DRAFT" && can(me, "recipe.manage") && <button className="danger" onClick={() => { if (confirm("Discard this draft?")) void act(`production/recipes/${r.id}/discard`, "Draft discarded"); }}>Discard</button>}
        {can(me, "recipe.manage") && <button className="right" onClick={() => setEditing(r)}>{r.status === "APPROVED" ? "New version" : "Copy"}</button>}
      </div>
    </div>
  );
  return (
    <>
      <div className="page-head"><div><h1>Recipes</h1>
        <div className="sub">Bill of materials for bakery products and café drinks. A new version is a draft until a second person approves it; approval replaces the previous version for production, stock consumption and costing.</div></div>
        {can(me, "recipe.manage") && <button className="right accent" onClick={() => setEditing({})}>New recipe</button>}</div>
      <div className="row" style={{ marginBottom: 12 }}><input style={{ maxWidth: 320 }} placeholder="Find a recipe" value={filter} onChange={(e) => setFilter(e.target.value)} aria-label="Find a recipe" /></div>
      {recipes.error && <p className="muted">{recipes.error}</p>}
      {drafts.length > 0 && <><h3 style={{ margin: "6px 0 10px" }}>Waiting for approval ({drafts.length})</h3>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(330px, 1fr))", gap: 14, marginBottom: 18 }}>{drafts.map(card)}</div></>}
      <h3 style={{ margin: "6px 0 10px" }}>Active recipes</h3>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(330px, 1fr))", gap: 14 }}>{rows.filter((r) => r.status === "APPROVED").map(card)}</div>
      {editing && <RecipeForm base={editing} onClose={() => setEditing(null)} onSaved={() => { setEditing(null); recipes.reload(); }} />}
    </>
  );
}

function RecipeForm({ base, onClose, onSaved }: { base: Row; onClose: () => void; onSaved: () => void }) {
  const toast = useToast();
  const prods = useApi<Row[]>("catalog/products?active=1");
  const [sku, setSku] = useState<string>(base.sku ?? "");
  const [out, setOut] = useState<string>(base.output_qty ? String(Number(base.output_qty)) : "1");
  const [labor, setLabor] = useState<string>(base.labor_minutes ? String(Number(base.labor_minutes)) : "0");
  const [ws, setWs] = useState<string>(base.workstation ?? "");
  const [instr, setInstr] = useState<string>(base.instructions ?? "");
  const [lines, setLines] = useState<Row[]>(() => (base.lines ?? []).map((l: Row) => ({ sku: l.sku, qty: String(Number(l.qty)), waste_pct: String(Number(l.waste_pct)), phantom: l.phantom })));
  const all = prods.data ?? [];
  const makeable = all.filter((p) => ["FINISHED", "SEMI", "MENU"].includes(p.kind));
  const ingredients = useMemo(() => all.filter((p) => p.sku !== sku && p.kind !== "MENU" && p.kind !== "SERVICE"), [all, sku]);
  const unitOf = (s: string) => all.find((p) => p.sku === s)?.unit ?? "";
  const setLine = (i: number, k: string, v: unknown) => setLines((ls) => ls.map((l, j) => (j === i ? { ...l, [k]: v } : l)));
  async function save() {
    try {
      await post("production/recipes", { sku, output_qty: out, labor_minutes: labor, workstation: ws, instructions: instr,
        lines: lines.filter((l) => l.sku).map((l) => ({ ...l, phantom: !!l.phantom })) });
      toast("Draft saved - ask a second person to approve it", "good");
      onSaved();
    } catch (e) { toast(errText(e), "bad"); }
  }
  return (
    <Modal title={base.id ? `New version of ${base.product}` : "New recipe"} onClose={onClose} wide>
      <div className="col">
        <div className="form-grid">
          <label className="field span2">Product made<select value={sku} onChange={(e) => setSku(e.target.value)} disabled={!!base.id}>
            <option value="">— choose —</option>{makeable.map((p) => <option key={p.sku} value={p.sku}>{p.name} ({p.sku})</option>)}</select></label>
          <label className="field">One batch makes ({unitOf(sku) || "units"})<input value={out} inputMode="decimal" onChange={(e) => setOut(e.target.value)} /></label>
          <label className="field">Labour minutes per batch<input value={labor} inputMode="decimal" onChange={(e) => setLabor(e.target.value)} /></label>
          <label className="field">Workstation<input value={ws} onChange={(e) => setWs(e.target.value)} placeholder="Oven line 1" /></label>
        </div>
        <table className="data lines-editor"><thead><tr><th>Ingredient</th><th className="num">Quantity</th><th className="num">Waste %</th><th>Sub-recipe</th><th /></tr></thead>
          <tbody>{lines.map((l, i) => (
            <tr key={i}>
              <td><select value={l.sku} onChange={(e) => setLine(i, "sku", e.target.value)} aria-label="Ingredient"><option value="">— choose —</option>
                {ingredients.map((p) => <option key={p.sku} value={p.sku}>{p.name} ({p.unit})</option>)}</select></td>
              <td><input value={l.qty} inputMode="decimal" onChange={(e) => setLine(i, "qty", e.target.value)} aria-label="Quantity" style={{ textAlign: "right" }} /></td>
              <td><input value={l.waste_pct} inputMode="decimal" onChange={(e) => setLine(i, "waste_pct", e.target.value)} aria-label="Waste percent" style={{ textAlign: "right", maxWidth: 90 }} /></td>
              <td><label className="chk"><input type="checkbox" checked={!!l.phantom} onChange={(e) => setLine(i, "phantom", e.target.checked)} />use its recipe</label></td>
              <td><button className="ghost" onClick={() => setLines((ls) => ls.filter((_, j) => j !== i))} aria-label="Remove line">✕</button></td></tr>))}</tbody></table>
        <button onClick={() => setLines((ls) => [...ls, { sku: "", qty: "", waste_pct: "0", phantom: false }])}>+ Add ingredient</button>
        <label className="field">Method / notes<textarea rows={3} value={instr} onChange={(e) => setInstr(e.target.value)} /></label>
        <p className="muted small">Quantities are per batch, in each ingredient's own unit. Tick <b>sub-recipe</b> for an item made in-house (e.g. dough) to use its approved recipe instead of stock.</p>
        <button className="primary lg" disabled={!sku || !lines.some((l) => l.sku)} onClick={save}>Save as draft</button>
      </div>
    </Modal>
  );
}

/* =========================================================== People */
export function People() {
  const me = useMe();
  const [q, setQ] = useState("");
  const users = useApi<Row[]>(`iam/users${q ? `?q=${encodeURIComponent(q)}` : ""}`);
  const meta = useApi<{ roles: Row[]; branches: Row[] }>("iam/roles");
  const [editing, setEditing] = useState<Row | null>(null);
  return (
    <>
      <div className="page-head"><div><h1>People &amp; access</h1>
        <div className="sub">Who can sign in, what they can do and where. Back-office staff use a username and password; till staff use a 4–8 digit PIN. Every change is in the audit trail.</div></div>
        <button className="right accent" onClick={() => setEditing({})}>Add person</button></div>
      <div className="card pad col">
        <input style={{ maxWidth: 320 }} placeholder="Search name or username" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search people" />
        {users.error && <p className="muted">{users.error}</p>}
        <div className="scroll" style={{ maxHeight: 640 }}>
          <table className="data"><thead><tr><th>Person</th><th>Roles</th><th>Sign-in</th><th>Last sign-in</th><th>Status</th><th /></tr></thead>
            <tbody>{(users.data ?? []).map((u) => (
              <tr key={u.id}><td><b>{u.name}</b><div className="small muted">{u.username}{u.employee_code ? ` · ${u.employee_code}` : ""}</div></td>
                <td className="small">{u.is_superuser ? <Badge kind="bad">super admin</Badge> : u.roles.map((r: Row, i: number) => <div key={i}>{r.role_name} <span className="muted">@ {r.branch ?? "all"}</span></div>)}</td>
                <td className="small">{u.has_password ? "password" : ""}{u.has_password && u.has_pin ? " + " : ""}{u.has_pin ? "PIN" : ""}</td>
                <td className="muted small">{ago(u.last_login)}</td>
                <td>{!u.is_active ? <Badge>disabled</Badge> : u.locked ? <Badge kind="bad">locked</Badge> : <Badge kind="good">active</Badge>}</td>
                <td>{(!u.is_superuser || me.is_superuser) && <button onClick={() => setEditing(u)}>Edit</button>}</td></tr>))}</tbody></table>
        </div>
      </div>
      {editing && meta.data && <PersonForm u={editing} roles={meta.data.roles} branches={meta.data.branches}
        onClose={() => setEditing(null)} onSaved={() => { setEditing(null); users.reload(); }} />}
    </>
  );
}

function PersonForm({ u, roles, branches, onClose, onSaved }: { u: Row; roles: Row[]; branches: Row[]; onClose: () => void; onSaved: () => void }) {
  const toast = useToast();
  const me = useMe();
  const isNew = !u.id;
  const [f, setF] = useState<Row>({ username: "", display_name: "", employee_code: "", password: "", pin: "", is_active: true, ...u });
  const [assign, setAssign] = useState<Row[]>(() => (u.roles ?? []).map((r: Row) => ({ role: r.role, branch: r.branch ?? "" })));
  async function save() {
    const body: Row = { display_name: f.display_name, employee_code: f.employee_code, roles: assign.filter((a) => a.role).map((a) => ({ role: a.role, branch: a.branch || null })) };
    if (isNew) body.username = f.username.trim().toLowerCase();
    if (f.password) body.password = f.password;
    if (f.pin) body.pin = f.pin;
    if (!isNew) body.is_active = f.is_active;
    try {
      if (isNew) await post("iam/users", body); else await patch(`iam/users/${u.id}`, body);
      toast(isNew ? "Person added" : "Saved", "good");
      onSaved();
    } catch (e) { toast(errText(e), "bad"); }
  }
  async function quick(body: Row, ok: string) {
    try { await patch(`iam/users/${u.id}`, body); toast(ok, "good"); onSaved(); } catch (e) { toast(errText(e), "bad"); }
  }
  return (
    <Modal title={isNew ? "Add person" : `Edit ${u.name}`} onClose={onClose} wide>
      <div className="col">
        <div className="form-grid">
          <label className="field">Username<input value={f.username} disabled={!isNew} onChange={(e) => setF({ ...f, username: e.target.value })} placeholder="shop1.cashier2" autoComplete="off" /></label>
          <label className="field">Full name<input value={f.display_name} onChange={(e) => setF({ ...f, display_name: e.target.value })} /></label>
          <label className="field">Employee no.<input value={f.employee_code} onChange={(e) => setF({ ...f, employee_code: e.target.value })} /></label>
          <label className="field">{isNew ? "Password (back office)" : "New password"}<input type="password" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} autoComplete="new-password" placeholder={isNew ? "leave empty for till-only staff" : "unchanged"} /></label>
          <label className="field">{isNew ? "Till PIN" : "New till PIN"}<input type="password" inputMode="numeric" value={f.pin} onChange={(e) => setF({ ...f, pin: e.target.value.replace(/\D/g, "").slice(0, 8) })} autoComplete="new-password" placeholder={u.has_pin ? "unchanged" : "4–8 digits"} /></label>
        </div>
        <div className="muted small">Roles — a role can be limited to one branch or apply to all:</div>
        <table className="data lines-editor"><tbody>{assign.map((a, i) => (
          <tr key={i}><td><select value={a.role} onChange={(e) => setAssign((x) => x.map((y, j) => (j === i ? { ...y, role: e.target.value } : y)))} aria-label="Role">
            <option value="">— role —</option>{roles.filter((r) => r.code !== "SUPER_ADMIN" || me.is_superuser).map((r) => <option key={r.code} value={r.code}>{r.name}</option>)}</select></td>
            <td><select value={a.branch} onChange={(e) => setAssign((x) => x.map((y, j) => (j === i ? { ...y, branch: e.target.value } : y)))} aria-label="Branch">
              <option value="">All branches</option>{branches.map((b) => <option key={b.code} value={b.code}>{b.name}</option>)}</select></td>
            <td><button className="ghost" onClick={() => setAssign((x) => x.filter((_, j) => j !== i))} aria-label="Remove role">✕</button></td></tr>))}</tbody></table>
        <button onClick={() => setAssign((x) => [...x, { role: "", branch: "" }])}>+ Add role</button>
        {!isNew && <div className="row wrap">
          <label className="chk"><input type="checkbox" checked={f.is_active} onChange={(e) => setF({ ...f, is_active: e.target.checked })} />Account active</label>
          {u.locked && <button onClick={() => quick({ unlock: true }, "Unlocked")}>Unlock</button>}
          {u.has_pin && <button className="danger" onClick={() => quick({ clear_pin: true }, "PIN removed")}>Remove PIN</button>}
        </div>}
        <p className="muted small">PINs must differ between people who share a branch — a supervisor approval is recognised by PIN alone. Passwords need 10+ characters and must not be common.</p>
        <button className="primary lg" onClick={save}>{isNew ? "Add person" : "Save changes"}</button>
      </div>
    </Modal>
  );
}
