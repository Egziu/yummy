import { createContext, useContext, useEffect, useState } from "react";
import { NavLink, Navigate, Route, Routes } from "react-router-dom";
import { useTheme } from "../lib/ui";
import { api, getToken, post, setToken } from "./api";
import { Dashboard } from "./Dashboard";
import { ControlTower } from "./Tower";
import { WarehouseMap } from "./MapPage";
import { Inventory, Procurement, Production, Transfers } from "./Ops";
import { Accounting, AuditPage, Quality, SyncMonitor } from "./Finance";
import { People, Products, Recipes } from "./Setup";
import { BranchHub, useMode } from "./BranchHub";

export interface Me { id: number; username: string; name: string; is_superuser: boolean; permissions: string[];
  branches: { id: number; code: string; name: string; kind: string }[] }
const MeCtx = createContext<Me | null>(null);
export const useMe = () => useContext(MeCtx)!;
export const can = (me: Me, p: string) => me.is_superuser || me.permissions.includes(p);

export function Office() {
  const mode = useMode();
  if (mode === null) return null;
  return mode.mode === "branch" ? <BranchHub mode={mode} /> : <HqOffice />;
}

function HqOffice() {
  const [me, setMe] = useState<Me | null>(null);
  const [checking, setChecking] = useState(true);
  const [theme, toggleTheme] = useTheme();
  useEffect(() => {
    const out = () => setMe(null);
    window.addEventListener("yummy:logout", out);
    if (getToken()) api<Me>("auth/me").then(setMe).catch(() => setMe(null)).finally(() => setChecking(false));
    else setChecking(false);
    return () => window.removeEventListener("yummy:logout", out);
  }, []);
  if (checking) return null;
  if (!me) return <OfficeLogin onLogin={setMe} />;

  const nav: [string, string, string, string?][] = [
    ["Overview", "", "", ""],
    ["dashboard", "Executive dashboard", "◆", "reports.branch"],
    ["tower", "Control tower", "⌁", "reports.branch"],
    ["Operations", "", "", ""],
    ["warehouse", "Warehouse map", "▦", "inventory.view"],
    ["inventory", "Inventory", "▤", "inventory.view"],
    ["transfers", "Transfers", "⇄", "transfer.request|transfer.approve|transfer.dispatch|transfer.receive"],
    ["production", "Production", "♨", "production.view"],
    ["procurement", "Procurement", "⛟", "procurement.request|procurement.approve|procurement.receive|procurement.invoice"],
    ["Control", "", "", ""],
    ["accounting", "Accounting", "Σ", "accounting.view"],
    ["quality", "Quality & recall", "✚", "quality.manage"],
    ["sync", "Terminals & sync", "⟳", "sync.monitor"],
    ["audit", "Audit trail", "≣", "accounting.view"],
    ["Setup", "", "", ""],
    ["products", "Products & prices", "◫", "catalog.manage|price.manage"],
    ["recipes", "Recipes", "✎", "recipe.manage|recipe.approve"],
    ["people", "People & access", "☺", "admin.users"],
  ];
  const allowed = (perm?: string) => !perm || perm.split("|").some((p) => can(me, p));
  const first = nav.find(([, , , perm]) => perm && allowed(perm))?.[0] ?? "dashboard";

  return (
    <MeCtx.Provider value={me}>
      <div className="office">
        <nav className="side" aria-label="Main">
          <div className="brand">Yummy<span>.</span>OS</div>
          {nav.map(([path, label, icon, perm]) => (!label ? <div key={path} className="sect">{path}</div>
            : allowed(perm) && <NavLink key={path} to={`/office/${path}`}><span aria-hidden>{icon}</span>{label}</NavLink>))}
          <div style={{ marginTop: "auto", padding: "10px 12px", fontSize: 13, opacity: .85 }}>
            <div>{me.name}</div>
            <div className="row" style={{ marginTop: 8 }}>
              <button className="ghost" style={{ color: "inherit", minHeight: 32, whiteSpace: "nowrap", fontSize: 12.5, padding: "4px 8px" }} onClick={toggleTheme}>Theme: {theme}</button>
              <button className="ghost" style={{ color: "inherit", minHeight: 32, whiteSpace: "nowrap", fontSize: 12.5, padding: "4px 8px" }} onClick={async () => { await post("auth/logout").catch(() => 0); setToken(null); setMe(null); }}>Sign out</button>
            </div>
            {me.is_superuser && <a href="/admin/" style={{ padding: "6px 0", fontSize: 12 }}>Advanced configuration ↗</a>}
          </div>
        </nav>
        <main className="page">
          <Routes>
            <Route path="dashboard" element={<Dashboard />} />
            <Route path="tower" element={<ControlTower />} />
            <Route path="warehouse" element={<WarehouseMap />} />
            <Route path="inventory" element={<Inventory />} />
            <Route path="transfers" element={<Transfers />} />
            <Route path="production" element={<Production />} />
            <Route path="procurement" element={<Procurement />} />
            <Route path="accounting" element={<Accounting />} />
            <Route path="quality" element={<Quality />} />
            <Route path="sync" element={<SyncMonitor />} />
            <Route path="audit" element={<AuditPage />} />
            <Route path="products" element={<Products />} />
            <Route path="recipes" element={<Recipes />} />
            <Route path="people" element={<People />} />
            <Route path="*" element={<Navigate to={`/office/${first}`} replace />} />
          </Routes>
        </main>
      </div>
    </MeCtx.Provider>
  );
}

export function OfficeLogin({ onLogin, subtitle }: { onLogin: (m: Me) => void; subtitle?: string }) {
  const [u, setU] = useState("");
  const [p, setP] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true); setErr("");
    try {
      const r = await post<{ token: string; user: Me }>("auth/login", { username: u, password: p });
      setToken(r.token);
      onLogin(r.user);
    } catch (e2) { setErr((e2 as Error).message); } finally { setBusy(false); }
  }
  return (
    <div className="landing">
      <form className="card pad col" style={{ width: "min(400px, 100%)", gap: 14 }} onSubmit={submit}>
        <div className="wordmark">Yummy<span>.</span>OS</div>
        <p className="muted">{subtitle ?? "Back office · head office, production, warehouse and branch management."}</p>
        <label className="field">Username<input value={u} onChange={(e) => setU(e.target.value)} autoComplete="username" autoFocus required /></label>
        <label className="field">Password<input type="password" value={p} onChange={(e) => setP(e.target.value)} autoComplete="current-password" required /></label>
        {err && <p style={{ color: "var(--bad)" }}>{err}</p>}
        <button className="primary lg" disabled={busy}>{busy ? "Signing in…" : "Sign in"}</button>
      </form>
    </div>
  );
}
