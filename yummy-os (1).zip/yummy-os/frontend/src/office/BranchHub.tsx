import { useEffect, useState } from "react";
import { money } from "../lib/money";
import { ago, Badge, useTheme, useToast } from "../lib/ui";
import { api, getToken, post, setToken, useApi } from "./api";
import { OfficeLogin, type Me } from "./Office";

type Row = Record<string, any>; // eslint-disable-line @typescript-eslint/no-explicit-any
export interface Mode { mode: "hq" | "branch"; branch?: { code: string; name: string }; server?: string; hq_online?: boolean; enrolled?: boolean }

export function useMode() {
  const [mode, setMode] = useState<Mode | null>(null);
  useEffect(() => {
    let live = true;
    fetch("/api/mode").then((r) => (r.ok ? r.json() : { mode: "hq" })).catch(() => ({ mode: "hq" }))
      .then((m) => { if (live) setMode(m as Mode); });
    return () => { live = false; };
  }, []);
  return mode;
}

/** Branch server: a small live view for the shop/café manager. Everything else lives at HQ. */
export function BranchHub({ mode }: { mode: Mode }) {
  const [me, setMe] = useState<Me | null>(null);
  const [checking, setChecking] = useState(true);
  useEffect(() => {
    const out = () => setMe(null);
    window.addEventListener("yummy:logout", out);
    if (getToken()) api<Me>("auth/me").then(setMe).catch(() => setMe(null)).finally(() => setChecking(false));
    else setChecking(false);
    return () => window.removeEventListener("yummy:logout", out);
  }, []);
  if (checking) return null;
  if (!me) return <OfficeLogin onLogin={setMe} subtitle={`Branch server · ${mode.branch?.name ?? ""}. Managers of this branch sign in here; everything else is on the head-office system.`} />;
  return <Hub me={me} onOut={() => setMe(null)} />;
}

function Hub({ me, onOut }: { me: Me; onOut: () => void }) {
  const toast = useToast();
  const [theme, toggleTheme] = useTheme();
  const st = useApi<Row>("edge/status", 5000);
  const problems = useApi<Row[]>("edge/problems", 20000);
  const [busy, setBusy] = useState(false);
  const s = st.data;
  async function syncNow() {
    setBusy(true);
    try {
      const r = await post<Row>("edge/sync-now");
      toast(r.ok ? `Synced with HQ${r.forwarded ? ` · ${r.forwarded} sent` : ""}` : `HQ not reachable: ${r.error}`, r.ok ? "good" : "bad");
      st.reload(); problems.reload();
    } finally { setBusy(false); }
  }
  return (
    <div className="page" style={{ maxWidth: 1180, margin: "0 auto" }}>
      <div className="page-head">
        <div><h1>{s?.branch?.name ?? "Branch"} · branch server</h1>
          <div className="sub">Tills and kitchen screens here keep working with or without internet. Every sale is stored on this server and sent to head office in order, exactly once.</div></div>
        <div className="right row">
          <button className="ghost" onClick={toggleTheme}>Theme: {theme}</button>
          <button className="ghost" onClick={async () => { await post("auth/logout").catch(() => 0); setToken(null); onOut(); }}>Sign out {me.name}</button>
        </div>
      </div>
      {!s ? <div className="card pad">{st.error ?? "Loading…"}</div> : (
        <>
          <div className="kpis">
            <div className="kpi"><div className="label">Head office link</div>
              <div className="value">{s.hq_online ? <Badge kind="good"><span className="dot" />online</Badge> : <Badge kind="warn">offline</Badge>}</div>
              <div className="delta muted">last contact {ago(s.last_contact_at)}</div></div>
            <div className="kpi"><div className="label">Waiting to send</div><div className="value num">{s.queue.pending}</div>
              <div className="delta muted">{s.queue.oldest_pending_at ? `oldest ${ago(s.queue.oldest_pending_at)}` : "all delivered"}</div></div>
            <div className="kpi"><div className="label">Sales today</div><div className="value num">{s.today.sales}</div>
              <div className="delta muted">{s.today.ethiopian_date}</div></div>
            <div className="kpi"><div className="label">Takings today</div><div className="value num">ETB {money(s.today.total)}</div>
              <div className="delta muted">refunds {money(s.today.refunded)}</div></div>
            <div className="kpi"><div className="label">Kitchen tickets open</div><div className="value num">{s.kitchen_open}</div></div>
          </div>
          {s.last_error && <div className="card pad" style={{ borderColor: "var(--warn)" }}><b>Head office:</b> {s.last_error}
            <div className="small muted">Selling continues normally. Queued sales are kept on this server and sent automatically when the link returns.</div></div>}
          <div className="two">
            <div className="card pad">
              <div className="row"><h3 className="grow">Tills &amp; screens</h3><a href="/pos"><button>Open till</button></a></div>
              <table className="data"><thead><tr><th>Device</th><th>Status</th><th className="num">Waiting on device</th><th className="num">Sales today</th><th className="num">Takings</th></tr></thead>
                <tbody>{s.terminals.map((t: Row) => (
                  <tr key={t.code}><td><b>{t.code}</b><div className="small muted">{t.name} · {t.kind}</div></td>
                    <td>{!t.is_active ? <Badge kind="bad">revoked</Badge> : !t.enrolled ? <Badge>not enrolled</Badge> : !t.last_seen_at ? <Badge>not used here yet</Badge> : t.online ? <Badge kind="good"><span className="dot" />online</Badge> : <Badge kind="warn">offline {ago(t.last_seen_at)}</Badge>}</td>
                    <td className="num">{t.pending}</td><td className="num">{t.sales_today}</td><td className="num">{money(t.total_today)}</td></tr>))}</tbody></table>
            </div>
            <div className="card pad col">
              <h3>Sync with head office</h3>
              <div className="small">Server <b>{s.server}</b> · {s.hq_url}</div>
              <div className="small muted">Data from HQ received {ago(s.bundle_at)} · last send {ago(s.last_push_at)}</div>
              <div className="small muted">Delivered today: {s.queue.applied_today} · rejected at HQ: {s.queue.rejected_hq} · rejected here: {s.queue.rejected_local}{s.queue.held ? ` · held: ${s.queue.held}` : ""}</div>
              <button className="primary" disabled={busy} onClick={syncNow}>{busy ? "Syncing…" : "Sync now"}</button>
            </div>
          </div>
          <div className="card pad">
            <h3>Latest receipts</h3>
            <table className="data"><thead><tr><th>Receipt</th><th>Till</th><th>When</th><th className="num">Total</th><th className="num">Refunded</th></tr></thead>
              <tbody>{s.recent_sales.map((r: Row) => <tr key={r.id}><td>{r.number}</td><td>{r.terminal}</td><td className="muted">{ago(r.created_at)}</td>
                <td className="num">{money(r.total)}</td><td className="num">{Number(r.refunded_total) ? money(r.refunded_total) : "—"}</td></tr>)}</tbody></table>
            {s.recent_sales.length === 0 && <p className="muted">No sales yet today.</p>}
          </div>
          <div className="card pad">
            <h3>Operations that need a manager</h3>
            {(problems.data ?? []).length === 0 ? <p className="muted">Nothing to review.</p> : (
              <table className="data"><thead><tr><th>Received</th><th>Till</th><th>Operation</th><th>Stopped at</th><th>Reason</th><th /></tr></thead>
                <tbody>{(problems.data ?? []).map((p) => <tr key={p.op_id}><td className="muted">{ago(p.received_at)}</td><td>{p.terminal}</td><td>{p.kind} {p.number}</td>
                  <td>{p.where === "held" ? <Badge kind="warn">held here</Badge> : p.where}</td><td><Badge kind="bad">{p.error}</Badge> <span className="small">{p.detail}</span></td>
                  <td>{p.held && <button onClick={async () => { await post(`edge/ops/${p.op_id}/requeue`); toast("Will be sent again", "good"); problems.reload(); st.reload(); }}>Send again</button>}</td></tr>)}</tbody></table>)}
            <p className="muted small">Rejected operations are also listed at head office under Terminals &amp; sync, where they are resolved.</p>
          </div>
        </>
      )}
    </div>
  );
}
