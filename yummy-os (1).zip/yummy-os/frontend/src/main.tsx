import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter, Link, Route, Routes } from "react-router-dom";
import "./styles.css";
import { ToastProvider, useTheme } from "./lib/ui";
import { PosApp } from "./pos/PosApp";
import { Office } from "./office/Office";
import { formatEthiopian } from "./lib/ethiopian";
import { useMode } from "./office/BranchHub";

function Landing() {
  useTheme();
  const mode = useMode();
  return (
    <div className="landing">
      <div className="col" style={{ gap: 22, width: "min(900px, 100%)" }}>
        <div>
          <div className="wordmark">Yummy<span>.</span>OS</div>
          <p className="muted">Yummy Café &amp; Bakery operating system · {formatEthiopian(new Date())}</p>
          {mode?.mode === "branch" && <p><span className="badge info">Branch server · {mode.branch?.name}</span>{" "}
            {mode.hq_online ? <span className="badge good">head office connected</span> : <span className="badge warn">working offline</span>}</p>}
        </div>
        <div className="tiles">
          <Link to="/pos" style={{ textDecoration: "none" }}><button className="tile card" style={{ width: "100%" }}>
            <strong>Point of sale</strong><span className="muted">Shops &amp; cafés · works offline, syncs automatically</span><span className="badge good">Counter</span></button></Link>
          <Link to="/office" style={{ textDecoration: "none" }}><button className="tile card" style={{ width: "100%" }}>
            <strong>{mode?.mode === "branch" ? "Branch view" : "Back office"}</strong><span className="muted">{mode?.mode === "branch" ? "Today's sales, devices and the link to head office" : "Dashboards, products, recipes, people, finance"}</span><span className="badge info">Management</span></button></Link>
          <Link to="/pos" style={{ textDecoration: "none" }}><button className="tile card" style={{ width: "100%" }}>
            <strong>Kitchen display</strong><span className="muted">Enrol a KDS terminal — barista &amp; kitchen tickets</span><span className="badge warn">Café</span></button></Link>
        </div>
      </div>
    </div>
  );
}

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <ToastProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/pos/*" element={<PosApp />} />
          <Route path="/office/*" element={<Office />} />
          <Route path="*" element={<Landing />} />
        </Routes>
      </BrowserRouter>
    </ToastProvider>
  </StrictMode>,
);
