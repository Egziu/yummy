"""
Browser end-to-end test: back-office management + HQ / branch server with a real HQ outage.

Starts real processes - HQ (gunicorn, seeded database), a SHOP1 branch server (gunicorn, its own
empty database) and the branch sync agent - then drives Chromium:

  1. HQ back office: create a product and its price, write a new recipe version (production
     manager) and approve it (a different production manager), add a cashier with a PIN.
  2. HQ back office: add a branch server for SHOP1 and a new till; enrol the branch server.
  3. Branch till (talking only to the branch server): enrol, the NEW cashier signs in with the
     PIN created at HQ and sells the NEW product at the NEW price.
  4. HQ is KILLED. The branch keeps selling; a refund is looked up and approved by the manager's
     PIN on the branch server; the branch view shows HQ offline and the queue growing.
  5. HQ is restarted. The agent drains the queue in order; HQ has every sale and the refund
     exactly once; ledgers verified with verify_integrity.

  python e2e/run_branch_e2e.py --out e2e/screenshots-branch
"""
import argparse
import json
import os
import secrets
import signal
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

from playwright.sync_api import expect, sync_playwright

ROOT = Path(__file__).resolve().parent.parent
BACKEND = ROOT / "backend"
DEMO_PASSWORD = os.environ.get("YUMMY_DEMO_PASSWORD", "Yummy@2026demo")
HQ_PORT, BR_PORT = 8011, 8012
HQ, BR = f"http://127.0.0.1:{HQ_PORT}", f"http://127.0.0.1:{BR_PORT}"
PG = "postgres://yummy:yummy@localhost:5432"
SECRET = secrets.token_hex(32)


def env(**kw):
    e = {**os.environ, "YUMMY_DEBUG": "0", "YUMMY_SECRET_KEY": SECRET, "YUMMY_SSL_REDIRECT": "0",
         "YUMMY_ALLOWED_HOSTS": "127.0.0.1,localhost", "PYTHONUNBUFFERED": "1"}
    e.update(kw)
    return e


HQ_ENV = env(DATABASE_URL=f"{PG}/yummy", YUMMY_MODE="hq")
BR_ENV = env(DATABASE_URL=f"{PG}/yummy_shop1", YUMMY_MODE="branch", YUMMY_ALLOW_INSECURE_HQ="1")
LOGS = Path("/tmp/yummy-e2e-logs")
LOGS.mkdir(exist_ok=True)


def gunicorn(port, e, name):
    return subprocess.Popen(["gunicorn", "yummy.wsgi:application", "--bind", f"127.0.0.1:{port}", "--workers", "3",
                             "--timeout", "60"], cwd=BACKEND, env=e, stdout=open(LOGS / f"{name}.log", "a"),
                            stderr=subprocess.STDOUT, start_new_session=True)


def wait_up(base, timeout=40):
    t0 = time.time()
    while time.time() - t0 < timeout:
        try:
            with urllib.request.urlopen(base + "/api/health", timeout=2) as r:
                if r.status == 200:
                    return
        except Exception:
            time.sleep(0.5)
    raise RuntimeError(f"{base} did not start")


def stop(p):
    if p and p.poll() is None:
        os.killpg(p.pid, signal.SIGKILL)  # a hard crash, not a graceful shutdown
        p.wait()


def api(base, path, data=None, token=None):
    req = urllib.request.Request(base + path, data=json.dumps(data).encode() if data is not None else None,
                                 headers={"Content-Type": "application/json",
                                          **({"Authorization": f"Bearer {token}"} if token else {})},
                                 method="POST" if data is not None else "GET")
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read())


def manage(e, *args):
    r = subprocess.run([sys.executable, "manage.py", *args], cwd=BACKEND, env=e, capture_output=True, text=True)
    if r.returncode:
        raise RuntimeError(f"manage.py {' '.join(args)} failed:\n{r.stdout}\n{r.stderr}")
    return r.stdout


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=str(Path(__file__).parent / "screenshots-branch"))
    args = ap.parse_args()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    step = {"n": 0}

    def shot(page, name):
        step["n"] += 1
        page.wait_for_timeout(400)
        page.screenshot(path=str(out / f"{step['n']:02d}-{name}.png"))
        print(f"  ✓ {name}")

    # fresh branch database
    subprocess.run(["su", "postgres", "-c", "dropdb --if-exists yummy_shop1 && createdb -O yummy yummy_shop1"], check=True)
    manage(BR_ENV, "migrate", "--noinput")
    manage(HQ_ENV, "migrate", "--noinput")
    procs = {"hq": gunicorn(HQ_PORT, HQ_ENV, "hq"), "br": gunicorn(BR_PORT, BR_ENV, "branch"), "agent": None}
    try:
        wait_up(HQ)
        wait_up(BR)
        run(procs, shot)
    finally:
        for p in procs.values():
            stop(p)
    print("BRANCH E2E PASSED")


def login(page, base, user, pw=DEMO_PASSWORD):
    page.goto(base + "/office")
    page.get_by_label("Username").fill(user)
    page.get_by_label("Password").fill(pw)
    page.get_by_role("button", name="Sign in").click()
    page.wait_for_timeout(1200)


def logout(page):
    page.get_by_role("button", name="Sign out").click()
    page.wait_for_timeout(500)


def run(procs, shot):
    admin = api(HQ, "/api/auth/login", {"username": "admin", "password": DEMO_PASSWORD})["token"]
    for s in api(HQ, "/api/replica/servers", token=admin):  # previous runs: one active server per branch
        if s["branch"] == "SHOP1" and s["is_active"]:
            api(HQ, f"/api/replica/servers/{s['code']}/revoke", {}, admin)
    tag = secrets.token_hex(2).upper()
    sku, pname, price = f"FG-TEFF-{tag}", f"Teff cookies {tag}", "95.00"
    pin = "".join(str(secrets.randbelow(10)) for _ in range(6))  # fresh PIN: PINs must be unique per branch
    with sync_playwright() as p:
        browser = p.chromium.launch()
        hq = browser.new_context(viewport={"width": 1440, "height": 900}).new_page()
        hq.on("pageerror", lambda e: print("PAGE ERROR (HQ):", e))

        print("1. HQ back office: product, price, recipe (author + different approver), new cashier")
        login(hq, HQ, "admin")
        hq.goto(HQ + "/office/products")
        hq.get_by_role("button", name="New product").click()
        m = hq.locator(".modal")
        m.get_by_label("Name", exact=True).fill(pname)
        m.get_by_label("SKU (code)").fill(sku)
        m.get_by_label("Type").select_option("FINISHED")
        m.get_by_label("Shelf life (days)").fill("5")
        m.get_by_label("Sold at the tills").check()
        shot(hq, "hq-new-product")
        m.get_by_role("button", name="Save").click()
        expect(hq.get_by_text(f"{pname} created")).to_be_visible()
        hq.get_by_placeholder("Search name, SKU, barcode").fill(tag)
        row = hq.locator("tr", has_text=pname)
        expect(row).to_be_visible()
        row.get_by_role("button", name="Prices").click()
        hq.locator(".modal label", has_text="Standard prices").locator("input").fill(price)
        shot(hq, "hq-set-price")
        hq.get_by_role("button", name="Save prices").click()
        expect(hq.locator("tr", has_text=pname)).to_contain_text("95.00", timeout=10000)
        shot(hq, "hq-products")

        hq.goto(HQ + "/office/people")
        hq.get_by_role("button", name="Add person").click()
        m = hq.locator(".modal")
        m.get_by_label("Username").fill(f"shop1.almaz{tag.lower()}")
        m.get_by_label("Full name").fill(f"Almaz {tag}")
        m.get_by_label("Till PIN").fill(pin)
        m.get_by_role("button", name="+ Add role").click()
        m.get_by_label("Role", exact=True).select_option("CASHIER")
        m.get_by_label("Branch", exact=True).select_option("SHOP1")
        shot(hq, "hq-add-cashier")
        m.get_by_role("button", name="Add person").click()
        expect(hq.get_by_text("Person added")).to_be_visible()
        logout(hq)

        login(hq, HQ, "prodmgr")
        hq.goto(HQ + "/office/recipes")
        card = hq.locator(".card", has=hq.get_by_role("heading", name="Macchiato")).first
        card.get_by_role("button", name="New version").click()
        hq.locator(".modal .lines-editor tbody tr").first.get_by_label("Quantity").fill("0.010")
        hq.get_by_label("Method / notes").fill("Slightly stronger shot from the new grinder.")
        shot(hq, "hq-recipe-new-version")
        hq.get_by_role("button", name="Save as draft").click()
        expect(hq.get_by_text("Waiting for approval")).to_be_visible()
        expect(hq.get_by_text("Another person must approve your recipe.").first).to_be_visible()
        shot(hq, "hq-recipe-awaiting-approval")
        logout(hq)
        login(hq, HQ, "chef")
        hq.goto(HQ + "/office/recipes")
        draft = hq.locator(".card", has_text="draft").filter(has=hq.get_by_role("heading", name="Macchiato")).first
        draft.get_by_role("button", name="Approve").click()
        expect(hq.get_by_text("approved - now used for sales and costing")).to_be_visible()
        shot(hq, "hq-recipe-approved")
        logout(hq)

        print("2. HQ: branch server + new till; enrol the branch server")
        login(hq, HQ, "admin")
        hq.goto(HQ + "/office/sync")
        hq.get_by_role("button", name="Add branch server").click()
        m = hq.locator(".modal")
        m.get_by_label("Branch").select_option("SHOP1")
        m.get_by_label("Server code").fill(f"SHOP1-SRV-{tag}")
        m.get_by_label("Name").fill("Back-room mini PC")
        m.get_by_role("button", name="Create & get enrolment code").click()
        code = hq.locator(".modal .num").inner_text().strip()
        assert len(code) == 8, code
        shot(hq, "hq-branch-server-code")
        hq.keyboard.press("Escape")
        print("  enrolling:", manage(BR_ENV, "edge_enroll", "--hq", HQ, "--server", f"SHOP1-SRV-{tag}", "--code", code).strip())
        procs["agent"] = subprocess.Popen([sys.executable, "manage.py", "edge_agent"], cwd=BACKEND, env=BR_ENV,
                                          stdout=open(LOGS / "agent.log", "a"), stderr=subprocess.STDOUT,
                                          start_new_session=True)
        hq.get_by_role("button", name="New till / screen").click()
        m = hq.locator(".modal")
        m.get_by_label("Branch").select_option("SHOP1")
        tcode = f"SHOP1-T{tag}"
        m.get_by_label("Device code").fill(tcode)
        m.get_by_label("Name").fill("Counter 2")
        m.get_by_role("button", name="Create & get enrolment code").click()
        tcode_val = hq.locator(".modal .num").inner_text().strip()
        hq.keyboard.press("Escape")
        hq.wait_for_timeout(12000)  # agent picks up the new till and cashier
        hq.reload()
        expect(hq.locator("tr", has_text=f"SHOP1-SRV-{tag}")).to_contain_text("online", timeout=20000)
        shot(hq, "hq-sync-page-branch-online")

        print("3. Branch till via the branch server: new cashier, new product, new price")
        bctx = browser.new_context(viewport={"width": 1366, "height": 860})
        till = bctx.new_page()
        till.on("pageerror", lambda e: print("PAGE ERROR (till):", e))
        till.goto(BR + "/")
        expect(till.get_by_text("Branch server")).to_be_visible()
        shot(till, "branch-landing")
        till.goto(BR + "/pos")
        till.get_by_label("Terminal code").fill(tcode)
        till.get_by_label("8-digit enrolment code").fill(tcode_val)
        till.get_by_role("button", name="Enrol terminal").click()
        expect(till.get_by_text("Who is selling?")).to_be_visible(timeout=15000)

        def sign_in(name, pin):
            till.get_by_role("button", name=name).click()
            for d in pin:
                till.locator(".keypad button", has_text=d).first.click()
            till.wait_for_timeout(1500)
            if till.get_by_role("heading", name="Open shift").is_visible():
                till.get_by_role("button", name="Open shift").last.click()

        sign_in(f"Almaz {tag}", pin)
        tile = till.locator(".ptile", has_text=pname)
        expect(tile).to_contain_text("95", timeout=10000)

        def sell(*items):
            for it in items:
                till.locator(".ptile", has_text=it).first.click()
            till.get_by_role("button", name="Charge").click()
            till.locator(".quick-cash button").first.click()
            till.get_by_role("button", name="Complete sale").click()
            expect(till.locator(".receipt")).to_be_visible(timeout=10000)

        sell(pname, pname)
        shot(till, "branch-till-sale-new-product")
        till.get_by_role("button", name="New sale").click()
        expect(till.locator(".syncpill")).not_to_contain_text("pending", timeout=30000)
        time.sleep(6)
        hq_before = api(HQ, f"/api/reports/dashboard?branch=SHOP1", token=admin)["kpis"]["today"]["transactions"]

        print("4. HQ goes DOWN - the branch keeps going")
        stop(procs["hq"])
        sell("White bread - small")
        till.get_by_role("button", name="New sale").click()
        sell(pname, "Butter croissant")
        till.get_by_role("button", name="New sale").click()
        sell("Traditional Dabo")
        till.get_by_role("button", name="New sale").click()
        # the till itself is online (to the branch server): nothing waits on the device
        expect(till.locator(".syncpill")).to_contain_text("Online", timeout=20000)
        expect(till.locator(".syncpill")).not_to_contain_text("pending", timeout=30000)
        shot(till, "branch-till-online-while-hq-down")
        # refund looked up and approved on the branch server, no internet
        till.get_by_role("button", name="Refund").click()
        till.locator(".modal table.data tbody tr").first.click()
        till.locator(".modal input[type=number]").first.fill("1")
        till.get_by_placeholder("e.g. stale, wrong item").fill("Burnt edge")
        till.get_by_role("button", name="Supervisor approval").click()
        for d in "1111":
            till.locator(".modal .keypad button", has_text=d).last.click()
        expect(till.get_by_text("Refund recorded")).to_be_visible(timeout=10000)
        shot(till, "branch-refund-approved-hq-down")

        hub = bctx.new_page()
        login(hub, BR, "shop1.manager")
        expect(hub.get_by_role("heading", name="branch server")).to_be_visible(timeout=10000)
        hub.wait_for_timeout(16000)  # agent notices HQ is gone
        hub.reload()
        expect(hub.locator(".kpi", has_text="Head office link")).to_contain_text("offline", timeout=20000)
        pending = int(hub.locator(".kpi", has_text="Waiting to send").locator(".value").inner_text())
        assert pending >= 4, f"expected queued operations while HQ is down, saw {pending}"
        shot(hub, "branch-hub-hq-down")

        print("5. HQ comes back - the queue drains in order, exactly once")
        procs["hq"] = gunicorn(HQ_PORT, HQ_ENV, "hq")
        wait_up(HQ)
        hub.get_by_role("button", name="Sync now").click()
        t0 = time.time()
        while time.time() - t0 < 60:
            hub.reload()
            hub.wait_for_timeout(1500)
            if hub.locator(".kpi", has_text="Waiting to send").locator(".value").inner_text().strip() == "0":
                break
        expect(hub.locator(".kpi", has_text="Head office link")).to_contain_text("online", timeout=20000)
        shot(hub, "branch-hub-drained")
        admin = api(HQ, "/api/auth/login", {"username": "admin", "password": DEMO_PASSWORD})["token"]
        after = api(HQ, f"/api/reports/dashboard?branch=SHOP1", token=admin)["kpis"]["today"]["transactions"]
        assert after - hq_before == 3, f"HQ should have exactly 3 more SHOP1 sales, got {after - hq_before}"
        print(f"  ✓ HQ received exactly {after - hq_before} offline sales + the refund (no loss, no duplicates)")
        hq.goto(HQ + "/office/sync")
        hq.wait_for_timeout(2000)
        shot(hq, "hq-sync-after-recovery")
        browser.close()
    print(manage(HQ_ENV, "verify_integrity"))
    out = manage(HQ_ENV, "shell", "-c", f"from apps.pos.models import Sale,Refund;"
                 f"print('SALES', Sale.objects.filter(terminal__code='{tcode}').count(), 'REFUNDS', "
                 f"Refund.objects.filter(sale__terminal__code='{tcode}').count())")
    print(" ", out.strip())
    assert "SALES 4 REFUNDS 1" in out, out


if __name__ == "__main__":
    os.environ.setdefault("PLAYWRIGHT_BROWSERS_PATH", "/opt/pw-browsers")
    sys.exit(main())
