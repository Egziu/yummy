# Yummy OS

**Offline-first operating system for Yummy Café & Bakery** — head office, central production, main warehouse,
three shops and two cafés on one ledger. Built from the *Yummy OS Master Development Prompt v1.0* (October 2026).

> Release **1.1.0** — adds back-office management of products, prices, recipes and people, and **branch servers**
> (one HQ system of record + a server per shop/café that keeps the branch fully working offline).
> Release 1.0.0 was the foundation release. What is implemented and verified, and what is not yet built, is listed
> honestly in [docs/STATUS.md](docs/STATUS.md). Test evidence (real command output) is in
> [docs/VERIFICATION.md](docs/VERIFICATION.md).

## What it does

| Area | Delivered |
|---|---|
| **Branch servers (1.1)** | One head-office server is the system of record; each shop or café can run a small branch server on its LAN. With no internet the whole branch keeps working — tills, kitchen screens, refunds across tills, staff sign-in, the manager's branch view — and every operation is forwarded to HQ in order, exactly once, when the link returns. Verified by killing HQ mid-trading in a browser test. See [docs/LAN_INSTALL.md](docs/LAN_INSTALL.md). |
| **Management screens (1.1)** | Products (types, units, VAT, barcodes, shelf life, reorder points), effective-dated prices per price list, categories, café add-ons, recipe versions written by one person and approved by another, people & access (roles per branch, passwords, PINs unique per branch, unlock, deactivate), new tills/screens and branch servers — all in the back office, permission-checked and audited. |
| **Offline POS (shops & cafés)** | PWA that sells, prints receipts, takes cash / telebirr / CBE Birr / bank / card, refunds, cash in/out, shift open/close — **with no internet**, including a cold reload of the browser. Every action is stored in IndexedDB and uploaded in order when the network returns; the server applies each operation exactly once. |
| **Café service** | Dine-in tables & takeaway tabs saved on the device, modifiers (extra shot, extra milk), send-to-kitchen tickets, kitchen/barista display (KDS), recipe-based ingredient consumption (a cappuccino consumes beans + milk). |
| **Inventory** | Immutable stock ledger, lots & expiry, FEFO picking, reservations, in-transit stock, quarantine/holds, adjustments & disposals with approval, discrepancy register, moving-average valuation. |
| **Warehouse map** | Live floor map (zones → racks → shelves) coloured from the ledger: low, expiring, near capacity, quarantined; pick-frequency heatmap; drag-and-drop layout editor; live activity feed. |
| **Production** | Versioned recipes with nested (phantom) sub-recipes and cycle detection, cost simulation, production orders (plan → approve → release → complete), FEFO material issue, actual batch costing (materials + labour + overhead), output lots with expiry, QC hold → quarantine, smart planner. |
| **Distribution** | Transfer requests → approval (FEFO lots reserved) → dispatch (in transit) → receipt with damage & shortage reconciliation; double receipt impossible. |
| **Procurement** | Purchase orders, approval by a different person, goods receipt with lots, three-way match (quantity & price tolerances), held invoices, duplicate-invoice protection, payments. |
| **Accounting** | Double-entry GL posted automatically by every event, configurable posting rules, cost centres per branch, period locking, trial balance, P&L by branch, journal register. Database refuses unbalanced or edited journals. |
| **Control & intelligence** | Executive dashboard (live / provisional data labelling, daily briefing from facts), control tower (network map, supply-chain flow, workflows in motion), recall trace (ingredient lot → batches → outlets → receipts), sync monitor, hash-chained audit trail, CSV exports with formula-injection protection. |
| **Security** | Argon2 passwords, expiring hashed tokens, login lockout, device-enrolled terminals (revocable), per-cashier PINs verified on-device, branch-scoped RBAC enforced server-side, segregation of duties, append-only ledgers enforced by PostgreSQL triggers. |
| **Operations** | Docker image + Compose stack (PostgreSQL with WAL archiving, nginx TLS, backup sidecar), nightly encrypted base backups + logical dumps, point-in-time restore script, **a recovery drill that was actually run (RPO 0, RTO 2 s on test data)**, integrity verifier, CI pipeline. |

Localisation: ETB, Africa/Addis_Ababa, Ethiopian calendar on receipts and dashboards, English/Amharic POS labels and
Amharic product names. VAT is configuration (seeded at 15 %) — **verify current Ethiopian tax rules with a qualified
advisor before go-live.**

## Screens

`e2e/screenshots/` contains screenshots captured by the automated browser test, e.g. `05-pos-offline-queue.png`
(selling with the network cut), `06-pos-offline-receipt-after-reload.png`, `09-office-dashboard.png`,
`10-office-control-tower.png`, `11-office-warehouse-map.png`, `19-kds-barista-screen.png`.

## Quick start (local)

Requirements: Python 3.13, Node 22, PostgreSQL 16.

```bash
createuser -P yummy && createdb -O yummy yummy          # password: yummy (dev only)
pip install -r backend/requirements-dev.txt
cd frontend && npm ci && npx vite build && cd ..
cd backend
export YUMMY_DEBUG=1
python manage.py migrate
python manage.py seed_demo          # demo company + 14 days of simulated trading (~4 min)
python manage.py runserver 8000
```

Open `http://localhost:8000/` →

* **Back office** `/office` — users `ceo`, `finance`, `whmgr`, `prodmgr`, `admin` … password `Yummy@2026demo` (demo only).
* **POS** `/pos` — enter the terminal code (e.g. `SHOP1-T1`) and the 8-digit enrolment code printed by `seed_demo`
  (or issue one in *Terminals & sync*). Cashier PINs: Shop 1 cashier `1010`, manager `1111`; Café 1 cashier `4040`,
  manager `4444` (see seed output for all).
* **Try offline:** in the POS open the sync pill → *Practice offline mode*, or switch the device to airplane mode.
  Keep selling, reload the page, sign in again, sell again; turn the network back on and watch the queue drain.

## Production deployment

Local network (head office + branch servers): **[docs/LAN_INSTALL.md](docs/LAN_INSTALL.md)**. In short:

```bash
cd deploy
./yummy setup hq hq.yummy.lan 192.168.10.5 && ./yummy up hq && ./yummy admin        # head office
./yummy setup branch shop1.yummy.lan 192.168.20.5 && ./yummy up branch               # each branch PC
./yummy branch-enrol https://hq.yummy.lan SHOP1-SRV <code from HQ>
```

Cloud: the root `Dockerfile` + `railway.json` deploy HQ to Railway (or any container host); branch servers on
the shop LANs then connect to it over HTTPS. Operations, backups and recovery: [docs/OPERATIONS.md](docs/OPERATIONS.md).
Products, prices, recipes, people and devices are managed in the back office (`/office` → Setup).

## Tests

```bash
cd backend && YUMMY_DEBUG=1 python -m pytest -q        # 365 tests on PostgreSQL (scenarios A–I, branch servers, management, security)
cd frontend && npm test                                # pricing parity with the server + sync engine
python e2e/run_e2e.py                                  # real browser: offline selling, reload offline, café, KDS, refund
python e2e/run_branch_e2e.py                           # real browser + real processes: management screens, branch server, HQ killed and restored
python e2e/load_test.py                                # 5 terminals syncing concurrently
python backend/manage.py verify_integrity              # accounting/inventory/audit invariants on any database
sudo deploy/scripts/pitr_drill.sh seeded.dump          # disaster-recovery rehearsal
```

## Repository map

```
backend/            Django 5.2 LTS modular monolith (apps/: core, iam, catalog, inventory, accounting,
                    procurement, production, transfers, pos, reports, replica = HQ/branch sync) + tests/
frontend/           React 19 + TypeScript PWA: src/pos (offline POS + sync engine), src/kds, src/office
spec/               pricing_cases.json — shared by server and POS tests so offline totals equal the books
e2e/                Playwright browser test, load test, screenshots
deploy/             `yummy` installer CLI, Dockerfile, compose files (HQ, branch), nginx, PostgreSQL config, backups
docs/               ARCHITECTURE, LAN_INSTALL, OPERATIONS, STATUS (done vs. remaining), VERIFICATION, USER_GUIDE
```
