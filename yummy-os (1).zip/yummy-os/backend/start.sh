#!/bin/sh
# Container entrypoint: migrate, initialise, optionally seed demo data (once), then serve.
#   YUMMY_MODE=hq      head-office system of record (default)
#   YUMMY_MODE=branch  branch server; YUMMY_RUN_AGENT=1 also runs the HQ sync agent in this container
set -e
python manage.py migrate --noinput
python manage.py init_org
if [ "${YUMMY_MODE:-hq}" = "hq" ] && [ "${YUMMY_SEED_DEMO:-0}" = "1" ]; then
  # runs in the background so the web server is up immediately; refuses if data already exists
  (python manage.py seed_demo --days "${YUMMY_SEED_DAYS:-14}" --i-understand-this-is-demo > /tmp/seed.log 2>&1 \
     && echo "seed_demo finished" || echo "seed_demo skipped or failed: $(tail -1 /tmp/seed.log)") &
fi
if [ "${YUMMY_MODE:-hq}" = "branch" ] && [ "${YUMMY_RUN_AGENT:-0}" = "1" ]; then
  # keep the agent alive: restart it if it ever exits
  (while true; do python manage.py edge_agent || true; sleep 5; done) &
fi
exec gunicorn yummy.wsgi:application --bind "0.0.0.0:${PORT:-8000}" --workers "${WEB_CONCURRENCY:-3}" \
  --timeout 60 --keep-alive 5 --access-logfile - --forwarded-allow-ips "*"
