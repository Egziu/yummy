"""
Compact Yummy organisation for tests: WH (warehouse), PROD, SHOP1, SHOP2, CAFE1.
All tests run against PostgreSQL so constraints, row locks and triggers are real.
"""
import uuid
from datetime import timedelta
from decimal import Decimal as D

import pytest
from django.core.management import call_command
from django.db import connection
from django.utils import timezone

from apps.catalog.models import Category, Modifier, PriceList, PriceListItem, Product, TaxRate, Unit
from apps.core.models import Branch
from apps.iam.models import Role, RoleAssignment, Terminal, User
from apps.inventory import services as inv
from apps.inventory.models import Location, StockMovement
from apps.production.models import Recipe, RecipeLine


@pytest.fixture(autouse=True)
def fast_pins(settings):
    settings.YUMMY_PIN_ITERATIONS = 1000  # production uses 120k; tests only need correctness
    settings.PASSWORD_HASHERS = ["django.contrib.auth.hashers.MD5PasswordHasher"]  # speed only; prod uses Argon2


@pytest.fixture(autouse=True)
def fresh_throttles():
    from django.core.cache import cache

    cache.clear()  # rate-limit counters must not leak between tests


@pytest.fixture(autouse=True)
def immediate_constraints(db):
    """Fire deferred constraint triggers (journal balance) at statement end inside test transactions."""
    with connection.cursor() as c:
        c.execute("SET CONSTRAINTS ALL IMMEDIATE")


class Org:
    pass


@pytest.fixture
def org(db):
    call_command("init_org", verbosity=0)
    o = Org()
    o.b = {c: Branch.objects.create(code=c, name=c, kind=k) for c, k in
           [("WH", "WAREHOUSE"), ("PROD", "PRODUCTION"), ("SHOP1", "SHOP"), ("SHOP2", "SHOP"), ("CAFE1", "CAFE")]}
    L = Location.Kind
    o.loc = {
        "WH-A": Location.objects.create(code="WH-A", name="Dry store", branch=o.b["WH"]),
        "WH-C": Location.objects.create(code="WH-C", name="Finished goods", branch=o.b["WH"]),
        "WH-QC": Location.objects.create(code="WH-QC", name="Quarantine", branch=o.b["WH"], kind=L.QUARANTINE),
        "PROD": Location.objects.create(code="PROD-FLOOR", name="Floor", branch=o.b["PROD"], kind=L.PRODUCTION),
        "PROD-QC": Location.objects.create(code="PROD-QC", name="QC", branch=o.b["PROD"], kind=L.QUARANTINE),
    }
    for c in ("SHOP1", "SHOP2", "CAFE1"):
        o.loc[c] = Location.objects.create(code=f"{c}-FLOOR", name=c, branch=o.b[c], kind=L.SALES, is_sellable=True)
    kg, l_, pcs = (Unit.objects.create(code=c, name=c) for c in ("kg", "l", "pcs"))
    o.vat = TaxRate.objects.create(code="VAT15", name="VAT", rate=D("0.15"))
    cat = Category.objects.create(name="All")
    P = Product.Kind

    def prod(sku, kind, unit, **kw):
        return Product.objects.create(sku=sku, name=sku.title(), kind=kind, unit=unit, category=cat, **kw)

    o.p = {
        "flour": prod("FLOUR", P.RAW, kg, standard_cost=D("80")),
        "milk": prod("MILK", P.RAW, l_, standard_cost=D("70")),
        "beans": prod("BEANS", P.RAW, kg, standard_cost=D("900")),
        "sugar": prod("SUGAR", P.RAW, kg, standard_cost=D("120")),
        "dough": prod("DOUGH", P.SEMI, kg, track_lots=False),
        "bread": prod("BREAD", P.FINISHED, pcs, tax_rate=o.vat, is_sellable=True, shelf_life_days=2),
        "cake": prod("CAKE", P.FINISHED, pcs, tax_rate=o.vat, is_sellable=True, shelf_life_days=4),
        "cappuccino": prod("CAPPUCCINO", P.MENU, pcs, tax_rate=o.vat, is_sellable=True, track_lots=False,
                           station="BARISTA"),
    }
    o.shot = Modifier.objects.create(name="Extra shot", price_delta=D("15"), ingredient=o.p["beans"],
                                     ingredient_qty=D("0.009"))
    o.shot.applies_to.add(o.p["cappuccino"])
    pl = PriceList.objects.create(code="DEFAULT", name="Default", tax_inclusive=True)
    start = timezone.now() - timedelta(days=30)
    PriceListItem.objects.create(price_list=pl, product=o.p["bread"], price=D("15"), effective_from=start)
    PriceListItem.objects.create(price_list=pl, product=o.p["cake"], price=D("1200"), effective_from=start)
    PriceListItem.objects.create(price_list=pl, product=o.p["cappuccino"], price=D("70"), effective_from=start)

    # recipes: dough (phantom) -> bread ; cappuccino made to order
    rd = Recipe.objects.create(product=o.p["dough"], output_qty=D("10"), labor_minutes=D("30"))
    RecipeLine.objects.create(recipe=rd, ingredient=o.p["flour"], qty=D("6"))
    RecipeLine.objects.create(recipe=rd, ingredient=o.p["milk"], qty=D("3"))
    rb = Recipe.objects.create(product=o.p["bread"], output_qty=D("100"), labor_minutes=D("60"))
    RecipeLine.objects.create(recipe=rb, ingredient=o.p["dough"], qty=D("5"), explode=True)
    rc = Recipe.objects.create(product=o.p["cappuccino"], output_qty=D("1"))
    RecipeLine.objects.create(recipe=rc, ingredient=o.p["beans"], qty=D("0.009"))
    RecipeLine.objects.create(recipe=rc, ingredient=o.p["milk"], qty=D("0.15"))
    Recipe.objects.filter(pk__in=[rd.pk, rb.pk, rc.pk]).update(status="APPROVED")

    roles = {r.code: r for r in Role.objects.all()}

    def user(name, role, branch=None, pin=None):
        u = User.objects.create(username=name, display_name=name)
        u.set_password("Test-pass-2026!")
        if pin:
            u.set_pin(pin)
        u.save()
        RoleAssignment.objects.create(user=u, role=roles[role], branch=o.b[branch] if branch else None)
        return u

    o.u = {
        "buyer": user("buyer", "PROCUREMENT_OFFICER", "WH"),
        "procmgr": user("procmgr", "PROCUREMENT_MANAGER"),
        "clerk": user("clerk", "WAREHOUSE_OFFICER", "WH"),
        "whmgr": user("whmgr", "WAREHOUSE_MANAGER", "WH"),
        "accountant": user("accountant", "ACCOUNTANT"),
        "finance": user("finance", "FINANCE_MANAGER"),
        "prodmgr": user("prodmgr", "PRODUCTION_MANAGER", "PROD"),
        "baker": user("baker", "BAKER", "PROD"),
        "ceo": user("ceo", "CEO"),
        "qa": user("qa", "QUALITY_OFFICER"),
        "cashier1": user("cashier1", "CASHIER", "SHOP1", pin="1010"),
        "mgr1": user("mgr1", "BRANCH_MANAGER", "SHOP1", pin="1111"),
        "cashier2": user("cashier2", "CASHIER", "SHOP2", pin="2020"),
        "mgr2": user("mgr2", "BRANCH_MANAGER", "SHOP2", pin="2222"),
        "cafecash": user("cafecash", "CASHIER", "CAFE1", pin="4040"),
        "cafemgr": user("cafemgr", "BRANCH_MANAGER", "CAFE1", pin="4444"),
    }
    o.t = {c: Terminal.objects.create(code=f"{c}-T1", name=c, branch=o.b[c]) for c in ("SHOP1", "SHOP2", "CAFE1")}
    return o


def stock(product, location, qty, cost, lot_code=None, expiry=None):
    lot = inv.get_or_create_lot(product, lot_code, expiry) if lot_code else None
    return inv.receive(product, location, D(str(qty)), D(str(cost)), StockMovement.Kind.OPENING, "TEST", "opening",
                       lot=lot)


def op(kind, payload, op_id=None):
    return {"op_id": op_id or str(uuid.uuid4()), "kind": kind, "created_at": timezone.now().isoformat(),
            "payload": payload}


def open_shift(terminal, cashier, float_="500.00"):
    from apps.pos.sync import apply_batch

    sid = str(uuid.uuid4())
    r = apply_batch(terminal, [op("shift_open", {"shift_id": sid, "cashier_id": cashier.pk, "opening_float": float_,
                                                 "opened_at": timezone.now().isoformat()})])
    assert r[0]["status"] == "APPLIED", r
    return sid


_seq = {"n": 0}


def sale_payload(terminal, shift_id, cashier, lines, method="CASH", **extra):
    """lines: [(product, qty, unit_price, discount, modifiers)] -> payload priced with the canonical algorithm."""
    from apps.core.money import from_cents, price_line

    _seq["n"] += 1
    out, total = [], 0
    for i, (p, qty, price, disc, mods) in enumerate(lines, start=1):
        c = price_line(D(price), D(qty), D(disc), p.tax_rate.rate, True)
        total += c["total"]
        out.append({"line_no": i, "product_id": p.pk, "qty": str(qty), "unit_price": str(price), "discount": str(disc),
                    "tax_rate": str(p.tax_rate.rate), "total": str(from_cents(c["total"])),
                    "modifiers": [{"id": m.pk} for m in mods]})
    t = from_cents(total)
    payload = {"id": str(uuid.uuid4()), "number": f"{terminal.code}-{_seq['n']:06d}", "shift_id": shift_id,
               "cashier_id": cashier.pk, "created_at": timezone.now().isoformat(), "tax_inclusive": True,
               "lines": out, "payments": [{"method": method, "amount": str(t), "tendered": str(t) if method == "CASH" else None,
                                           "reference": "" if method == "CASH" else "TX1"}],
               "totals": {"total": str(t)}}
    payload.update(extra)
    return payload
