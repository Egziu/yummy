from yummy.urls import branch_urlpatterns as urlpatterns  # noqa: F401
