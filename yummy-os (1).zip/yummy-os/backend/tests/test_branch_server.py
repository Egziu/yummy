"""
HQ <-> branch server: enrolment, master-data bundle, fully offline selling at the branch,
exactly-once ordered forwarding, kitchen screens, branch sign-in and isolation between branches.

Both sides share one test database (their tables are disjoint). The branch's calls to HQ are
routed in-process through HQ's real URL configuration and views, so the HQ code under test is the
production code; switching `hq.online` off makes every call fail exactly like a dead link.
"""
import json
import uuid
from decimal import Decimal as D
from urllib.parse import urlsplit

import pytest
from django.urls import resolve
from django.utils import timezone
from rest_framework.test import APIClient, APIRequestFactory

from apps.accounting.services import trial_balance
from apps.iam.models import Terminal, User
from apps.pos.models import KitchenTicket, Refund, Sale, SyncOperation
from apps.replica import agent
from apps.replica.models import BranchServer, EdgeConfig, EdgeOp, EdgeSale

from .conftest import op, sale_payload, stock
from .test_security_api import client_for

pytestmark = pytest.mark.urls("tests.branch_urls")


class FakeHQ:
    """Routes the branch server's HTTPS calls to HQ's views in-process."""

    def __init__(self):
        self.online = True
        self.calls = []

    def __call__(self, method, path, data=None, cfg=None, timeout=15, auth=True):
        if not self.online:
            raise agent.HQError("HQ unreachable: [Errno 101] Network is unreachable")
        self.calls.append((method, path))
        f = APIRequestFactory()
        headers = {"HTTP_X_BRANCH_SERVER_TOKEN": agent.token(cfg)} if auth else {}
        if method == "GET":
            req = f.get(path, **headers)
        else:
            req = f.generic(method, path, json.dumps(data or {}), content_type="application/json", **headers)
        match = resolve(urlsplit(path).path, urlconf="tests.hq_urls")
        resp = match.func(req, **match.kwargs)
        resp.render()
        body = json.loads(resp.content or b"{}")
        if resp.status_code >= 400:
            raise agent.HQError(f"HQ answered {resp.status_code}: {body.get('detail', '')}", resp.status_code, body)
        return body


@pytest.fixture
def hq(monkeypatch):
    fake = FakeHQ()
    monkeypatch.setattr(agent, "hq_request", fake)
    return fake


def _root():
    u = User.objects.create(username="root", is_superuser=True, is_staff=True)
    u.set_password("Root-pass-2026!")
    u.save()
    return u


def enrol_branch(org, hq, branch="SHOP1"):
    root = _root()
    s = BranchServer.objects.create(code=f"{branch}-SRV", name=f"{branch} server", branch=org.b[branch])
    code = s.new_enrollment_code()
    cfg = agent.enroll("https://hq.test", s.code, code)
    return cfg, root


def enrol_till(org, hq, branch="SHOP1"):
    term = org.t[branch]
    code = term.new_enrollment_code()
    r = APIClient().post("/api/terminals/enroll", {"terminal_code": term.code, "enrollment_code": code}, format="json")
    assert r.status_code == 200, r.content
    c = APIClient()
    c.credentials(HTTP_X_TERMINAL_TOKEN=r.json()["device_token"])
    return term, c


def till_sync(c, *ops):
    r = c.post("/api/pos/sync", {"ops": list(ops), "pending_count": len(ops)}, format="json")
    assert r.status_code == 200, r.content
    return r.json()["results"]


def shift_op(cashier):
    sid = str(uuid.uuid4())
    return sid, op("shift_open", {"shift_id": sid, "cashier_id": cashier.pk, "opening_float": "300.00",
                                  "opened_at": timezone.now().isoformat()})


# ---------------------------------------------------------------------------------------------

def test_enrolment_bundle_and_least_privilege(org, hq):
    cfg, _ = enrol_branch(org, hq)
    b = cfg.bundle
    assert cfg.branch_code == "SHOP1" and cfg.enrolled
    assert {p["sku"] for p in b["products"]} >= {"BREAD", "CAKE"}
    assert {c["name"] for c in b["cashiers"]} >= {"cashier1", "mgr1"}
    # only branch-scoped managers' password verifiers reach the branch: no cashiers, no HQ staff, no superusers
    assert [u["username"] for u in b["hub_users"]] == ["mgr1"]
    assert [t["code"] for t in b["terminals"]] == ["SHOP1-T1"]
    # one-time code: reuse fails; a second active server for the branch is refused
    s = BranchServer.objects.get(code="SHOP1-SRV")
    with pytest.raises(agent.HQError):
        agent.enroll("https://hq.test", s.code, "00000000")


@pytest.mark.urls("tests.hq_urls")
def test_hq_back_office_manages_branch_servers(org):
    c = client_for(_root())
    r = c.post("/api/replica/servers", {"code": "CAFE1-SRV", "name": "Café 1 server", "branch": "CAFE1"}, format="json")
    assert r.status_code == 200 and len(r.json()["enrollment_code"]) == 8
    assert c.post("/api/replica/servers", {"code": "CAFE1-SRV2", "name": "dup", "branch": "CAFE1"},
                  format="json").status_code == 409
    assert c.get("/api/replica/servers").json()[0]["code"] == "CAFE1-SRV"
    assert c.post("/api/replica/servers/CAFE1-SRV/revoke").status_code == 200
    assert client_for(org.u["cashier1"]).get("/api/replica/servers").status_code == 403


def test_branch_keeps_selling_offline_then_forwards_exactly_once(org, hq):
    stock(org.p["bread"], org.loc["SHOP1"], 40, D("6"), "B1")
    enrol_branch(org, hq)
    term, till = enrol_till(org, hq)
    hq.online = False  # the internet goes down at the shop

    cashier, mgr = org.u["cashier1"], org.u["mgr1"]
    sid, so = shift_op(cashier)
    sales = [sale_payload(term, sid, cashier, [(org.p["bread"], n, "15.00", "0", [])]) for n in (2, 3, 4)]
    res = till_sync(till, so, *[op("sale", s) for s in sales])
    assert [r["status"] for r in res] == ["APPLIED"] * 4
    # refund of the first receipt, found on the branch server with no internet
    look = till.get(f"/api/pos/sales/{sales[0]['number']}")
    assert look.status_code == 200 and look.json()["lines"][0]["qty"] == "2.000"
    refund = op("refund", {"id": str(uuid.uuid4()), "number": "R-1", "sale_id": sales[0]["id"], "shift_id": sid,
                           "cashier_id": cashier.pk, "approver_id": mgr.pk, "reason": "stale", "method": "CASH",
                           "restock": False, "lines": [{"line_no": 1, "qty": "1"}],
                           "created_at": timezone.now().isoformat()})
    assert till_sync(till, refund)[0]["status"] == "APPLIED"
    # a second till asking to refund more than is left is stopped at the branch
    too_much = op("refund", {**refund["payload"], "id": str(uuid.uuid4()), "number": "R-2",
                             "lines": [{"line_no": 1, "qty": "2"}]})
    assert till_sync(till, too_much)[0]["error"] == "excess_refund"
    # branch view of stock: HQ's last figure minus what was sold here and not yet booked at HQ
    boot = till.get("/api/pos/bootstrap").json()
    bread = next(p for p in boot["products"] if p["sku"] == "BREAD")
    assert bread["stock"] == 40 - 9 and boot["last_receipt_seq"] >= 1
    assert Sale.objects.count() == 0  # HQ has nothing yet
    assert agent.cycle()["ok"] is False and "unreachable" in EdgeConfig.get().last_error

    hq.online = True  # link restored
    r = agent.cycle()
    assert r["ok"] and r["forwarded"] == 6
    assert Sale.objects.filter(branch=org.b["SHOP1"]).count() == 3
    assert Refund.objects.count() == 1 and Refund.objects.get().approved_by == mgr
    assert set(EdgeOp.objects.values_list("hq_status", flat=True)) == {"APPLIED", "REJECTED"}
    assert SyncOperation.objects.filter(status="REJECTED", result__error="excess_refund").count() == 1
    assert trial_balance()["balanced"]

    # lost response: the branch re-sends operations HQ already applied -> absorbed, no duplicates
    EdgeOp.objects.update(hq_status="PENDING")
    assert agent.cycle()["ok"]
    assert Sale.objects.count() == 3 and Refund.objects.count() == 1
    assert EdgeOp.objects.filter(hq_status="PENDING").count() == 0


def test_branch_rejects_only_what_hq_also_rejects(org, hq):
    enrol_branch(org, hq)
    term, till = enrol_till(org, hq)
    cashier = org.u["cashier1"]
    sid, so = shift_op(cashier)
    bad = sale_payload(term, sid, cashier, [(org.p["bread"], 2, "15.00", "0", [])])
    bad["totals"]["total"] = "1.00"
    unpaid = sale_payload(term, sid, cashier, [(org.p["bread"], 1, "15.00", "0", [])])
    unpaid["payments"][0]["amount"] = "10.00"
    res = till_sync(till, so, op("sale", bad), op("sale", unpaid))
    assert [r["status"] for r in res] == ["APPLIED", "REJECTED", "REJECTED"]
    assert {res[1]["error"], res[2]["error"]} == {"totals_mismatch", "payment_mismatch"}
    agent.cycle()
    # HQ independently reaches the same verdicts and keeps them for manager review
    errs = set(SyncOperation.objects.filter(status="REJECTED").values_list("result__error", flat=True))
    assert errs == {"totals_mismatch", "payment_mismatch"} and Sale.objects.count() == 0


def test_kitchen_screen_works_offline_and_history_reaches_hq(org, hq):
    BranchServer.objects.all().delete()
    root = _root()
    s = BranchServer.objects.create(code="CAFE1-SRV", name="Café server", branch=org.b["CAFE1"])
    agent.enroll("https://hq.test", s.code, s.new_enrollment_code())
    term, till = enrol_till(org, hq, "CAFE1")
    kds = Terminal.objects.create(code="CAFE1-KDS", name="Bar", branch=org.b["CAFE1"], kind="KDS")
    code = kds.new_enrollment_code()
    agent.pull()
    tok = APIClient().post("/api/terminals/enroll", {"terminal_code": kds.code, "enrollment_code": code},
                           format="json").json()["device_token"]
    screen = APIClient()
    screen.credentials(HTTP_X_TERMINAL_TOKEN=tok)
    hq.online = False
    cashier = org.u["cafecash"]
    sid, so = shift_op(cashier)
    tid = str(uuid.uuid4())
    ticket = op("kitchen_ticket", {"id": tid, "station": "BARISTA", "order_ref": "T4",
                                   "items": [{"name": "Cappuccino", "qty": 2, "modifiers": ["Extra shot"]}],
                                   "created_at": timezone.now().isoformat()})
    assert till_sync(till, so, ticket)[1]["status"] == "APPLIED"
    board = screen.get("/api/kds/tickets?station=BARISTA").json()
    assert [t["order_ref"] for t in board] == ["T4"]
    assert screen.post(f"/api/kds/tickets/{tid}", {"status": "READY"}, format="json").status_code == 200
    assert KitchenTicket.objects.count() == 0
    hq.online = True
    assert agent.cycle()["ok"]
    t = KitchenTicket.objects.get(pk=tid)
    assert t.status == "READY" and t.ready_at is not None and root


def test_branch_server_cannot_act_for_another_branch(org, hq):
    cfg, _ = enrol_branch(org, hq)
    other = org.t["SHOP2"]
    sid = str(uuid.uuid4())
    body = {"ops": [{**op("shift_open", {"shift_id": sid, "cashier_id": org.u["cashier2"].pk, "opening_float": "1",
                                         "opened_at": timezone.now().isoformat()}), "terminal": other.code}]}
    r = hq("POST", "/api/replica/push", body)
    assert r["results"][0]["status"] == "REJECTED" and r["results"][0]["error"] == "forbidden"
    # sale look-ups are scoped to the server's branch too
    with pytest.raises(agent.HQError) as e:
        hq("GET", "/api/replica/sales/SHOP2-T1-000001")
    assert e.value.status == 404
    # a revoked server is locked out immediately
    BranchServer.objects.filter(code=cfg.server_code).update(is_active=False)
    with pytest.raises(agent.HQError) as e:
        hq("GET", "/api/replica/bundle")
    assert e.value.status in (401, 403)
    assert "revoked" in agent.cycle()["error"]


def test_hq_push_keeps_order_when_a_dependency_is_missing(org, hq):
    enrol_branch(org, hq)
    term = org.t["SHOP1"]
    cashier = org.u["cashier1"]
    sid, so = shift_op(cashier)
    sale = sale_payload(term, sid, cashier, [(org.p["bread"], 1, "15.00", "0", [])])
    later = sale_payload(term, sid, cashier, [(org.p["bread"], 1, "15.00", "0", [])])
    r = hq("POST", "/api/replica/push", {"ops": [{**op("sale", sale), "terminal": term.code},
                                                  {**op("sale", later), "terminal": term.code}]})
    assert [x["status"] for x in r["results"]] == ["RETRY", "RETRY"]
    assert r["results"][1]["detail"] == "waiting_for_earlier_operation" and Sale.objects.count() == 0
    r = hq("POST", "/api/replica/push", {"ops": [{**so, "terminal": term.code}, {**op("sale", sale), "terminal": term.code}]})
    assert [x["status"] for x in r["results"]] == ["APPLIED", "APPLIED"]


def test_branch_hub_sign_in_and_hq_only_paths(org, hq):
    enrol_branch(org, hq)
    c = APIClient()
    assert c.post("/api/auth/login", {"username": "cashier1", "password": "Test-pass-2026!"},
                  format="json").status_code == 401  # cashiers sign in at the till with a PIN, not here
    assert c.post("/api/auth/login", {"username": "root", "password": "Root-pass-2026!"},
                  format="json").status_code == 401  # HQ superusers' credentials never leave HQ
    r = c.post("/api/auth/login", {"username": "mgr1", "password": "Test-pass-2026!"}, format="json")
    assert r.status_code == 200, r.content
    c.credentials(HTTP_AUTHORIZATION="Bearer " + r.json()["token"])
    st = c.get("/api/edge/status").json()
    assert st["mode"] == "branch" and st["branch"]["code"] == "SHOP1" and st["queue"]["pending"] == 0
    assert c.get("/api/inventory/balances").json()["error"] == "hq_only"
    assert APIClient().get("/api/edge/status").status_code in (401, 403)
    # lock-out after repeated failures
    bad = APIClient()
    for _ in range(5):
        bad.post("/api/auth/login", {"username": "mgr1", "password": "nope"}, format="json")
    assert bad.post("/api/auth/login", {"username": "mgr1", "password": "Test-pass-2026!"},
                    format="json").status_code == 423


def test_till_enrolment_needs_hq_and_revocation_propagates(org, hq):
    enrol_branch(org, hq)
    term = org.t["SHOP1"]
    code = term.new_enrollment_code()
    hq.online = False
    r = APIClient().post("/api/terminals/enroll", {"terminal_code": term.code, "enrollment_code": code}, format="json")
    assert r.status_code == 503
    hq.online = True
    term, till = enrol_till(org, hq)
    assert till.get("/api/pos/bootstrap").status_code == 200
    Terminal.objects.filter(pk=term.pk).update(is_active=False, token_hash="")  # revoked at HQ
    agent.pull()
    assert till.get("/api/pos/bootstrap").status_code in (401, 403)
    assert EdgeSale.objects.count() == 0


# ------------------------------------------------------------------ review fixes (robustness & parity)

def test_hq_staff_credentials_never_reach_branch(org, hq):
    from apps.iam.models import Role, RoleAssignment

    qa = org.u["qa"]  # all-branches quality officer who also helps at SHOP1
    RoleAssignment.objects.create(user=qa, role=Role.objects.get(code="BRANCH_MANAGER"), branch=org.b["SHOP1"])
    cfg, _ = enrol_branch(org, hq)
    assert [u["username"] for u in cfg.bundle["hub_users"]] == ["mgr1"]


def test_malformed_or_orphaned_ops_never_block_the_branch(org, hq):
    from apps.iam.models import User as U

    enrol_branch(org, hq)
    term, till = enrol_till(org, hq)
    cashier = org.u["cashier1"]
    U.objects.filter(pk=org.u["cashier2"].pk).update(is_active=False)
    # 1) a shift opened by someone HQ will refuse, then a sale in it (branch can't know: bundle is stale)
    sid_bad = str(uuid.uuid4())
    bad_shift = op("shift_open", {"shift_id": sid_bad, "cashier_id": org.u["cashier2"].pk, "opening_float": "0",
                                  "opened_at": timezone.now().isoformat()})
    orphan = sale_payload(term, sid_bad, cashier, [(org.p["bread"], 1, "15.00", "0", [])])
    # 2) a sale HQ cannot parse but the branch accepted
    sid, so = shift_op(cashier)
    weird = sale_payload(term, sid, cashier, [(org.p["bread"], 1, "15.00", "0", [])])
    weird["lines"][0]["product_id"] = "abc"
    nulls = sale_payload(term, sid, cashier, [(org.p["bread"], 1, "15.00", "0", [])])
    nulls["totals"] = None
    good = sale_payload(term, sid, cashier, [(org.p["bread"], 2, "15.00", "0", [])])
    res = till_sync(till, bad_shift, op("sale", orphan), so, op("sale", weird), op("sale", nulls), op("sale", good))
    assert all(r["status"] == "APPLIED" for r in res), res
    assert agent.cycle()["ok"]
    st = {o.payload.get("number") or o.kind: (o.hq_status, o.hq_result.get("error")) for o in EdgeOp.objects.all()}
    assert st["shift_open"][0] in ("APPLIED", "REJECTED")
    assert st[orphan["number"]] == ("REJECTED", "dependency_rejected")
    assert st[weird["number"]] == ("REJECTED", "invalid_payload")
    assert st[nulls["number"]][0] == "APPLIED"   # null totals simply means "no claimed total" at both ends
    assert st[good["number"]][0] == "APPLIED"
    assert not EdgeOp.objects.filter(hq_status="PENDING").exists()
    # sales HQ refused are dropped from the branch journal (they can't be refunded or counted)
    assert not EdgeSale.objects.filter(number=orphan["number"]).exists()


def test_branch_rejection_is_never_booked_and_hq_rejection_is_undone(org, hq):
    stock(org.p["bread"], org.loc["SHOP1"], 10, D("6"), "B1")
    enrol_branch(org, hq)
    term, till = enrol_till(org, hq)
    cashier, mgr1, mgr2 = org.u["cashier1"], org.u["mgr1"], org.u["mgr2"]
    sid, so = shift_op(cashier)
    sale = sale_payload(term, sid, cashier, [(org.p["bread"], 1, "15.00", "0", [])])
    till_sync(till, so, op("sale", sale))
    hq.online = False

    def refund(num, approver):
        return op("refund", {"id": str(uuid.uuid4()), "number": num, "sale_id": sale["id"], "shift_id": sid,
                             "cashier_id": cashier.pk, "approver_id": approver.pk, "reason": "x", "method": "CASH",
                             "restock": False, "lines": [{"line_no": 1, "qty": "1"}],
                             "created_at": timezone.now().isoformat()})
    # approved by another branch's manager: the branch can't tell offline, accepts; HQ will refuse
    assert till_sync(till, refund("R-1", mgr2))[0]["status"] == "APPLIED"
    # the branch now thinks the line is fully refunded and stops a second refund
    assert till_sync(till, refund("R-2", mgr1))[0]["error"] == "excess_refund"
    hq.online = True
    assert agent.cycle()["ok"]
    # R-1 refused at HQ; R-2 was rejected at the branch and is recorded at HQ but NEVER booked
    assert Refund.objects.count() == 0
    assert SyncOperation.objects.filter(status="REJECTED").count() == 2
    # the branch journal was corrected, so the cashier can now do it properly
    assert EdgeSale.objects.get(pk=sale["id"]).lines[0]["qty_refunded"] == "0.000"
    assert till_sync(till, refund("R-3", mgr1))[0]["status"] == "APPLIED"
    agent.cycle()
    assert Refund.objects.get().number == "R-3"


def test_held_op_parks_its_till_but_not_the_branch(org, hq, monkeypatch):
    from apps.replica.models import EdgeOp as E

    monkeypatch.setattr(agent, "HOLD_AFTER", 2)
    enrol_branch(org, hq)
    t1 = org.t["SHOP1"]
    t2 = Terminal.objects.create(code="SHOP1-T2", name="2", branch=org.b["SHOP1"])
    cashier = org.u["cashier1"]
    # T1: a sale whose shift HQ has never seen (HQ keeps answering RETRY) followed by more T1 work
    ghost = sale_payload(t1, str(uuid.uuid4()), cashier, [(org.p["bread"], 1, "15.00", "0", [])])
    E.objects.create(op_id=uuid.uuid4(), terminal_code=t1.code, kind="sale", payload=ghost, local_status="ACCEPTED")
    _, so1 = shift_op(cashier)
    E.objects.create(op_id=so1["op_id"], terminal_code=t1.code, kind="shift_open", payload=so1["payload"],
                     local_status="ACCEPTED")
    # T2: independent work
    _, so2 = shift_op(cashier)
    E.objects.create(op_id=so2["op_id"], terminal_code=t2.code, kind="shift_open", payload=so2["payload"],
                     local_status="ACCEPTED")
    agent.cycle()
    assert E.objects.get(payload__number=ghost["number"]).hq_status == "PENDING"  # still in order, retrying
    agent.cycle()
    assert E.objects.get(payload__number=ghost["number"]).hq_status == "HELD"
    agent.cycle()
    # T2 moves on; T1's later work waits behind its held operation (order within a till is never broken)
    assert E.objects.get(op_id=so2["op_id"]).hq_status == "APPLIED"
    assert E.objects.get(op_id=so1["op_id"]).hq_status == "PENDING"
    assert BranchServer.objects.get(branch=org.b["SHOP1"], is_active=True).reported_held == 1
    # "Send again" puts T1 back in line, held op first
    held = E.objects.get(hq_status="HELD")
    c = APIClient()
    tok = c.post("/api/auth/login", {"username": "mgr1", "password": "Test-pass-2026!"}, format="json").json()["token"]
    c.credentials(HTTP_AUTHORIZATION="Bearer " + tok)
    assert c.post(f"/api/edge/ops/{held.op_id}/requeue").json()["ok"]
    agent.cycle()
    assert E.objects.get(op_id=held.op_id).hq_status == "PENDING"
    assert E.objects.get(op_id=so1["op_id"]).hq_status == "PENDING"


def test_only_one_pusher_at_a_time(org, hq):
    import psycopg
    from django.db import connection

    enrol_branch(org, hq)
    s = connection.settings_dict
    other = psycopg.connect(host=s["HOST"], port=s["PORT"], user=s["USER"], password=s["PASSWORD"], dbname=s["NAME"],
                            autocommit=True)
    try:
        other.execute("SELECT pg_advisory_lock(%s)", [agent.PUSH_LOCK])
        assert agent.push() == 0 and not any(p == "/api/replica/push" for _, p in hq.calls)
    finally:
        other.close()


def test_branch_session_ends_when_hq_changes_password(org, hq):
    enrol_branch(org, hq)
    c = APIClient()
    tok = c.post("/api/auth/login", {"username": "mgr1", "password": "Test-pass-2026!"}, format="json").json()["token"]
    c.credentials(HTTP_AUTHORIZATION="Bearer " + tok)
    assert c.get("/api/auth/me").status_code == 200
    m = org.u["mgr1"]
    m.set_password("Changed-pass-2026!")
    m.save()
    agent.pull()
    assert c.get("/api/auth/me").status_code in (401, 403)


def test_push_rejects_malformed_bodies_cleanly(org, hq):
    enrol_branch(org, hq)
    for body in ({"ops": ["x"]}, {"ops": [], "pending_count": "abc", "terminals": ["x", {"code": 5}]}):
        try:
            r = hq("POST", "/api/replica/push", body)
            assert r["results"] == []
        except agent.HQError as e:
            assert e.status == 400
