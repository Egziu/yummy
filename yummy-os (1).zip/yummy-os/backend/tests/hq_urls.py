from yummy.urls import hq_urlpatterns as urlpatterns  # noqa: F401
