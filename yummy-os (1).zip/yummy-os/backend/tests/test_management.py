"""Back-office management: products & prices, recipes (author/approver separation), people & PINs."""
from datetime import timedelta
from decimal import Decimal as D

from django.utils import timezone

from apps.catalog.models import PriceListItem, Product
from apps.catalog.services import resolve_price
from apps.core.models import AuditLog
from apps.iam.models import ApiToken, Role, RoleAssignment, User
from apps.production.models import Recipe

from .test_security_api import client_for


def _admin(org):
    u = User.objects.create(username="root", is_superuser=True, is_staff=True)
    u.set_password("Root-pass-2026!")
    u.save()
    return u


def test_catalog_manager_creates_product_and_changes_price(org):
    cm = User.objects.create(username="cm")
    RoleAssignment.objects.create(user=cm, role=Role.objects.get(code="CATALOG_MANAGER"))
    c = client_for(cm)
    meta = c.get("/api/catalog/meta").json()
    cat, unit = meta["categories"][0]["id"], next(u["id"] for u in meta["units"] if u["code"] == "pcs")
    r = c.post("/api/catalog/products", {"sku": "FG-DABO", "name": "Dabo loaf", "kind": "FINISHED", "category_id": cat,
                                         "unit_id": unit, "tax_rate_id": org.vat.pk, "is_sellable": True,
                                         "shelf_life_days": 3, "barcode": "2900001"}, format="json")
    assert r.status_code == 201, r.content
    pid = r.json()["id"]
    # duplicate SKU / barcode refused
    assert c.post("/api/catalog/products", {"sku": "fg-dabo", "name": "x", "kind": "RAW", "category_id": cat,
                                            "unit_id": unit}, format="json").status_code == 409
    # price effective now; the old price is closed, not overwritten
    assert c.post(f"/api/catalog/products/{pid}/price", {"price_list": "DEFAULT", "price": "22.50"},
                  format="json").status_code == 200
    assert c.post(f"/api/catalog/products/{pid}/price", {"price_list": "DEFAULT", "price": "24.00"},
                  format="json").status_code == 200
    p = Product.objects.get(pk=pid)
    assert resolve_price(p, org.b["SHOP1"])[0] == D("24.00")
    items = PriceListItem.objects.filter(product=p).order_by("effective_from")
    assert [str(i.price) for i in items] == ["22.50", "24.00"] or items.count() == 1  # same-instant edits collapse
    assert c.get("/api/catalog/products?q=dabo").json()[0]["prices"]["DEFAULT"] == "24.00"
    # edit bumps version and is audited
    r = c.patch(f"/api/catalog/products/{pid}", {"name": "Dabo loaf (large)"}, format="json")
    assert r.status_code == 200 and r.json()["version"] == 2
    assert AuditLog.objects.filter(action="catalog.product_updated").exists()
    assert AuditLog.objects.filter(action="catalog.price_changed").count() == 2


def test_price_change_is_effective_dated_for_history(org):
    fin = org.u["finance"]  # finance manager holds price.manage
    c = client_for(fin)
    before = timezone.now()
    assert c.post(f"/api/catalog/products/{org.p['bread'].pk}/price", {"price_list": "DEFAULT", "price": "18"},
                  format="json").status_code == 200
    assert resolve_price(org.p["bread"], org.b["SHOP1"], before)[0] == D("15")  # history kept
    assert resolve_price(org.p["bread"], org.b["SHOP1"])[0] == D("18")


def test_catalog_writes_need_permission(org):
    c = client_for(org.u["cashier1"])
    assert c.post("/api/catalog/products", {"sku": "X1", "name": "x", "kind": "RAW", "category_id": 1, "unit_id": 1},
                  format="json").status_code == 403
    assert c.post(f"/api/catalog/products/{org.p['bread'].pk}/price", {"price_list": "DEFAULT", "price": "1"},
                  format="json").status_code == 403
    # production manager may create items but not change selling prices
    pm = client_for(org.u["prodmgr"])
    assert pm.post(f"/api/catalog/products/{org.p['bread'].pk}/price", {"price_list": "DEFAULT", "price": "1"},
                   format="json").status_code == 403


def test_product_type_locked_after_history(org):
    from .conftest import stock

    stock(org.p["flour"], org.loc["WH-A"], 5, D("80"), "F1")
    c = client_for(_admin(org))
    r = c.patch(f"/api/catalog/products/{org.p['flour'].pk}", {"kind": "RESALE"}, format="json")
    assert r.status_code == 409


def test_recipe_version_needs_a_different_approver(org):
    author, approver = org.u["prodmgr"], User.objects.create(username="chef2")
    RoleAssignment.objects.create(user=approver, role=Role.objects.get(code="PRODUCTION_MANAGER"),
                                  branch=org.b["PROD"])
    ca = client_for(author)
    r = ca.post("/api/production/recipes", {"sku": "CAKE", "output_qty": "10", "labor_minutes": "45",
                                            "lines": [{"sku": "FLOUR", "qty": "2", "waste_pct": "2"},
                                                      {"sku": "SUGAR", "qty": "1"},
                                                      {"sku": "MILK", "qty": "1.5"}]}, format="json")
    assert r.status_code == 201, r.content
    rid, ver = r.json()["id"], r.json()["version"]
    assert ver == 1 and Recipe.objects.get(pk=rid).status == "DRAFT"
    # the author cannot approve their own recipe
    assert ca.post(f"/api/production/recipes/{rid}/approve").status_code == 409
    assert client_for(approver).post(f"/api/production/recipes/{rid}/approve").status_code == 200
    rec = Recipe.objects.get(pk=rid)
    assert rec.status == "APPROVED" and rec.approved_by == approver
    assert Product.objects.get(sku="CAKE").standard_cost > 0
    # a second version retires the first only when approved
    r2 = ca.post("/api/production/recipes", {"sku": "CAKE", "output_qty": "12",
                                             "lines": [{"sku": "FLOUR", "qty": "2.2"}]}, format="json")
    assert r2.json()["version"] == 2 and Recipe.objects.get(pk=rid).status == "APPROVED"
    client_for(approver).post(f"/api/production/recipes/{r2.json()['id']}/approve")
    assert Recipe.objects.get(pk=rid).status == "RETIRED"


def test_recipe_validation(org):
    c = client_for(org.u["prodmgr"])
    bad = [
        {"sku": "CAKE", "output_qty": "0", "lines": [{"sku": "FLOUR", "qty": "1"}]},
        {"sku": "CAKE", "output_qty": "1", "lines": []},
        {"sku": "CAKE", "output_qty": "1", "lines": [{"sku": "CAKE", "qty": "1"}]},
        {"sku": "CAKE", "output_qty": "1", "lines": [{"sku": "FLOUR", "qty": "1"}, {"sku": "FLOUR", "qty": "2"}]},
        {"sku": "FLOUR", "output_qty": "1", "lines": [{"sku": "SUGAR", "qty": "1"}]},  # raw materials have no recipe
        {"sku": "CAKE", "output_qty": "1", "lines": [{"sku": "CAPPUCCINO", "qty": "1"}]},  # non-stocked w/o phantom
    ]
    for b in bad:
        assert c.post("/api/production/recipes", b, format="json").status_code == 409, b
    assert client_for(org.u["cashier1"]).post("/api/production/recipes", {"sku": "CAKE"}, format="json").status_code == 403


def test_user_admin_creates_staff_with_roles_and_unique_pin(org):
    admin = _admin(org)
    c = client_for(admin)
    r = c.post("/api/iam/users", {"username": "shop1.cashier2", "display_name": "Almaz", "pin": "7070",
                                  "roles": [{"role": "CASHIER", "branch": "SHOP1"}]}, format="json")
    assert r.status_code == 201, r.content
    u = User.objects.get(username="shop1.cashier2")
    assert u.check_pin("7070") and not u.has_usable_password()
    # same PIN as the SHOP1 manager is refused (approvals are identified by PIN)
    r = c.post("/api/iam/users", {"username": "shop1.x", "pin": "1111", "roles": [{"role": "CASHIER", "branch": "SHOP1"}]},
               format="json")
    assert r.status_code == 409 and r.json()["error"] == "pin_in_use"
    # ...but the same PIN at an unrelated branch is fine
    assert c.post("/api/iam/users", {"username": "shop2.y", "pin": "1111", "roles": [{"role": "CASHIER", "branch": "SHOP2"}]},
                  format="json").status_code == 201
    # weak password refused
    r = c.post("/api/iam/users", {"username": "weak", "password": "123", "roles": [{"role": "CEO"}]}, format="json")
    assert r.status_code == 409 and r.json()["error"] == "weak_password"
    # deactivate ends sessions
    tok = ApiToken.issue(u)
    assert c.patch(f"/api/iam/users/{u.pk}", {"is_active": False}, format="json").status_code == 200
    assert not ApiToken.objects.filter(user=u).exists() and tok
    assert AuditLog.objects.filter(action="iam.user_created").count() == 2


def test_user_admin_guard_rails(org):
    # a non-superuser admin cannot create a super admin or edit a superuser
    hr = User.objects.create(username="hr")
    role = Role.objects.create(code="HR", name="HR", permissions=["admin.users", "pos.sell"])
    RoleAssignment.objects.create(user=hr, role=role)
    c = client_for(hr)
    assert c.post("/api/iam/users", {"username": "evil", "password": "Strong-pass-2026!",
                                     "roles": [{"role": "SUPER_ADMIN"}]}, format="json").status_code == 403
    # cannot hand out permissions they do not hold
    assert c.post("/api/iam/users", {"username": "evil2", "password": "Strong-pass-2026!",
                                     "roles": [{"role": "FINANCE_MANAGER"}]}, format="json").status_code == 403
    root = _admin(org)
    assert c.patch(f"/api/iam/users/{root.pk}", {"password": "Another-pass-2026!"}, format="json").status_code == 403
    # cannot lock themselves out
    assert c.patch(f"/api/iam/users/{hr.pk}", {"is_active": False}, format="json").status_code == 409
    assert c.patch(f"/api/iam/users/{hr.pk}", {"roles": [{"role": "CASHIER", "branch": "SHOP1"}]},
                   format="json").status_code in (403, 409)
    # cashiers cannot see the user list at all
    assert client_for(org.u["cashier1"]).get("/api/iam/users").status_code == 403


def test_reset_pin_and_unlock(org):
    c = client_for(_admin(org))
    mgr = org.u["mgr1"]
    User.objects.filter(pk=mgr.pk).update(locked_until=timezone.now() + timedelta(minutes=10), failed_logins=3)
    r = c.patch(f"/api/iam/users/{mgr.pk}", {"unlock": True, "pin": "1212"}, format="json")
    assert r.status_code == 200 and not r.json()["locked"]
    mgr.refresh_from_db()
    assert mgr.check_pin("1212") and not mgr.check_pin("1111")


# ------------------------------------------------------------------ review fixes (privilege & scope)

def _scoped_admin(org, branch="SHOP1"):
    role = Role.objects.create(code="BR_ADMIN", name="Branch admin",
                               permissions=["admin.users", "pos.sell", "pos.refund", "pos.refund_approve",
                                            "pos.shift_approve", "pos.discount_override", "kds.operate",
                                            "reports.branch"])
    a = User.objects.create(username="bradmin")
    RoleAssignment.objects.create(user=a, role=role, branch=org.b[branch])
    return a


def test_scoped_admin_cannot_take_over_more_privileged_accounts(org):
    c = client_for(_scoped_admin(org))
    fin, mgr2 = org.u["finance"], org.u["mgr2"]
    assert c.patch(f"/api/iam/users/{fin.pk}", {"password": "Taken-over-2026!"}, format="json").status_code == 403
    assert c.patch(f"/api/iam/users/{mgr2.pk}", {"pin": "9898"}, format="json").status_code == 403
    assert c.patch(f"/api/iam/users/{fin.pk}", {"is_active": False}, format="json").status_code == 403
    fin.refresh_from_db()
    assert fin.is_active and fin.check_password("Test-pass-2026!")
    # ...but people at their own branch with roles they could grant are fine
    assert c.patch(f"/api/iam/users/{org.u['cashier1'].pk}", {"pin": "1919"}, format="json").status_code == 200


def test_scoped_admin_cannot_widen_own_scope(org):
    a = _scoped_admin(org)
    c = client_for(a)
    r = c.patch(f"/api/iam/users/{a.pk}", {"roles": [{"role": "BR_ADMIN", "branch": None}]}, format="json")
    assert r.status_code == 403
    assert RoleAssignment.objects.get(user=a).branch == org.b["SHOP1"]


def test_price_changes_are_scoped(org):
    from apps.catalog.models import Modifier, PriceList

    pl2 = PriceList.objects.create(code="SHOP2-LIST", name="Shop 2", branch=org.b["SHOP2"])
    shop_pricer = User.objects.create(username="pricer2")
    RoleAssignment.objects.create(user=shop_pricer, role=Role.objects.create(code="P2", name="p2", permissions=["price.manage"]),
                                  branch=org.b["SHOP2"])
    c = client_for(shop_pricer)
    bread = org.p["bread"].pk
    assert c.post(f"/api/catalog/products/{bread}/price", {"price_list": "DEFAULT", "price": "0.01"},
                  format="json").status_code == 403
    assert c.post(f"/api/catalog/products/{bread}/price", {"price_list": pl2.code, "price": "16"},
                  format="json").status_code == 200
    # catalogue editors without price rights cannot change VAT or add-on prices (both change what customers pay)
    pm = client_for(org.u["prodmgr"])
    assert pm.patch(f"/api/catalog/products/{bread}", {"tax_rate_id": None}, format="json").status_code == 403
    shot = Modifier.objects.get(name="Extra shot")
    assert pm.patch(f"/api/catalog/modifiers/{shot.pk}", {"name": "Extra shot", "price_delta": "1"},
                    format="json").status_code == 403
    assert pm.patch(f"/api/catalog/products/{bread}", {"shelf_life_days": 3}, format="json").status_code == 200


def test_pin_rechecked_when_moving_branch_or_reactivating(org):
    c = client_for(_admin(org))
    r = c.post("/api/iam/users", {"username": "mover", "pin": "2020", "roles": [{"role": "CASHIER", "branch": "SHOP1"}]},
               format="json")
    assert r.status_code == 201  # 2020 is free at SHOP1
    uid = r.json()["id"]
    move = {"roles": [{"role": "CASHIER", "branch": "SHOP2"}]}
    assert c.patch(f"/api/iam/users/{uid}", move, format="json").json()["error"] == "pin_required"
    assert c.patch(f"/api/iam/users/{uid}", {**move, "pin": "2020"}, format="json").json()["error"] == "pin_in_use"
    assert c.patch(f"/api/iam/users/{uid}", {**move, "pin": "2121"}, format="json").status_code == 200
    assert c.patch(f"/api/iam/users/{uid}", {"is_active": False}, format="json").status_code == 200
    assert c.patch(f"/api/iam/users/{uid}", {"is_active": True}, format="json").json()["error"] == "pin_required"
    assert c.patch(f"/api/iam/users/{uid}", {"is_active": True, "pin": "2323"}, format="json").status_code == 200


def test_malformed_management_input_is_a_clean_4xx(org):
    c = client_for(_admin(org))
    bread = org.p["bread"].pk
    assert c.patch(f"/api/catalog/products/{bread}", ["x"], format="json").status_code == 400
    assert c.post(f"/api/catalog/products/{bread}/price", {"price_list": "DEFAULT", "price": "1e20"},
                  format="json").status_code == 400
    assert c.post("/api/production/recipes", {"sku": "CAKE", "output_qty": "1", "lines": ["x"]},
                  format="json").status_code == 409
    assert c.post("/api/production/recipes/999999/discard").status_code == 409
    assert c.post("/api/production/recipes/999999/approve").status_code == 409
