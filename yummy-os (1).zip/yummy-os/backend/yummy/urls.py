from django.conf import settings
from django.contrib import admin
from django.db import connection
from django.http import FileResponse, Http404, JsonResponse
from django.urls import include, path, re_path
from drf_spectacular.views import SpectacularAPIView, SpectacularRedocView

from apps.iam import views as iam
from apps.inventory import views as inventory
from apps.pos import views as pos
from apps.procurement import views as procurement
from apps.production import views as production
from apps.reports import views as reports
from apps.transfers import views as transfers
from apps.catalog import views as catalog
from apps.iam import users as iam_users
from apps.replica import edge, hq


def health(request):
    """Liveness + database readiness."""
    try:
        with connection.cursor() as c:
            c.execute("SELECT 1")
        return JsonResponse({"status": "ok", "database": "ok"})
    except Exception:
        return JsonResponse({"status": "degraded", "database": "unreachable"}, status=503)


def mode(request):
    return JsonResponse({"mode": "hq"})


def spa(request, *args, **kwargs):
    index = settings.FRONTEND_DIST / "index.html"
    if not index.exists():
        raise Http404("Frontend not built. Run `npm run build` in frontend/.")
    resp = FileResponse(open(index, "rb"), content_type="text/html")
    resp["Cache-Control"] = "no-cache"
    return resp


api = [
    path("health", health),
    path("mode", mode),
    path("auth/login", iam.login),
    path("auth/logout", iam.logout),
    path("auth/me", iam.me),
    path("terminals", iam.terminals),
    path("terminals/enroll", iam.enroll_terminal),
    path("terminals/<str:code>/revoke", iam.revoke_terminal),
    # people & access
    path("iam/users", iam_users.users),
    path("iam/users/<int:uid>", iam_users.user_detail),
    path("iam/roles", iam_users.roles),
    # catalogue management
    path("catalog/meta", catalog.meta),
    path("catalog/products", catalog.products),
    path("catalog/products/<int:pid>", catalog.product_detail),
    path("catalog/products/<int:pid>/price", catalog.set_price),
    path("catalog/products/<int:pid>/price/remove", catalog.remove_price),
    path("catalog/categories", catalog.category),
    path("catalog/categories/<int:cid>", catalog.category),
    path("catalog/modifiers", catalog.modifiers),
    path("catalog/modifiers/<int:mid>", catalog.modifier_detail),
    # branch servers (HQ side)
    path("replica/enroll", hq.enroll),
    path("replica/bundle", hq.bundle),
    path("replica/push", hq.push),
    path("replica/enroll-terminal", hq.enroll_terminal),
    path("replica/sales/<str:number>", hq.sale_lookup),
    path("replica/servers", hq.servers),
    path("replica/servers/<str:code>/revoke", hq.revoke_server),
    # POS (device-authenticated)
    path("pos/bootstrap", pos.bootstrap),
    path("pos/sync", pos.sync),
    path("pos/heartbeat", pos.heartbeat),
    path("pos/sales/<str:number>", pos.lookup_sale),
    path("kds/tickets", pos.kds_tickets),
    path("kds/tickets/<uuid:ticket_id>", pos.kds_update),
    # master data
    path("branches", inventory.branches),
    path("products", inventory.products),
    # inventory
    path("inventory/balances", inventory.balances),
    path("inventory/movements", inventory.movements),
    path("inventory/locations", inventory.locations),
    path("inventory/locations/<int:location_id>/map", inventory.update_map),
    path("inventory/adjustments", inventory.adjustments),
    path("inventory/adjustments/<int:adj_id>/approve", inventory.approve_adjustment),
    path("inventory/expiring", inventory.expiring),
    path("inventory/lots/<int:lot_id>/hold", inventory.lot_hold),
    path("inventory/discrepancies", inventory.discrepancies),
    path("inventory/discrepancies/<int:disc_id>/resolve", inventory.resolve_discrepancy),
    # transfers
    path("transfers", transfers.transfers),
    path("transfers/<int:tid>", transfers.transfer_detail),
    path("transfers/<int:tid>/<str:action>", transfers.transfer_action),
    # production
    path("production/orders", production.orders),
    path("production/orders/<int:oid>", production.order_detail),
    path("production/orders/<int:oid>/<str:action>", production.order_action),
    path("production/recipes", production.recipes),
    path("production/recipes/<int:rid>/simulate", production.simulate),
    path("production/recipes/<int:rid>/approve", production.approve_recipe),
    path("production/recipes/<int:rid>/discard", production.discard_recipe),
    path("production/plan", production.plan),
    # procurement
    path("procurement/suppliers", procurement.suppliers),
    path("procurement/orders", procurement.purchase_orders),
    path("procurement/orders/<int:pid>/<str:action>", procurement.po_action),
    path("procurement/invoices/<int:iid>/pay", procurement.pay),
    # reports & accounting
    path("reports/dashboard", reports.dashboard),
    path("reports/control-tower", reports.control_tower),
    path("reports/warehouse-map", reports.warehouse_map),
    path("reports/recall", reports.recall_trace),
    path("reports/export/<str:report>.csv", reports.export_csv),
    path("accounting/trial-balance", reports.trial_balance),
    path("accounting/pnl", reports.profit_and_loss),
    path("accounting/journals", reports.journals),
    path("accounting/periods/<int:year>/<int:month>/lock", reports.lock_period),
    path("sync/conflicts", reports.sync_conflicts),
    path("sync/conflicts/<uuid:op_id>/resolve", reports.resolve_conflict),
    path("audit", reports.audit_log),
    path("schema", SpectacularAPIView.as_view(), name="schema"),
    path("docs", SpectacularRedocView.as_view(url_name="api:schema")),
]

# Branch server: the same till/kitchen-screen API, served from the branch's own database.
branch_api = [
    path("health", health),
    path("mode", edge.mode),
    path("auth/login", edge.login),
    path("auth/logout", edge.logout),
    path("auth/me", edge.me),
    path("terminals/enroll", edge.enroll_terminal),
    path("pos/bootstrap", edge.bootstrap),
    path("pos/sync", edge.sync),
    path("pos/heartbeat", edge.heartbeat),
    path("pos/sales/<str:number>", edge.lookup_sale),
    path("kds/tickets", edge.kds_tickets),
    path("kds/tickets/<uuid:ticket_id>", edge.kds_update),
    path("edge/status", edge.status),
    path("edge/problems", edge.problems),
    path("edge/sync-now", edge.sync_now),
    path("edge/ops/<uuid:op_id>/requeue", edge.requeue),
    re_path(r"^.*$", edge.not_here),
]

branch_urlpatterns = [
    path("api/", include((branch_api, "api"))),
    re_path(r"^(?!api/|static/).*$", spa),
]
hq_urlpatterns = [
    path("api/", include((api, "api"))),
    path("admin/", admin.site.urls),
    re_path(r"^(?!api/|admin/|static/).*$", spa),
]
urlpatterns = branch_urlpatterns if settings.YUMMY_MODE == "branch" else hq_urlpatterns
