"""
HTTP hardening and speed.

SecurityHeadersMiddleware - Content-Security-Policy for the app (scripts only from this origin, no
  framing, no third-party connections), Permissions-Policy, and no-store on API answers so
  shared/proxy caches never keep business data.
ApiGzipMiddleware - compresses larger JSON answers (till catalogue, branch bundles, reports).
  Authentication answers are never compressed (they carry fresh secrets; BREACH-style attacks
  need a secret and attacker-reflected input in the same compressed response).
"""
from django.middleware.gzip import GZipMiddleware

CSP = ("default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; "
       "font-src 'self' data:; connect-src 'self'; worker-src 'self'; manifest-src 'self'; frame-ancestors 'none'; "
       "base-uri 'self'; form-action 'self'; object-src 'none'")
PERMISSIONS_POLICY = "camera=(), microphone=(), geolocation=(), payment=(), usb=(), interest-cohort=()"
NO_GZIP = ("/api/auth/", "/api/terminals/enroll", "/api/replica/enroll", "/api/replica/enroll-terminal")


class SecurityHeadersMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        path = request.path
        if not path.startswith("/admin/"):  # Django admin ships its own inline assets
            response.setdefault("Content-Security-Policy", CSP)
        response.setdefault("Permissions-Policy", PERMISSIONS_POLICY)
        if path.startswith("/api/"):
            response["Cache-Control"] = "no-store"
        return response


class ApiGzipMiddleware(GZipMiddleware):
    max_random_bytes = 32

    def process_response(self, request, response):
        if not request.path.startswith("/api/") or request.path.startswith(NO_GZIP):
            return response
        if not response.get("Content-Type", "").startswith("application/json"):
            return response
        if not response.streaming and len(response.content) < 2048:
            return response
        return super().process_response(request, response)
