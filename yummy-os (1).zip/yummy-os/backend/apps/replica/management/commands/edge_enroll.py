from django.conf import settings
from django.core.management.base import BaseCommand, CommandError

from apps.replica import agent


class Command(BaseCommand):
    help = "Branch server: enrol with HQ using the one-time code shown in HQ's back office (Terminals & sync)."

    def add_arguments(self, parser):
        parser.add_argument("--hq", required=True, help="HQ address, e.g. https://hq.yummy.local")
        parser.add_argument("--server", required=True, help="Branch-server code created at HQ, e.g. SHOP1-SRV")
        parser.add_argument("--code", required=True, help="8-digit one-time enrolment code")

    def handle(self, *args, **o):
        if settings.YUMMY_MODE != "branch":
            raise CommandError("Set YUMMY_MODE=branch on this machine first.")
        try:
            cfg = agent.enroll(o["hq"], o["server"], o["code"])
        except agent.HQError as e:
            raise CommandError(str(e))
        self.stdout.write(self.style.SUCCESS(
            f"Enrolled as {cfg.server_code} for {cfg.branch_code} ({cfg.branch_name}). "
            f"{len(cfg.bundle.get('products', []))} products, {len(cfg.bundle.get('terminals', []))} terminals received."))
