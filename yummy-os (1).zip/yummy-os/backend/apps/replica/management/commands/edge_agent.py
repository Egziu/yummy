import signal

from django.conf import settings
from django.core.management.base import BaseCommand, CommandError

from apps.replica import agent


class Command(BaseCommand):
    help = "Branch server: keep master data in step with HQ and forward queued till operations (runs forever)."

    def add_arguments(self, parser):
        parser.add_argument("--once", action="store_true", help="Run a single pull+push cycle and exit")

    def handle(self, *args, **opts):
        if settings.YUMMY_MODE != "branch":
            raise CommandError("edge_agent only runs on a branch server (YUMMY_MODE=branch).")
        if opts["once"]:
            self.stdout.write(str(agent.cycle()))
            return
        stopping = []
        signal.signal(signal.SIGTERM, lambda *a: stopping.append(1))
        signal.signal(signal.SIGINT, lambda *a: stopping.append(1))
        self.stdout.write("edge agent started")
        agent.run_forever(stop=lambda: bool(stopping))
