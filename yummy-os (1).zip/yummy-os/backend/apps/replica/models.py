"""
HQ <-> branch-server replication.

One head-office (HQ) server is the system of record: stock ledger, accounts, purchasing,
production, master data. Each shop or café may run a *branch server* on its own LAN. The
branch server keeps that branch fully working with no internet: tills, kitchen screens,
receipt look-ups for refunds, branch sign-in and a live branch view. It stores every till
operation durably and forwards it to HQ, in order and exactly once, whenever the link is up.
HQ applies each operation with the same rules as a till that talks to HQ directly, so there is
only ever one set of books - nothing to merge, no conflicting ledgers.

  HQ side:      BranchServer  (an enrolled branch server, token-authenticated)
  Branch side:  EdgeConfig, EdgeTerminal, EdgeOp, EdgeSale, EdgeTicket, EdgeSession, EdgeUserState
"""
import hashlib
import hmac
import secrets
from datetime import timedelta

from django.db import models
from django.utils import timezone

from apps.core.models import Branch


def sha256(raw: str) -> str:
    return hashlib.sha256(raw.encode()).hexdigest()


# ============================================================================ HQ side

class BranchServer(models.Model):
    code = models.CharField(max_length=30, unique=True)
    name = models.CharField(max_length=80)
    branch = models.ForeignKey(Branch, on_delete=models.PROTECT, related_name="servers")
    token_hash = models.CharField(max_length=64, blank=True, db_index=True)
    enrollment_code_hash = models.CharField(max_length=64, blank=True)
    enrollment_expires_at = models.DateTimeField(null=True, blank=True)
    is_active = models.BooleanField(default=True)
    enrolled_at = models.DateTimeField(null=True, blank=True)
    last_seen_at = models.DateTimeField(null=True, blank=True)
    last_push_at = models.DateTimeField(null=True, blank=True)
    last_pull_at = models.DateTimeField(null=True, blank=True)
    reported_pending = models.PositiveIntegerField(default=0)
    reported_rejected = models.PositiveIntegerField(default=0)
    reported_held = models.PositiveIntegerField(default=0)
    app_version = models.CharField(max_length=30, blank=True)
    ops_applied = models.PositiveBigIntegerField(default=0)

    class Meta:
        ordering = ["code"]
        constraints = [models.UniqueConstraint(fields=["branch"], condition=models.Q(is_active=True),
                                               name="one_active_server_per_branch")]

    def __str__(self):
        return f"{self.code} ({self.branch.code})"

    def new_enrollment_code(self, minutes=60):
        code = f"{secrets.randbelow(10**8):08d}"
        self.enrollment_code_hash = sha256(code)
        self.enrollment_expires_at = timezone.now() + timedelta(minutes=minutes)
        self.save(update_fields=["enrollment_code_hash", "enrollment_expires_at"])
        return code

    def enroll(self, code):
        if (not self.is_active or not self.enrollment_code_hash or self.enrollment_expires_at is None
                or self.enrollment_expires_at < timezone.now()
                or not hmac.compare_digest(self.enrollment_code_hash, sha256(code))):
            return None
        raw = secrets.token_urlsafe(48)
        self.token_hash = sha256(raw)
        self.enrollment_code_hash = ""
        self.enrolled_at = timezone.now()
        self.save(update_fields=["token_hash", "enrollment_code_hash", "enrolled_at"])
        return raw

    @classmethod
    def lookup(cls, raw):
        if not raw:
            return None
        return cls.objects.select_related("branch").filter(token_hash=sha256(raw), is_active=True).first()


# ============================================================================ Branch side

class EdgeConfig(models.Model):
    """Singleton (pk=1) holding this branch server's link to HQ and the last master-data bundle."""

    hq_url = models.URLField(blank=True)
    server_code = models.CharField(max_length=30, blank=True)
    token = models.CharField(max_length=128, blank=True, help_text="Branch-server credential issued by HQ")
    branch_code = models.CharField(max_length=20, blank=True)
    branch_name = models.CharField(max_length=120, blank=True)
    bundle = models.JSONField(default=dict, blank=True)
    bundle_version = models.CharField(max_length=64, blank=True)
    bundle_at = models.DateTimeField(null=True, blank=True)
    last_contact_at = models.DateTimeField(null=True, blank=True)
    last_push_at = models.DateTimeField(null=True, blank=True)
    last_attempt_at = models.DateTimeField(null=True, blank=True)
    last_error = models.CharField(max_length=255, blank=True)

    @classmethod
    def get(cls):
        obj, _ = cls.objects.get_or_create(pk=1)
        return obj

    @property
    def enrolled(self):
        return bool(self.token and self.hq_url)

    @property
    def hq_online(self):
        return bool(self.last_contact_at and (timezone.now() - self.last_contact_at).total_seconds() < 90
                    and not self.last_error)


class EdgeTerminal(models.Model):
    code = models.CharField(max_length=30, primary_key=True)
    name = models.CharField(max_length=80)
    kind = models.CharField(max_length=10)
    token_hash = models.CharField(max_length=64, blank=True, db_index=True)
    is_active = models.BooleanField(default=True)
    hq_last_receipt_seq = models.PositiveIntegerField(default=0)
    last_seen_at = models.DateTimeField(null=True, blank=True)
    reported_pending = models.PositiveIntegerField(default=0)
    app_version = models.CharField(max_length=30, blank=True)

    class Meta:
        ordering = ["code"]

    @classmethod
    def lookup(cls, raw):
        if not raw:
            return None
        return cls.objects.filter(token_hash=sha256(raw), is_active=True).exclude(token_hash="").first()


class EdgeOp(models.Model):
    """Durable, ordered store-and-forward queue. `seq` is the global forwarding order."""

    class Local(models.TextChoices):
        ACCEPTED = "ACCEPTED", "Accepted"
        REJECTED = "REJECTED", "Rejected at branch"

    class Hq(models.TextChoices):
        PENDING = "PENDING", "Waiting for HQ"
        APPLIED = "APPLIED", "Applied at HQ"
        REJECTED = "REJECTED", "Rejected at HQ"
        HELD = "HELD", "Held: HQ kept asking to retry - needs a manager"

    seq = models.BigAutoField(primary_key=True)
    op_id = models.UUIDField(unique=True)
    terminal_code = models.CharField(max_length=30, db_index=True)
    kind = models.CharField(max_length=20)
    payload = models.JSONField(default=dict)
    client_created_at = models.CharField(max_length=40, blank=True)
    received_at = models.DateTimeField(auto_now_add=True)
    local_status = models.CharField(max_length=10, choices=Local.choices)
    local_result = models.JSONField(default=dict, blank=True)
    hq_status = models.CharField(max_length=10, choices=Hq.choices, default=Hq.PENDING, db_index=True)
    hq_result = models.JSONField(default=dict, blank=True)
    forwarded_at = models.DateTimeField(null=True, blank=True)
    attempts = models.PositiveIntegerField(default=0)
    last_error = models.CharField(max_length=255, blank=True)

    class Meta:
        ordering = ["seq"]


class EdgeSale(models.Model):
    """Branch journal of receipts: refund look-ups and the branch view work with no internet."""

    id = models.UUIDField(primary_key=True)
    number = models.CharField(max_length=40, unique=True)
    terminal_code = models.CharField(max_length=30, db_index=True)
    shift_id = models.CharField(max_length=40, blank=True)
    cashier_id = models.IntegerField(null=True)
    created_at = models.DateTimeField(db_index=True)
    order_type = models.CharField(max_length=10, blank=True)
    total = models.DecimalField(max_digits=14, decimal_places=2)
    tax_total = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    refunded_total = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    lines = models.JSONField(default=list)
    payments = models.JSONField(default=list)
    source = models.CharField(max_length=5, default="local", help_text="local = sold here; hq = fetched from HQ")

    class Meta:
        ordering = ["-created_at"]


class EdgeTicket(models.Model):
    id = models.UUIDField(primary_key=True)
    terminal_code = models.CharField(max_length=30)
    station = models.CharField(max_length=10)
    order_ref = models.CharField(max_length=40)
    order_type = models.CharField(max_length=10, default="DINE_IN")
    items = models.JSONField(default=list)
    status = models.CharField(max_length=10, default="NEW")
    created_at = models.DateTimeField(db_index=True)
    updated_at = models.DateTimeField(auto_now=True)
    ready_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["created_at"]


class EdgeSession(models.Model):
    key_hash = models.CharField(max_length=64, primary_key=True)
    user_id = models.IntegerField()
    username = models.CharField(max_length=150)
    password_fp = models.CharField(max_length=64, blank=True, help_text="Ends the session if HQ changes the password")
    created_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField()


class EdgeUserState(models.Model):
    """Branch-side login throttling (failed attempts / temporary lock)."""

    username = models.CharField(max_length=150, primary_key=True)
    failed = models.PositiveSmallIntegerField(default=0)
    locked_until = models.DateTimeField(null=True, blank=True)
