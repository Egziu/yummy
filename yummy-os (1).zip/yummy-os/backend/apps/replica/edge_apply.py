"""
Branch-side acceptance of till operations.

A branch server must answer tills instantly, with or without HQ. It therefore:
  1. stores every operation durably (EdgeOp) - exactly once per op_id, in arrival order;
  2. updates its branch journal (receipts, refunds, kitchen tickets) so look-ups and the
     kitchen screens work offline;
  3. answers APPLIED or REJECTED.

It only rejects what HQ would certainly reject too (malformed payloads, totals that don't add
up, a refund approved by the cashier themself, refunding more than was sold). Anything that
depends on HQ's data (stock, permissions changed since the last bundle, prices) is accepted and
decided by HQ when the operation is forwarded - HQ keeps the books. Every operation, including
locally rejected ones, is forwarded so HQ's review queue sees exactly what the tills sent.
"""
import uuid
from decimal import Decimal

from django.db import DataError, IntegrityError, transaction
from django.utils import timezone

from apps.core.money import from_cents, price_line, q2, q3, to_cents
from apps.pos.sync import Reject, _dec, _dt, _uuid

from .models import EdgeOp, EdgeSale, EdgeTicket

KNOWN = {"shift_open", "cash_move", "sale", "refund", "kitchen_ticket", "shift_close", "ticket_status"}
PAYMENT_METHODS = {"CASH", "TELEBIRR", "CBE_BIRR", "BANK_TRANSFER", "CARD", "CREDIT"}
STATIONS = {"BARISTA", "KITCHEN", "DESSERT"}


def _products(bundle):
    return {p["id"]: p for p in bundle.get("products", [])}


def check_sale(p, bundle):
    _uuid(p.get("id"), "id")
    _uuid(p.get("shift_id"), "shift_id")
    _dt(p.get("created_at"), "created_at")
    number = str(p.get("number", ""))[:40]
    if not number:
        raise Reject("duplicate_number", "Receipt number missing")
    if EdgeSale.objects.filter(number=number).exclude(pk=p.get("id")).exists():
        raise Reject("duplicate_number", f"Receipt number '{number}' already used by another sale")
    lines, payments = p.get("lines") or [], p.get("payments") or []
    if not isinstance(lines, list) or not isinstance(payments, list):
        raise Reject("invalid_payload", "lines and payments must be lists")
    if not lines:
        raise Reject("invalid_payload", "Sale has no lines")
    if not payments:
        raise Reject("invalid_payload", "Sale has no payments")
    tax_inclusive = bool(p.get("tax_inclusive", True))
    prods = _products(bundle)
    total_c = tax_c = 0
    journal = []
    for i, l in enumerate(lines, start=1):
        qty = _dec(l.get("qty"), "qty")
        unit_price = _dec(l.get("unit_price"), "unit_price")
        discount = _dec(l.get("discount", "0"), "discount")
        rate = _dec(l.get("tax_rate", "0"), "tax_rate")
        try:
            calc = price_line(unit_price, qty, discount, rate, tax_inclusive)
        except ValueError as e:
            raise Reject("invalid_line", f"Line {i}: {e}")
        if l.get("total") is not None and to_cents(_dec(l["total"], "total")) != calc["total"]:
            raise Reject("totals_mismatch", f"Line {i}: terminal total {l['total']} != server {from_cents(calc['total'])}")
        total_c += calc["total"]
        tax_c += calc["tax"]
        prod = prods.get(l.get("product_id"), {})
        journal.append({"line_no": i, "product_id": l.get("product_id"), "name": prod.get("name") or l.get("name") or "?",
                        "qty": str(q3(qty)), "qty_refunded": "0.000", "total": str(from_cents(calc["total"])),
                        "tax": str(from_cents(calc["tax"])), "is_stocked": bool(prod.get("is_stocked", True))})
    pay_c, pays = 0, []
    for pm in payments:
        if pm.get("method") not in PAYMENT_METHODS:
            raise Reject("invalid_payment", f"Unknown payment method {pm.get('method')}")
        amt = to_cents(_dec(pm.get("amount"), "amount"))
        if amt <= 0:
            raise Reject("invalid_payment", "Payment amounts must be positive")
        pay_c += amt
        pays.append({"method": pm["method"], "amount": str(from_cents(amt))})
    if pay_c != total_c:
        raise Reject("payment_mismatch", f"Payments {from_cents(pay_c)} do not equal total {from_cents(total_c)}")
    totals = p.get("totals") or {}
    claimed = totals.get("total") if isinstance(totals, dict) else None
    if claimed is not None and to_cents(_dec(claimed, "totals.total")) != total_c:
        raise Reject("totals_mismatch", f"Terminal total {claimed} != server {from_cents(total_c)}")
    return number, from_cents(total_c), from_cents(tax_c), journal, pays


def check_refund(p):
    _uuid(p.get("id"), "id")
    _uuid(p.get("shift_id"), "shift_id")
    sale_id = _uuid(p.get("sale_id"), "sale_id")
    if p.get("approver_id") is None or str(p.get("approver_id")) == str(p.get("cashier_id")):
        raise Reject("sod_violation", "Refund must be approved by a different person")
    if not str(p.get("reason", "")).strip():
        raise Reject("invalid_payload", "A refund reason is required")
    if p.get("method", "CASH") not in PAYMENT_METHODS:
        raise Reject("invalid_payment", "Unknown refund method")
    specs = p.get("lines") or []
    if not specs:
        raise Reject("invalid_payload", "Refund has no lines")
    sale = EdgeSale.objects.select_for_update().filter(pk=sale_id).first()
    if sale is None:
        return None, []  # sold before this branch server existed: HQ validates the limits
    lines = {int(l["line_no"]): l for l in sale.lines}
    updates = []
    for spec in specs:
        try:
            ln = int(spec.get("line_no", 0))
        except (TypeError, ValueError):
            raise Reject("invalid_line", "Bad line number")
        line = lines.get(ln)
        if line is None:
            raise Reject("invalid_line", f"Sale has no line {ln}")
        qty = q3(_dec(spec.get("qty"), "qty"))
        remaining = Decimal(line["qty"]) - Decimal(line["qty_refunded"])
        if qty <= 0 or qty > remaining:
            raise Reject("excess_refund", f"Line {ln}: cannot refund {qty}; {remaining} remaining")
        updates.append((ln, qty))
    return sale, updates


def _refund_amount(line, qty):
    """Branch estimate of a refund (HQ computes the exact remainder-safe split)."""
    total = Decimal(line["total"])
    return q2(total * qty / Decimal(line["qty"]))


def accept(terminal_code, op, bundle):
    """Accept one operation. Returns the per-op result for the till."""
    try:
        op_id = _uuid(op.get("op_id"), "op_id")
    except Reject as r:
        return {"op_id": op.get("op_id"), "status": "REJECTED", "error": r.code, "detail": r.detail}
    existing = EdgeOp.objects.filter(op_id=op_id).first()
    if existing:
        if existing.terminal_code != terminal_code:
            return {"op_id": str(op_id), "status": "REJECTED", "error": "forbidden", "detail": "Operation id conflict"}
        return _answer(existing)
    kind = str(op.get("kind", ""))[:20]
    payload = op.get("payload") or {}
    status, result = EdgeOp.Local.ACCEPTED, {}
    try:
        with transaction.atomic():
            if not isinstance(payload, dict):
                payload = {"_raw": str(op.get("payload"))[:500]}
                raise Reject("invalid_payload", "payload must be an object")
            try:
                result = _apply(kind, terminal_code, payload, bundle)
            except (ValueError, TypeError, AttributeError, KeyError, ArithmeticError, DataError) as e:
                raise Reject("invalid_payload", f"Malformed operation: {type(e).__name__}")
            row = EdgeOp.objects.create(op_id=op_id, terminal_code=terminal_code, kind=kind, payload=payload,
                                        client_created_at=str(op.get("created_at") or "")[:40],
                                        local_status=status, local_result=result)
    except Reject as r:
        try:
            row = EdgeOp.objects.create(op_id=op_id, terminal_code=terminal_code, kind=kind, payload=payload,
                                        client_created_at=str(op.get("created_at") or "")[:40],
                                        local_status=EdgeOp.Local.REJECTED,
                                        local_result={"error": r.code, "detail": r.detail})
        except IntegrityError:  # concurrent duplicate delivery of the same op
            row = EdgeOp.objects.get(op_id=op_id)
    except IntegrityError:
        row = EdgeOp.objects.filter(op_id=op_id).first()
        if row is None:
            return {"op_id": str(op_id), "status": "RETRY", "detail": "busy"}
    return _answer(row)


def _apply(kind, terminal_code, payload, bundle):
    """Branch-journal effect of one operation (inside the caller's transaction). Raises Reject."""
    if kind not in KNOWN:
        raise Reject("unknown_kind", f"Unknown operation '{kind}'")
    if kind == "sale":
        number, total, tax, journal, pays = check_sale(payload, bundle)
        EdgeSale.objects.create(
            id=_uuid(payload["id"], "id"), number=number, terminal_code=terminal_code,
            shift_id=str(payload.get("shift_id")), cashier_id=_int(payload.get("cashier_id")),
            created_at=_dt(payload.get("created_at"), "created_at"), total=total, tax_total=tax,
            order_type=str(payload.get("order_type", ""))[:10], lines=journal, payments=pays)
        return {"sale_id": str(payload["id"]), "number": number, "total": str(total)}
    if kind == "refund":
        sale, updates = check_refund(payload)
        effect = []
        if sale is not None:
            by_no = {int(l["line_no"]): l for l in sale.lines}
            amount = Decimal("0")
            for ln, qty in updates:
                line = by_no[ln]
                a = _refund_amount(line, qty)
                amount += a
                line["qty_refunded"] = str(q3(Decimal(line["qty_refunded"]) + qty))
                effect.append([ln, str(qty), str(a)])
            sale.lines = list(by_no.values())
            sale.refunded_total = min(sale.total, sale.refunded_total + amount)
            sale.save(update_fields=["lines", "refunded_total"])
        # `_effect` lets the branch undo its journal if HQ later rejects the refund (never sent to tills)
        return {"refund_id": str(payload.get("id")), "_effect": {"sale_id": str(sale.id) if sale else None, "lines": effect}}
    if kind == "kitchen_ticket":
        tid = _uuid(payload.get("id"), "id")
        station = payload.get("station", "KITCHEN")
        if station not in STATIONS:
            raise Reject("invalid_payload", "Unknown station")
        raw = payload.get("items") or []
        if not isinstance(raw, list) or not all(isinstance(i, dict) for i in raw):
            raise Reject("invalid_payload", "Ticket items must be objects")
        items = [{"name": str(i.get("name", ""))[:80], "qty": str(i.get("qty", "1")),
                  "modifiers": [str(m)[:40] for m in (i.get("modifiers") or [])][:10],
                  "note": str(i.get("note", ""))[:120]} for i in raw][:50]
        if not items:
            raise Reject("invalid_payload", "Ticket has no items")
        if not EdgeTicket.objects.filter(pk=tid).exists():
            EdgeTicket.objects.create(id=tid, terminal_code=terminal_code, station=station,
                                      order_ref=str(payload.get("order_ref", ""))[:40],
                                      order_type=str(payload.get("order_type", "DINE_IN"))[:10], items=items,
                                      created_at=_dt(payload.get("created_at"), "created_at"))
        return {"ticket_id": str(tid)}
    if kind == "ticket_status":
        _uuid(payload.get("ticket_id"), "ticket_id")
        return {"ticket_id": str(payload.get("ticket_id"))}
    # shift_open / shift_close / cash_move: structure only; HQ computes cash and over/short
    _uuid(payload.get("shift_id"), "shift_id")
    if kind == "cash_move":
        _uuid(payload.get("id"), "id")
        if payload.get("kind") not in ("IN", "OUT") or q2(_dec(payload.get("amount"), "amount")) <= 0:
            raise Reject("invalid_payload", "Cash movement needs IN/OUT and a positive amount")
    return {"shift_id": str(payload.get("shift_id"))}


def undo_refund(op):
    """HQ rejected a refund the branch had accepted: give the quantities back in the branch journal."""
    eff = (op.local_result or {}).get("_effect") or {}
    if not eff.get("sale_id"):
        return
    with transaction.atomic():
        sale = EdgeSale.objects.select_for_update().filter(pk=eff["sale_id"]).first()
        if sale is None:
            return
        by_no = {int(l["line_no"]): l for l in sale.lines}
        back = Decimal("0")
        for ln, qty, amount in eff.get("lines", []):
            line = by_no.get(int(ln))
            if line is None:
                continue
            line["qty_refunded"] = str(q3(max(Decimal("0"), Decimal(line["qty_refunded"]) - Decimal(qty))))
            back += Decimal(amount)
        sale.lines = list(by_no.values())
        sale.refunded_total = max(Decimal("0"), sale.refunded_total - back)
        sale.save(update_fields=["lines", "refunded_total"])


def _answer(row):
    public = {k: v for k, v in (row.local_result or {}).items() if not k.startswith("_")}
    if row.local_status == EdgeOp.Local.REJECTED:
        return {"op_id": str(row.op_id), "status": "REJECTED", **public}
    return {"op_id": str(row.op_id), "status": "APPLIED", **public, "at_branch": True}


def _int(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def synthetic_ticket_status(ticket, status):
    """A kitchen-screen tap becomes a forwarded operation so HQ's ticket history matches."""
    EdgeOp.objects.create(op_id=uuid.uuid4(), terminal_code=ticket.terminal_code, kind="ticket_status",
                          payload={"ticket_id": str(ticket.id), "status": status, "at": timezone.now().isoformat()},
                          client_created_at=timezone.now().isoformat(), local_status=EdgeOp.Local.ACCEPTED,
                          local_result={"ticket_id": str(ticket.id), "status": status})
