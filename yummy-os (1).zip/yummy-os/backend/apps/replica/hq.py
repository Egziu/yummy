"""
HQ endpoints used by branch servers (token-authenticated) and by the back office (managing branch servers).

  POST /api/replica/enroll                 one-time enrolment code -> branch-server credential
  GET  /api/replica/bundle?since=<version> master data for the branch (unchanged -> {"unchanged": true})
  POST /api/replica/push                   ordered till operations, applied exactly once with HQ rules
  POST /api/replica/enroll-terminal        till enrolment relayed by the branch server
  GET  /api/replica/sales/<number>         receipt look-up for refunds (sales made before the branch server)
"""

from django.db import transaction
from django.utils import timezone
from django.utils.dateparse import parse_datetime
from rest_framework import authentication, exceptions, serializers
from rest_framework.decorators import api_view, authentication_classes, permission_classes, throttle_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.throttling import AnonRateThrottle

from apps.core import audit
from apps.core.exceptions import PermissionDeniedError
from apps.core.models import Branch
from apps.iam.models import RoleAssignment, Terminal, User
from apps.iam.permissions import branches_for, require, require_user
from apps.pos.models import Sale
from apps.pos.sync import MAX_BATCH, apply_operation
from apps.pos.views import branch_catalog, catalog_version, last_receipt_seq, sale_json

from .models import BranchServer

HUB_PERMS = {"reports.branch", "sync.monitor"}


class ServerPrincipal:
    is_authenticated = True
    is_active = True
    is_superuser = False
    pk = None
    id = None

    def __init__(self, server):
        self.server = server


class BranchServerAuthentication(authentication.BaseAuthentication):
    header = "HTTP_X_BRANCH_SERVER_TOKEN"

    def authenticate(self, request):
        raw = request.META.get(self.header)
        if not raw:
            return None
        server = BranchServer.lookup(raw)
        if server is None:
            raise exceptions.AuthenticationFailed("Branch server is not enrolled or has been revoked.")
        BranchServer.objects.filter(pk=server.pk).update(last_seen_at=timezone.now())
        return ServerPrincipal(server), server


def _server(request) -> BranchServer:
    if not isinstance(request.auth, BranchServer):
        raise PermissionDeniedError("This endpoint is only available to enrolled branch servers.")
    return request.auth


def server_view(methods):
    def deco(fn):
        fn = permission_classes([AllowAny])(fn)
        fn = authentication_classes([BranchServerAuthentication])(fn)
        return api_view(methods)(fn)
    return deco


class EnrollThrottle(AnonRateThrottle):
    scope = "enroll"


# ------------------------------------------------------------------ bundle

def build_bundle(server):
    branch = server.branch
    catalog = branch_catalog(branch)
    # Only people whose access is limited to THIS branch: anyone with an all-branches role (HQ staff),
    # staff/superusers, or roles at other branches never has a password verifier on a branch machine.
    hub_users = []
    scoped = (RoleAssignment.objects.filter(branch=branch, user__is_active=True, user__is_superuser=False,
                                            user__is_staff=False)
              .values_list("user_id", flat=True).distinct())
    for u in User.objects.filter(pk__in=scoped).prefetch_related("assignments__role").order_by("username"):
        assignments = list(u.assignments.all())
        if any(a.branch_id != branch.pk for a in assignments):
            continue
        perms = set().union(*(a.role.permissions for a in assignments))
        if perms & HUB_PERMS and u.has_usable_password():
            hub_users.append({"id": u.pk, "username": u.username, "name": u.label, "password": u.password,
                              "permissions": sorted(perms)})
    terms = []
    for t in Terminal.objects.filter(branch=branch).order_by("code"):
        nums = Sale.objects.filter(terminal=t, number__startswith=f"{t.code}-").order_by("-created_at") \
            .values_list("number", flat=True)[:200]
        terms.append({"code": t.code, "name": t.name, "kind": t.kind, "token_hash": t.token_hash,
                      "is_active": t.is_active, "last_receipt_seq": last_receipt_seq(t.code, nums)})
    bundle = {"server": {"code": server.code, "name": server.name}, **catalog, "hub_users": hub_users,
              "terminals": terms}
    return bundle, catalog_version(bundle)


@server_view(["GET"])
def bundle(request):
    server = _server(request)
    data, version = build_bundle(server)
    BranchServer.objects.filter(pk=server.pk).update(last_pull_at=timezone.now(),
                                                     app_version=str(request.query_params.get("v", ""))[:30])
    if request.query_params.get("since") == version:
        return Response({"unchanged": True, "version": version, "server_time": timezone.now().isoformat()})
    return Response({"version": version, "bundle": data, "server_time": timezone.now().isoformat()})


# ------------------------------------------------------------------ push

@server_view(["POST"])
def push(request):
    server = _server(request)
    if not isinstance(request.data, dict):
        return Response({"error": "invalid", "detail": "body must be an object"}, status=400)
    ops = request.data.get("ops") or []
    if not isinstance(ops, list) or len(ops) > MAX_BATCH:
        return Response({"error": "invalid", "detail": f"ops must be a list of at most {MAX_BATCH}"}, status=400)
    if not all(isinstance(op, dict) for op in ops):
        return Response({"error": "invalid", "detail": "each op must be an object"}, status=400)
    terms = {t.code: t for t in Terminal.objects.filter(branch=server.branch).select_related("branch")}
    results, blocked, applied, touched = [], False, 0, set()
    for op in ops:
        if blocked:
            results.append({"op_id": op.get("op_id"), "status": "RETRY", "detail": "waiting_for_earlier_operation"})
            continue
        term = terms.get(str(op.get("terminal", "")))
        if term is None:
            r = {"op_id": op.get("op_id"), "status": "REJECTED", "error": "forbidden",
                 "detail": f"Terminal {op.get('terminal')} does not belong to {server.branch.code}"}
            audit.record("replica.foreign_terminal_op", object_type="replica.BranchServer", object_id=server.pk,
                         branch=server.branch, data={"server": server.code, "terminal": str(op.get("terminal"))[:30],
                                                     "op_id": str(op.get("op_id"))[:40], "kind": str(op.get("kind"))[:20],
                                                     "payload": op.get("payload") if isinstance(op.get("payload"), dict) else None})
        else:
            r = apply_operation(term, op)
            touched.add(term.pk)
        results.append(r)
        if r["status"] == "APPLIED":
            applied += 1
        if r["status"] == "RETRY":
            blocked = True
    now = timezone.now()
    if touched:
        Terminal.objects.filter(pk__in=touched).update(last_sync_at=now)
    heartbeats = request.data.get("terminals") or []
    for hb in heartbeats if isinstance(heartbeats, list) else []:  # device health relayed by the branch server
        if not isinstance(hb, dict):
            continue
        t = terms.get(str(hb.get("code", "")))
        seen = parse_datetime(str(hb.get("last_seen_at") or ""))
        if t is None or seen is None:
            continue
        if t.last_seen_at is None or seen > t.last_seen_at:
            Terminal.objects.filter(pk=t.pk).update(
                last_seen_at=seen, reported_pending=_count(hb.get("pending")),
                app_version=str(hb.get("app_version", ""))[:30])
    upd = {"last_push_at": now, "reported_pending": _count(request.data.get("pending_count")),
           "reported_rejected": _count(request.data.get("rejected_count")),
           "reported_held": _count(request.data.get("held_count"))}
    BranchServer.objects.filter(pk=server.pk).update(**upd)
    if applied:
        from django.db.models import F

        BranchServer.objects.filter(pk=server.pk).update(ops_applied=F("ops_applied") + applied)
    return Response({"results": results, "server_time": now.isoformat()})


def _count(v):
    try:
        return max(0, min(int(v or 0), 10**9))
    except (TypeError, ValueError):
        return 0


# ------------------------------------------------------------------ enrolment & look-ups

class ServerEnrollIn(serializers.Serializer):
    server_code = serializers.CharField(max_length=30)
    enrollment_code = serializers.RegexField(r"^\d{8}$")
    app_version = serializers.CharField(max_length=30, required=False, allow_blank=True)


@api_view(["POST"])
@authentication_classes([])
@permission_classes([AllowAny])
@throttle_classes([EnrollThrottle])
def enroll(request):
    data = ServerEnrollIn(data=request.data)
    data.is_valid(raise_exception=True)
    with transaction.atomic():
        s = BranchServer.objects.select_for_update().select_related("branch").filter(
            code=data.validated_data["server_code"]).first()
        token = s.enroll(data.validated_data["enrollment_code"]) if s else None
        if not token:
            return Response({"error": "enrollment_failed", "detail": "Code is wrong, expired or already used."},
                            status=400)
        s.app_version = data.validated_data.get("app_version", "")
        s.save(update_fields=["app_version"])
        audit.record("replica.server_enrolled", obj=s, branch=s.branch)
    return Response({"server_token": token, "server": {"code": s.code, "name": s.name},
                     "branch": {"code": s.branch.code, "name": s.branch.name}})


class TermEnrollIn(serializers.Serializer):
    terminal_code = serializers.CharField(max_length=30)
    enrollment_code = serializers.RegexField(r"^\d{8}$")
    app_version = serializers.CharField(max_length=30, required=False, allow_blank=True)


@server_view(["POST"])
def enroll_terminal(request):
    server = _server(request)
    data = TermEnrollIn(data=request.data)
    data.is_valid(raise_exception=True)
    with transaction.atomic():
        term = Terminal.objects.select_for_update().filter(code=data.validated_data["terminal_code"],
                                                           branch=server.branch).first()
        token = term.enroll(data.validated_data["enrollment_code"]) if term else None
        if not token:
            return Response({"error": "enrollment_failed", "detail": "Code is wrong, expired or already used."},
                            status=400)
        term.app_version = data.validated_data.get("app_version", "")
        term.save(update_fields=["app_version"])
        audit.record("terminal.enrolled", obj=term, branch=term.branch, terminal=term,
                     data={"via_branch_server": server.code})
    return Response({"device_token": token, "terminal": {"code": term.code, "name": term.name, "kind": term.kind,
                                                          "branch": server.branch.code}})


@server_view(["GET"])
def sale_lookup(request, number):
    server = _server(request)
    sale = (Sale.objects.filter(number=number, branch=server.branch).select_related("terminal")
            .prefetch_related("lines__product", "payments").first())
    if sale is None:
        return Response({"error": "not_found", "detail": "No sale with that number at this branch."}, status=404)
    return Response(sale_json(sale))


# ------------------------------------------------------------------ back office: manage branch servers

class ServerIn(serializers.Serializer):
    code = serializers.RegexField(r"^[A-Z0-9\-]{2,30}$")
    name = serializers.CharField(max_length=80)
    branch = serializers.CharField(max_length=20)


@api_view(["GET", "POST"])
def servers(request):
    user = require_user(request)
    if request.method == "GET":
        require(user, "sync.monitor")
        allowed = branches_for(user, "sync.monitor")
        now = timezone.now()
        return Response([
            {"code": s.code, "name": s.name, "branch": s.branch.code, "branch_name": s.branch.name,
             "is_active": s.is_active, "enrolled": bool(s.token_hash), "last_seen_at": s.last_seen_at,
             "last_push_at": s.last_push_at, "last_pull_at": s.last_pull_at, "pending": s.reported_pending,
             "rejected": s.reported_rejected, "held": s.reported_held, "ops_applied": s.ops_applied, "app_version": s.app_version,
             "online": bool(s.last_seen_at and (now - s.last_seen_at).total_seconds() < 120)}
            for s in BranchServer.objects.filter(branch__in=allowed).select_related("branch")
        ])
    data = ServerIn(data=request.data)
    data.is_valid(raise_exception=True)
    branch = Branch.objects.filter(code=data.validated_data["branch"]).first()
    if branch is None:
        return Response({"error": "invalid", "detail": "Unknown branch."}, status=400)
    require(user, "admin.terminals", branch)
    with transaction.atomic():
        s = BranchServer.objects.filter(code=data.validated_data["code"]).first()
        if s is None:
            if BranchServer.objects.filter(branch=branch, is_active=True).exists():
                return Response({"error": "conflict", "detail": f"{branch.code} already has an active branch server. "
                                                                 "Revoke it first."}, status=409)
            s = BranchServer.objects.create(code=data.validated_data["code"], name=data.validated_data["name"],
                                            branch=branch)
        elif s.branch_id != branch.pk:
            return Response({"error": "conflict", "detail": "That server code belongs to another branch."}, status=409)
        elif not s.is_active:
            return Response({"error": "conflict", "detail": "That server was revoked. Use a new code."}, status=409)
        code = s.new_enrollment_code()
        audit.record("replica.enrollment_code_issued", actor=user, obj=s, branch=branch)
    return Response({"server": s.code, "branch": branch.code, "enrollment_code": code,
                     "expires_at": s.enrollment_expires_at})


@api_view(["POST"])
def revoke_server(request, code):
    user = require_user(request)
    s = BranchServer.objects.select_related("branch").filter(code=code).first()
    if s is None:
        return Response({"error": "not_found"}, status=404)
    require(user, "admin.terminals", s.branch)
    s.is_active, s.token_hash = False, ""
    s.save(update_fields=["is_active", "token_hash"])
    audit.record("replica.server_revoked", actor=user, obj=s, branch=s.branch)
    return Response({"ok": True})
