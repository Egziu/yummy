"""
Branch-server API. Mounted instead of the HQ API when YUMMY_MODE=branch.

Same paths and payloads the tills and kitchen screens already use (/api/pos/*, /api/kds/*,
/api/terminals/enroll), so the same app works against HQ or against the branch server, plus a
small branch hub for managers (/api/auth/*, /api/edge/*).
"""
import secrets
from datetime import datetime, timedelta
from decimal import Decimal

from django.conf import settings
from django.contrib.auth.hashers import check_password
from django.db import transaction
from django.db.models import Count, Q, Sum
from django.utils import timezone
from rest_framework import authentication, exceptions, serializers
from rest_framework.decorators import api_view, authentication_classes, permission_classes, throttle_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.throttling import AnonRateThrottle

from apps.core.ethiopian import format_ethiopian
from apps.pos.sync import MAX_BATCH

from . import agent
from .edge_apply import accept, synthetic_ticket_status
from .models import EdgeConfig, EdgeOp, EdgeSale, EdgeSession, EdgeTerminal, EdgeTicket, EdgeUserState, sha256

HUB_PERMS = {"reports.branch", "sync.monitor"}


# ------------------------------------------------------------------ authentication

class EdgeUser:
    is_authenticated = True
    is_active = True
    is_superuser = False

    def __init__(self, data, session=None):
        self.pk = self.id = data["id"]
        self.username = data["username"]
        self.label = data.get("name") or data["username"]
        self.permissions = set(data.get("permissions", []))
        self.session = session


class TerminalAuth(authentication.BaseAuthentication):
    def authenticate(self, request):
        raw = request.META.get("HTTP_X_TERMINAL_TOKEN")
        if not raw:
            return None
        term = EdgeTerminal.lookup(raw)
        if term is None:
            raise exceptions.AuthenticationFailed("Terminal is not enrolled or has been revoked.")
        EdgeTerminal.objects.filter(pk=term.pk).update(last_seen_at=timezone.now())
        return None, term


def _hub_users():
    return {u["username"]: u for u in EdgeConfig.get().bundle.get("hub_users", [])}


class SessionAuth(authentication.BaseAuthentication):
    def authenticate(self, request):
        header = authentication.get_authorization_header(request).decode()
        if not header.startswith("Bearer "):
            return None
        s = EdgeSession.objects.filter(key_hash=sha256(header[7:].strip())).first()
        if s is None or s.expires_at < timezone.now():
            raise exceptions.AuthenticationFailed("Session expired or invalid.")
        u = _hub_users().get(s.username)
        if u is None or (s.password_fp and s.password_fp != sha256(u["password"])):
            s.delete()  # removed, demoted or password changed at HQ since sign-in
            raise exceptions.AuthenticationFailed("Please sign in again.")
        return EdgeUser(u, s), s

    def authenticate_header(self, request):
        return "Bearer"


def edge_view(methods, auth=(TerminalAuth, SessionAuth)):
    def deco(fn):
        fn = permission_classes([AllowAny])(fn)
        fn = authentication_classes(list(auth))(fn)
        return api_view(methods)(fn)
    return deco


def _terminal(request):
    if not isinstance(request.auth, EdgeTerminal):
        raise exceptions.PermissionDenied("This endpoint is only available to enrolled terminals.")
    return request.auth


def _hub_user(request):
    if not isinstance(request.user, EdgeUser):
        raise exceptions.NotAuthenticated("Sign in first.")
    if not (request.user.permissions & HUB_PERMS):
        raise exceptions.PermissionDenied("Branch managers only.")
    return request.user


class LoginThrottle(AnonRateThrottle):
    scope = "login"


class EnrollThrottle(AnonRateThrottle):
    scope = "enroll"


# ------------------------------------------------------------------ mode & health

def mode_payload():
    cfg = EdgeConfig.get()
    return {"mode": "branch", "branch": {"code": cfg.branch_code, "name": cfg.branch_name},
            "server": cfg.server_code, "enrolled": cfg.enrolled, "hq_online": cfg.hq_online,
            "last_contact_at": cfg.last_contact_at}


@edge_view(["GET"], auth=())
def mode(request):
    return Response(mode_payload())


# ------------------------------------------------------------------ tills

def _bundle_or_503():
    cfg = EdgeConfig.get()
    if not cfg.bundle:
        raise exceptions.APIException("This branch server has not received its data from HQ yet.")
    return cfg


def _pending_qty():
    """Units sold here that HQ has not booked yet - subtracted from HQ's last stock figure."""
    out = {}
    for o in EdgeOp.objects.filter(kind="sale", hq_status=EdgeOp.Hq.PENDING, local_status=EdgeOp.Local.ACCEPTED):
        for l in o.payload.get("lines") or []:
            try:
                out[l.get("product_id")] = out.get(l.get("product_id"), 0) + float(l.get("qty") or 0)
            except (TypeError, ValueError):
                continue
    return out


@edge_view(["GET"])
def bootstrap(request):
    term = _terminal(request)
    cfg = _bundle_or_503()
    b = cfg.bundle
    pending = _pending_qty()
    products = []
    for p in b.get("products", []):
        p = dict(p)
        if p.get("stock") is not None and p["id"] in pending:
            p["stock"] = p["stock"] - pending[p["id"]]
        products.append(p)
    nums = EdgeSale.objects.filter(terminal_code=term.code, number__startswith=f"{term.code}-").values_list(
        "number", flat=True)
    from apps.pos.views import last_receipt_seq

    local_seq = last_receipt_seq(term.code, list(nums))
    return Response({
        "terminal": {"code": term.code, "name": term.name, "kind": term.kind},
        "branch": b["branch"], "settings": b["settings"], "categories": b["categories"], "products": products,
        "cashiers": b["cashiers"], "payment_methods": b["payment_methods"],
        "catalog_version": cfg.bundle_version, "last_receipt_seq": max(local_seq, term.hq_last_receipt_seq),
        "server_time": timezone.now().isoformat(), "ethiopian_date": format_ethiopian(timezone.localdate()),
        "via_branch_server": True,
    })


@edge_view(["POST"])
def sync(request):
    term = _terminal(request)
    ops = request.data.get("ops") or []
    if not isinstance(ops, list) or len(ops) > MAX_BATCH:
        return Response({"error": "invalid", "detail": f"ops must be a list of at most {MAX_BATCH}"}, status=400)
    bundle = EdgeConfig.get().bundle
    results = [accept(term.code, op if isinstance(op, dict) else {}, bundle) for op in ops]
    upd = {"last_seen_at": timezone.now()}
    if request.data.get("pending_count") is not None:
        try:
            upd["reported_pending"] = max(0, int(request.data["pending_count"]) - len(ops))
        except (TypeError, ValueError):
            pass
    EdgeTerminal.objects.filter(pk=term.pk).update(**upd)
    return Response({"results": results, "server_time": timezone.now().isoformat()})


@edge_view(["POST"])
def heartbeat(request):
    term = _terminal(request)
    upd = {"last_seen_at": timezone.now(), "app_version": str(request.data.get("app_version", ""))[:30]}
    try:
        upd["reported_pending"] = max(0, int(request.data.get("pending_count") or 0))
    except (TypeError, ValueError):
        pass
    EdgeTerminal.objects.filter(pk=term.pk).update(**upd)
    return Response({"server_time": timezone.now().isoformat()})


def _edge_sale_json(s):
    return {"id": str(s.id), "number": s.number, "created_at": s.created_at, "total": str(s.total),
            "refunded_total": str(s.refunded_total), "shift_id": s.shift_id, "lines": s.lines, "payments": s.payments,
            "terminal": s.terminal_code}


@edge_view(["GET"])
def lookup_sale(request, number):
    _terminal(request)
    s = EdgeSale.objects.filter(number=number).first()
    if s is None:
        try:  # sold before this branch server existed, or at a till still talking to HQ directly
            r = agent.hq_request("GET", f"/api/replica/sales/{number}", timeout=8)
        except agent.HQError as e:
            detail = ("No sale with that number at this branch." if e.status == 404
                      else "Receipt not found on the branch server and HQ is unreachable right now.")
            return Response({"error": "not_found", "detail": detail}, status=404)
        with transaction.atomic():
            s, _ = EdgeSale.objects.get_or_create(id=r["id"], defaults={
                "number": r["number"], "terminal_code": r.get("terminal", ""), "shift_id": r.get("shift_id", ""),
                "created_at": r["created_at"], "total": Decimal(r["total"]), "tax_total": Decimal(r.get("tax_total") or 0),
                "refunded_total": Decimal(r["refunded_total"]), "lines": r["lines"], "payments": r["payments"],
                "source": "hq"})
    return Response(_edge_sale_json(s))


class EnrollIn(serializers.Serializer):
    terminal_code = serializers.CharField(max_length=30)
    enrollment_code = serializers.RegexField(r"^\d{8}$")
    app_version = serializers.CharField(max_length=30, required=False, allow_blank=True)


@api_view(["POST"])
@authentication_classes([])
@permission_classes([AllowAny])
@throttle_classes([EnrollThrottle])
def enroll_terminal(request):
    """Relayed to HQ: one enrolment code works once, wherever it is used. Needs the HQ link."""
    data = EnrollIn(data=request.data)
    data.is_valid(raise_exception=True)
    try:
        r = agent.hq_request("POST", "/api/replica/enroll-terminal", dict(data.validated_data), timeout=15)
    except agent.HQError as e:
        if e.status:
            return Response(e.body or {"error": "enrollment_failed"}, status=e.status if e.status < 500 else 502)
        return Response({"error": "hq_unreachable", "detail": "Enrolling a new till needs the link to HQ. "
                                                               "Try again when the internet is back."}, status=503)
    t = r["terminal"]
    EdgeTerminal.objects.update_or_create(code=t["code"], defaults={
        "name": t["name"], "kind": t["kind"], "is_active": True, "token_hash": sha256(r["device_token"]),
        "app_version": data.validated_data.get("app_version", "")})
    return Response(r)


# ------------------------------------------------------------------ kitchen screens

def _kds_ok(request):
    if isinstance(request.auth, EdgeTerminal):
        return
    u = request.user
    if not (isinstance(u, EdgeUser) and "kds.operate" in u.permissions):
        raise exceptions.PermissionDenied("Kitchen screen access requires an enrolled screen.")


@edge_view(["GET"])
def kds_tickets(request):
    _kds_ok(request)
    qs = EdgeTicket.objects.filter(created_at__gte=timezone.now() - timedelta(hours=12)).exclude(
        status__in=["SERVED", "VOID"])
    if station := request.query_params.get("station"):
        qs = qs.filter(station=station)
    return Response([{"id": str(t.id), "station": t.station, "order_ref": t.order_ref, "order_type": t.order_type,
                      "items": t.items, "status": t.status, "created_at": t.created_at} for t in qs[:200]])


@edge_view(["POST"])
def kds_update(request, ticket_id):
    _kds_ok(request)
    status = request.data.get("status")
    if status not in {"NEW", "PREPARING", "READY", "SERVED", "VOID"}:
        return Response({"error": "invalid", "detail": "Unknown status"}, status=400)
    with transaction.atomic():
        t = EdgeTicket.objects.select_for_update().filter(pk=ticket_id).first()
        if t is None:
            return Response({"error": "not_found"}, status=404)
        if t.status != status:
            t.status = status
            if status == "READY":
                t.ready_at = timezone.now()
            t.save(update_fields=["status", "ready_at", "updated_at"])
            synthetic_ticket_status(t, status)
    return Response({"ok": True, "status": t.status})


# ------------------------------------------------------------------ branch hub (managers)

_DUMMY = []


def _dummy_hash():
    if not _DUMMY:
        from django.contrib.auth.hashers import make_password

        _DUMMY.append(make_password(secrets.token_urlsafe(16)))
    return _DUMMY[0]


class LoginIn(serializers.Serializer):
    username = serializers.CharField(max_length=150)
    password = serializers.CharField(max_length=256, trim_whitespace=False)


def _me(u):
    cfg = EdgeConfig.get()
    return {"id": u.pk, "username": u.username, "name": u.label, "is_superuser": False,
            "permissions": sorted(u.permissions), "mode": "branch",
            "branches": [{"id": 0, "code": cfg.branch_code, "name": cfg.branch_name, "kind": ""}]}


@api_view(["POST"])
@authentication_classes([])
@permission_classes([AllowAny])
@throttle_classes([LoginThrottle])
def login(request):
    data = LoginIn(data=request.data)
    data.is_valid(raise_exception=True)
    username = data.validated_data["username"]
    state, _ = EdgeUserState.objects.get_or_create(username=username[:150])
    if state.locked_until and state.locked_until > timezone.now():
        return Response({"error": "locked", "detail": "Account temporarily locked after failed attempts."}, status=423)
    u = _hub_users().get(username)
    # same work whether or not the username exists (no user enumeration by timing)
    ok = check_password(data.validated_data["password"], u["password"] if u else _dummy_hash()) and u is not None
    if not ok:
        state.failed += 1
        if state.failed >= settings.YUMMY_MAX_FAILED_LOGINS:
            state.failed, state.locked_until = 0, timezone.now() + timedelta(minutes=settings.YUMMY_LOCKOUT_MINUTES)
        state.save()
        return Response({"error": "invalid_credentials",
                         "detail": "Wrong username or password, or this account is not a manager at this branch."},
                        status=401)
    if not (set(u["permissions"]) & HUB_PERMS):
        return Response({"error": "forbidden", "detail": "Branch managers only."}, status=403)
    state.failed, state.locked_until = 0, None
    state.save()
    raw = secrets.token_urlsafe(32)
    EdgeSession.objects.filter(expires_at__lt=timezone.now()).delete()
    EdgeSession.objects.create(key_hash=sha256(raw), user_id=u["id"], username=u["username"],
                               password_fp=sha256(u["password"]),
                               expires_at=timezone.now() + timedelta(hours=settings.YUMMY_TOKEN_TTL_HOURS))
    return Response({"token": raw, "user": _me(EdgeUser(u))})


@edge_view(["POST"], auth=(SessionAuth,))
def logout(request):
    _hub_user(request)
    if isinstance(request.auth, EdgeSession):
        request.auth.delete()
    return Response({"ok": True})


@edge_view(["GET"], auth=(SessionAuth,))
def me(request):
    return Response(_me(_hub_user(request)))


@edge_view(["GET"], auth=(SessionAuth,))
def status(request):
    _hub_user(request)
    cfg = EdgeConfig.get()
    now = timezone.now()
    today = timezone.localdate()
    start = timezone.make_aware(datetime(today.year, today.month, today.day))
    sales = EdgeSale.objects.filter(created_at__gte=start, source="local")
    by_term = {r["terminal_code"]: r for r in sales.values("terminal_code").annotate(n=Count("id"), total=Sum("total"))}
    q = EdgeOp.objects
    return Response({
        **mode_payload(),
        "hq_url": cfg.hq_url, "bundle_version": cfg.bundle_version, "bundle_at": cfg.bundle_at,
        "last_push_at": cfg.last_push_at, "last_attempt_at": cfg.last_attempt_at, "last_error": cfg.last_error,
        "queue": {"pending": q.filter(hq_status="PENDING").count(),
                  "oldest_pending_at": q.filter(hq_status="PENDING").order_by("seq").values_list("received_at", flat=True).first(),
                  "applied_today": q.filter(hq_status="APPLIED", forwarded_at__gte=start).count(),
                  "rejected_hq": q.filter(hq_status="REJECTED").count(),
                  "held": q.filter(hq_status="HELD").count(),
                  "rejected_local": q.filter(local_status="REJECTED").count()},
        "today": {"sales": sales.count(), "total": str(sales.aggregate(s=Sum("total"))["s"] or 0),
                  "refunded": str(sales.aggregate(s=Sum("refunded_total"))["s"] or 0),
                  "date": today, "ethiopian_date": format_ethiopian(today)},
        "terminals": [{"code": t.code, "name": t.name, "kind": t.kind, "enrolled": bool(t.token_hash),
                       "is_active": t.is_active, "last_seen_at": t.last_seen_at, "pending": t.reported_pending,
                       "online": bool(t.last_seen_at and (now - t.last_seen_at).total_seconds() < 120),
                       "sales_today": by_term.get(t.code, {}).get("n", 0),
                       "total_today": str(by_term.get(t.code, {}).get("total") or 0)}
                      for t in EdgeTerminal.objects.all()],
        "kitchen_open": EdgeTicket.objects.exclude(status__in=["SERVED", "VOID"]).filter(
            created_at__gte=now - timedelta(hours=12)).count(),
        "recent_sales": [_edge_sale_json(s) for s in sales[:15]],
    })


@edge_view(["GET"], auth=(SessionAuth,))
def problems(request):
    _hub_user(request)
    rows = EdgeOp.objects.filter(Q(hq_status__in=["REJECTED", "HELD"]) | Q(local_status="REJECTED")).order_by("-seq")[:200]
    out = []
    for o in rows:
        if o.hq_status == "HELD":
            where, info = "held", {"error": "held", "detail": o.last_error}
        elif o.local_status == "REJECTED":
            where, info = "branch", o.local_result
        else:
            where, info = "HQ", o.hq_result
        out.append({"op_id": str(o.op_id), "terminal": o.terminal_code, "kind": o.kind,
                    "number": o.payload.get("number", ""), "received_at": o.received_at, "where": where,
                    "error": info.get("error", ""), "detail": info.get("detail", ""), "held": o.hq_status == "HELD"})
    return Response(out)


@edge_view(["POST"], auth=(SessionAuth,))
def requeue(request, op_id):
    """Send a held operation again (e.g. after HQ fixed the cause)."""
    _hub_user(request)
    # releasing the held op releases its till's queue too (it was waiting behind it, still in order)
    n = EdgeOp.objects.filter(op_id=op_id, hq_status="HELD").update(hq_status="PENDING", attempts=0, last_error="")
    return Response({"ok": bool(n)})


@edge_view(["POST"], auth=(SessionAuth,))
def sync_now(request):
    _hub_user(request)
    return Response(agent.cycle(max_batches=2, timeout=12))  # bounded: well inside the web worker timeout


def not_here(request, *args, **kwargs):
    from django.http import JsonResponse

    return JsonResponse({"error": "hq_only", "detail": "This is a branch server. That function is on the head-office "
                                                         "server."}, status=404)
