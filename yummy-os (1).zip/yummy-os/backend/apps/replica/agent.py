"""
Branch-server sync agent: pulls master data from HQ and forwards queued till operations.

Runs as its own process (`manage.py edge_agent`). Every cycle:
  1. pull   - GET /api/replica/bundle?since=<version>; store it and refresh enrolled terminals;
  2. push   - forward PENDING operations in `seq` order, 100 at a time. APPLIED/REJECTED are final;
              RETRY stops the cycle so the order is never broken;
  3. tidy   - prune local data HQ already holds (served kitchen tickets, old forwarded operations).

Network failures only set `last_error`; nothing is lost - the queue lives in the branch database.
"""
import json
import logging
import os
import ssl
import time
import urllib.error
import urllib.request
from datetime import timedelta

from django.conf import settings
from django.db import connection, transaction
from django.utils import timezone

from .edge_apply import undo_refund
from .models import EdgeConfig, EdgeOp, EdgeSale, EdgeTerminal, EdgeTicket

log = logging.getLogger("yummy.edge")
APP_VERSION = "1.1.0"
BATCH = 100
HOLD_AFTER = 120  # consecutive RETRY answers for one operation (~10 min) before it is held for a manager
PUSH_LOCK = 7_221_002  # advisory lock: only one pusher at a time (agent process or "Sync now")


class HQError(Exception):
    def __init__(self, message, status=None, body=None):
        super().__init__(message)
        self.status, self.body = status, body


def _ssl_context():
    ctx = ssl.create_default_context()
    ca = getattr(settings, "YUMMY_HQ_CA_FILE", "") or os.environ.get("YUMMY_HQ_CA_FILE", "")
    if ca:
        ctx.load_verify_locations(cafile=ca)
    return ctx


def token(cfg=None):
    return os.environ.get("YUMMY_HQ_TOKEN") or (cfg or EdgeConfig.get()).token


def hq_request(method, path, data=None, cfg=None, timeout=15, auth=True):
    cfg = cfg or EdgeConfig.get()
    base = (cfg.hq_url or os.environ.get("YUMMY_HQ_URL", "")).rstrip("/")
    if not base:
        raise HQError("HQ address is not configured")
    if not base.startswith("https://") and not getattr(settings, "YUMMY_ALLOW_INSECURE_HQ", False):
        raise HQError("HQ address must use https:// (set YUMMY_ALLOW_INSECURE_HQ=1 only for a closed test network)")
    body = json.dumps(data).encode() if data is not None else None
    req = urllib.request.Request(base + path, data=body, method=method)
    req.add_header("Content-Type", "application/json")
    req.add_header("Accept", "application/json")
    req.add_header("User-Agent", f"yummy-branch-server/{APP_VERSION}")
    if auth:
        req.add_header("X-Branch-Server-Token", token(cfg))
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=_ssl_context() if base.startswith("https") else None) as r:
            raw = r.read()
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as e:
        raw = e.read()
        try:
            parsed = json.loads(raw)
        except ValueError:
            parsed = {"detail": raw[:200].decode(errors="replace")}
        raise HQError(f"HQ answered {e.code}: {parsed.get('detail', '')}"[:250], e.code, parsed)
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        raise HQError(f"HQ unreachable: {getattr(e, 'reason', e)}"[:250])


# ------------------------------------------------------------------ enrolment

def enroll(hq_url, server_code, enrollment_code):
    cfg = EdgeConfig.get()
    cfg.hq_url = hq_url.rstrip("/")
    r = hq_request("POST", "/api/replica/enroll", {"server_code": server_code, "enrollment_code": enrollment_code,
                                                   "app_version": APP_VERSION}, cfg=cfg, auth=False)
    cfg.token = r["server_token"]
    cfg.server_code = r["server"]["code"]
    cfg.branch_code, cfg.branch_name = r["branch"]["code"], r["branch"]["name"]
    cfg.bundle_version = ""
    cfg.save()
    pull(cfg)
    return cfg


# ------------------------------------------------------------------ pull

def pull(cfg=None, timeout=15):
    cfg = cfg or EdgeConfig.get()
    r = hq_request("GET", f"/api/replica/bundle?since={cfg.bundle_version}&v={APP_VERSION}", cfg=cfg, timeout=timeout)
    now = timezone.now()
    if r.get("unchanged"):
        EdgeConfig.objects.filter(pk=cfg.pk).update(last_contact_at=now, last_error="")
        return False
    bundle = r["bundle"]
    with transaction.atomic():
        seen = set()
        for t in bundle.get("terminals", []):
            seen.add(t["code"])
            row = EdgeTerminal.objects.filter(code=t["code"]).first() or EdgeTerminal(code=t["code"])
            row.name, row.kind, row.is_active = t["name"], t["kind"], t["is_active"]
            # HQ is the authority on device credentials; a till enrolled through this server
            # is known locally at once and confirmed here on the next pull.
            row.token_hash = t["token_hash"] if t["is_active"] else ""
            row.hq_last_receipt_seq = max(row.hq_last_receipt_seq, int(t.get("last_receipt_seq") or 0))
            row.save()
        EdgeTerminal.objects.exclude(code__in=seen).update(is_active=False, token_hash="")
        cfg.bundle, cfg.bundle_version, cfg.bundle_at = bundle, r["version"], now
        cfg.branch_code = bundle["branch"]["code"]
        cfg.branch_name = bundle["branch"]["name"]
        cfg.last_contact_at, cfg.last_error = now, ""
        cfg.save()
    return True


# ------------------------------------------------------------------ push

def push(cfg=None, max_batches=1000, timeout=60):
    """Forward queued operations. Only one pusher runs at a time (PostgreSQL advisory lock)."""
    with connection.cursor() as c:
        c.execute("SELECT pg_try_advisory_lock(%s)", [PUSH_LOCK])
        if not c.fetchone()[0]:
            return 0  # another process is already forwarding
    try:
        return _push(cfg or EdgeConfig.get(), max_batches, timeout)
    finally:
        with connection.cursor() as c:
            c.execute("SELECT pg_advisory_unlock(%s)", [PUSH_LOCK])


def _wire(o):
    d = {"op_id": str(o.op_id), "terminal": o.terminal_code, "kind": o.kind, "payload": o.payload,
         "created_at": o.client_created_at or o.received_at.isoformat()}
    if o.local_status == EdgeOp.Local.REJECTED:
        d["rejected_at_branch"] = o.local_result  # HQ records it for review and never books it
    return d


def _push(cfg, max_batches, timeout):
    sent = 0
    for _ in range(max_batches):
        # a till with a held operation waits behind it: its later operations may depend on it
        # (same shift, refunds of its sales), so only other tills keep moving
        held = list(EdgeOp.objects.filter(hq_status=EdgeOp.Hq.HELD).values_list("terminal_code", flat=True).distinct())
        batch = list(EdgeOp.objects.filter(hq_status=EdgeOp.Hq.PENDING).exclude(terminal_code__in=held)
                     .order_by("seq")[:BATCH])
        terminals = [{"code": t.code, "last_seen_at": t.last_seen_at.isoformat() if t.last_seen_at else None,
                      "pending": t.reported_pending, "app_version": t.app_version}
                     for t in EdgeTerminal.objects.exclude(last_seen_at=None)]
        pending = EdgeOp.objects.filter(hq_status=EdgeOp.Hq.PENDING).count()
        rejected = EdgeOp.objects.filter(hq_status=EdgeOp.Hq.REJECTED).count()
        r = hq_request("POST", "/api/replica/push", {
            "ops": [_wire(o) for o in batch],
            "terminals": terminals, "pending_count": pending, "rejected_count": rejected,
            "held_count": EdgeOp.objects.filter(hq_status=EdgeOp.Hq.HELD).count(),
        }, cfg=cfg, timeout=timeout)
        now = timezone.now()
        by_id = {str(o.op_id): o for o in batch}
        stop = False
        for res in r.get("results", []):
            o = by_id.get(str(res.get("op_id")))
            if o is None:
                continue
            if res.get("status") in ("APPLIED", "REJECTED"):
                with transaction.atomic():  # final status and journal correction together, or neither
                    o.hq_status = res["status"]
                    o.hq_result = {k: v for k, v in res.items() if k not in ("op_id", "status")}
                    o.forwarded_at = now
                    o.last_error = ""
                    o.save(update_fields=["hq_status", "hq_result", "forwarded_at", "last_error"])
                    if res["status"] == "REJECTED" and o.local_status == EdgeOp.Local.ACCEPTED:
                        _hq_rejected(o)
                sent += 1
            else:
                o.attempts += 1
                o.last_error = str(res.get("detail", "retry"))[:255]
                held = o.attempts >= HOLD_AFTER
                if held:  # never block the whole branch behind one till's operation: park it, other tills move on
                    o.hq_status = EdgeOp.Hq.HELD
                    log.error("edge sync: op %s (%s) held after %s retries: %s", o.op_id, o.kind, o.attempts, o.last_error)
                o.save(update_fields=["attempts", "last_error", "hq_status"])
                stop = not held
                break
        EdgeConfig.objects.filter(pk=cfg.pk).update(last_contact_at=now, last_push_at=now, last_error="")
        if stop or len(batch) < BATCH:
            return sent
    return sent


def _hq_rejected(o):
    """HQ refused something the branch had accepted: keep the branch journal truthful."""
    if o.kind == "refund":
        undo_refund(o)
    elif o.kind == "sale":
        EdgeSale.objects.filter(pk=o.payload.get("id")).delete()  # not booked: cannot be refunded or counted


# ------------------------------------------------------------------ housekeeping

def tidy(now=None):
    now = now or timezone.now()
    EdgeTicket.objects.filter(updated_at__lt=now - timedelta(days=2)).delete()
    EdgeOp.objects.filter(hq_status=EdgeOp.Hq.APPLIED, forwarded_at__lt=now - timedelta(days=30)).delete()
    # keep a rolling 60 days of receipts for refunds; HQ keeps everything
    old = EdgeSale.objects.filter(created_at__lt=now - timedelta(days=60))
    pending_ids = set(EdgeOp.objects.filter(kind="sale", hq_status=EdgeOp.Hq.PENDING).values_list("payload__id", flat=True))
    old.exclude(id__in=[i for i in pending_ids if i]).delete()


def cycle(max_batches=1000, timeout=60):
    """One pull+push round. Returns a small status dict; never raises for network problems."""
    cfg = EdgeConfig.get()
    EdgeConfig.objects.filter(pk=cfg.pk).update(last_attempt_at=timezone.now())
    if not (cfg.hq_url and token(cfg)):
        return {"ok": False, "error": "not enrolled"}
    try:
        changed = pull(cfg, timeout=min(timeout, 15))
        sent = push(EdgeConfig.get(), max_batches, timeout)
        return {"ok": True, "bundle_changed": changed, "forwarded": sent}
    except HQError as e:
        msg = str(e)
        if e.status in (401, 403):
            msg = "HQ refused this branch server's credential (revoked?). Re-enrol with a new code."
        EdgeConfig.objects.filter(pk=cfg.pk).update(last_error=msg[:255])
        log.warning("edge sync: %s", msg)
        return {"ok": False, "error": msg}


def run_forever(stop=lambda: False):
    last_tidy = 0.0
    while not stop():
        r = cycle()
        if time.time() - last_tidy > 3600:
            tidy()
            last_tidy = time.time()
        busy = EdgeOp.objects.filter(hq_status=EdgeOp.Hq.PENDING).exists()
        time.sleep(3 if (r.get("ok") and busy) else 10 if r.get("ok") else 15)
