"""
Catalogue management for the back office: products, selling prices, categories and café modifiers.

Every write is permission-checked server side (catalog.manage / price.manage) and audited.
Prices are effective-dated: a change closes the current price and opens a new one, so past
sales keep the price they were charged and terminals pick the new price up on their next sync.
"""
from django.db import transaction
from django.db.models import Max, Q
from django.shortcuts import get_object_or_404
from django.utils import timezone
from rest_framework import serializers
from rest_framework.decorators import api_view
from rest_framework.response import Response

from apps.core import audit
from apps.core.api import dec
from apps.core.money import q2
from apps.iam.permissions import require, require_user

from .models import Category, Modifier, PriceList, PriceListItem, Product, TaxRate, Unit

HEX = r"^#[0-9A-Fa-f]{6}$"


def _current_prices(product_ids):
    now = timezone.now()
    out = {}
    items = (PriceListItem.objects.filter(product_id__in=product_ids, effective_from__lte=now)
             .filter(Q(effective_to__isnull=True) | Q(effective_to__gt=now))
             .select_related("price_list").order_by("effective_from"))
    for it in items:
        out.setdefault(it.product_id, {})[it.price_list.code] = str(it.price)
    return out


def _product_json(p, prices=None):
    return {
        "id": p.pk, "sku": p.sku, "barcode": p.barcode or "", "name": p.name, "name_local": p.name_local,
        "kind": p.kind, "kind_label": p.get_kind_display(), "category_id": p.category_id,
        "category": p.category.name, "unit_id": p.unit_id, "unit": p.unit.code,
        "tax_rate_id": p.tax_rate_id, "is_sellable": p.is_sellable, "track_lots": p.track_lots,
        "shelf_life_days": p.shelf_life_days, "reorder_point": str(p.reorder_point),
        "reorder_qty": str(p.reorder_qty), "standard_cost": str(p.standard_cost), "station": p.station,
        "allergens": p.allergens, "color": p.color, "is_active": p.is_active, "version": p.version,
        "updated_at": p.updated_at, "prices": (prices or {}).get(p.pk, {}),
        "modifier_ids": [m.pk for m in p.modifiers.all()],
    }


class ProductIn(serializers.Serializer):
    sku = serializers.RegexField(r"^[A-Za-z0-9][A-Za-z0-9\-_.]{1,39}$")
    barcode = serializers.RegexField(r"^[0-9A-Za-z\-]{0,64}$", required=False, allow_blank=True)
    name = serializers.CharField(max_length=120)
    name_local = serializers.CharField(max_length=120, required=False, allow_blank=True)
    kind = serializers.ChoiceField(choices=Product.Kind.choices)
    category_id = serializers.IntegerField()
    unit_id = serializers.IntegerField()
    tax_rate_id = serializers.IntegerField(required=False, allow_null=True)
    is_sellable = serializers.BooleanField(default=False)
    track_lots = serializers.BooleanField(default=True)
    shelf_life_days = serializers.IntegerField(required=False, allow_null=True, min_value=0, max_value=3650)
    reorder_point = serializers.DecimalField(max_digits=14, decimal_places=3, min_value=0, default=0)
    reorder_qty = serializers.DecimalField(max_digits=14, decimal_places=3, min_value=0, default=0)
    station = serializers.ChoiceField(choices=Product.Station.choices, default=Product.Station.NONE)
    allergens = serializers.RegexField(r"^[a-z ,\-]{0,200}$", required=False, allow_blank=True)
    color = serializers.RegexField(HEX, required=False, allow_blank=True)
    is_active = serializers.BooleanField(default=True)

    def validate(self, d):
        if not Category.objects.filter(pk=d["category_id"]).exists():
            raise serializers.ValidationError({"category_id": "unknown category"})
        if not Unit.objects.filter(pk=d["unit_id"]).exists():
            raise serializers.ValidationError({"unit_id": "unknown unit"})
        if d.get("tax_rate_id") and not TaxRate.objects.filter(pk=d["tax_rate_id"]).exists():
            raise serializers.ValidationError({"tax_rate_id": "unknown tax rate"})
        if d["kind"] in (Product.Kind.MENU, Product.Kind.SERVICE):
            d["track_lots"] = False
        return d


def _apply_product(p, d):
    for f in ("sku", "name", "name_local", "kind", "category_id", "unit_id", "tax_rate_id", "is_sellable", "track_lots",
              "shelf_life_days", "reorder_point", "reorder_qty", "station", "allergens", "color", "is_active"):
        if f in d:
            setattr(p, f, d[f])
    if "barcode" in d:
        p.barcode = d["barcode"] or None


@api_view(["GET"])
def meta(request):
    require_user(request)
    return Response({
        "categories": [{"id": c.id, "name": c.name, "color": c.color, "sort_order": c.sort_order,
                        "parent_id": c.parent_id} for c in Category.objects.all()],
        "units": [{"id": u.id, "code": u.code, "name": u.name} for u in Unit.objects.order_by("code")],
        "tax_rates": [{"id": t.id, "code": t.code, "name": t.name, "rate": str(t.rate)}
                      for t in TaxRate.objects.filter(is_active=True)],
        "price_lists": [{"id": pl.id, "code": pl.code, "name": pl.name, "branch": pl.branch.code if pl.branch else None,
                         "tax_inclusive": pl.tax_inclusive} for pl in PriceList.objects.filter(is_active=True)
                        .select_related("branch").order_by("code")],
        "kinds": [{"value": v, "label": l} for v, l in Product.Kind.choices],
        "stations": [{"value": v, "label": l} for v, l in Product.Station.choices],
    })


@api_view(["GET", "POST"])
def products(request):
    user = require_user(request)
    if request.method == "GET":
        if not _any(user, "catalog.manage", "price.manage", "recipe.manage", "inventory.view", "production.view"):
            require(user, "catalog.manage")
        qs = Product.objects.select_related("category", "unit").prefetch_related("modifiers")
        if q := request.query_params.get("q"):
            qs = qs.filter(Q(name__icontains=q) | Q(sku__icontains=q) | Q(barcode=q) | Q(name_local__icontains=q))
        if k := request.query_params.get("kind"):
            qs = qs.filter(kind__in=k.split(","))
        if request.query_params.get("active") == "1":
            qs = qs.filter(is_active=True)
        rows = list(qs[:1000])
        prices = _current_prices([p.pk for p in rows])
        return Response([_product_json(p, prices) for p in rows])
    require(user, "catalog.manage")
    if not isinstance(request.data, dict):
        return Response({"error": "invalid", "detail": "Send an object."}, status=400)
    data = ProductIn(data=request.data)
    data.is_valid(raise_exception=True)
    d = data.validated_data
    if Product.objects.filter(sku__iexact=d["sku"]).exists():
        return Response({"error": "conflict", "detail": f"SKU {d['sku']} already exists."}, status=409)
    if d.get("barcode") and Product.objects.filter(barcode=d["barcode"]).exists():
        return Response({"error": "conflict", "detail": "That barcode is already used by another product."}, status=409)
    with transaction.atomic():
        p = Product()
        _apply_product(p, d)
        p.save()
        audit.record("catalog.product_created", actor=user, obj=p, data={"sku": p.sku, "name": p.name, "kind": p.kind})
    return Response(_product_json(Product.objects.select_related("category", "unit").get(pk=p.pk)), status=201)


def _require_price_scope(user, price_list=None):
    """Selling prices: a branch price list needs price.manage at that branch; the default list (all branches),
    VAT and add-on prices need price.manage for all branches."""
    from apps.iam.models import RoleAssignment

    if user.is_superuser:
        return
    branch = price_list.branch if price_list is not None else None
    if branch is not None:
        require(user, "price.manage", branch)
        return
    if not RoleAssignment.objects.filter(user=user, branch__isnull=True,
                                         role__permissions__contains=["price.manage"]).exists():
        from apps.core.exceptions import PermissionDeniedError

        raise PermissionDeniedError("Changing prices for all branches (or VAT / add-on prices) needs price.manage "
                                    "for all branches.")


def _any(user, *perms):
    from apps.iam.permissions import has_perm

    return any(has_perm(user, x) for x in perms)


@api_view(["PATCH"])
def product_detail(request, pid):
    user = require_user(request)
    require(user, "catalog.manage")
    if not isinstance(request.data, dict):
        return Response({"error": "invalid", "detail": "Send an object."}, status=400)
    p = get_object_or_404(Product, pk=pid)
    data = ProductIn(p, data={**_product_json(p), **request.data}, partial=False)
    data.is_valid(raise_exception=True)
    d = data.validated_data
    if d["sku"].lower() != p.sku.lower() and Product.objects.filter(sku__iexact=d["sku"]).exclude(pk=p.pk).exists():
        return Response({"error": "conflict", "detail": f"SKU {d['sku']} already exists."}, status=409)
    if d.get("barcode") and Product.objects.filter(barcode=d["barcode"]).exclude(pk=p.pk).exists():
        return Response({"error": "conflict", "detail": "That barcode is already used by another product."}, status=409)
    if d.get("tax_rate_id") != p.tax_rate_id:
        _require_price_scope(user)  # VAT changes what customers pay
    if d["kind"] != p.kind and _has_history(p):
        return Response({"error": "conflict", "detail": "The product type cannot change once it has stock or sales history."},
                        status=409)
    before = _product_json(p)
    with transaction.atomic():
        _apply_product(p, d)
        p.version += 1
        p.save()
        changed = {k: [before[k], v] for k, v in _product_json(p).items()
                   if k in before and before[k] != v and k not in ("updated_at", "version", "prices", "modifier_ids")}
        audit.record("catalog.product_updated", actor=user, obj=p, data={"sku": p.sku, "changes": changed})
    return Response(_product_json(Product.objects.select_related("category", "unit").prefetch_related("modifiers").get(pk=p.pk),
                                  _current_prices([p.pk])))


def _has_history(p):
    from apps.inventory.models import StockMovement
    from apps.pos.models import SaleLine

    return StockMovement.objects.filter(product=p).exists() or SaleLine.objects.filter(product=p).exists()


@api_view(["POST"])
def set_price(request, pid):
    """Effective now: closes the open price and starts a new one (history is kept for past receipts)."""
    user = require_user(request)
    require(user, "price.manage")
    if not isinstance(request.data, dict):
        return Response({"error": "invalid", "detail": "Send an object."}, status=400)
    p = get_object_or_404(Product, pk=pid)
    pl = get_object_or_404(PriceList, code=request.data.get("price_list"), is_active=True)
    _require_price_scope(user, pl)
    price = q2(dec(request.data, "price"))
    if price < 0 or price >= 10**9:
        return Response({"error": "invalid", "detail": "Price must be between 0 and 999,999,999.99."}, status=400)
    now = timezone.now()
    with transaction.atomic():
        Product.objects.select_for_update().filter(pk=p.pk).first()  # serialise concurrent changes
        items = PriceListItem.objects.select_for_update().filter(price_list=pl, product=p).filter(
            Q(effective_to__isnull=True) | Q(effective_to__gt=now))
        old = [str(i.price) for i in items if i.effective_from <= now]
        for it in items:
            if it.effective_from >= now:
                it.delete()  # an unused future price is superseded
            else:
                it.effective_to = now
                it.save(update_fields=["effective_to"])
        PriceListItem.objects.create(price_list=pl, product=p, price=price, effective_from=now)
        audit.record("catalog.price_changed", actor=user, obj=p,
                     data={"sku": p.sku, "price_list": pl.code, "old": old, "new": str(price)})
    return Response({"product_id": p.pk, "price_list": pl.code, "price": str(price), "effective_from": now})


@api_view(["POST"])
def remove_price(request, pid):
    """Stop selling a product on one price list from now on."""
    user = require_user(request)
    require(user, "price.manage")
    if not isinstance(request.data, dict):
        return Response({"error": "invalid", "detail": "Send an object."}, status=400)
    p = get_object_or_404(Product, pk=pid)
    pl = get_object_or_404(PriceList, code=request.data.get("price_list"))
    _require_price_scope(user, pl)
    now = timezone.now()
    with transaction.atomic():
        n = 0
        for it in PriceListItem.objects.select_for_update().filter(price_list=pl, product=p).filter(
                Q(effective_to__isnull=True) | Q(effective_to__gt=now)):
            if it.effective_from >= now:
                it.delete()
            else:
                it.effective_to = now
                it.save(update_fields=["effective_to"])
            n += 1
        audit.record("catalog.price_removed", actor=user, obj=p, data={"sku": p.sku, "price_list": pl.code})
    return Response({"ok": True, "closed": n})


class CategoryIn(serializers.Serializer):
    name = serializers.CharField(max_length=80)
    color = serializers.RegexField(HEX, default="#C8742B")
    sort_order = serializers.IntegerField(min_value=0, max_value=999, default=0)
    parent_id = serializers.IntegerField(required=False, allow_null=True)


@api_view(["POST", "PATCH"])
def category(request, cid=None):
    user = require_user(request)
    require(user, "catalog.manage")
    if not isinstance(request.data, dict):
        return Response({"error": "invalid", "detail": "Send an object."}, status=400)
    data = CategoryIn(data=request.data)
    data.is_valid(raise_exception=True)
    d = data.validated_data
    c = get_object_or_404(Category, pk=cid) if cid else Category()
    if d.get("parent_id"):
        parent = get_object_or_404(Category, pk=d["parent_id"])
        node = parent
        while node is not None:  # no cycles
            if c.pk and node.pk == c.pk:
                return Response({"error": "invalid", "detail": "A category cannot be inside itself."}, status=400)
            node = node.parent
    c.name, c.color, c.sort_order, c.parent_id = d["name"], d["color"], d["sort_order"], d.get("parent_id")
    with transaction.atomic():
        c.save()
        audit.record("catalog.category_saved", actor=user, obj=c, data={"name": c.name})
    return Response({"id": c.id, "name": c.name, "color": c.color, "sort_order": c.sort_order, "parent_id": c.parent_id},
                    status=201 if not cid else 200)


class ModifierIn(serializers.Serializer):
    name = serializers.CharField(max_length=60)
    group = serializers.CharField(max_length=40, default="Extras")
    price_delta = serializers.DecimalField(max_digits=12, decimal_places=2, min_value=0)
    ingredient_id = serializers.IntegerField(required=False, allow_null=True)
    ingredient_qty = serializers.DecimalField(max_digits=12, decimal_places=3, min_value=0, default=0)
    applies_to = serializers.ListField(child=serializers.IntegerField(), default=list, max_length=500)
    is_active = serializers.BooleanField(default=True)


def _modifier_json(m):
    return {"id": m.id, "name": m.name, "group": m.group, "price_delta": str(m.price_delta),
            "ingredient_id": m.ingredient_id, "ingredient": m.ingredient.name if m.ingredient else None,
            "ingredient_qty": str(m.ingredient_qty), "applies_to": [p.pk for p in m.applies_to.all()],
            "is_active": m.is_active}


@api_view(["GET", "POST"])
def modifiers(request):
    user = require_user(request)
    if request.method == "GET":
        return Response([_modifier_json(m) for m in Modifier.objects.select_related("ingredient")
                         .prefetch_related("applies_to").order_by("group", "name")])
    return _save_modifier(user, Modifier(), request.data, created=True)


@api_view(["PATCH"])
def modifier_detail(request, mid):
    user = require_user(request)
    return _save_modifier(user, get_object_or_404(Modifier, pk=mid), request.data)


def _save_modifier(user, m, payload, created=False):
    require(user, "catalog.manage")
    if not isinstance(payload, dict):
        return Response({"error": "invalid", "detail": "Send an object."}, status=400)
    data = ModifierIn(data=payload)
    data.is_valid(raise_exception=True)
    d = data.validated_data
    if (created and d["price_delta"]) or (not created and d["price_delta"] != m.price_delta):
        _require_price_scope(user)  # an add-on price is a selling price
    if d.get("ingredient_id"):
        ing = get_object_or_404(Product, pk=d["ingredient_id"])
        if not ing.is_stocked:
            return Response({"error": "invalid", "detail": "The ingredient must be a stocked item."}, status=400)
    targets = list(Product.objects.filter(pk__in=d["applies_to"]))
    if len(targets) != len(set(d["applies_to"])):
        return Response({"error": "invalid", "detail": "Unknown product in 'applies to'."}, status=400)
    with transaction.atomic():
        m.name, m.group, m.price_delta = d["name"], d["group"], d["price_delta"]
        m.ingredient_id, m.ingredient_qty, m.is_active = d.get("ingredient_id"), d["ingredient_qty"], d["is_active"]
        m.save()
        m.applies_to.set(targets)
        audit.record("catalog.modifier_saved", actor=user, obj=m, data={"name": m.name, "price_delta": str(m.price_delta)})
    return Response(_modifier_json(m), status=201 if created else 200)


def next_recipe_version(product):
    from apps.production.models import Recipe

    return (Recipe.objects.filter(product=product).aggregate(v=Max("version"))["v"] or 0) + 1
