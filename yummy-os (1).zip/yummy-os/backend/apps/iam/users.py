"""
People management for the back office: accounts, roles per branch, passwords and till PINs.

Guard rails (server side):
  * admin.users is required; only a superuser can create/edit superusers or grant SUPER_ADMIN.
  * nobody can deactivate themselves or remove their own admin rights;
  * passwords go through Django's validators; PINs are 4-8 digits and must be unique among
    people who share a branch (a supervisor approval is identified by PIN alone);
  * every change is written to the audit trail - without the secret values.
"""
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError as DjangoValidationError
from django.db import transaction
from django.db.models import Q
from django.shortcuts import get_object_or_404
from rest_framework import serializers
from rest_framework.decorators import api_view
from rest_framework.response import Response

from apps.core import audit
from apps.core.exceptions import BusinessRuleError, PermissionDeniedError
from apps.core.models import Branch

from .models import PERMISSIONS, ApiToken, Role, RoleAssignment, User
from .permissions import require, require_user  # noqa: E402


def _user_json(u):
    return {
        "id": u.pk, "username": u.username, "display_name": u.display_name, "name": u.label,
        "employee_code": u.employee_code, "is_active": u.is_active, "is_superuser": u.is_superuser,
        "locked": u.is_locked(), "has_pin": bool(u.pin_hash), "has_password": u.has_usable_password(),
        "last_login": u.last_login, "date_joined": u.date_joined,
        "roles": [{"role": a.role.code, "role_name": a.role.name, "branch": a.branch.code if a.branch else None}
                  for a in u.assignments.all()],
    }


class AssignmentIn(serializers.Serializer):
    role = serializers.CharField(max_length=40)
    branch = serializers.CharField(max_length=20, required=False, allow_null=True, allow_blank=True)


class UserIn(serializers.Serializer):
    username = serializers.RegexField(r"^[a-z0-9][a-z0-9._\-]{1,149}$", required=False)
    display_name = serializers.CharField(max_length=120, required=False, allow_blank=True)
    employee_code = serializers.CharField(max_length=30, required=False, allow_blank=True)
    password = serializers.CharField(max_length=256, required=False, allow_blank=True, trim_whitespace=False)
    pin = serializers.RegexField(r"^\d{4,8}$", required=False, allow_blank=True)
    clear_pin = serializers.BooleanField(required=False, default=False)
    is_active = serializers.BooleanField(required=False)
    unlock = serializers.BooleanField(required=False, default=False)
    roles = AssignmentIn(many=True, required=False)


def _resolve_roles(actor, roles):
    out = []
    for r in roles:
        role = Role.objects.filter(code=r["role"]).first()
        if role is None:
            raise BusinessRuleError(f"Unknown role {r['role']}.")
        branch = None
        if r.get("branch"):
            branch = Branch.objects.filter(code=r["branch"]).first()
            if branch is None:
                raise BusinessRuleError(f"Unknown branch {r['branch']}.")
        if role.code == "SUPER_ADMIN" and not actor.is_superuser:
            raise PermissionDeniedError("Only a super administrator can grant the Super Administrator role.")
        # an administrator can only hand out permissions they hold themselves at that scope
        if not actor.is_superuser:
            missing = set(role.permissions) - _actor_perms(actor, branch)
            if missing:
                raise PermissionDeniedError(f"You cannot grant {role.name}: you do not hold {sorted(missing)[0]}.")
        out.append((role, branch))
    if len({(r.pk, b.pk if b else None) for r, b in out}) != len(out):
        raise BusinessRuleError("The same role is listed twice for the same branch.")
    return out


def _actor_perms(actor, branch):
    """What `actor` may grant at `branch`. For an all-branches grant only the actor's all-branches roles count."""
    qs = RoleAssignment.objects.filter(user=actor).select_related("role")
    qs = qs.filter(branch__isnull=True) if branch is None else qs.filter(Q(branch__isnull=True) | Q(branch=branch))
    out = set()
    for a in qs:
        out.update(a.role.permissions)
    return out


def _require_outranks(actor, target):
    """A non-superuser may only manage someone whose every role they could have granted themselves."""
    if actor.is_superuser or actor.pk == target.pk:
        return
    if target.is_superuser:
        raise PermissionDeniedError("Only a super administrator can change a super administrator's account.")
    _resolve_roles(actor, [{"role": a.role.code, "branch": a.branch.code if a.branch else None}
                           for a in target.assignments.select_related("role", "branch")])


def _branch_scope(assignments):
    return None if any(b is None for _, b in assignments) else {b.pk for _, b in assignments}


def _pin_clash(user, pin, assignments):
    """True if another active person who shares a branch with `user` already uses this PIN."""
    branch_ids = {b.pk for _, b in assignments if b is not None}
    global_scope = any(b is None for _, b in assignments)
    others = User.objects.filter(is_active=True).exclude(pk=user.pk).exclude(pin_hash="")
    if not global_scope:
        others = others.filter(Q(assignments__branch_id__in=branch_ids) | Q(assignments__branch__isnull=True)
                               | Q(is_superuser=True)).distinct()
    return any(o.check_pin(pin) for o in others)


def _check_password(pw, user):
    try:
        validate_password(pw, user)
    except DjangoValidationError as e:
        raise BusinessRuleError(" ".join(e.messages), code="weak_password")


@api_view(["GET", "POST"])
def users(request):
    actor = require_user(request)
    require(actor, "admin.users")
    if request.method == "POST" and not isinstance(request.data, dict):
        raise BusinessRuleError("Send an object.")
    if request.method == "GET":
        qs = User.objects.prefetch_related("assignments__role", "assignments__branch").order_by("username")
        if q := request.query_params.get("q"):
            qs = qs.filter(Q(username__icontains=q) | Q(display_name__icontains=q) | Q(employee_code__icontains=q))
        return Response([_user_json(u) for u in qs[:500]])
    data = UserIn(data=request.data)
    data.is_valid(raise_exception=True)
    d = data.validated_data
    if not d.get("username"):
        raise BusinessRuleError("A username is required.")
    if User.objects.filter(username__iexact=d["username"]).exists():
        raise BusinessRuleError(f"Username {d['username']} is already taken.", code="conflict")
    assignments = _resolve_roles(actor, d.get("roles") or [])
    if not assignments:
        raise BusinessRuleError("Give the person at least one role.")
    with transaction.atomic():
        u = User(username=d["username"], display_name=d.get("display_name", ""),
                 employee_code=d.get("employee_code", ""))
        if d.get("password"):
            _check_password(d["password"], u)
            u.set_password(d["password"])
        else:
            u.set_unusable_password()  # till-only staff sign in with a PIN
        if d.get("pin"):
            if _pin_clash(u, d["pin"], assignments):
                raise BusinessRuleError("That PIN is already used by someone at the same branch. Choose another.",
                                        code="pin_in_use")
            u.set_pin(d["pin"])
        u.save()
        for role, branch in assignments:
            RoleAssignment.objects.create(user=u, role=role, branch=branch)
        audit.record("iam.user_created", actor=actor, obj=u,
                     data={"username": u.username, "roles": [[r.code, b.code if b else None] for r, b in assignments],
                           "password_set": bool(d.get("password")), "pin_set": bool(d.get("pin"))})
    return Response(_user_json(User.objects.prefetch_related("assignments__role", "assignments__branch").get(pk=u.pk)),
                    status=201)


@api_view(["PATCH"])
def user_detail(request, uid):
    actor = require_user(request)
    require(actor, "admin.users")
    u = get_object_or_404(User, pk=uid)
    _require_outranks(actor, u)
    if not isinstance(request.data, dict):
        raise BusinessRuleError("Send an object.")
    data = UserIn(data=request.data, partial=True)
    data.is_valid(raise_exception=True)
    d = data.validated_data
    changes = []
    with transaction.atomic():
        u = User.objects.select_for_update().get(pk=u.pk)
        if "display_name" in d:
            u.display_name = d["display_name"]
            changes.append("display_name")
        if "employee_code" in d:
            u.employee_code = d["employee_code"]
            changes.append("employee_code")
        reactivated = False
        if "is_active" in d and d["is_active"] != u.is_active:
            if u.pk == actor.pk and not d["is_active"]:
                raise BusinessRuleError("You cannot deactivate your own account.")
            u.is_active = d["is_active"]
            reactivated = u.is_active
            changes.append("activated" if u.is_active else "deactivated")
            if not u.is_active:
                ApiToken.objects.filter(user=u).delete()  # end open sessions immediately
        if d.get("unlock"):
            u.failed_logins, u.locked_until = 0, None
            changes.append("unlocked")
        assignments = None
        if "roles" in d:
            assignments = _resolve_roles(actor, d["roles"])
            if u.pk == actor.pk and not actor.is_superuser:
                kept = any("admin.users" in r.permissions for r, _ in assignments)
                if not kept:
                    raise BusinessRuleError("You cannot remove your own user-administration rights.")
            # never silently strip a role the actor could not have granted
            for a in u.assignments.select_related("role", "branch"):
                if (a.role, a.branch) not in assignments:
                    _resolve_roles(actor, [{"role": a.role.code, "branch": a.branch.code if a.branch else None}])
            old_scope = _branch_scope([(a.role, a.branch) for a in u.assignments.select_related("branch")])
            new_scope = _branch_scope(assignments)
            widened = new_scope is None and old_scope is not None or (
                new_scope is not None and old_scope is not None and not new_scope <= old_scope)
            if widened and u.pin_hash and not d.get("pin") and not d.get("clear_pin"):
                raise BusinessRuleError("This person has a till PIN. Give them a new PIN when adding branches, "
                                        "so it can be checked against the people already there.", code="pin_required")
            RoleAssignment.objects.filter(user=u).delete()
            for role, branch in assignments:
                RoleAssignment.objects.create(user=u, role=role, branch=branch)
            changes.append("roles")
        if reactivated and u.pin_hash and not d.get("pin") and not d.get("clear_pin"):
            raise BusinessRuleError("This person has a till PIN. Set a new PIN when re-activating them.",
                                    code="pin_required")
        if d.get("password"):
            _check_password(d["password"], u)
            u.set_password(d["password"])
            ApiToken.objects.filter(user=u).delete()
            changes.append("password_reset")
        if d.get("clear_pin"):
            u.pin_hash, u.pin_salt, u.pin_iterations = "", "", 0
            changes.append("pin_cleared")
        elif d.get("pin"):
            scope = assignments if assignments is not None else [(a.role, a.branch) for a in u.assignments.all()]
            if _pin_clash(u, d["pin"], scope):
                raise BusinessRuleError("That PIN is already used by someone at the same branch. Choose another.",
                                        code="pin_in_use")
            u.set_pin(d["pin"])
            changes.append("pin_reset")
        u.save()
        audit.record("iam.user_updated", actor=actor, obj=u, data={"username": u.username, "changes": changes,
                     "roles": [[r.code, b.code if b else None] for r, b in assignments] if assignments is not None else None})
    return Response(_user_json(User.objects.prefetch_related("assignments__role", "assignments__branch").get(pk=u.pk)))


@api_view(["GET"])
def roles(request):
    actor = require_user(request)
    require(actor, "admin.users")
    return Response({
        "roles": [{"code": r.code, "name": r.name, "permissions": r.permissions, "is_system": r.is_system}
                  for r in Role.objects.all()],
        "permissions": PERMISSIONS,
        "branches": [{"code": b.code, "name": b.name, "kind": b.kind} for b in Branch.objects.filter(is_active=True)],
    })
