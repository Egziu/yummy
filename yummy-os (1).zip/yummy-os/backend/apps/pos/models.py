import uuid

from django.conf import settings
from django.db import models
from django.db.models import Q
from django.db.models.fields.json import KT

from apps.catalog.models import Product
from apps.core.models import Branch
from apps.iam.models import Terminal


class Shift(models.Model):
    class Status(models.TextChoices):
        OPEN = "OPEN", "Open"
        CLOSED = "CLOSED", "Closed"

    id = models.UUIDField(primary_key=True, editable=False)  # generated on the terminal
    terminal = models.ForeignKey(Terminal, on_delete=models.PROTECT, related_name="shifts")
    branch = models.ForeignKey(Branch, on_delete=models.PROTECT)
    cashier = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="+")
    opened_at = models.DateTimeField()
    opening_float = models.DecimalField(max_digits=12, decimal_places=2)
    status = models.CharField(max_length=6, choices=Status.choices, default=Status.OPEN)
    closed_at = models.DateTimeField(null=True, blank=True)
    counted_cash = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    expected_cash = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    over_short = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    closed_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.PROTECT,
                                  related_name="+")
    approved_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.PROTECT,
                                    related_name="+")

    class Meta:
        ordering = ["-opened_at"]


class CashMovement(models.Model):
    class Kind(models.TextChoices):
        IN = "IN", "Cash in"
        OUT = "OUT", "Cash out / drop"

    id = models.UUIDField(primary_key=True, editable=False)
    shift = models.ForeignKey(Shift, on_delete=models.PROTECT, related_name="cash_movements")
    kind = models.CharField(max_length=3, choices=Kind.choices)
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    reason = models.CharField(max_length=120)
    at = models.DateTimeField()
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)

    class Meta:
        constraints = [models.CheckConstraint(condition=Q(amount__gt=0), name="cash_move_positive")]


class Sale(models.Model):
    class OrderType(models.TextChoices):
        RETAIL = "RETAIL", "Retail"
        DINE_IN = "DINE_IN", "Dine-in"
        TAKEAWAY = "TAKEAWAY", "Takeaway"

    id = models.UUIDField(primary_key=True, editable=False)  # client generated -> idempotent
    number = models.CharField(max_length=40, unique=True)  # receipt number printed offline
    branch = models.ForeignKey(Branch, on_delete=models.PROTECT, related_name="sales")
    terminal = models.ForeignKey(Terminal, on_delete=models.PROTECT)
    shift = models.ForeignKey(Shift, on_delete=models.PROTECT, related_name="sales")
    cashier = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="+")
    order_type = models.CharField(max_length=10, choices=OrderType.choices, default=OrderType.RETAIL)
    table_label = models.CharField(max_length=20, blank=True)
    customer_name = models.CharField(max_length=80, blank=True)
    customer_tin = models.CharField(max_length=40, blank=True)
    created_at = models.DateTimeField(db_index=True, help_text="Moment of sale on the terminal clock")
    synced_at = models.DateTimeField(auto_now_add=True)
    was_offline = models.BooleanField(default=False)
    tax_inclusive = models.BooleanField(default=True)
    gross = models.DecimalField(max_digits=14, decimal_places=2)
    discount_total = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    tax_total = models.DecimalField(max_digits=14, decimal_places=2)
    total = models.DecimalField(max_digits=14, decimal_places=2)
    cost_total = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    refunded_total = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    flags = models.JSONField(default=list, blank=True, help_text="Review flags, e.g. price differences")
    discount_approved_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True,
                                             on_delete=models.PROTECT, related_name="+")

    class Meta:
        ordering = ["-created_at"]
        indexes = [models.Index(fields=["branch", "created_at"])]
        constraints = [
            models.CheckConstraint(condition=Q(total__gte=0) & Q(tax_total__gte=0), name="sale_nonneg"),
            models.CheckConstraint(condition=Q(refunded_total__lte=models.F("total")), name="sale_refund_limit"),
        ]

    def __str__(self):
        return self.number


class SaleLine(models.Model):
    sale = models.ForeignKey(Sale, on_delete=models.CASCADE, related_name="lines")
    line_no = models.PositiveSmallIntegerField()
    product = models.ForeignKey(Product, on_delete=models.PROTECT)
    qty = models.DecimalField(max_digits=12, decimal_places=3)
    unit_price = models.DecimalField(max_digits=12, decimal_places=2)
    gross = models.DecimalField(max_digits=14, decimal_places=2)
    discount = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    tax_rate = models.DecimalField(max_digits=6, decimal_places=4)
    tax = models.DecimalField(max_digits=14, decimal_places=2)
    base = models.DecimalField(max_digits=14, decimal_places=2, help_text="Revenue excluding VAT")
    total = models.DecimalField(max_digits=14, decimal_places=2)
    cost = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    qty_refunded = models.DecimalField(max_digits=12, decimal_places=3, default=0)
    modifiers = models.JSONField(default=list, blank=True)
    note = models.CharField(max_length=160, blank=True)

    class Meta:
        unique_together = [("sale", "line_no")]
        constraints = [
            models.CheckConstraint(condition=Q(qty__gt=0), name="sl_qty_positive"),
            models.CheckConstraint(condition=Q(qty_refunded__gte=0) & Q(qty_refunded__lte=models.F("qty")),
                                   name="sl_refund_within_qty"),
        ]


class Payment(models.Model):
    class Method(models.TextChoices):
        CASH = "CASH", "Cash"
        TELEBIRR = "TELEBIRR", "telebirr"
        CBE_BIRR = "CBE_BIRR", "CBE Birr"
        BANK_TRANSFER = "BANK_TRANSFER", "Bank transfer"
        CARD = "CARD", "Card"
        CREDIT = "CREDIT", "Customer credit"

    sale = models.ForeignKey(Sale, on_delete=models.CASCADE, related_name="payments")
    method = models.CharField(max_length=14, choices=Method.choices)
    amount = models.DecimalField(max_digits=14, decimal_places=2, help_text="Amount applied to the sale")
    tendered = models.DecimalField(max_digits=14, decimal_places=2, null=True, blank=True)
    reference = models.CharField(max_length=80, blank=True)

    class Meta:
        constraints = [models.CheckConstraint(condition=Q(amount__gt=0), name="payment_amount_positive")]


class Refund(models.Model):
    id = models.UUIDField(primary_key=True, editable=False)
    number = models.CharField(max_length=40, unique=True)
    sale = models.ForeignKey(Sale, on_delete=models.PROTECT, related_name="refunds")
    shift = models.ForeignKey(Shift, on_delete=models.PROTECT, related_name="refunds")
    created_at = models.DateTimeField()
    cashier = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="+")
    approved_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="+")
    reason = models.CharField(max_length=160)
    method = models.CharField(max_length=14, choices=Payment.Method.choices, default=Payment.Method.CASH)
    amount = models.DecimalField(max_digits=14, decimal_places=2)
    tax = models.DecimalField(max_digits=14, decimal_places=2)
    restock = models.BooleanField(default=False)
    lines = models.JSONField(default=list)


class KitchenTicket(models.Model):
    class Status(models.TextChoices):
        NEW = "NEW", "New"
        PREPARING = "PREPARING", "Preparing"
        READY = "READY", "Ready"
        SERVED = "SERVED", "Served"
        VOID = "VOID", "Voided"

    id = models.UUIDField(primary_key=True, editable=False)
    branch = models.ForeignKey(Branch, on_delete=models.PROTECT)
    terminal = models.ForeignKey(Terminal, on_delete=models.PROTECT)
    station = models.CharField(max_length=10)
    order_ref = models.CharField(max_length=40, help_text="Table or tab label")
    order_type = models.CharField(max_length=10, default="DINE_IN")
    items = models.JSONField(default=list)
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.NEW)
    created_at = models.DateTimeField()
    updated_at = models.DateTimeField(auto_now=True)
    ready_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["created_at"]


class SyncOperation(models.Model):
    """Idempotency ledger: each terminal operation is applied exactly once."""

    class Status(models.TextChoices):
        APPLIED = "APPLIED", "Applied"
        REJECTED = "REJECTED", "Rejected (needs review)"

    op_id = models.UUIDField(primary_key=True)
    terminal = models.ForeignKey(Terminal, on_delete=models.PROTECT, related_name="operations")
    kind = models.CharField(max_length=20)
    status = models.CharField(max_length=10, choices=Status.choices)
    result = models.JSONField(default=dict)
    payload = models.JSONField(default=dict)
    client_created_at = models.DateTimeField()
    received_at = models.DateTimeField(auto_now_add=True)
    resolved_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.PROTECT)
    resolution_note = models.CharField(max_length=255, blank=True)

    class Meta:
        ordering = ["-received_at"]
        indexes = [  # small partial indexes for "was the operation that creates this rejected?" look-ups
            models.Index(KT("payload__shift_id"), "kind", name="syncop_rej_shift",
                         condition=Q(status="REJECTED")),
            models.Index(KT("payload__id"), "kind", name="syncop_rej_id", condition=Q(status="REJECTED")),
        ]


def new_uuid():
    return uuid.uuid4()
